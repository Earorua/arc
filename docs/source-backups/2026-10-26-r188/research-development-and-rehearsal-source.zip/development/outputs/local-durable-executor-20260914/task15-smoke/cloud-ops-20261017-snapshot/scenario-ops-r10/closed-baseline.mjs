// New paired stores are current; the accepted U9 failure remains historical.
import {FIXED} from './guards.mjs';
import {loadPairedCurrent} from '../../../../local-durable-executor-20261026/successor-r185/current-baseline.mjs';
export function loadCurrentClosed(inputs){return loadPairedCurrent({...inputs,acceptanceReference:FIXED.currentClosedAcceptance});}
