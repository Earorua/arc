// Planning rules only. Callers bind real evidence, persisted clocks and current time.
import {assertCompletionScope, NATIVE_FRESHNESS_MS} from './contracts.mjs';
import {STAGE_PLAN,PROFILE_TOTAL_MS,SHUTDOWN_FIXED_MS} from './profile.mjs';

export const STAGES = STAGE_PLAN;
export const LIMITS = Object.freeze({observerRows:256,totalMs:PROFILE_TOTAL_MS,freshnessMs:NATIVE_FRESHNESS_MS,executionMs:1260000,quietMs:1170000,collectorMs:720000,childMs:45000,shutdownFixedMs:SHUTDOWN_FIXED_MS});

function integer(value, name) {
  if (!Number.isSafeInteger(value) || value < 0) throw new TypeError(`${name}: nonnegative safe integer required`);
  return value;
}
function add(a, b) {
  if (a > Number.MAX_SAFE_INTEGER - b) throw new RangeError('integer overflow');
  return a + b;
}
function boolean(value, name) {
  if (typeof value !== 'boolean') throw new TypeError(`${name}: boolean required`);
}
function past(value, now, name) {
  integer(value, name);
  if (value > now) throw new RangeError(`${name}: future clock`);
}
function decision(reasons, fields = {}) {
  return Object.freeze({...fields, canAdvance: reasons.length === 0,
    disposition: reasons.length ? 'stop-new-admission/incomplete' : 'within-planning-bounds',
    maintenanceOffApproved: false, evidenceProvenanceVerified: false, reasons: Object.freeze(reasons)});
}

export function observerNeed({remainingMs, unmatchedStarts}) {
  integer(remainingMs, 'remainingMs'); integer(unmatchedStarts, 'unmatchedStarts');
  // Integer arithmetic also preserves ceil at the largest safe input values.
  const need = 2n * ((BigInt(remainingMs) + 59_999n) / 60_000n) + BigInt(unmatchedStarts) + 18n;
  if (need > BigInt(Number.MAX_SAFE_INTEGER)) throw new RangeError('integer overflow');
  return Number(need);
}

export function shutdownNeed({now, latestExecutionExpiresAt, unmatchedStarts, prospectiveStart}) {
  integer(now, 'now'); integer(unmatchedStarts, 'unmatchedStarts'); boolean(prospectiveStart, 'prospectiveStart');
  if (latestExecutionExpiresAt !== null) integer(latestExecutionExpiresAt, 'latestExecutionExpiresAt');
  const actualRemaining = latestExecutionExpiresAt === null ? 0 : Math.max(0, latestExecutionExpiresAt - now);
  const executionRemaining = Math.max(actualRemaining, prospectiveStart ? LIMITS.executionMs : 0);
  return observerNeed({remainingMs: add(executionRemaining, LIMITS.shutdownFixedMs), unmatchedStarts});
}

function stageWindow({now, activationStartedAt, stage, stageStartedAt}) {
  integer(now, 'now'); past(activationStartedAt, now, 'activation clock'); past(stageStartedAt, now, 'stage clock');
  const index = STAGES.findIndex(item => item.stage === stage);
  if (index < 0) throw new TypeError('unknown stage');
  if (stageStartedAt < activationStartedAt || (stage === 'activation' && stageStartedAt !== activationStartedAt)) {
    throw new RangeError('inconsistent activation/stage clock');
  }
  const cumulativeStageMs = STAGES.slice(0, index + 1).reduce((sum, item) => sum + item.durationMs, 0);
  const stageCutoffAt = add(stageStartedAt, STAGES[index].durationMs);
  const cumulativeStageCutoffAt = add(activationStartedAt, cumulativeStageMs);
  const cumulativeCutoffAt = add(activationStartedAt, LIMITS.totalMs);
  const operationDeadlineAt = Math.min(stageCutoffAt, cumulativeStageCutoffAt, cumulativeCutoffAt);
  const remainingStageMs = Math.max(0, operationDeadlineAt - now);
  const remainingPlannedMs = add(remainingStageMs, LIMITS.totalMs - cumulativeStageMs);
  const reasons = [];
  if (now >= stageCutoffAt) reasons.push('stage-cutoff');
  if (now >= cumulativeStageCutoffAt) reasons.push('cumulative-stage-cutoff');
  if (now >= cumulativeCutoffAt) reasons.push('cumulative-cutoff');
  return {stageCutoffAt, cumulativeStageCutoffAt, cumulativeCutoffAt, operationDeadlineAt,
    remainingStageMs, remainingPlannedMs, reasons};
}

function replayExpiry({now, earliestPackageExpiresAt, remainingReplayMs}) {
  integer(remainingReplayMs, 'remainingReplayMs');
  const replayEndsAt = add(now, remainingReplayMs);
  if (earliestPackageExpiresAt === null) {
    if (remainingReplayMs !== 0) throw new TypeError('package expiry required for replay');
    return {replayEndsAt, expiresTooSoon: false};
  }
  integer(earliestPackageExpiresAt, 'earliestPackageExpiresAt');
  return {replayEndsAt, expiresTooSoon: earliestPackageExpiresAt <= replayEndsAt};
}

function closedProofShape({proof, expectedExecutorVersion, now, activationStartedAt, stage, stageStartedAt, prospectiveStart}) {
  if (!proof || typeof proof !== 'object' || Array.isArray(proof)) throw new TypeError('maintenance-close proof record required');
  const hash = /^[a-f0-9]{64}$/u;
  const version = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/u;
  if (typeof expectedExecutorVersion !== 'string' || !version.test(expectedExecutorVersion)
    || proof.executorVersion !== expectedExecutorVersion) throw new TypeError('maintenance-close version mismatch');
  if (typeof proof.closeResultSha256 !== 'string' || !hash.test(proof.closeResultSha256)
    || typeof proof.nativeEvidenceSha256 !== 'string' || !hash.test(proof.nativeEvidenceSha256)) throw new TypeError('maintenance-close proof hashes required');
  if (proof.admission !== 'false' || proof.maintenance !== 'false'
    || !Array.isArray(proof.crons) || proof.crons.length !== 0) throw new TypeError('maintenance-close flags required');
  for (const key of ['closeEndedAt', 'nativeStartedAt', 'nativeEndedAt']) past(proof[key], now, key);
  if (proof.closeEndedAt < activationStartedAt) throw new RangeError('maintenance-close precedes current activation');
  if (proof.closeEndedAt > proof.nativeStartedAt || proof.nativeStartedAt > proof.nativeEndedAt) throw new RangeError('maintenance-close proof clock order');
  if (!assertCompletionScope(proof.scope).safeToClose) throw new TypeError('maintenance-close scope must be settled');
  if (prospectiveStart) throw new TypeError('prospectiveStart after maintenance-close');
  if (stage === 'propagation' && stageStartedAt !== proof.closeEndedAt) throw new RangeError('propagation must start at actual close end');
  if (stage === 'drain' && stageStartedAt < add(proof.closeEndedAt, 931_000)) throw new RangeError('drain before actual propagation horizon');
}

export function checkHandoff({now, activationStartedAt, stage, stageStartedAt, rowsUsed, unmatchedStarts,
  latestExecutionExpiresAt, prospectiveStart, earliestPackageExpiresAt, remainingReplayMs,
  nativeMaintenanceClosedProof, expectedExecutorVersion}) {
  integer(rowsUsed, 'rowsUsed'); integer(unmatchedStarts, 'unmatchedStarts');
  if (rowsUsed > LIMITS.observerRows) throw new RangeError('rowsUsed exceeds fixed cap');
  if (unmatchedStarts > rowsUsed) throw new RangeError('unmatchedStarts exceeds stored rows');
  const {reasons, ...window} = stageWindow({now, activationStartedAt, stage, stageStartedAt});
  const plannedNeed = observerNeed({remainingMs: window.remainingPlannedMs, unmatchedStarts});
  const shutdownRows = shutdownNeed({now, latestExecutionExpiresAt, unmatchedStarts, prospectiveStart});
  const afterClose = stage === 'propagation' || stage === 'drain';
  if (afterClose) {
    if (nativeMaintenanceClosedProof === undefined) reasons.push('maintenance-close-proof-required');
    else closedProofShape({proof: nativeMaintenanceClosedProof, expectedExecutorVersion, now, activationStartedAt, stage, stageStartedAt, prospectiveStart});
  }
  const requiredRows = afterClose && nativeMaintenanceClosedProof !== undefined ? plannedNeed : Math.max(plannedNeed, shutdownRows);
  const rowsRemaining = LIMITS.observerRows - rowsUsed;
  if (rowsRemaining < requiredRows) reasons.push('observer-capacity');
  const expiry = replayExpiry({now, earliestPackageExpiresAt, remainingReplayMs});
  if (expiry.expiresTooSoon) reasons.push('package-expiry');
  const maxOperationMs = reasons.length ? 0 : Math.min(LIMITS.collectorMs, window.remainingStageMs);
  return decision(reasons, {...window, plannedNeed, shutdownNeed: shutdownRows, requiredRows, rowsRemaining,
    maxOperationMs, maxChildMs: Math.min(LIMITS.childMs, maxOperationMs),
    cloudContactAllowed: stage !== 'quiet', replayEndsAt: expiry.replayEndsAt});
}

export function checkTemporal({now, originalClocks, currentClocks, anchorStartedAt,
  nativeStartedAt, nativeEndedAt, evaluatedAt, readinessStartedAt}) {
  integer(now, 'now');
  for (const key of ['activationStartedAt', 'stage', 'stageStartedAt']) {
    if (!originalClocks || !currentClocks || originalClocks[key] !== currentClocks[key]) {
      throw new TypeError('original clocks changed');
    }
  }
  const {activationStartedAt, stage, stageStartedAt} = originalClocks;
  const {reasons} = stageWindow({now, activationStartedAt, stage, stageStartedAt});
  for (const [name, value] of Object.entries({anchorStartedAt, nativeStartedAt, nativeEndedAt, evaluatedAt, readinessStartedAt})) {
    past(value, now, name);
  }
  if (nativeEndedAt < nativeStartedAt || evaluatedAt < nativeEndedAt) throw new RangeError('inconsistent native/evaluation clock');
  const nativeAgeMs = now - nativeStartedAt;
  const readinessAgeMs = now - readinessStartedAt;
  if (nativeAgeMs >= LIMITS.freshnessMs) reasons.push('stale-native');
  if (readinessAgeMs >= LIMITS.freshnessMs) reasons.push('stale-readiness');
  return decision(reasons, {anchorAgeMs: now - anchorStartedAt, nativeAgeMs, readinessAgeMs});
}

export function checkQuiet({now, clientExitedAt, lastCloudContactAt, contactRequested}) {
  integer(now, 'now'); past(clientExitedAt, now, 'clientExitedAt'); boolean(contactRequested, 'contactRequested');
  if (lastCloudContactAt !== null) past(lastCloudContactAt, now, 'lastCloudContactAt');
  const quietBasisAt = Math.max(clientExitedAt, lastCloudContactAt ?? clientExitedAt);
  const quietEndsAt = add(quietBasisAt, LIMITS.quietMs);
  const reasons = [];
  if (now < quietEndsAt) reasons.push('quiet-incomplete');
  if (contactRequested) reasons.push('quiet-cloud-contact');
  return decision(reasons, {quietBasisAt, quietEndsAt, cloudContactAllowed: false});
}

export function checkReplayTimes({now, original, bound, earliestPackageExpiresAt, remainingReplayMs}) {
  integer(now, 'now');
  for (const key of ['acceptedAt', 'beganAt', 'executionExpiresAt']) {
    if (!original || !bound || original[key] !== bound[key]) throw new TypeError('original replay times changed');
    integer(original[key], key);
  }
  past(original.acceptedAt, now, 'acceptedAt'); past(original.beganAt, now, 'beganAt');
  if (original.executionExpiresAt !== add(original.beganAt, LIMITS.executionMs)) throw new RangeError('invalid original execution grant');
  if (earliestPackageExpiresAt === null) throw new TypeError('package expiry required for replay');
  const {replayEndsAt, expiresTooSoon} = replayExpiry({now, earliestPackageExpiresAt, remainingReplayMs});
  return decision(expiresTooSoon ? ['package-expiry'] : [], {replayEndsAt});
}
