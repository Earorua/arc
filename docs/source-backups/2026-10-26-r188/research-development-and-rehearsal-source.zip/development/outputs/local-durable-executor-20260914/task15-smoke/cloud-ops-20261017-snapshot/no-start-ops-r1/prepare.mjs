// Local only. Root invokes successful preparation once, after independent reviews.
import assert from 'node:assert/strict';
import {existsSync,mkdirSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {loadAcceptedInputs,loadReviews,fastReverify,ANCHORS,main} from './context.mjs';
import {OPERATION,ACCOUNT,preparationPath,serialize,hash,utc,oldVersions} from './rules.mjs';
import {readConfig} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/mapping.mjs';
export function buildPreparation(ctx,preparedAt){
 utc(preparedAt);const files=[],emptyConfigs={};
 for(const role of ['site','executor']){const path=join(preparationPath,'wrangler.'+role+'.empty.json'),bytes=serialize(readConfig(role,ctx.configs[role]));emptyConfigs[role]={path,sha256:hash(bytes)};files.push({path,bytes});}
 const record={schemaVersion:'arc-snapshot-no-start-preparation-v1',operationId:OPERATION,status:'LOCAL_PREPARATION_ONLY',preparedAt,accountId:ACCOUNT,plan:ANCHORS.plan,materialization:ANCHORS.materialization,runtimePins:ctx.runtimePins,inputPins:ctx.inputPins,testPins:ctx.testPins,reviews:ctx.reviewReferences,entries:ctx.entries,oldVersions,emptyConfigs,newWorkflowId:null,rootAcceptanceCreated:false,cloudReads:0,cloudMutations:0,workerControlCalls:0,providerCalls:0,schemaWrites:0,task15Accepted:false};
 files.push({path:join(preparationPath,'preparation.json'),bytes:serialize(record)});return {record,files};
}
export async function run(argv){
 assert.ok(Array.isArray(argv)&&argv.length===0,'NO_ARGUMENTS_ACCEPTED');assert.equal(existsSync(preparationPath),false,'EXCLUSIVE_PREPARATION');
 const ctx=await loadAcceptedInputs(),reviews=loadReviews(ctx),built=buildPreparation({...ctx,...reviews},new Date().toISOString());fastReverify(ctx,[...Object.values(reviews.reviewReferences),...reviews.testPins]);
 mkdirSync(preparationPath);for(const file of built.files)writeFileSync(file.path,file.bytes,{flag:'wx'});
 return {status:'LOCAL_PREPARATION_ONLY',path:preparationPath,rootAcceptanceCreated:false,cloudCalls:0};
}
await main(import.meta.url,run);
