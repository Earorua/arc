import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readdirSync,mkdtempSync,mkdirSync,writeFileSync,rmSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {moduleFor,required,N,O,W,acceptance,originals,finalConfigs,clone,hash,fakeRef,baseline,uuid} from './offline-fixtures.mjs';
const c=await moduleFor('context'),prep=await moduleFor('prepare'),project=await moduleFor('project');
test('fixed output directory requires exactly four or six ordinary members',()=>{
 const dir=mkdtempSync(join(N,'offline-membership-'));try{for(const name of ['a','b','c','d'])writeFileSync(join(dir,name),'offline');required(c,'exactDirectory')(dir,['a','b','c','d']);writeFileSync(join(dir,'extra'),'offline');assert.throws(()=>c.exactDirectory(dir,['a','b','c','d']));}finally{rmSync(dir,{recursive:true});}
});
test('hash pins detect changed local input bytes',()=>{const dir=mkdtempSync(join(N,'offline-pins-')),p=join(dir,'input');try{writeFileSync(p,'original');const ref={path:p,sha256:hash('original')};required(c,'verify')(ref);writeFileSync(p,'changed');assert.throws(()=>c.verify(ref));}finally{rmSync(dir,{recursive:true});}});
test('current exact materialized transform is verified independently of historical output absence',()=>{
 for(const role of ['site','executor'])required(c,'assertFinalConfig')(role,originals[role],finalConfigs[role],acceptance.entries[role]);
 for(const role of ['site','executor']){const altered=clone(finalConfigs[role]);altered.vars.EXTRA='value';assert.throws(()=>c.assertFinalConfig(role,originals[role],altered,acceptance.entries[role]));}
});
test('accepted materialization and operation plan are immutable fixed anchors',()=>{required(c,'assertFixedAnchors')();assert.equal(c.ANCHORS.materialization.sha256,'d7534ebf3e26f4aedbc14328efdeb53bf93e147bc5d48b99038262e868877e1c');assert.equal(c.ANCHORS.plan.sha256,'710d819fd238438e33730fe3fc4e3bd5f6b41bc093e14749d89bd006226f401f');});
test('preparation builds two fixed independent empty database configs, without an acceptance',()=>{
 const local={entries:acceptance.entries,configs:finalConfigs,runtimePins:[fakeRef('runtime')],inputPins:[fakeRef('input')],testPins:[fakeRef('test')],base:{state:{versions:baseline.versions}},reviewReferences:{spec:fakeRef('spec'),quality:fakeRef('quality')}};
 const out=required(prep,'buildPreparation')(local,'2026-10-17T08:00:00.000Z');assert.equal(out.files.length,3);assert.equal(out.record.status,'LOCAL_PREPARATION_ONLY');assert.equal(out.record.rootAcceptanceCreated,false);assert.deepEqual(Object.keys(out.record.emptyConfigs),['site','executor']);assert.equal(out.record.newWorkflowId,null);
 for(const role of ['site','executor']){const value=JSON.parse(out.files.find(f=>f.path.endsWith('wrangler.'+role+'.empty.json')).bytes);assert.equal(value.d1_databases[0].database_id,acceptance.resources[role==='site'?'siteD1':'executorD1'].id);assert.equal(value.vars,undefined);assert.equal(value.main,undefined);}
});
test('invalid CLI arguments refuse before directory creation or graph loading',async()=>{
 const before=readdirSync(N).sort();for(const [name,args]of [['prepare',['invalid']],['collect',[]],['collect',['paired','override']],['deploy',[]],['deploy',['anything','0'.repeat(64)]]]){const mod=await moduleFor(name);await assert.rejects(required(mod,'run')(args));}assert.deepEqual(readdirSync(N).sort(),before);
});
test('no root acceptance means valid collection also refuses before output',async()=>{assert.equal(existsSync(join(N,'root-tooling-acceptance-r1.json')),false);const mod=await moduleFor('collect');await assert.rejects(required(mod,'run')(['pre-first']));assert.equal(existsSync(join(N,'observations')),false);});
test('new export gate checks actual repaired Site artifact and rejects extra modules',()=>{
 const dir=mkdtempSync(join(N,'offline-export-')),target=join(dir,finalConfigs.site.name);mkdirSync(join(target,'src'),{recursive:true});
 try{const raw={name:finalConfigs.site.name,main:'src/index.js',workers_dev:true,preview_urls:false,compatibility_date:finalConfigs.site.compatibility_date,vars:finalConfigs.site.vars,services:finalConfigs.site.services,d1_databases:finalConfigs.site.d1_databases.map(({binding,database_id})=>({binding,database_id}))};writeFileSync(join(target,'wrangler.jsonc'),JSON.stringify(raw));writeFileSync(join(target,'src/index.js'),readFileSync(acceptance.entries.site.artifact.path));const value=required(project,'projectExport')(dir,'site',finalConfigs.site);assert.equal(value.entrySha256,acceptance.entries.site.artifact.sha256);assert.equal(value.projection.vars.ARC_AI_IP_HASH_SALT,undefined);writeFileSync(join(target,'src/extra.js'),'extra');assert.throws(()=>project.projectExport(dir,'site',finalConfigs.site));}finally{rmSync(dir,{recursive:true});}
});
test('plain secret types prevent export gate',()=>{const raw={id:uuid(900),resources:{bindings:[]}};assert.throws(()=>required(project,'projectVersion')(JSON.stringify(raw),'site',uuid(900),finalConfigs.site));});
