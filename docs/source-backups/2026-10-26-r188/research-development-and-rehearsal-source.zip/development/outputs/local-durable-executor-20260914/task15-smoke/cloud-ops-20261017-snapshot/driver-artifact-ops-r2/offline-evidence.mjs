// Test-only capability guard and observed import inventory; no filesystem monkey patches.
import fs from 'node:fs';
import http from 'node:http';import https from 'node:https';import net from 'node:net';import tls from 'node:tls';import dgram from 'node:dgram';import childProcess from 'node:child_process';
import {registerHooks,syncBuiltinESMExports}from 'node:module';import {fileURLToPath}from 'node:url';import {resolve,relative,dirname,sep}from 'node:path';
import {WORKSPACE,OPS,sha256}from './accepted-bytes.mjs';
const local=p=>relative(WORKSPACE,resolve(p)).split(sep).join('/');
export function installOfflineGuard(){
 const counts={networkCalls:0,deniedChildren:0,compilerChildren:0},loaded=new Set(),metadata=new Set(),restores=[];
 const compiler=resolve(WORKSPACE,'node_modules/@esbuild/win32-x64/esbuild.exe');const compilerSha256=sha256(fs.readFileSync(compiler));
 function remember(path){
  const p=resolve(path),rel=local(p);if(rel.startsWith('../')||rel.includes(':'))throw Error('OFFLINE_IMPORT_OUTSIDE_WORKSPACE');loaded.add(p);
  for(let dir=dirname(p);dir.startsWith(WORKSPACE);dir=dirname(dir)){
   for(const name of ['package.json','tsconfig.json']){const candidate=resolve(dir,name);if(fs.existsSync(candidate)&&fs.statSync(candidate).isFile())metadata.add(candidate);}
   if(dir===WORKSPACE)break;
  }
 }
 const patch=(object,key,replacement)=>{const old=object[key];object[key]=replacement;restores.push(()=>object[key]=old);return old;};
 const denyNetwork=()=>{counts.networkCalls++;throw Error('OFFLINE_NETWORK_DENIED');};
 patch(globalThis,'fetch',denyNetwork);if(globalThis.WebSocket)patch(globalThis,'WebSocket',denyNetwork);
 for(const [object,names]of [[http,['request','get']],[https,['request','get']],[net,['connect','createConnection']],[net.Socket.prototype,['connect']],[tls,['connect']],[dgram,['createSocket']]])for(const name of names)patch(object,name,denyNetwork);
 const nativeSpawn=childProcess.spawn;
 patch(childProcess,'spawn',(command,args,options)=>{
  if(resolve(command)!==compiler||!Array.isArray(args)||args.length!==2||args[0]!=='--service=0.28.0'||args[1]!=='--ping'||options?.shell||sha256(fs.readFileSync(compiler))!==compilerSha256){counts.deniedChildren++;throw Error('OFFLINE_CHILD_DENIED');}
  counts.compilerChildren++;return nativeSpawn(command,args,options);
 });
 for(const name of ['spawnSync','exec','execSync','execFile','execFileSync','fork'])patch(childProcess,name,()=>{counts.deniedChildren++;throw Error('OFFLINE_CHILD_DENIED');});
 syncBuiltinESMExports();
 const hooks=registerHooks({resolve(specifier,context,next){const result=next(specifier,context);if(result.url.startsWith('file:'))remember(fileURLToPath(result.url));return result;},load(url,context,next){if(url.startsWith('file:'))remember(fileURLToPath(url));return next(url,context);}});
 for(const name of ['offline-evidence.mjs','driver-offline.test.mjs','accepted-bytes.mjs','assemble.mjs','review-gate.mjs'])remember(resolve(WORKSPACE,OPS,name));
 remember(compiler);metadata.add(resolve(WORKSPACE,'node_modules/@esbuild/win32-x64/package.json'));
 return {counts,
  dependencies(){
   const refs=paths=>[...paths].sort().map(path=>({path:local(path),sha256:sha256(fs.readFileSync(path))}));
   return {scope:'Observed imports plus package/TypeScript metadata; builtins supplied by the recorded Node runtime',nodeVersion:process.version,files:refs(loaded),metadata:refs(metadata),compiler:{path:local(compiler),sha256:compilerSha256}};
  },
  async close(){try{const esbuild=await import('esbuild');esbuild.stop();}finally{hooks.deregister();for(const restore of restores.reverse())restore();syncBuiltinESMExports();}}
 };
}
