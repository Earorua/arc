// Snapshot-only identity, evidence and dispatch pins. No child or network side effects.
import {readFileSync,writeFileSync,existsSync,lstatSync,realpathSync,readdirSync} from 'node:fs';
import {readFile,lstat,realpath} from 'node:fs/promises';
import {resolve,dirname,relative,isAbsolute} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {performance} from 'node:perf_hooks';
import {runtimeInventory,runtimeNames} from './runtime-closure.mjs';
import {assertChildRuntimeStructure} from './child-runtime.mjs';
import {NATIVE_LOCAL_CEILING_MS} from './timing-policy.mjs';
export const here=import.meta.dirname,root=resolve(here,'../../../../..'),G=resolve(here,'..');
export const hash=x=>createHash('sha256').update(x).digest('hex'),same=isDeepStrictEqual;
export const assert=(ok,code)=>{if(!ok)throw Error(code);};
export const integer=x=>Number.isSafeInteger(x)&&x>=0,digest=x=>typeof x==='string'&&/^[a-f0-9]{64}$/u.test(x),uuid=x=>typeof x==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u.test(x);
export function utc(x){assert(typeof x==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(x)&&integer(Date.parse(x))&&new Date(Date.parse(x)).toISOString()===x,'EXACT_UTC_TIME');return Date.parse(x);}
export function local(p){assert(typeof p==='string','LOCAL_PATH');const path=resolve(root,p),r=relative(root,path);assert(r!==''&&!r.startsWith('..')&&!isAbsolute(r),'WORKSPACE_PATH');return path;}
export function inputReference(value,sha256){assert(typeof value==='string'&&digest(sha256),'PINNED_INPUT_REFERENCE');const path=resolve(value),r=relative(here,path);assert(r&&!r.startsWith('..')&&!isAbsolute(r)&&path.endsWith('.json'),'FIXED_SCENARIO_INPUT_SCOPE');return {path,sha256};}
export function verify(r){assert(r&&typeof r.path==='string'&&digest(r.sha256),'EXACT_FILE_REFERENCE');const path=resolve(root,r.path),stat=lstatSync(path);assert(stat.isFile()&&!stat.isSymbolicLink()&&realpathSync.native(path)===path,'ORDINARY_PINNED_FILE');const bytes=readFileSync(path);assert(hash(bytes)===r.sha256,'HASH_CHANGED');return bytes;}
export const ref=p=>{const path=resolve(root,p);return {path,sha256:hash(readFileSync(path))};},jsonRef=r=>JSON.parse(verify(r).toString('utf8').replace(/^\uFEFF/u,''));
export function write(p,v){const path=resolve(p),r=relative(here,path);assert(r&&!r.startsWith('..')&&!isAbsolute(r),'NEW_SCENARIO_OUTPUT_ONLY');writeFileSync(path,JSON.stringify(v,null,2)+'\n',{flag:'wx'});return ref(path);}
const pin=(path,sha256)=>Object.freeze({path:resolve(root,path),sha256});
const code='outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261005-replay/long-followup-preparation-r1/r2-preparation/';
export const FIXED=frozen({
 sequence:'20261026-snapshot-r8',epoch:'20261017-snapshot',accountId:'54eaadb89014252836694203c1e22546',
 continuationPlan:pin('docs/superpowers/plans/2026-10-17-arc-v8-snapshot-scenario-continuation.md','5e050612db84afc24998287a39ec54110c0488286429473754b133315577d98d'),
 schemaAcceptance:pin(resolve(G,'root-schema-initialization-acceptance-r1.json'),'35d07ffeb78ebe25030c6d038fb9a1c78c395b4e82663717cba533833784b584'),
 currentClosedAcceptance:pin('outputs/local-durable-executor-20261026/paired-store-r184/root-rebind-acceptance.json','d6ee9f6c9c0a74cfbb40756e23e78a60d7a6541eb12e60bf01042a1cb52e0ab8'),
 task1:pin(resolve(G,'root-driver-artifact-materialization-acceptance-r1.json'),'a24416ce7e0424c7d1226fbae396a42fa16a6d9b78e4c5f6aad7e6bcc0d76919'),
 inventory:pin(resolve(here,'isolation-inventory.json'),'8bc5dc630defb3563a09b2067d08f71d38e8180bc97e017d09264f75cff1b2e2'),
 report:pin(resolve(G,'../build/cloud/task15-snapshot-cloud-20261017-r1/report.json'),'0307f90a50137a2c176d0576d1c4ca60137822d3ae8388f6043ba3261bd7753f'),
 driver:pin('scripts/test-research-cloud-smoke.mjs','472e0cecc6ee0f070b71d46174b7151a562689e4fef4dfaffd4e38ae06158099'),
 wrapper:pin('node_modules/wrangler/bin/wrangler.js','72d02815cbffc9ad14e1667188296e7126e13f0d90bfbb6046db8e6c4b6ff39a'),
 cli:pin('node_modules/wrangler/wrangler-dist/cli.js','fc1aa72afc91906759a3555e76e6dae1b13504f71dec6d3bbfa0fe24c351ebd7'),
 preload:pin('outputs/local-durable-executor-20261012/maintenance-stop/read-connection-trace-r2.cjs','1db8481ccee8e5d924e18bde8b3b44d1fd1934c0c1a147815d02b305e79489f9'),
 maskedLauncher:pin('scripts/run-research-cloud-smoke.ps1','7017350c6103cbb8903afe1327959e62cb6ea98f38361de4b6c7effb29cd0957'),
 artifacts:{site:'443e7fd5d9a54e42f5a321f24d8b5c9a3bc12f47aa222702e665bd2f030c6993',executor:'b8a8faea136b335f58042f2bf7106ecbb13db30add7a78c16e200d6e192e4cfb'},
 workers:{site:'arc-v8-smoke-site-20260921',executor:'arc-v8-smoke-executor-20260921'},
 schemaDatabases:{site:'ab1c37a2-dd68-482d-8cbf-4175cfd4480b',executor:'ea89c802-37ba-496d-960f-b4e1403c3afe'},
 databases:{site:'9eea10cc-ddbf-405c-872b-ee9da8b6d3a6',executor:'c4b3d3b2-9c72-4c47-a752-c221b6ad8f40'},
 versions:{site:'d427c1d2-87e6-44fd-9392-4374d3ea7016',executor:'0eaeec45-6d8f-4b25-a06d-c7b1ccb68308'},
 workflowName:'arc-v8-smoke-workflow-20261017-snapshot',workflowId:'0461e04e-0639-40dc-899a-b4b147887339',bucket:'arc-v8-smoke-receipts-20261017-snapshot',
 codec:pin(code+'production-codec.mjs','41c27dab4136eace4c272e742b6499f8ee986e43341bd1fd9398cf1a1fe68b3b'),
 receiptProjector:pin(code+'project-r2-evidence.mjs','ef1bff3621e7a0804d6f8f71cf6148344c86c94f78b3cddf6665af0077010b51'),
 codecSources:pin(code+'source-freeze.json','dcd57c6968b57f82760ab23327f7fbf64f442d02df950af16d06289390ed8289'),
 metadataRule:pin('outputs/local-durable-executor-20261016/r9-closure-metadata-rule-r1.mjs','f4ccc6cd624819f985cd7a52130cc9c81ffb924e8da1291a22b908633be2b0fb'),
 statusHandler:pin('worker/research-executor-smoke/site-entry.ts','213cdee24b8bd4bca6e6a04ce7e8d7cd7b382bd58d3a828fd60baaa62aabb8dc'),
 integrationClarifications:pin('docs/superpowers/specs/2026-10-14-arc-v8-task2-integration-clarifications.md','ca231ec88aafadba43903a03abae4a1996ec8cbf66cf26eec8ab5451ea69cd12'),
 closureAddendum:pin('docs/superpowers/specs/2026-10-14-arc-v8-incomplete-closure-addendum.md','c1b877635dbce4f7e946d60f4b04fdd909beb5588ca4a0dba2285d56b17dd2fd'),
 diagnostics:{enums:pin('outputs/local-durable-executor-20261014/deployment-diagnostic-r1/enums.cjs','d65558edc3878e8fc97af0f74cbe58f6ddd0218467e33e122cc3edb1b0b08339'),project:pin('outputs/local-durable-executor-20261014/deployment-diagnostic-r1/project.mjs','019df5bc7ad8c02c5358f0a2487793cb5d0a57e8bed8e99a69ddff7c736ae96a'),trace:pin('outputs/local-durable-executor-20261014/deployment-diagnostic-r1/trace.cjs','2ddaf2c7bf099a1cae482031d629f9f4f7bfe96a1bda0b213d5c279fc439f1f1')},
 deployMitigation:{preload:pin('outputs/local-durable-executor-20261026/deploy-concurrency-r178/wrangler-proxy-cap.cjs','ee0b7288fd5754a8b32eda766efe3e4a4a2971aae2720a97028b4e6ea3007d4b'),transform:pin('outputs/local-durable-executor-20261026/deploy-concurrency-r178/transform.cjs','c3190a711c9ca89658a0fb4df9a50cc4e6c9791228a369acfaa87519a14f2225')},
 materialsPath:resolve(G,'root-scenario-tools-materials-acceptance-r9.json'),baselinePath:resolve(here,'closed-baseline-acceptance.json'),
});
export const toolNames=runtimeNames;
export const toolRefs=()=>Object.fromEntries(toolNames.map(n=>[n,ref(resolve(here,n))]));
export function assertFresh(start,end,now){const a=utc(start),b=utc(end);assert(integer(now)&&a<=b&&b<=now&&now-a<900000,'FRESH_ACTUAL_NATIVE_START');}
export function assertSuccessorBindings(value){assert(value?.sequence===FIXED.sequence&&same(value.currentClosedAcceptance,FIXED.currentClosedAcceptance),'EXACT_SNAPSHOT_ACCEPTED_BINDINGS');}
// Filled by the fixed accepted graph loader; no caller-created context is accepted.
const contexts=new WeakMap();
function frozen(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))frozen(x);Object.freeze(v);}return v;}
export function assertLocalNativeWork(c,started){assertContext(c);assert(Number.isFinite(started)&&performance.now()-started+c.validation.elapsedMs<=NATIVE_LOCAL_CEILING_MS,'FINITE_NATIVE_PREPARATION_OR_EVALUATION_LOCAL_BOUND');}
export function assertContext(c){assert(contexts.has(c),'VALIDATED_ENTRYPOINT_CONTEXT_REQUIRED');}
async function verifyRuntimeFiles(references){
 const bytes=new Array(references.length);let next=0;
 // Each file retains all checks; only independent reads overlap. Never publish a partial context.
 const workers=await Promise.allSettled(Array.from({length:Math.min(4,references.length)},async()=>{
  while(next<references.length){const index=next++,r=references[index];assert(r&&typeof r.path==='string'&&digest(r.sha256),'EXACT_FILE_REFERENCE');
   const path=resolve(root,r.path),stat=await lstat(path);assert(stat.isFile()&&!stat.isSymbolicLink()&&await realpath(path)===path,'ORDINARY_PINNED_FILE');
   const current=await readFile(path);assert(hash(current)===r.sha256,'HASH_CHANGED');bytes[index]=current;
  }
 }));
 const failure=workers.find(r=>r.status==='rejected');if(failure)throw failure.reason;
 return bytes;
}
export async function createValidationContext(){
 assert(process.versions.node==='24.14.1'&&process.execPath==='C:\\Program Files\\nodejs\\node.exe','PINNED_NODE_RUNTIME');const started=performance.now(),entrypointStartedAt=Date.now(),files=new Map(),pins=new Map();
 // Storage receives private verified bytes; external seeds retain their full digest check.
 const store=(r,bytes)=>{assert(bytes instanceof Uint8Array,'CURRENT_CONSUMED_BYTES');if(pins.has(r.path))assert(same(pins.get(r.path),r),'NO_CONFLICTING_CONTEXT_PINS');pins.set(r.path,r);files.set(r.path,Buffer.from(bytes));return files.get(r.path);};
 const seed=(reference,bytes)=>{const r={path:resolve(root,reference.path),sha256:reference.sha256};assert(digest(r.sha256)&&bytes instanceof Uint8Array&&hash(bytes)===r.sha256,'CURRENT_CONSUMED_BYTES');return store(r,bytes);};
 const load=reference=>{const r={path:resolve(root,reference.path),sha256:reference.sha256};if(pins.has(r.path)){assert(pins.get(r.path).sha256===r.sha256,'NO_CONFLICTING_CONTEXT_PINS');return files.get(r.path);}return store(r,verify(r));};
 const read=r=>frozen(JSON.parse(load(r).toString('utf8').replace(/^\uFEFF/u,'')));
 const {loadAcceptedSnapshot}=await import('./accepted-context.mjs');const data=await loadAcceptedSnapshot({load,read,seed});
 const runtime=runtimeInventory((r,takeBytes)=>{if(pins.has(r.path))assert(pins.get(r.path).sha256===r.sha256,'NO_CONFLICTING_CONTEXT_PINS');else seed(r,takeBytes());});
 const pending=runtime.references.filter(r=>{if(!pins.has(r.path))return true;assert(pins.get(r.path).sha256===r.sha256,'NO_CONFLICTING_CONTEXT_PINS');return false;});
 const loaded=await verifyRuntimeFiles(pending);for(let i=0;i<pending.length;i++){store(pending[i],loaded[i]);loaded[i]=undefined;}
 assert(read(ref(resolve(root,'node_modules/wrangler/package.json'))).version==='4.92.0','PINNED_WRANGLER_RUNTIME');
 assert(same(data.inventoryReference,FIXED.inventory),'EXACT_STATIC_IDENTITY_RECIPE');
 const directories=[...new Map([...data.historicalDirectories,...runtime.child.directories].map(d=>[d.path,d])).values()];
 // Materials bind this verified snapshot; complete late checks still reread every current pin.
 const runtimePins=new Map(runtime.references.map(r=>[r.path,r]));
 const tools=frozen(Object.fromEntries(toolNames.map(name=>{const path=resolve(here,name),r=runtimePins.get(path);assert(r&&pins.get(path)?.sha256===r.sha256,'COMPLETE_CONTEXT_TOOL_PINS');return [name,{path:r.path,sha256:r.sha256}];})));
 const c=Object.freeze({...frozen(data),read,verify:r=>Buffer.from(load(r)),currentReferences:()=>[...pins.values()],inputReferences:frozen([...pins.values()]),runtime:frozen(runtime),validation:Object.freeze({entrypointStartedAt,fileCount:files.size,runtimeFileCount:runtime.references.length,elapsedMs:performance.now()-started,historicalFreshnessRenewed:false,cloudCalls:0})});contexts.set(c,{pins,directories,tools});return c;
}
export function assertCurrentPins(c,refs=[]){assertContext(c);const started=performance.now(),bound=contexts.get(c),all=new Map([...bound.pins]);for(const r of refs){const path=resolve(root,r.path);if(all.has(path))assert(all.get(path).sha256===r.sha256,'PIN_REFERENCE_CONFLICT');all.set(path,r);}for(const r of all.values())verify(r);assertChildRuntimeStructure(c.runtime.child);for(const d of bound.directories){assert(same(readdirSync(d.path).sort(),[...d.names].sort()),'FROZEN_EVIDENCE_DIRECTORY_MEMBERSHIP');}return {fileCount:all.size,elapsedMs:performance.now()-started};}
export function assertMaterials(reference,c){
 assertContext(c);assert(reference?.path===FIXED.materialsPath,'FIXED_ROOT_MATERIALS_PATH');const m=c.read(reference);assertSuccessorBindings(m);
 assert(m.schemaVersion==='arc-snapshot-scenario-materials-acceptance-v1'&&m.rootReviewed===true&&m.specPassed===true&&m.qualityPassed===true&&m.epoch===FIXED.epoch&&same(m.inventory,FIXED.inventory)&&same(m.report,FIXED.report)&&same(m.task1,FIXED.task1)&&same(m.tools,contexts.get(c).tools),'ALL_REVIEWED_MATERIALS_REQUIRED');
 for(const r of [m.specReview,m.qualityReview,m.task2Acceptance,m.task3Acceptance,m.timingContract,m.preparation])c.verify(r);
 const task2=c.read(m.task2Acceptance),task3=c.read(m.task3Acceptance),timing=c.read(m.timingContract);
 assert(task2.rootReviewed===true&&task2.specPassed===true&&task2.qualityPassed===true&&same(task2.preparation,m.preparation)&&same(task2.tools,m.tools),'ROOT_TASK2_STATIC_DRY_RUN_ACCEPTANCE');
 assert(task3.rootReviewed===true&&task3.specPassed===true&&task3.qualityPassed===true&&same(task3.task2Acceptance,m.task2Acceptance)&&same(task3.timingContract,m.timingContract),'INDEPENDENT_TASK3_ACCEPTANCE');
 assert(timing.schemaVersion==='arc-snapshot-attended-timing-v1'&&timing.actualMeasurements===true&&timing.reviewed===true&&same(timing.task2Profile,task2.profile),'ACTUAL_FINAL_TASK3_TIMING');
 c.assertTimingFit(timing);const profile=c.read(task2.profile);assert(same(profile.operationProfile,c.profile)&&profile.measurementScope==='LOCAL_OFFLINE_ONLY'&&profile.cloudCalls===0,'ACTUAL_TASK2_MEASURED_PROFILE_BINDING');
 const roles=['long','after-r2','after-d1'].flatMap(id=>['start','status','replay'].map(mode=>id+':'+mode));
 assert(Array.isArray(m.launchers)&&same(m.launchers.map(x=>x.role).sort(),roles.sort())&&new Set(m.launchers.map(x=>x.path)).size===9,'NINE_DISTINCT_REVIEWED_LAUNCHERS');
 for(const r of [...m.launchers,...m.task3Files])c.verify(r);assert(m.task3Files.length>=5&&m.controlCredentialMode==='secure-masked-tty'&&m.providerCallsAllowed===false,'FINAL_TASK3_MATERIALS');
 c.verify(FIXED.inventory);return m;
}
// Mechanically retained approved neutral final-child environment. Reads no credential file/value.
export function neutralDeploy(){
 verify(FIXED.wrapper);verify(FIXED.cli);assert(!process.env.NODE_OPTIONS,'UNEXPECTED_NODE_PRELOAD');
 const cwd='C:/Users/XF/AppData/Local/Temp/arc15-cloud-DWBRaL';assert(existsSync(cwd)&&!['.env','.env.local','.dev.vars'].some(n=>existsSync(resolve(cwd,n))),'EXISTING_NEUTRAL_CWD');
 const rejected=new Set(['CLOUDFLARE_API_BASE_URL','CF_API_BASE_URL','CLOUDFLARE_API_TOKEN','CF_API_TOKEN','CLOUDFLARE_API_KEY','CF_API_KEY','WRANGLER_CI_OVERRIDE_NAME','WRANGLER_CI_OVERRIDE_NETWORK_MODE_HOST','CLOUDFLARE_ENV','WRANGLER_API_ENVIRONMENT','CLOUDFLARE_COMPLIANCE_REGION','WRANGLER_OUTPUT_FILE_DIRECTORY','WRANGLER_OUTPUT_FILE_PATH','WRANGLER_LOG_PATH','WRANGLER_LOG','WRANGLER_AUTH_DOMAIN','WRANGLER_AUTH_URL','WRANGLER_TOKEN_URL','WRANGLER_REVOKE_URL','WRANGLER_CLIENT_ID']);
 for(const k of Object.keys(process.env))assert(!rejected.has(k.toUpperCase()),'UNEXPECTED_TARGET_API_CREDENTIAL_SELECTOR');
 const env={...process.env,CLOUDFLARE_ACCOUNT_ID:FIXED.accountId,CLOUDFLARE_LOAD_DEV_VARS_FROM_DOT_ENV:'false',CLOUDFLARE_INCLUDE_PROCESS_ENV:'false',WRANGLER_API_ENVIRONMENT:'production',CLOUDFLARE_COMPLIANCE_REGION:'public',WRANGLER_LOG:'log',WRANGLER_WRITE_LOGS:'false',WRANGLER_LOG_SANITIZE:'true',WRANGLER_SEND_METRICS:'false',WRANGLER_SEND_ERROR_REPORTS:'false',CI:'true',NO_COLOR:'1',FORCE_COLOR:'0'};
 for(const k of ['NODE_PATH','HTTP_PROXY','http_proxy','HTTPS_PROXY','https_proxy','ALL_PROXY','all_proxy','NO_PROXY','no_proxy'])delete env[k];env.HTTPS_PROXY='http://127.0.0.1:7897/';return {cwd,env,windowsHide:true,timeout:45000,maxBuffer:262144};
}
export function neutralRead(){verify(FIXED.preload);const o=neutralDeploy();return {...o,env:{...o.env,NODE_OPTIONS:'--require '+JSON.stringify(FIXED.preload.path)}};}
export async function main(moduleUrl,action){if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===moduleUrl){try{await action();}catch{console.log(JSON.stringify({disposition:'STOP_RECONCILE_NO_RETRY',rawDiagnosticPersisted:false}));process.exitCode=1;}}}
