import test from 'node:test';import assert from 'node:assert/strict';import {readFile,writeFile,mkdir,access}from 'node:fs/promises';import {resolve,dirname,relative,sep}from 'node:path';import {randomUUID}from 'node:crypto';
import {WORKSPACE,OPS,OUTPUT,sha256}from './accepted-bytes.mjs';import {writeOfflineFixture}from './assemble.mjs';
const base='outputs/local-durable-executor-20260914/task15-smoke';
const portable=p=>relative(WORKSPACE,p).split(sep).join('/');const json=x=>JSON.stringify(x,null,2)+'\n';
const mutations=[
 ['report-hash','artifact-ineligible',(r,i)=>{i.artifactReportSha256='f'.repeat(64);},false],
 ['artifact-bytes','artifact-digest',(r,i)=>{r.site.sha256='f'.repeat(64);i.resources.siteWorker.artifactSha256=r.site.sha256;}],
 ['source-digest','source-digest',r=>{r.inputHashes[r.site.inputs[0]]='f'.repeat(64);}],
 ['role-input','deployment-artifact',r=>{r.site.inputs[0]='scripts/offline-forbidden.ts';}],
 ['policy','artifact-ineligible',r=>{r.policy.retries=1;}],
 ['alias','artifact-alias-proof',r=>{r.aliasEdges.pop();}],
 ['artifact-path','artifact-digest',(r,i)=>{r.site.output=r.provenance.acceptedReferences.siteArtifact.path;i.resources.siteWorker.entry=r.site.output;}],
 ['report-self-path','artifact-ineligible',r=>{r.report=OUTPUT+'/report.json';}],
 ['inventory-extra-field','inventory-fields',(r,i)=>{i.resources.receipts.extra=true;}],
 ['external-input','source-digest',r=>{r.inputHashes['C:/Program Files/nodejs/node.exe']='f'.repeat(64);}],
];
function inventory(report,reportBytes){
 const worker=(role,peer)=>({id:'offline-'+role+'-worker',name:'offline-'+role+'-worker',revision:'offline-not-a-deployment',artifactSha256:report[role].sha256,entry:report[role].output,peerId:'offline-'+peer+'-worker'});
 return{schemaVersion:'arc-smoke-isolation-v1',verified:true,isolated:true,verifiedAt:1,accountId:'0'.repeat(32),controlOrigin:'https://offline.invalid',controlKeyId:'offline-no-secret',artifactReportSha256:sha256(reportBytes),resources:{siteWorker:worker('site','executor'),executorWorker:{...worker('executor','site'),public:false},siteD1:{id:'offline-site-db',name:'offline-site-db'},executorD1:{id:'offline-executor-db',name:'offline-executor-db'},receipts:{id:'offline-receipts',name:'offline-receipts',private:true},workflow:{id:'offline-workflow',name:'offline-workflow',workerId:'offline-executor-worker'}}};
}
test('unchanged real driver stops at credential-channel and rejects invalid fixtures before it',async t=>{
 let install;try{({installOfflineGuard:install}=await import('./offline-evidence.mjs'));}catch(e){assert.fail('Offline transport/import guard missing: '+e.code);}
 const guard=install(),id=randomUUID(),records=[],fixturePaths=[];let transportCalls=0,inputReads=0,validHelper,helperCompilation;
 const input=Object.freeze({isTTY:true,read(){inputReads++;throw Error('OFFLINE_CREDENTIAL_READ_DENIED');}});
 const transport=async()=>{transportCalls++;throw Error('OFFLINE_TRANSPORT_DENIED');};
 try{
  const {runSmokeDriver}=await import('../../../../../scripts/test-research-cloud-smoke.mjs');
  const valid=await writeOfflineFixture('driver-valid-'+id),validReport=JSON.parse(await readFile(resolve(WORKSPACE,valid.report)));
  const directory=dirname(valid.report);fixturePaths.push(directory);const inventoryPath=directory+'/offline-inventory.json';
  await writeFile(resolve(WORKSPACE,inventoryPath),json(inventory(validReport,await readFile(resolve(WORKSPACE,valid.report)))),{flag:'wx'});
  const reportName='offline-snapshot-driver-'+id;
  const run=async(reportPath,invPath,name)=>runSmokeDriver(['status','--inventory',invPath,'--artifact-report',reportPath,'--scenario','long','--report-name',name],{input,transport});
  await t.test('valid accepted bytes reach exact credential refusal',async()=>{
   const result=await run(valid.report,inventoryPath,reportName);records.push({case:'valid',result,reportName});fixturePaths.push(base+'/'+reportName);
   assert.deepEqual(result,{status:'refused',code:'credential-channel',accepted:false,cloudElapsedProved:false});validHelper=base+'/'+reportName+'/host-helper.mjs';
   assert.deepEqual(JSON.parse(await readFile(resolve(WORKSPACE,base+'/'+reportName+'/failure.json'))),result);assert.equal(inputReads,0);assert.equal(transportCalls,0);
  });
  for(const [name,code,mutate,rehash=true]of mutations)await t.test('invalid '+name+' fails before credentials',async()=>{
   const dir=base+'/build/cloud/offline-snapshot-driver-invalid-'+name+'-'+id;await mkdir(resolve(WORKSPACE,dir));fixturePaths.push(dir);
   const r=structuredClone(validReport);r.report=dir+'/report.json';
   // Share valid fixture artifacts only for checks that precede artifact locality; copy for all ordinary cases.
   for(const role of ['site','executor']){r[role].output=dir+'/'+role+'.js';r[role].metafile=dir+'/'+role+'.metafile.json';await writeFile(resolve(WORKSPACE,r[role].output),await readFile(resolve(WORKSPACE,validReport[role].output)),{flag:'wx'});await writeFile(resolve(WORKSPACE,r[role].metafile),await readFile(resolve(WORKSPACE,validReport[role].metafile)),{flag:'wx'});}
   const inv=inventory(r,Buffer.from(json(r)));mutate(r,inv);const bytes=Buffer.from(json(r));if(rehash)inv.artifactReportSha256=sha256(bytes);
   const rp=dir+'/report.json',ip=dir+'/offline-inventory.json';await writeFile(resolve(WORKSPACE,rp),bytes,{flag:'wx'});await writeFile(resolve(WORKSPACE,ip),json(inv),{flag:'wx'});
   const outputName='offline-snapshot-driver-bad-'+name+'-'+id.slice(0,8);const result=await run(rp,ip,outputName);records.push({case:name,result,reportName:outputName});assert.equal(result.code,code);assert.equal(result.status,'refused');
   await assert.rejects(access(resolve(WORKSPACE,base+'/'+outputName)),{code:'ENOENT'});assert.equal(inputReads,0);assert.equal(transportCalls,0);
  });
  await t.test('report outside the required cloud directory fails before credentials',async()=>{
   const path=OPS+'/offline-report-outside-cloud-'+id+'.json';await writeFile(resolve(WORKSPACE,path),json(validReport),{flag:'wx'});fixturePaths.push(path);
   const name='offline-snapshot-driver-outside-'+id.slice(0,8);const result=await run(path,inventoryPath,name);records.push({case:'outside-cloud-report',result,reportName:name});
   assert.equal(result.code,'inventory-path');await assert.rejects(access(resolve(WORKSPACE,base+'/'+name)),{code:'ENOENT'});assert.equal(inputReads,0);assert.equal(transportCalls,0);
  });
  await t.test('helper compilation is separately labelled and has the identical loaded bytes',async()=>{
   assert.ok(validHelper,'valid driver did not compile its helper');const dir=base+'/build/cloud/offline-snapshot-driver-helper-dependencies-'+id;await mkdir(resolve(WORKSPACE,dir));fixturePaths.push(dir);
   const {build}=await import('esbuild');const output=dir+'/host-helper.mjs';const result=await build({absWorkingDir:WORKSPACE,entryPoints:[resolve(WORKSPACE,'tests/helpers/research-cloud-smoke-fixture.ts')],outfile:resolve(WORKSPACE,output),bundle:true,platform:'node',format:'esm',target:'node24',packages:'external',logLevel:'silent',metafile:true});
   const metaPath=dir+'/host-helper.metafile.json';await writeFile(resolve(WORKSPACE,metaPath),json(result.metafile),{flag:'wx'});
   const outputSha256=sha256(await readFile(resolve(WORKSPACE,output)));assert.equal(outputSha256,sha256(await readFile(resolve(WORKSPACE,validHelper))));
   const inputs=[];for(const path of Object.keys(result.metafile.inputs).sort())inputs.push({path,sha256:sha256(await readFile(resolve(WORKSPACE,path)))});
   helperCompilation={offlineOnly:true,recompiledProductArtifacts:false,output:{path:output,sha256:outputSha256},driverHelper:{path:validHelper,sha256:outputSha256},metafile:{path:metaPath,sha256:sha256(await readFile(resolve(WORKSPACE,metaPath)))},inputs};
  });
  assert.equal(transportCalls,0);assert.equal(inputReads,0);assert.equal(guard.counts.networkCalls,0);assert.equal(guard.counts.deniedChildren,0);
  await assert.rejects(access(resolve(WORKSPACE,OUTPUT)),{code:'ENOENT'});
 }finally{
  const deps=guard.dependencies();const stats={...guard.counts,transportCalls,inputReads};const file=OPS+'/offline-driver-evidence-'+id+'.json';
  await writeFile(resolve(WORKSPACE,file),json({schemaVersion:'arc-snapshot-offline-driver-evidence-v1',scope:'OFFLINE_ONLY_NOT_OPERATIONAL_ACCEPTANCE',nodeVersion:process.version,driver:{path:'scripts/test-research-cloud-smoke.mjs',sha256:sha256(await readFile(resolve(WORKSPACE,'scripts/test-research-cloud-smoke.mjs')))},cases:records,stats,fixturePaths,helperCompilation:helperCompilation??null,dependencies:deps,operationalAssemblyCreated:false}),{flag:'wx'});
  console.log('OFFLINE_EVIDENCE '+file);await guard.close();
 }
});
