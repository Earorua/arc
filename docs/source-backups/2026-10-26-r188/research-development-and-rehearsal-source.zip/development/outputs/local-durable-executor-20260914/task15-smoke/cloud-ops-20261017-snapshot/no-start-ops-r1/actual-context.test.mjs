// One read-only accepted-graph pass. No fixtures or operation records are created.
import test from 'node:test';
import assert from 'node:assert/strict';
import {loadAcceptedInputs,fastReverify,ANCHORS,runtimeReferences} from './context.mjs';
import {oldVersions,artifactHashes,legacyWorkflowIds} from './rules.mjs';
test('actual accepted graph, materialization, dry runs and runtime closure load once',async()=>{
 const ctx=await loadAcceptedInputs();assert.deepEqual(ctx.base.state.versions,oldVersions);assert.equal(ctx.materialization.migrations.length,18);assert.equal(ctx.entries.site.artifact.sha256,artifactHashes.site);assert.equal(ctx.entries.executor.artifact.sha256,artifactHashes.executor);
 assert.deepEqual(Object.fromEntries(Object.entries(ctx.baseline.workflows).map(([name,x])=>[name,x.id])),legacyWorkflowIds);
 assert.equal(ctx.base.second.scope.capacity.rowsUsed,256);assert.deepEqual(ctx.base.second.scope.scope.observedScenarioIds,['long']);
 assert.ok(ctx.inputPins.some(r=>r.path===ANCHORS.materialization.path&&r.sha256===ANCHORS.materialization.sha256));assert.ok(ctx.runtimePins.some(r=>r.path.endsWith('write-transport.mjs')));
 const started=performance.now();fastReverify(ctx);console.log(JSON.stringify({actualAcceptedGraphLoadedOnce:true,runtimePins:ctx.runtimePins.length,inputPins:ctx.inputPins.length,dispatchRehashMs:Math.ceil(performance.now()-started),cloudCalls:0,preparationCreated:false}));
});
