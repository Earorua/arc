// Narrow additions to C5's reviewed validation rules. No I/O and no cloud calls.
import {assert,same,assertTerminalRosters} from '../../../../local-durable-executor-20261012/maintenance-stop/cloud-r5/rules.mjs';
export {assert,same,currentDeployment,assertDecisionWindow,assertOperationProjection,projectOperationOutput,assertZeroLifecycle,assertSettingsStable} from '../../../../local-durable-executor-20261012/maintenance-stop/cloud-r5/rules.mjs';
export const workers=Object.freeze({site:'arc-v8-smoke-site-20260921',executor:'arc-v8-smoke-executor-20260921'});
export const oldVersions=Object.freeze({site:'26dff9ec-1d62-4146-afa8-71b0f7acc310',executor:'994b5608-2690-4327-9e80-b52ce0b6f7cc'});
export const legacyWorkflowIds=Object.freeze({'arc-v8-smoke-workflow-20260921':'c4747dc0-68bb-4d73-b60d-54fb768778b6','arc-v8-smoke-workflow-20261005-replay':'6905d906-51de-4047-8d9b-876649c47a18','arc-v8-smoke-workflow-20261012-ack':'12d6d5d6-0e05-4a97-99ef-4558d09d089e'});
export const newWorkflow='arc-v8-smoke-workflow-20261013-guarded';
export const workflowNames=Object.freeze([...Object.keys(legacyWorkflowIds),newWorkflow]);
export const newDatabases=Object.freeze({site:'eda666b8-6d49-4c3b-aa45-59eb9ff2bf74',executor:'a480e7d5-c008-46da-99bf-ca2422c06621'});
export const bucket='arc-v8-smoke-receipts-20261013-guarded';
export const emptySql="SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' AND name != '_cf_KV' ORDER BY type,name";
export const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u.test(value);
export const deployCommand=shortConfig=>['deploy','--config',shortConfig,'--no-bundle','--strict','--no-x-autoconfig','--no-x-provision','--no-x-auto-create'];
export const assertUnused=(attemptExists,resultExists)=>assert(!attemptExists&&!resultExists,'EXCLUSIVE_ATTEMPT_EXISTS');
export function assertFreshGate(start,end,now=Date.now()){assert([start,end,now].every(Number.isFinite)&&start<=end&&end<=now&&now-start<900000,'STALE_OR_INVALID_GATE');}
export function assertStopped(c,role){
  assert(c.preview_urls===false&&same(c.routes??[],[])&&same(c.triggers?.crons??[],[]),'ROUTES_OR_CRON_NOT_CLOSED');
  if(role==='executor')assert(c.workers_dev===false&&c.vars?.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW==='false'&&c.vars?.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED==='false','EXECUTOR_NOT_STOPPED');
}
export function projectEmptyDatabase(stdout){
  const rows=JSON.parse(stdout);assert(Array.isArray(rows)&&rows.length===1&&rows[0].success===true&&same(rows[0].results,[])&&rows[0].meta?.rows_written===0&&rows[0].meta?.changed_db===false,'DATABASE_NOT_PROVEN_EMPTY');
  return {rows:[],rowsWritten:0,changedDb:false};
}
export function projectVersionBindings(raw,c){
 const expected=new Map([...Object.keys(c.vars??{}).map(n=>[n,'plain_text']),...(c.secrets?.required??[]).map(n=>[n,'secret_text']),...['d1_databases','r2_buckets','services','workflows'].flatMap((k,i)=>(c[k]??[]).map(b=>[b.binding,['d1','r2_bucket','service','workflow'][i]]))]);
 assert(Array.isArray(raw)&&raw.length===expected.size&&new Set(raw.map(b=>b.name)).size===raw.length&&raw.every(b=>expected.get(b.name)===b.type),'EXACT_BINDING_TYPES_REQUIRED_BEFORE_EXPORT');
 return raw.map(b=>{
  const out={name:b.name,type:b.type};
  if(b.type==='plain_text'){assert(b.text===c.vars[b.name],'UNAPPROVED_PLAIN_VALUE');if(b.name!=='ARC_AI_IP_HASH_SALT')out.value=b.text;}
  if(b.type==='d1'){assert(b.id===c.d1_databases.find(x=>x.binding===b.name).database_id,'D1_BINDING_CHANGED');out.id=b.id;}
  if(b.type==='r2_bucket'){assert(b.bucket_name===c.r2_buckets.find(x=>x.binding===b.name).bucket_name,'R2_BINDING_CHANGED');out.bucketName=b.bucket_name;}
  if(b.type==='service'){const expectedService=c.services.find(x=>x.binding===b.name);assert(b.service===expectedService.service&&(b.environment??'production')===(expectedService.environment??'production'),'SERVICE_BINDING_CHANGED');out.service=b.service;out.environment=b.environment??'production';}
  if(b.type==='workflow'){const expectedWorkflow=c.workflows.find(x=>x.binding===b.name);assert(b.workflow_name===expectedWorkflow.name&&b.class_name===expectedWorkflow.class_name&&(b.script_name??null)===(expectedWorkflow.script_name??null),'WORKFLOW_BINDING_CHANGED');out.workflowName=b.workflow_name;out.className=b.class_name;out.scriptName=b.script_name??null;}
  return out;
 });
}
export function assertFourWorkflows(observations,baseline){
  const workflows={},rosters={},ids=[];
  for(const name of workflowNames){
    const definitions=observations.filter(o=>o.id===name+'-definition'),instances=observations.filter(o=>o.id===name+'-instances');
    assert(definitions.length===1&&instances.length===1,'DUPLICATE_OR_MISSING_WORKFLOW_READ');
    const d=definitions[0],i=instances[0];
    assert(d.ok===true&&i.ok===true&&d.name===name&&i.name===name&&Array.isArray(d.fields),'WORKFLOW_READ_FAILED');
    assert(same(d.fields.map(f=>f.field).sort(),['Name','Id','Script Name','Class Name','Created On','Modified On'].sort()),'WORKFLOW_FIELDS_NOT_EXACT');
    const fields=Object.fromEntries(d.fields.map(f=>[f.field,f.value])),id=fields.Id;
    assert(fields.Name===name&&fields['Script Name']===workers.executor&&fields['Class Name']==='ResearchWorkflow'&&uuid(id),'WORKFLOW_IDENTITY_MISMATCH');
    if(name!==newWorkflow)assert(id===legacyWorkflowIds[name],'LEGACY_WORKFLOW_ID_CHANGED');
    else assert(!Object.values(legacyWorkflowIds).includes(id),'NEW_WORKFLOW_REUSES_ID');
    assert(i.availableListComplete===true&&Array.isArray(i.rows)&&i.rows.length<100,'WORKFLOW_ROSTER_INCOMPLETE');
    rosters[name]={complete:true,rows:i.rows};ids.push(id);workflows[name]={id,worker:fields['Script Name'],className:fields['Class Name'],availableInstanceCount:i.rows.length};
  }
  assert(new Set(ids).size===4,'DUPLICATE_WORKFLOW_ID');
  assertTerminalRosters(Object.fromEntries(Object.keys(legacyWorkflowIds).map(n=>[n,rosters[n]])),Object.keys(legacyWorkflowIds),baseline.rosters);
  assert(rosters[newWorkflow].rows.length===0,'NEW_WORKFLOW_NOT_EMPTY');
  return {workflows,rosters,newWorkflowId:workflows[newWorkflow].id};
}
// Error strings and CLI bodies are never persisted. These booleans are the complete error projection.
export function safeError(error){const text=String(error?.stdout??'')+String(error?.stderr??'');return {failureKind:error?.killed===true?'child-timeout':/strict mode|Aborting the deployment operation because of conflicts/iu.test(text)?'strict-refusal':/fetch failed|UND_ERR_|ECONNRESET/iu.test(text)?'transport-error':'guard-or-command-failure',rawContentPersisted:false};}
