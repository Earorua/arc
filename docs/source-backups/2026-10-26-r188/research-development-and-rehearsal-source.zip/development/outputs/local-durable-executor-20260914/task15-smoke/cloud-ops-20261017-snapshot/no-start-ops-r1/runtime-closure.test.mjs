// Actual local dependency bytes only; altered reads and child callbacks are explicitly offline.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {resolve,join} from 'node:path';
import {syncBuiltinESMExports} from 'node:module';
import {inventory} from './runtime-inventory-r2.mjs';
import * as c from './context.mjs';
import {createReadTransport} from './read-transport.mjs';
import {deployOnce} from './write-transport.mjs';
import {commandsFor} from './read-plans.mjs';
import {N,request,finalConfigs,uuid,hash} from './offline-fixtures.mjs';
const audited=inventory();
function complete(){
 const actual=c.runtimeReferences(),paths=new Set(actual.map(r=>r.path));
 const missing=audited.references.filter(r=>!paths.has(r.path));
 assert.deepEqual(missing,[],'INDEPENDENT_RESOLVED_RUNTIME_CLOSURE_MUST_BE_PINNED');
 assert.deepEqual(actual,audited.references,'EXACT_INDEPENDENT_RUNTIME_INVENTORY');return actual;
}
test('independent AST inventory covers every resolved dynamic target and transitive runtime edge',()=>{
 complete();assert.ok(audited.dynamic.some(d=>d.source.endsWith('closed-r6-successor-r1\\reconstruct.mjs')));assert.ok(audited.dynamic.some(d=>d.source.endsWith('closed-r5-successor-r1\\reconstruct.mjs')));
 console.log(JSON.stringify({kind:'INDEPENDENT_RESOLVED_RUNTIME_INVENTORY',...audited}));
});
test('every dynamic dependency byte change blocks read and write dispatch after the single accepted load',async t=>{
 complete();const ctx=await c.loadAcceptedInputs();assert.deepEqual(ctx.runtimePins,audited.references);
 const original=fs.readFileSync,cache=new Map(c.uniquePins([...ctx.runtimePins,...ctx.inputPins]).map(r=>[r.path,original(r.path)]));
 let target=null,changedRead=false,spawns=0;const spawn=()=>{spawns++;throw Error('OFFLINE_UNEXPECTED_CHILD');};
 const patched=t.mock.method(fs,'readFileSync',(path,options)=>{
  const key=typeof path==='string'?resolve(path):null;
  if(!cache.has(key))return original(path,options);
  const bytes=key===target?(changedRead=true,Buffer.concat([cache.get(key),Buffer.from('\nOFFLINE_CHANGED_BYTES')])):cache.get(key);
  const encoding=typeof options==='string'?options:options?.encoding;return encoding?bytes.toString(encoding):bytes;
 });
 syncBuiltinESMExports();
 try{
  c.fastReverify(ctx);const recheck=()=>c.fastReverify(ctx);
  for(const path of audited.dynamicClosure){
   target=path;changedRead=false;const q=request(),transport=createReadTransport({request:q,cli:'OFFLINE',cwd:'OFFLINE',env:{},remainingMs:120000,beforeSpawn:recheck,runtime:{spawn}});
   const read=await transport.read(commandsFor(q)[0].args,()=>({}));assert.equal(read.failureKind,'dispatch-pins',path);assert.equal(changedRead,true,path);assert.equal(read.attempts.length,0,path);
   changedRead=false;const write=await deployOnce({role:'executor',config:finalConfigs.executor,shortConfig:{path:'C:/Users/XF/AppData/Local/Temp/arc15-snapshot-no-start-executor-OFFLINE/wrangler.jsonc',sha256:hash('OFFLINE')},expectedVersion:uuid(900),cwd:'OFFLINE',env:{},beforeSpawn:recheck,runtime:{spawn}});
   assert.equal(write.commandFailureKind,'dispatch-pins',path);assert.equal(write.mutationAttempted,false,path);assert.equal(changedRead,true,path);
  }
  target=null;c.fastReverify(ctx);assert.equal(spawns,0);
  console.log(JSON.stringify({kind:'DYNAMIC_DEPENDENCY_DISPATCH_REFUSAL',acceptedGraphLoads:1,runtimePins:ctx.runtimePins.length,inputPins:ctx.inputPins.length,changedDependencies:audited.dynamicClosure.length,readRefusals:audited.dynamicClosure.length,writeRefusals:audited.dynamicClosure.length,injectedChildDispatches:spawns,actualSourceFilesChanged:0}));
 }finally{patched.mock.restore();syncBuiltinESMExports();}
});
test('corrected candidate uses new review slots and binds its new regression evidence',()=>{
 assert.deepEqual(c.reviewPaths,{spec:join(N,'spec-review-r2.json'),quality:join(N,'quality-review-r2.json')});
 for(const name of ['runtime-inventory-r2.mjs','runtime-closure.test.mjs','runtime-closure-red-r2.log','runtime-closure-red-r2-complete.log','runtime-closure-green-r2.log','focused-green-r2.log','syntax-r2.log','cli-refusals-r2.log','derivation-r2.json','implementation-report-r2.md'])assert.ok(c.evidenceNames.includes(name),name);
});
