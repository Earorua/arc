$ErrorActionPreference = 'Stop'
try {
if ($args.Count -ne 0) { throw 'Fixed no-argument attended command only' }
$arcEntry = 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261017-snapshot\scenario-ops-r10\terminal-entry.ps1'
if ((Get-FileHash -LiteralPath $arcEntry -Algorithm SHA256).Hash.ToLowerInvariant() -cne '2a303b8155c1e8da9adec28265d3728c0deabd7c41d6aa67004d7d18fc2ad781') { throw 'Reviewed terminal entry changed' }
. $arcEntry
    $arcExit = Invoke-ArcFixedTerminalCommand -Role 'after-r2:replay' -ContractPath 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261017-snapshot\scenario-ops-r10\launcher-contract.json' -ContractSha256 '3de5fd01184ed2bf6ad36c150cea9e7b837e0b19ac5143c20d921d4286a73918' -LauncherPath 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261017-snapshot\scenario-ops-r10\run-after-r2-replay-masked-once-r1.ps1' -LauncherSha256 '2d0eef86888034063d54f9f9e77b9e1e6ca70a925da72f4a2b478423d16add9a' -CommandPath $PSCommandPath
    Write-Host ('ExitCode: ' + $arcExit)
    exit $arcExit
} catch {
    [Console]::Error.WriteLine('TERMINAL_PREPARATION_REFUSED_STOP_RECONCILE_NO_RETRY')
    Write-Host 'ExitCode: 1'
    exit 1
}
