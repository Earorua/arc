// app/lib/planning/fingerprint.ts
function invalidJson() {
  throw new TypeError("Value must be plain JSON");
}
function hasExpectedPrototype(value, prototype) {
  try {
    return Object.getPrototypeOf(value) === prototype;
  } catch {
    invalidJson();
  }
}
function ownDescriptorSnapshot(value) {
  try {
    return Object.getOwnPropertyDescriptors(value);
  } catch {
    return invalidJson();
  }
}
function sortedObjectEntries(value) {
  if (!hasExpectedPrototype(value, Object.prototype)) invalidJson();
  const descriptors = ownDescriptorSnapshot(value);
  if (Object.getOwnPropertySymbols(descriptors).length > 0) invalidJson();
  const entries = [];
  for (const key of Object.getOwnPropertyNames(descriptors)) {
    const descriptor = descriptors[key];
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) invalidJson();
    entries.push([key, descriptor.value]);
  }
  return entries.sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
}
function arrayValues(value) {
  if (!hasExpectedPrototype(value, Array.prototype)) invalidJson();
  const descriptors = ownDescriptorSnapshot(value);
  if (Object.getOwnPropertySymbols(descriptors).length > 0) invalidJson();
  const lengthDescriptor = descriptors.length;
  if (!lengthDescriptor || !("value" in lengthDescriptor) || !Number.isSafeInteger(lengthDescriptor.value) || lengthDescriptor.value < 0) {
    invalidJson();
  }
  const length = lengthDescriptor.value;
  const names = Object.getOwnPropertyNames(descriptors);
  if (names.length !== length + 1) invalidJson();
  const values = [];
  for (const name of names) {
    if (name === "length") continue;
    const index = Number(name);
    const descriptor = descriptors[name];
    if (!Number.isSafeInteger(index) || index < 0 || index >= length || String(index) !== name || !descriptor.enumerable || !("value" in descriptor)) invalidJson();
    values.push([index, descriptor.value]);
  }
  return values.sort(([left], [right]) => left - right).map(([, item]) => item);
}
function serialize(value, stack) {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) invalidJson();
    return JSON.stringify(value);
  }
  if (typeof value !== "object") invalidJson();
  if (stack.has(value)) invalidJson();
  stack.add(value);
  try {
    if (Array.isArray(value)) {
      return `[${arrayValues(value).map((item) => serialize(item, stack)).join(",")}]`;
    }
    return `{${sortedObjectEntries(value).map(([key, item]) => `${JSON.stringify(key)}:${serialize(item, stack)}`).join(",")}}`;
  } finally {
    stack.delete(value);
  }
}
function canonicalJson(value) {
  return serialize(value, /* @__PURE__ */ new Set());
}

// app/server/research/executor/body.ts
var BRIDGE_BODY_LIMITS = Object.freeze({
  request: 4096,
  status: 4096,
  outbox: 16384,
  result: 1048576
});
var BridgeBodyError = class extends Error {
  constructor(code) {
    super(`Research bridge body failure: ${code}`);
    this.code = code;
    this.name = "BridgeBodyError";
  }
};
var typedArrayPrototype = Object.getPrototypeOf(Uint8Array.prototype);
var typedArrayByteLengthGetter = typedArrayPrototype ? Object.getOwnPropertyDescriptor(typedArrayPrototype, "byteLength")?.get : void 0;
function bridgeByteLength(value) {
  try {
    if (!(value instanceof Uint8Array) || typeof typedArrayByteLengthGetter !== "function") {
      throw new BridgeBodyError("body-read");
    }
    return Reflect.apply(typedArrayByteLengthGetter, value, []);
  } catch {
    throw new BridgeBodyError("body-read");
  }
}
function decodeBridgeJson(bytes) {
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new BridgeBodyError("invalid-json");
  }
}

// app/server/research/executor/receipt.ts
import { z as z9 } from "zod";

// app/contracts/research.ts
import { z as z3 } from "zod";

// app/contracts/intelligence.ts
import { z } from "zod";
var idSchema = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/u);
function isCalendarDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/u.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (year < 1 || month < 1 || month > 12 || day < 1) return false;
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day <= daysInMonth[month - 1];
}
function isIpLiteral(hostname) {
  if (hostname.includes(":")) return true;
  const octets = hostname.split(".");
  return octets.length === 4 && octets.every((octet) => /^\d{1,3}$/u.test(octet) && Number(octet) <= 255);
}
var nonPublicDnsSuffixes = ["internal", "test", "invalid", "example", "home.arpa"];
function hasNonPublicDnsSuffix(hostname) {
  return nonPublicDnsSuffixes.some(
    (suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`)
  );
}
function isPublicHttpsUrl(value) {
  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase().replace(/\.+$/u, "");
    return url.protocol === "https:" && url.username === "" && url.password === "" && hostname !== "localhost" && !hostname.endsWith(".localhost") && hostname !== "local" && !hostname.endsWith(".local") && hostname.includes(".") && !hasNonPublicDnsSuffix(hostname) && !isIpLiteral(hostname);
  } catch {
    return false;
  }
}
var calendarDateSchema = z.string().refine(isCalendarDate, "Invalid calendar date");
var publicHttpsUrlSchema = z.string().url().refine(isPublicHttpsUrl, "Public HTTPS URL required");
function isIanaTimeZoneIdentifier(value) {
  return typeof value === "string" && /^[A-Za-z][A-Za-z0-9._+-]*(?:\/[A-Za-z][A-Za-z0-9._+-]*)*$/u.test(value);
}
var skillCategorySchema = z.enum([
  "foundations",
  "frontend",
  "backend",
  "data",
  "quality",
  "cloud",
  "ai",
  "product"
]);
var skillImportanceSchema = z.enum(["core", "strong", "advantage"]);
var resourceCostSchema = z.enum(["free", "paid", "mixed"]);
var resourceFormatSchema = z.enum([
  "documentation",
  "course",
  "guide",
  "reference",
  "practice"
]);
var sourceTierSchema = z.enum([
  "primary",
  "institutional",
  "practitioner",
  "community"
]);
var resourcePurposeSchema = z.enum(["primary", "alternative", "reference"]);
var learningResourceSchema = z.object({
  id: idSchema,
  title: z.string().trim().min(3).max(180),
  url: publicHttpsUrlSchema,
  provider: z.string().trim().min(2).max(120),
  language: z.enum(["en", "zh-CN"]),
  cost: resourceCostSchema,
  format: resourceFormatSchema,
  sourceTier: sourceTierSchema,
  purpose: resourcePurposeSchema,
  estimatedMinutes: z.number().int().positive().nullable(),
  lastVerifiedAt: calendarDateSchema,
  skillIds: z.array(idSchema).min(1)
}).strict();
var roleSkillSchema = z.object({
  id: idSchema,
  name: z.string().trim().min(2).max(120),
  category: skillCategorySchema,
  importance: skillImportanceSchema,
  why: z.string().trim().min(12).max(360),
  // Deprecated compatibility field. Not learner evidence; do not use for product decisions.
  confidence: z.number().min(0.75).max(1),
  masteryCriteria: z.array(z.string().trim().min(12).max(240)).min(2),
  prerequisiteIds: z.array(idSchema),
  resourceIds: z.array(idSchema).min(1)
}).strict();
var rolePhaseSchema = z.object({
  id: idSchema,
  name: z.string().trim().min(2).max(120),
  weeks: z.number().int().positive(),
  outcome: z.string().trim().min(12).max(360),
  skillIds: z.array(idSchema).min(1)
}).strict();
var roleBlueprintSchema = z.object({
  id: idSchema,
  name: z.string().trim().min(2).max(120),
  summary: z.string().trim().min(20).max(500),
  version: z.string().regex(/^\d{4}\.\d{2}\.\d+$/u),
  status: z.enum(["ready", "needs-review", "draft"]),
  updatedAt: calendarDateSchema,
  languagePolicy: z.literal("english-first"),
  skills: z.array(roleSkillSchema).min(1),
  resources: z.array(learningResourceSchema).min(1),
  phases: z.array(rolePhaseSchema).min(1)
}).strict();

// app/contracts/planning.ts
import { z as z2 } from "zod";
var PLANNING_SCHEMA_VERSION = "2026.08.1";
var idSchema2 = z2.string().max(256).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/u);
var versionSchema = z2.string().max(32).regex(/^\d{4}\.\d{2}\.\d+$/u);
var fingerprintSchema = z2.string().trim().min(1).max(256);
var shortTextSchema = z2.string().trim().min(1).max(1e3);
var minuteSchema = z2.number().int().positive().max(720);
var availabilityMinuteSchema = z2.union([z2.literal(0), z2.number().int().min(15).max(720)]);
var calendarDateSchema2 = calendarDateSchema.max(10);
var publicHttpsUrlSchema2 = publicHttpsUrlSchema.max(2048);
var timestampSchema = z2.string().max(64).datetime({ offset: true });
function hasDuplicates(values) {
  return new Set(values).size !== values.length;
}
function issueDuplicateIds(ctx, values, path, message) {
  if (hasDuplicates(values)) ctx.addIssue({ code: "custom", path, message });
}
var skillSelfLevelSchema = z2.enum(["unseen", "conceptual", "guided", "independent"]);
var evidenceKindSchema = z2.enum(["repository", "deployment", "project", "document", "other"]);
var unitKindSchema = z2.enum(["learn", "calibrate", "reinforce"]);
var planGenerationSchema = z2.enum(["initial", "automatic", "proposed"]);
var learningEventKindSchema = z2.enum([
  "completed",
  "delayed",
  "skipped",
  "too_hard",
  "already_known",
  "availability_changed",
  "replan_accepted",
  "replan_discarded"
]);
var planningGenerateSourceSchema = z2.discriminatedUnion("source", [
  z2.object({ source: z2.literal("flagship"), roleId: z2.literal("ai-native-full-stack-engineer") }).strict(),
  z2.object({ source: z2.literal("research"), researchRunId: idSchema2 }).strict()
]);
var planningSourceReferenceSchema = z2.discriminatedUnion("source", [
  z2.object({ source: z2.literal("flagship"), roleId: z2.literal("ai-native-full-stack-engineer") }).strict(),
  z2.object({
    source: z2.literal("research"),
    researchRunId: idSchema2,
    packageId: idSchema2,
    blueprintId: idSchema2,
    blueprintVersion: versionSchema,
    registryId: idSchema2,
    registryVersion: versionSchema,
    configFingerprint: fingerprintSchema,
    contentFingerprint: fingerprintSchema
  }).strict()
]);
var skillEvidenceSchema = z2.object({
  id: idSchema2,
  skillId: idSchema2,
  kind: evidenceKindSchema,
  url: publicHttpsUrlSchema2,
  note: shortTextSchema.max(300)
}).strict();
var skillAuditAnswerSchema = z2.object({
  skillId: idSchema2,
  level: skillSelfLevelSchema,
  evidenceRefs: z2.array(idSchema2).max(3)
}).strict().superRefine((answer, ctx) => {
  issueDuplicateIds(ctx, answer.evidenceRefs, ["evidenceRefs"], "Evidence references must be unique");
});
var skillAuditVersionSchema = z2.object({
  id: idSchema2,
  schemaVersion: z2.literal(PLANNING_SCHEMA_VERSION),
  blueprintId: idSchema2,
  blueprintVersion: versionSchema,
  answers: z2.array(skillAuditAnswerSchema).max(64),
  evidence: z2.array(skillEvidenceSchema).max(192),
  createdBy: idSchema2,
  inputFingerprint: fingerprintSchema
}).strict().superRefine((audit, ctx) => {
  issueDuplicateIds(ctx, audit.answers.map(({ skillId }) => skillId), ["answers"], "Audit answers must have unique skill IDs");
  issueDuplicateIds(ctx, audit.evidence.map(({ id }) => id), ["evidence"], "Evidence IDs must be unique");
  const evidenceById = new Map(audit.evidence.map((evidence) => [evidence.id, evidence]));
  audit.answers.forEach((answer, answerIndex) => answer.evidenceRefs.forEach((reference, referenceIndex) => {
    const evidence = evidenceById.get(reference);
    if (!evidence || evidence.skillId !== answer.skillId) {
      ctx.addIssue({ code: "custom", path: ["answers", answerIndex, "evidenceRefs", referenceIndex], message: "Evidence must resolve to the answer's skill" });
    }
  }));
});
var weekdayMinutesSchema = z2.object({
  monday: availabilityMinuteSchema,
  tuesday: availabilityMinuteSchema,
  wednesday: availabilityMinuteSchema,
  thursday: availabilityMinuteSchema,
  friday: availabilityMinuteSchema,
  saturday: availabilityMinuteSchema,
  sunday: availabilityMinuteSchema
}).strict();
var availabilityExceptionSchema = z2.object({
  date: calendarDateSchema2,
  minutes: availabilityMinuteSchema,
  reason: z2.string().trim().min(1).max(300).nullable()
}).strict();
function isSupportedTimeZone(timeZone) {
  if (!isIanaTimeZoneIdentifier(timeZone)) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone });
    return true;
  } catch {
    return false;
  }
}
var availabilityVersionSchema = z2.object({
  id: idSchema2,
  schemaVersion: z2.literal(PLANNING_SCHEMA_VERSION),
  timeZone: z2.string().min(1).max(128).refine(isSupportedTimeZone, "Unsupported IANA time zone"),
  weekdays: weekdayMinutesSchema,
  exceptions: z2.array(availabilityExceptionSchema).max(90),
  weeklyMinutes: z2.number().int().min(30).max(2400),
  inputFingerprint: fingerprintSchema
}).strict().superRefine((availability, ctx) => {
  issueDuplicateIds(ctx, availability.exceptions.map(({ date }) => date), ["exceptions"], "Exception dates must be unique");
  const weeklyMinutes = Object.values(availability.weekdays).reduce((sum, minutes) => sum + minutes, 0);
  if (availability.weeklyMinutes !== weeklyMinutes) {
    ctx.addIssue({ code: "custom", path: ["weeklyMinutes"], message: "Weekly minutes must equal weekday total" });
  }
});
var planningTargetSchema = z2.object({
  id: idSchema2,
  schemaVersion: z2.literal(PLANNING_SCHEMA_VERSION),
  targetWeeks: z2.number().int().min(4).max(52),
  inputFingerprint: fingerprintSchema
}).strict();
var unitStepSchema = z2.object({
  id: idSchema2,
  label: z2.string().trim().min(1).max(180),
  minutes: minuteSchema
}).strict();
var unitCheckpointSchema = z2.object({
  id: idSchema2,
  label: z2.string().trim().min(1).max(180),
  stepIds: z2.array(idSchema2).min(1).max(12),
  estimatedMinutes: minuteSchema
}).strict().superRefine((checkpoint, ctx) => {
  issueDuplicateIds(ctx, checkpoint.stepIds, ["stepIds"], "Checkpoint step IDs must be unique");
});
var unitTemplateSchema = z2.object({
  id: idSchema2,
  version: versionSchema,
  skillId: idSchema2,
  kind: unitKindSchema,
  title: z2.string().trim().min(1).max(180),
  objective: z2.string().trim().min(1).max(500),
  whyNow: z2.string().trim().min(1).max(500),
  primaryResourceId: idSchema2,
  alternativeResourceIds: z2.array(idSchema2).max(8),
  steps: z2.array(unitStepSchema).min(1).max(12),
  checkpoints: z2.array(unitCheckpointSchema).max(8),
  buildTask: z2.string().trim().min(1).max(800),
  completionCriteria: z2.array(z2.string().trim().min(1).max(500)).min(1).max(8),
  proofRequirement: z2.string().trim().min(1).max(800),
  rubric: z2.array(z2.string().trim().min(1).max(500)).min(1).max(6),
  estimatedMinutes: minuteSchema
}).strict().superRefine((template, ctx) => {
  issueDuplicateIds(ctx, template.alternativeResourceIds, ["alternativeResourceIds"], "Alternative resource IDs must be unique");
  if (template.alternativeResourceIds.includes(template.primaryResourceId)) {
    ctx.addIssue({ code: "custom", path: ["alternativeResourceIds"], message: "Primary resource cannot also be an alternative" });
  }
  issueDuplicateIds(ctx, template.steps.map(({ id }) => id), ["steps"], "Step IDs must be unique");
  issueDuplicateIds(ctx, template.checkpoints.map(({ id }) => id), ["checkpoints"], "Checkpoint IDs must be unique");
  issueDuplicateIds(ctx, template.completionCriteria, ["completionCriteria"], "Completion criteria must be unique");
  issueDuplicateIds(ctx, template.rubric, ["rubric"], "Rubric rows must be unique");
  const stepIds = new Set(template.steps.map(({ id }) => id));
  template.checkpoints.forEach((checkpoint, checkpointIndex) => checkpoint.stepIds.forEach((stepId, stepIndex) => {
    if (!stepIds.has(stepId)) ctx.addIssue({ code: "custom", path: ["checkpoints", checkpointIndex, "stepIds", stepIndex], message: "Checkpoint step must resolve" });
  }));
});
var skillUnitTrackSchema = z2.object({
  skillId: idSchema2,
  templates: z2.array(unitTemplateSchema).min(1).max(8)
}).strict().superRefine((track, ctx) => {
  issueDuplicateIds(ctx, track.templates.map(({ id }) => id), ["templates"], "Template IDs must be unique within a skill track");
  track.templates.forEach((template, index) => {
    if (template.skillId !== track.skillId) ctx.addIssue({ code: "custom", path: ["templates", index, "skillId"], message: "Template skill must match its track" });
  });
});
var unitRegistrySchema = z2.object({
  id: idSchema2,
  version: versionSchema,
  blueprintId: idSchema2,
  blueprintVersion: versionSchema,
  tracks: z2.array(skillUnitTrackSchema).min(1).max(64)
}).strict().superRefine((registry, ctx) => {
  issueDuplicateIds(ctx, registry.tracks.map(({ skillId }) => skillId), ["tracks"], "Registry tracks must have unique skill IDs");
});
var planningSourceContextSchema = z2.object({
  reference: planningSourceReferenceSchema,
  blueprint: roleBlueprintSchema,
  registry: unitRegistrySchema
}).strict().superRefine((context, ctx) => {
  const reference = context.reference;
  const blueprintId = reference.source === "flagship" ? reference.roleId : reference.blueprintId;
  if (context.blueprint.id !== blueprintId) {
    ctx.addIssue({ code: "custom", path: ["blueprint", "id"], message: "Source blueprint identity must match" });
  }
  if (reference.source === "research" && context.blueprint.version !== reference.blueprintVersion) {
    ctx.addIssue({ code: "custom", path: ["blueprint", "version"], message: "Source blueprint version must match" });
  }
  if (context.registry.blueprintId !== context.blueprint.id || context.registry.blueprintVersion !== context.blueprint.version) {
    ctx.addIssue({ code: "custom", path: ["registry"], message: "Source registry domain must match its blueprint" });
  }
  if (reference.source === "research" && (context.registry.id !== reference.registryId || context.registry.version !== reference.registryVersion)) {
    ctx.addIssue({ code: "custom", path: ["registry"], message: "Source registry identity must match" });
  }
  if (reference.source === "flagship") {
    if (context.blueprint.version !== "2026.08.1") {
      ctx.addIssue({ code: "custom", path: ["blueprint", "version"], message: "Flagship blueprint version must match" });
    }
    if (context.registry.id !== "ai-native-full-stack-engineer-units" || context.registry.version !== "2026.08.1") {
      ctx.addIssue({ code: "custom", path: ["registry"], message: "Flagship registry identity must match" });
    }
  }
});
var pathUnitSchema = z2.object({
  id: idSchema2,
  templateId: idSchema2,
  templateVersion: versionSchema,
  checkpointId: idSchema2.nullable(),
  skillId: idSchema2,
  kind: unitKindSchema,
  estimatedMinutes: minuteSchema,
  prerequisiteUnitIds: z2.array(idSchema2).max(2e3)
}).strict().superRefine((unit, ctx) => {
  issueDuplicateIds(ctx, unit.prerequisiteUnitIds, ["prerequisiteUnitIds"], "Prerequisite unit IDs must be unique");
  if (unit.prerequisiteUnitIds.includes(unit.id)) ctx.addIssue({ code: "custom", path: ["prerequisiteUnitIds"], message: "A unit cannot require itself" });
});
var learningPathPhaseSchema = z2.object({
  phaseId: idSchema2,
  name: z2.string().trim().min(1).max(180),
  outcome: z2.string().trim().min(1).max(500),
  unitIds: z2.array(idSchema2).min(1).max(2e3)
}).strict().superRefine((phase, ctx) => {
  issueDuplicateIds(ctx, phase.unitIds, ["unitIds"], "Phase unit IDs must be unique");
});
var deferredSkillSchema = z2.object({
  skillId: idSchema2,
  reason: z2.enum(["target-date-advantage", "target-date-strong"])
}).strict();
var learningPathVersionSchema = z2.object({
  id: idSchema2,
  schemaVersion: z2.literal(PLANNING_SCHEMA_VERSION),
  blueprintId: idSchema2,
  blueprintVersion: versionSchema,
  registryId: idSchema2,
  registryVersion: versionSchema,
  auditVersionId: idSchema2,
  availabilityVersionId: idSchema2,
  targetId: idSchema2,
  scopeMode: z2.enum(["full-scope", "target-date"]),
  phases: z2.array(learningPathPhaseSchema).min(1).max(2e3),
  units: z2.array(pathUnitSchema).min(1).max(2e3),
  deferredSkills: z2.array(deferredSkillSchema).max(64),
  estimatedStartDate: calendarDateSchema2,
  estimatedCompletionDate: calendarDateSchema2,
  inputFingerprint: fingerprintSchema
}).strict().superRefine((path, ctx) => {
  issueDuplicateIds(ctx, path.phases.map(({ phaseId }) => phaseId), ["phases"], "Phase IDs must be unique");
  issueDuplicateIds(ctx, path.units.map(({ id }) => id), ["units"], "Path unit IDs must be unique");
  issueDuplicateIds(ctx, path.deferredSkills.map(({ skillId }) => skillId), ["deferredSkills"], "Deferred skill IDs must be unique");
  const unitIds = new Set(path.units.map(({ id }) => id));
  const phaseUnitIds = path.phases.flatMap(({ unitIds: ids }) => ids);
  issueDuplicateIds(ctx, phaseUnitIds, ["phases"], "A unit may appear in only one phase");
  path.phases.forEach((phase, phaseIndex) => phase.unitIds.forEach((unitId, unitIndex) => {
    if (!unitIds.has(unitId)) ctx.addIssue({ code: "custom", path: ["phases", phaseIndex, "unitIds", unitIndex], message: "Phase unit must resolve" });
  }));
  path.units.forEach((unit, unitIndex) => unit.prerequisiteUnitIds.forEach((prerequisiteId, prerequisiteIndex) => {
    if (!unitIds.has(prerequisiteId)) ctx.addIssue({ code: "custom", path: ["units", unitIndex, "prerequisiteUnitIds", prerequisiteIndex], message: "Prerequisite unit must resolve" });
  }));
});
var pathBuildResultSchema = z2.object({
  fullScope: learningPathVersionSchema,
  targetDate: learningPathVersionSchema.nullable(),
  infeasibleReason: z2.string().trim().min(1).max(1e3).nullable()
}).strict().superRefine((result, ctx) => {
  if (result.fullScope.scopeMode !== "full-scope") ctx.addIssue({ code: "custom", path: ["fullScope", "scopeMode"], message: "Full-scope result must be full-scope" });
  if (result.targetDate?.scopeMode !== "target-date" && result.targetDate !== null) ctx.addIssue({ code: "custom", path: ["targetDate", "scopeMode"], message: "Target-date result must be target-date" });
  if (result.targetDate === null !== (result.infeasibleReason !== null)) ctx.addIssue({ code: "custom", path: ["infeasibleReason"], message: "An infeasibility reason is required only without a target-date path" });
});
var dailyUnitSchema = z2.object({
  id: idSchema2,
  planVersionId: idSchema2,
  templateId: idSchema2,
  templateVersion: versionSchema,
  checkpointId: idSchema2.nullable(),
  skillId: idSchema2,
  kind: unitKindSchema,
  scheduledDate: calendarDateSchema2,
  slot: z2.enum(["primary", "stretch"]),
  required: z2.boolean(),
  objective: z2.string().trim().min(1).max(500),
  whyNow: z2.string().trim().min(1).max(500),
  primaryResourceId: idSchema2,
  alternativeResourceIds: z2.array(idSchema2).max(8),
  steps: z2.array(unitStepSchema).min(1).max(12),
  buildTask: z2.string().trim().min(1).max(800),
  completionCriteria: z2.array(z2.string().trim().min(1).max(500)).min(1).max(8),
  proofRequirement: z2.string().trim().min(1).max(800),
  rubric: z2.array(z2.string().trim().min(1).max(500)).min(1).max(6),
  estimatedMinutes: minuteSchema
}).strict().superRefine((unit, ctx) => {
  issueDuplicateIds(ctx, unit.alternativeResourceIds, ["alternativeResourceIds"], "Alternative resource IDs must be unique");
  if (unit.alternativeResourceIds.includes(unit.primaryResourceId)) {
    ctx.addIssue({ code: "custom", path: ["alternativeResourceIds"], message: "Primary resource cannot also be an alternative" });
  }
  issueDuplicateIds(ctx, unit.steps.map(({ id }) => id), ["steps"], "Step IDs must be unique");
  issueDuplicateIds(ctx, unit.completionCriteria, ["completionCriteria"], "Completion criteria must be unique");
  issueDuplicateIds(ctx, unit.rubric, ["rubric"], "Rubric rows must be unique");
});
var planDaySchema = z2.object({
  date: calendarDateSchema2,
  budgetMinutes: z2.number().int().min(0).max(720),
  status: z2.enum(["scheduled", "rest", "open"]),
  primaryUnitId: idSchema2.nullable(),
  stretchUnitId: idSchema2.nullable()
}).strict().superRefine((day, ctx) => {
  if (day.primaryUnitId !== null && day.primaryUnitId === day.stretchUnitId) ctx.addIssue({ code: "custom", path: ["stretchUnitId"], message: "Primary and stretch units must differ" });
});
var planVersionSchema = z2.object({
  id: idSchema2,
  schemaVersion: z2.literal(PLANNING_SCHEMA_VERSION),
  generation: planGenerationSchema,
  baseVersionId: idSchema2.nullable(),
  replanReason: learningEventKindSchema.nullable(),
  planningDate: calendarDateSchema2,
  pathVersionId: idSchema2,
  days: z2.array(planDaySchema).length(7),
  dailyUnitIds: z2.array(idSchema2).max(2e3),
  estimatedCompletionDate: calendarDateSchema2,
  inputFingerprint: fingerprintSchema,
  summary: z2.string().trim().min(1).max(1e3)
}).strict().superRefine((plan, ctx) => {
  issueDuplicateIds(ctx, plan.days.map(({ date }) => date), ["days"], "Plan dates must be unique");
  issueDuplicateIds(ctx, plan.dailyUnitIds, ["dailyUnitIds"], "Daily unit IDs must be unique");
  const placements = plan.days.flatMap((day, dayIndex) => [
    { dayIndex, slot: "primary", unitId: day.primaryUnitId },
    { dayIndex, slot: "stretch", unitId: day.stretchUnitId }
  ].filter((placement) => placement.unitId !== null));
  issueDuplicateIds(ctx, placements.map(({ unitId }) => unitId), ["days"], "A daily unit may be placed only once");
  const unitIds = new Set(plan.dailyUnitIds);
  placements.forEach(({ dayIndex, slot, unitId }) => {
    if (!unitIds.has(unitId)) ctx.addIssue({ code: "custom", path: ["days", dayIndex, `${slot}UnitId`], message: "Plan-day unit must be listed in dailyUnitIds" });
  });
  if (placements.length !== plan.dailyUnitIds.length || placements.some(({ unitId }) => !unitIds.has(unitId))) {
    ctx.addIssue({ code: "custom", path: ["dailyUnitIds"], message: "Every daily unit must have exactly one plan-day placement" });
  }
});
var planDiffItemSchema = z2.object({
  unitId: idSchema2,
  change: z2.enum(["added", "moved", "removed", "unchanged"]),
  fromDate: calendarDateSchema2.nullable(),
  toDate: calendarDateSchema2.nullable(),
  reason: z2.string().trim().min(1).max(1e3)
}).strict().superRefine((item, ctx) => {
  const invalid = item.change === "added" && (item.fromDate !== null || item.toDate === null) || item.change === "removed" && (item.fromDate === null || item.toDate !== null) || item.change === "moved" && (item.fromDate === null || item.toDate === null || item.fromDate === item.toDate) || item.change === "unchanged" && (item.fromDate === null || item.toDate === null || item.fromDate !== item.toDate);
  if (invalid) ctx.addIssue({ code: "custom", message: "Diff dates must match the change kind" });
});
var planDiffSchema = z2.object({
  id: idSchema2,
  basePlanVersionId: idSchema2,
  candidatePlanVersionId: idSchema2,
  items: z2.array(planDiffItemSchema).min(1).max(2e3),
  previousEstimatedCompletionDate: calendarDateSchema2,
  nextEstimatedCompletionDate: calendarDateSchema2,
  summary: z2.string().trim().min(1).max(1e3),
  inputFingerprint: fingerprintSchema
}).strict().superRefine((diff, ctx) => {
  issueDuplicateIds(ctx, diff.items.map(({ unitId }) => unitId), ["items"], "Diff unit IDs must be unique");
});
var unitEventInputSchema = z2.discriminatedUnion("kind", [
  z2.object({ kind: z2.literal("completed"), unitId: idSchema2, actualMinutes: z2.number().int().min(0).max(720).nullable(), planningDate: calendarDateSchema2 }).strict(),
  z2.object({ kind: z2.literal("delayed"), unitId: idSchema2, planningDate: calendarDateSchema2 }).strict(),
  z2.object({ kind: z2.literal("skipped"), unitId: idSchema2, planningDate: calendarDateSchema2 }).strict(),
  z2.object({ kind: z2.literal("too_hard"), unitId: idSchema2, planningDate: calendarDateSchema2 }).strict(),
  z2.object({ kind: z2.literal("already_known"), unitId: idSchema2, planningDate: calendarDateSchema2 }).strict()
]);
var planningEventInputSchema = z2.discriminatedUnion("kind", [
  ...unitEventInputSchema.options,
  z2.object({ kind: z2.literal("availability_changed"), availability: availabilityVersionSchema, planningDate: calendarDateSchema2 }).strict()
]);
var eventMetadataSchema = z2.object({
  eventId: idSchema2,
  mutationId: idSchema2,
  sequence: z2.number().int().positive(),
  targetPlanVersionId: idSchema2,
  occurredAt: timestampSchema
}).strict();
var decisionEventSchema = z2.discriminatedUnion("kind", [
  z2.object({ kind: z2.literal("replan_accepted"), candidatePlanVersionId: idSchema2 }).strict(),
  z2.object({ kind: z2.literal("replan_discarded"), candidatePlanVersionId: idSchema2 }).strict()
]);
var planningEventSchema = z2.union([
  ...planningEventInputSchema.options.map((event) => event.extend(eventMetadataSchema.shape).strict()),
  ...decisionEventSchema.options.map((event) => event.extend(eventMetadataSchema.shape).strict())
]).superRefine((event, ctx) => {
  if (new TextEncoder().encode(JSON.stringify(event)).byteLength > 32 * 1024) {
    ctx.addIssue({ code: "custom", message: "Planning event must not exceed 32 KiB serialized" });
  }
});
var planningWorkspaceSchema = z2.object({
  id: idSchema2,
  goalId: idSchema2,
  revision: z2.number().int().min(0),
  lastSequence: z2.number().int().min(0),
  audit: skillAuditVersionSchema,
  availability: availabilityVersionSchema,
  availabilityVersions: z2.array(availabilityVersionSchema).min(1).max(500),
  target: planningTargetSchema,
  pathVersions: z2.array(learningPathVersionSchema).min(1).max(500),
  planVersions: z2.array(planVersionSchema).min(1).max(500),
  dailyUnits: z2.array(dailyUnitSchema).max(2e3),
  events: z2.array(planningEventSchema).max(5e3),
  activePathVersionId: idSchema2,
  activePlanVersionId: idSchema2,
  pendingPlanVersionId: idSchema2.nullable()
}).strict().superRefine((workspace, ctx) => {
  issueDuplicateIds(ctx, workspace.pathVersions.map(({ id }) => id), ["pathVersions"], "Path version IDs must be unique");
  issueDuplicateIds(ctx, workspace.planVersions.map(({ id }) => id), ["planVersions"], "Plan version IDs must be unique");
  issueDuplicateIds(ctx, workspace.availabilityVersions.map(({ id }) => id), ["availabilityVersions"], "Availability version IDs must be unique");
  issueDuplicateIds(ctx, workspace.dailyUnits.map(({ planVersionId, id }) => `${planVersionId}:${id}`), ["dailyUnits"], "Daily unit IDs must be unique within a plan version");
  issueDuplicateIds(ctx, workspace.events.map(({ eventId }) => eventId), ["events"], "Event IDs must be unique");
  issueDuplicateIds(ctx, workspace.events.map(({ mutationId }) => mutationId), ["events"], "Event mutation IDs must be unique");
  issueDuplicateIds(ctx, workspace.events.map(({ sequence }) => String(sequence)), ["events"], "Event sequences must be unique");
  const paths = new Map(workspace.pathVersions.map((path) => [path.id, path]));
  const plans = new Map(workspace.planVersions.map((plan) => [plan.id, plan]));
  const availabilityVersions = new Map(workspace.availabilityVersions.map((availability) => [availability.id, availability]));
  const units = new Map(workspace.dailyUnits.map((unit) => [`${unit.planVersionId}:${unit.id}`, unit]));
  if (!paths.has(workspace.activePathVersionId)) ctx.addIssue({ code: "custom", path: ["activePathVersionId"], message: "Active path must resolve" });
  if (!plans.has(workspace.activePlanVersionId)) ctx.addIssue({ code: "custom", path: ["activePlanVersionId"], message: "Active plan must resolve" });
  if (workspace.pendingPlanVersionId !== null && !plans.has(workspace.pendingPlanVersionId)) ctx.addIssue({ code: "custom", path: ["pendingPlanVersionId"], message: "Pending plan must resolve" });
  const currentAvailability = availabilityVersions.get(workspace.availability.id);
  if (!currentAvailability || currentAvailability.inputFingerprint !== workspace.availability.inputFingerprint || JSON.stringify(currentAvailability) !== JSON.stringify(workspace.availability)) {
    ctx.addIssue({ code: "custom", path: ["availability"], message: "Current availability must match a historical availability snapshot" });
  }
  workspace.dailyUnits.forEach((unit, unitIndex) => {
    if (!plans.has(unit.planVersionId)) ctx.addIssue({ code: "custom", path: ["dailyUnits", unitIndex, "planVersionId"], message: "Daily unit plan version must resolve" });
  });
  workspace.pathVersions.forEach((path, pathIndex) => {
    if (path.auditVersionId !== workspace.audit.id) ctx.addIssue({ code: "custom", path: ["pathVersions", pathIndex, "auditVersionId"], message: "Path audit must be the workspace audit" });
    if (!availabilityVersions.has(path.availabilityVersionId)) ctx.addIssue({ code: "custom", path: ["pathVersions", pathIndex, "availabilityVersionId"], message: "Path availability must resolve" });
    if (path.targetId !== workspace.target.id) ctx.addIssue({ code: "custom", path: ["pathVersions", pathIndex, "targetId"], message: "Path target must be the workspace target" });
  });
  workspace.planVersions.forEach((plan, planIndex) => {
    if (!paths.has(plan.pathVersionId)) ctx.addIssue({ code: "custom", path: ["planVersions", planIndex, "pathVersionId"], message: "Plan path must resolve" });
    if (plan.baseVersionId !== null && !plans.has(plan.baseVersionId)) ctx.addIssue({ code: "custom", path: ["planVersions", planIndex, "baseVersionId"], message: "Plan base version must resolve" });
    plan.dailyUnitIds.forEach((unitId, unitIndex) => {
      const unit = units.get(`${plan.id}:${unitId}`);
      if (!unit) ctx.addIssue({ code: "custom", path: ["planVersions", planIndex, "dailyUnitIds", unitIndex], message: "Plan daily unit must resolve within its plan version" });
    });
    plan.days.forEach((day, dayIndex) => [
      { slot: "primary", unitId: day.primaryUnitId },
      { slot: "stretch", unitId: day.stretchUnitId }
    ].forEach(({ slot, unitId }) => {
      if (unitId === null) return;
      const unit = units.get(`${plan.id}:${unitId}`);
      if (!unit || unit.scheduledDate !== day.date || unit.slot !== slot) {
        ctx.addIssue({ code: "custom", path: ["planVersions", planIndex, "days", dayIndex, `${slot}UnitId`], message: "Placed daily unit must match its day and slot" });
      }
    }));
  });
  workspace.events.forEach((event, eventIndex) => {
    if (!plans.has(event.targetPlanVersionId)) ctx.addIssue({ code: "custom", path: ["events", eventIndex, "targetPlanVersionId"], message: "Event target plan must resolve" });
    if (event.kind === "availability_changed") {
      const availability = availabilityVersions.get(event.availability.id);
      if (!availability || availability.inputFingerprint !== event.availability.inputFingerprint || JSON.stringify(availability) !== JSON.stringify(event.availability)) {
        ctx.addIssue({ code: "custom", path: ["events", eventIndex, "availability"], message: "Availability-change event must match a retained availability snapshot" });
      }
    }
    if ("unitId" in event) {
      const targetPlan = plans.get(event.targetPlanVersionId);
      if (!units.has(`${event.targetPlanVersionId}:${event.unitId}`) || !targetPlan?.dailyUnitIds.includes(event.unitId)) {
        ctx.addIssue({ code: "custom", path: ["events", eventIndex, "unitId"], message: "Event unit must resolve within its target plan" });
      }
    }
    if ("candidatePlanVersionId" in event && !plans.has(event.candidatePlanVersionId)) ctx.addIssue({ code: "custom", path: ["events", eventIndex, "candidatePlanVersionId"], message: "Candidate plan must resolve" });
  });
  workspace.events.forEach((event, eventIndex) => {
    if (event.sequence !== eventIndex + 1) ctx.addIssue({ code: "custom", path: ["events", eventIndex, "sequence"], message: "Event sequences must be ordered and gap-free" });
  });
  if (workspace.lastSequence !== workspace.events.length) ctx.addIssue({ code: "custom", path: ["lastSequence"], message: "Last sequence must equal the terminal event sequence" });
});
var planningMutationResultSchema = z2.object({
  outcome: z2.enum(["active", "proposed", "accepted", "discarded"]),
  workspace: planningWorkspaceSchema,
  diff: planDiffSchema.nullable()
}).strict();
var MAX_PLANNING_WORKSPACE_BYTES = 4 * 1024 * 1024;

// app/contracts/research.ts
var idSchema3 = z3.string().max(256).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/u);
var minuteSchema2 = z3.number().int().positive().max(720);
var researchRoleSummarySchema = z3.object({
  id: idSchema3,
  name: z3.string().trim().min(2).max(120),
  summary: z3.string().trim().min(20).max(500)
}).strict();
var researchCandidateSkillSchema = z3.object({
  id: idSchema3,
  name: z3.string().trim().min(2).max(120),
  category: z3.enum(["foundations", "frontend", "backend", "data", "quality", "cloud", "ai", "product"]),
  importance: z3.enum(["core", "strong", "advantage"]),
  why: z3.string().trim().min(12).max(360),
  masteryCriteria: z3.array(z3.string().trim().min(12).max(240)).min(2).max(8),
  resourceIds: z3.array(idSchema3).min(1).max(32)
}).strict();
var researchPrerequisiteEdgeSchema = z3.object({
  skillId: idSchema3,
  prerequisiteSkillId: idSchema3
}).strict();
var researchCandidateResourceSchema = z3.object({
  id: idSchema3,
  title: z3.string().trim().min(3).max(180),
  url: z3.string().trim().min(1).max(2048),
  provider: z3.string().trim().min(2).max(120),
  language: z3.enum(["en", "zh-CN"]),
  cost: z3.enum(["free", "paid", "mixed"]),
  format: z3.enum(["documentation", "course", "guide", "reference", "practice"]),
  sourceTier: z3.enum(["primary", "institutional", "practitioner", "community"]),
  purpose: z3.enum(["primary", "alternative", "reference"]),
  estimatedMinutes: minuteSchema2.nullable(),
  skillIds: z3.array(idSchema3).min(1).max(64)
}).strict();
var researchCandidateStageSchema = z3.object({
  id: idSchema3,
  name: z3.string().trim().min(2).max(120),
  weeks: z3.number().int().positive().max(52),
  outcome: z3.string().trim().min(12).max(360),
  skillIds: z3.array(idSchema3).min(1).max(64)
}).strict();
var researchCandidateUnitStepSchema = z3.object({
  id: idSchema3,
  label: z3.string().trim().min(1).max(180),
  minutes: minuteSchema2
}).strict();
var researchCandidateUnitCheckpointSchema = z3.object({
  id: idSchema3,
  label: z3.string().trim().min(1).max(180),
  stepIds: z3.array(idSchema3).min(1).max(12),
  estimatedMinutes: minuteSchema2
}).strict();
var researchCandidateUnitTemplateSchema = z3.object({
  id: idSchema3,
  skillId: idSchema3,
  kind: z3.enum(["learn", "calibrate", "reinforce"]),
  title: z3.string().trim().min(1).max(180),
  objective: z3.string().trim().min(1).max(500),
  whyNow: z3.string().trim().min(1).max(500),
  primaryResourceId: idSchema3,
  alternativeResourceIds: z3.array(idSchema3).max(8),
  steps: z3.array(researchCandidateUnitStepSchema).min(1).max(12),
  checkpoints: z3.array(researchCandidateUnitCheckpointSchema).max(8),
  buildTask: z3.string().trim().min(1).max(800),
  completionCriteria: z3.array(z3.string().trim().min(1).max(500)).min(1).max(8),
  proofRequirement: z3.string().trim().min(1).max(800),
  rubric: z3.array(z3.string().trim().min(1).max(500)).min(1).max(6),
  estimatedMinutes: minuteSchema2
}).strict();
var researchCandidateEvidenceSchema = z3.object({
  id: idSchema3,
  skillId: idSchema3,
  resourceId: idSchema3
}).strict();
var researchCandidateSchema = z3.object({
  role: researchRoleSummarySchema,
  skills: z3.array(researchCandidateSkillSchema).min(1).max(64),
  prerequisiteEdges: z3.array(researchPrerequisiteEdgeSchema).max(4096),
  resources: z3.array(researchCandidateResourceSchema).min(1).max(256),
  stages: z3.array(researchCandidateStageSchema).min(1).max(24),
  unitTemplates: z3.array(researchCandidateUnitTemplateSchema).min(1).max(512),
  evidence: z3.array(researchCandidateEvidenceSchema).min(1).max(512)
}).strict();
var researchStateSchema = z3.enum([
  "queued",
  "researching",
  "validating",
  "ready",
  "needs-review",
  "failed"
]);
var researchIssueCodeSchema = z3.enum([
  "invalid-schema",
  "invalid-graph",
  "invalid-registry",
  "missing-skill-source",
  "missing-core-authority",
  "unsafe-url",
  "unreferenced-url",
  "missing-free-alternative",
  "missing-unit",
  "minute-mismatch",
  "unsafe-content"
]);
var sortedIssueCodesSchema = z3.array(researchIssueCodeSchema).max(64).superRefine((issueCodes, ctx) => {
  const sortedUniqueCodes = [...new Set(issueCodes)].sort();
  if (issueCodes.some((code, index) => code !== sortedUniqueCodes[index])) {
    ctx.addIssue({ code: "custom", message: "Issue codes must be sorted and unique" });
  }
});
var researchQualityReportSchema = z3.object({
  passed: z3.boolean(),
  issueCodes: sortedIssueCodesSchema,
  skillCount: z3.number().int().min(0).max(64),
  sourceCount: z3.number().int().min(0).max(256),
  unitCount: z3.number().int().min(0).max(512),
  observedAt: calendarDateSchema
}).strict().superRefine((report, ctx) => {
  if (report.passed !== (report.issueCodes.length === 0)) {
    ctx.addIssue({ code: "custom", path: ["passed"], message: "Passed must match the absence of issues" });
  }
});
var providerCitationAnnotationSchema = z3.object({
  type: z3.literal("url_citation"),
  url: z3.string().trim().min(1).max(2048),
  title: z3.string().trim().min(1).max(500)
}).strict();
var providerUsageSchema = /* @__PURE__ */ (() => {
  const providerTokenCountSchema = z3.number().int().min(0).max(1e7);
  return z3.object({
    promptTokens: providerTokenCountSchema,
    completionTokens: providerTokenCountSchema,
    totalTokens: providerTokenCountSchema,
    costMicros: z3.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    webSearchRequests: z3.number().int().min(0).max(10)
  }).strict().superRefine((usage, ctx) => {
    if (usage.totalTokens !== usage.promptTokens + usage.completionTokens) {
      ctx.addIssue({ code: "custom", path: ["totalTokens"], message: "Total tokens must equal prompt plus completion tokens" });
    }
  });
})();
var auditedSourceSchema = z3.object({
  canonicalUrl: z3.string().trim().min(1).max(2048),
  title: z3.string().trim().min(1).max(500),
  hostname: z3.string().trim().min(1).max(253),
  sourceTier: z3.enum(["primary", "institutional", "practitioner", "community"]),
  observedAt: calendarDateSchema,
  citationHash: z3.string().trim().min(1).max(256)
}).strict();
var researchVersionSchema = z3.string().trim().min(1).max(64);
var researchBlueprintSchema = roleBlueprintSchema.extend({
  id: idSchema3,
  version: roleBlueprintSchema.shape.version.max(32),
  skills: z3.array(roleBlueprintSchema.shape.skills.element.extend({
    id: idSchema3,
    masteryCriteria: researchCandidateSkillSchema.shape.masteryCriteria,
    prerequisiteIds: z3.array(idSchema3).max(64),
    resourceIds: researchCandidateSkillSchema.shape.resourceIds
  })).min(1).max(64),
  resources: z3.array(roleBlueprintSchema.shape.resources.element.extend({
    id: idSchema3,
    url: roleBlueprintSchema.shape.resources.element.shape.url.max(2048),
    estimatedMinutes: minuteSchema2.nullable(),
    skillIds: researchCandidateResourceSchema.shape.skillIds
  })).min(1).max(256),
  phases: z3.array(roleBlueprintSchema.shape.phases.element.extend({
    id: idSchema3,
    weeks: researchCandidateStageSchema.shape.weeks,
    skillIds: researchCandidateStageSchema.shape.skillIds
  })).min(1).max(24)
});
var researchPackageSchema = z3.object({
  id: idSchema3,
  blueprint: researchBlueprintSchema,
  registry: unitRegistrySchema,
  sourceEvidence: z3.array(auditedSourceSchema).min(1).max(256),
  qualityReport: researchQualityReportSchema,
  promptVersion: researchVersionSchema,
  inputSchemaVersion: researchVersionSchema,
  outputSchemaVersion: researchVersionSchema,
  qualityVersion: researchVersionSchema,
  modelConfigVersion: researchVersionSchema,
  contentFingerprint: z3.string().trim().min(16).max(256),
  observedAt: calendarDateSchema,
  expiresAt: calendarDateSchema
}).strict();
var researchPlanningDataSchema = researchPackageSchema.pick({
  id: true,
  blueprint: true,
  registry: true
});
var publicRunIdentityShape = {
  id: idSchema3,
  role: z3.string().trim().min(2).max(160),
  locale: z3.enum(["zh-CN", "en-US"]),
  backgroundAccepted: z3.boolean().default(false)
};
var activeResearchRunPublicViewSchema = z3.object({
  ...publicRunIdentityShape,
  state: z3.enum(["queued", "researching", "validating"]),
  retryable: z3.literal(false)
}).strict();
var readyResearchRunPublicViewSchema = z3.object({
  ...publicRunIdentityShape,
  state: z3.literal("ready"),
  retryable: z3.literal(false),
  packageId: idSchema3,
  summary: z3.string().trim().min(20).max(500),
  skillCount: z3.number().int().min(1).max(64),
  sourceCount: z3.number().int().min(1).max(256),
  observedAt: calendarDateSchema,
  quality: z3.object({
    passed: z3.literal(true),
    issueCodes: z3.array(researchIssueCodeSchema).max(0)
  }).strict(),
  planningData: researchPlanningDataSchema
}).strict();
var needsReviewResearchRunPublicViewSchema = z3.object({
  ...publicRunIdentityShape,
  state: z3.literal("needs-review"),
  retryable: z3.boolean(),
  quality: z3.object({
    issueCodes: sortedIssueCodesSchema,
    skillCount: z3.number().int().min(0).max(64),
    sourceCount: z3.number().int().min(0).max(256),
    unitCount: z3.number().int().min(0).max(512)
  }).strict().superRefine((quality, ctx) => {
    if (quality.issueCodes.length === 0) {
      ctx.addIssue({ code: "custom", path: ["issueCodes"], message: "Needs review requires at least one issue" });
    }
  })
}).strict();
var researchPublicFailureCategorySchema = z3.enum([
  "timeout",
  "rate-limited",
  "allowance-reached",
  "service-unavailable",
  "content-rejected",
  "invalid-result",
  "internal"
]);
var failedResearchRunPublicViewSchema = z3.object({
  ...publicRunIdentityShape,
  state: z3.literal("failed"),
  failureCategory: researchPublicFailureCategorySchema,
  retryable: z3.boolean()
}).strict();
var researchRunPublicViewSchema = z3.discriminatedUnion("state", [
  activeResearchRunPublicViewSchema,
  readyResearchRunPublicViewSchema,
  needsReviewResearchRunPublicViewSchema,
  failedResearchRunPublicViewSchema
]);
var researchRequestSchema = z3.object({
  mutationId: z3.string().trim().min(8).max(128).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/u),
  role: z3.string().trim().min(2).max(160),
  locale: z3.enum(["zh-CN", "en-US"])
}).strict();
var researchRetryRequestSchema = z3.object({
  mutationId: researchRequestSchema.shape.mutationId
}).strict();
var researchRecoverRequestSchema = z3.discriminatedUnion("kind", [
  researchRequestSchema.extend({ kind: z3.literal("start") }).strict(),
  researchRequestSchema.extend({
    kind: z3.literal("retry"),
    sourceRunId: researchPackageSchema.shape.id
  }).strict()
]);
var researchErrorCodeSchema = z3.enum([
  "UNAUTHENTICATED",
  "INVALID_INPUT",
  "NOT_FOUND",
  "CONFLICT",
  "RATE_LIMITED",
  "ALLOWANCE_REACHED",
  "RESEARCH_NEEDS_REVIEW",
  "RESEARCH_UNAVAILABLE",
  "INTERNAL"
]);
var researchRecoverySchema = z3.enum([
  "sign-in",
  "refresh",
  "retry",
  "use-flagship",
  "retry-or-flagship"
]);
var researchRequestIdSchema = z3.string().min(1).max(128).refine((value) => value === value.trim() && !/[\u0000-\u001f\u007f-\u009f]/u.test(value));
var researchEligibilityViewSchema = z3.object({
  eligible: z3.boolean(),
  requestId: researchRequestIdSchema
}).strict();
var expectedRecovery = {
  UNAUTHENTICATED: "sign-in",
  INVALID_INPUT: void 0,
  NOT_FOUND: void 0,
  CONFLICT: "refresh",
  RATE_LIMITED: "retry",
  ALLOWANCE_REACHED: "use-flagship",
  RESEARCH_NEEDS_REVIEW: "retry-or-flagship",
  RESEARCH_UNAVAILABLE: "retry-or-flagship",
  INTERNAL: void 0
};
var researchPublicErrorSchema = z3.object({
  code: researchErrorCodeSchema,
  message: z3.string().trim().min(1).max(240),
  recovery: researchRecoverySchema.optional()
}).strict().superRefine((error, context) => {
  if (error.recovery !== expectedRecovery[error.code]) {
    context.addIssue({ code: "custom", path: ["recovery"], message: "Recovery must match the public Research error" });
  }
});
var researchSuccessEnvelopeSchema = z3.object({
  run: researchRunPublicViewSchema,
  requestId: researchRequestIdSchema
}).strict();
function expectedRunError(run) {
  if (run.state === "needs-review") return "RESEARCH_NEEDS_REVIEW";
  if (run.state !== "failed") return null;
  if (run.failureCategory === "rate-limited") return "RATE_LIMITED";
  if (run.failureCategory === "allowance-reached") return "ALLOWANCE_REACHED";
  return "RESEARCH_UNAVAILABLE";
}
var researchErrorEnvelopeSchema = z3.object({
  error: researchPublicErrorSchema,
  run: researchRunPublicViewSchema.optional(),
  requestId: researchRequestIdSchema
}).strict().superRefine((envelope, context) => {
  if (envelope.run && expectedRunError(envelope.run) !== envelope.error.code) {
    context.addIssue({ code: "custom", path: ["run"], message: "Terminal run contradicts the public Research error" });
  }
});
var researchHttpEnvelopeSchema = z3.union([
  researchSuccessEnvelopeSchema,
  researchErrorEnvelopeSchema
]);

// app/server/research/provider.ts
import { z as z5 } from "zod";

// app/server/research/result-diagnostic.ts
import { z as z4 } from "zod";
var providerDiagnosticReasons = [
  "choices-invalid",
  "finish-not-stop",
  "content-invalid",
  "annotations-invalid",
  "upstream-error",
  "provider-error",
  "filtered"
];
var providerUsageIssueCodes = [
  "usage-shape",
  "prompt-tokens",
  "completion-tokens",
  "total-tokens",
  "token-total-mismatch",
  "cost",
  "web-search-requests"
];
var providerWebSearchContainerStates = ["unavailable", "missing", "null", "object", "invalid"];
var providerWebSearchRequestStates = [
  "unavailable",
  "missing",
  "null",
  "non-number",
  "non-finite",
  "non-integer",
  "out-of-range",
  "valid"
];
var providerWebSearchUsageSources = ["legacy", "details", "both", "missing", "invalid", "conflict"];
var researchAttemptErrorCodes = [
  "repair-required",
  "invalid-result",
  "missing-key",
  "timeout",
  "rate",
  "balance",
  "unavailable",
  "filtered",
  "invalid-transport"
];
var researchCandidateDiagnosticReasons = [
  "content-limit",
  "json-syntax",
  "node-limit",
  "depth-limit",
  "string-limit",
  "array-limit",
  "object-limit",
  "schema-rejected"
];
var researchCandidateIssueCodes = [
  "invalid-type",
  "invalid-value",
  "invalid-format",
  "too-small",
  "too-big",
  "unrecognized-keys",
  "other"
];
var sortedCandidateIssuesSchema = z4.array(z4.object({
  path: z4.string(),
  code: z4.enum(researchCandidateIssueCodes)
}).strict()).max(16).superRefine((issues, context) => {
  const sortedUnique = [...new Map(issues.map((issue) => [`${issue.path}\0${issue.code}`, issue])).values()].sort((left, right) => left.path.localeCompare(right.path) || left.code.localeCompare(right.code));
  if (issues.some((issue, index) => issue.path !== sortedUnique[index]?.path || issue.code !== sortedUnique[index]?.code)) {
    context.addIssue({ code: "custom", message: "Candidate issues must be sorted and unique" });
  }
});
var researchCandidateDiagnosticSchema = z4.object({
  outcome: z4.enum(["accepted", "rejected"]),
  reason: z4.enum(researchCandidateDiagnosticReasons).nullable(),
  issues: sortedCandidateIssuesSchema,
  truncated: z4.boolean()
}).strict().superRefine((diagnostic, context) => {
  if (diagnostic.reason === null !== (diagnostic.outcome === "accepted")) {
    context.addIssue({ code: "custom", path: ["reason"], message: "Outcome and reason must agree" });
  }
  if (diagnostic.reason !== "schema-rejected" && (diagnostic.issues.length !== 0 || diagnostic.truncated)) {
    context.addIssue({ code: "custom", path: ["issues"], message: "Only schema rejection may include issues" });
  }
  if (diagnostic.truncated && diagnostic.issues.length !== 16) {
    context.addIssue({ code: "custom", path: ["truncated"], message: "A truncated diagnostic must retain the issue cap" });
  }
});
var sortedUsageIssueCodesSchema = z4.array(z4.enum(providerUsageIssueCodes)).max(7).superRefine((codes, context) => {
  const sortedUnique = [...new Set(codes)].sort();
  if (codes.some((code, index) => code !== sortedUnique[index])) {
    context.addIssue({ code: "custom", message: "Usage issue codes must be sorted and unique" });
  }
});
var providerWebSearchUsageDiagnosticSchema = z4.object({
  container: z4.enum(providerWebSearchContainerStates),
  requests: z4.enum(providerWebSearchRequestStates)
}).strict().superRefine((diagnostic, context) => {
  if (diagnostic.container === "object" && diagnostic.requests === "unavailable" || diagnostic.container !== "object" && diagnostic.requests !== "unavailable") {
    context.addIssue({ code: "custom", message: "Search container and request states must agree" });
  }
});
var providerResultDiagnosticSchema = z4.object({
  outcome: z4.enum(["accepted", "rejected"]),
  reason: z4.enum(providerDiagnosticReasons).nullable(),
  finishReasonState: z4.enum(["recognized", "missing", "invalid", "unrecognized", "unavailable"]),
  finishReason: z4.enum(["stop", "length", "tool_calls", "content_filter", "error"]).nullable(),
  usageIssueCodes: sortedUsageIssueCodesSchema,
  webSearchUsage: providerWebSearchUsageDiagnosticSchema,
  webSearchUsageDetails: providerWebSearchUsageDiagnosticSchema,
  webSearchUsageSource: z4.enum(providerWebSearchUsageSources)
}).strict().superRefine((diagnostic, context) => {
  if (diagnostic.reason === null !== (diagnostic.outcome === "accepted")) {
    context.addIssue({ code: "custom", path: ["reason"], message: "Outcome and reason must agree" });
  }
  if (diagnostic.finishReason !== null !== (diagnostic.finishReasonState === "recognized")) {
    context.addIssue({ code: "custom", path: ["finishReason"], message: "Finish reason and state must agree" });
  }
  const legacyState = diagnostic.webSearchUsage.container === "unavailable" ? "unavailable" : diagnostic.webSearchUsage.container === "missing" ? "missing" : diagnostic.webSearchUsage.requests === "valid" ? "valid" : "invalid";
  const detailsState = diagnostic.webSearchUsageDetails.container === "unavailable" ? "unavailable" : diagnostic.webSearchUsageDetails.container === "missing" ? "missing" : diagnostic.webSearchUsageDetails.requests === "valid" ? "valid" : "invalid";
  const sourceValid = legacyState === "unavailable" || detailsState === "unavailable" ? legacyState === "unavailable" && detailsState === "unavailable" && diagnostic.webSearchUsageSource === "invalid" : legacyState === "invalid" || detailsState === "invalid" ? diagnostic.webSearchUsageSource === "invalid" : legacyState === "missing" && detailsState === "missing" ? diagnostic.webSearchUsageSource === "missing" : legacyState === "valid" && detailsState === "missing" ? diagnostic.webSearchUsageSource === "legacy" : legacyState === "missing" && detailsState === "valid" ? diagnostic.webSearchUsageSource === "details" : diagnostic.webSearchUsageSource === "both" || diagnostic.webSearchUsageSource === "conflict";
  if (!sourceValid) {
    context.addIssue({
      code: "custom",
      path: ["webSearchUsageSource"],
      message: "Search usage shapes and source must agree"
    });
  }
});
var researchAttemptDiagnosticSchema = z4.object({
  status: z4.enum(["accepted", "rejected", "failed"]),
  errorCode: z4.enum(researchAttemptErrorCodes).nullable(),
  charged: z4.union([z4.boolean(), z4.literal("unknown")])
}).strict().superRefine((diagnostic, context) => {
  if (diagnostic.status === "accepted" && diagnostic.errorCode !== null || diagnostic.status !== "accepted" && diagnostic.errorCode === null || diagnostic.status !== "failed" && diagnostic.charged === false || diagnostic.status === "rejected" && diagnostic.errorCode !== "invalid-result" && diagnostic.errorCode !== "repair-required" || diagnostic.status === "failed" && (diagnostic.errorCode === "invalid-result" || diagnostic.errorCode === "repair-required")) {
    context.addIssue({ code: "custom", message: "Inconsistent Research attempt diagnostic" });
  }
});
var researchRunDiagnosticSchema = z4.object({
  errorCode: z4.enum([
    "missing-key",
    "timeout",
    "rate",
    "balance",
    "unavailable",
    "filtered",
    "invalid-transport",
    "invalid-result",
    "result-too-large",
    "unrecognized"
  ]).nullable(),
  quality: z4.object({
    passed: z4.boolean(),
    issueCodes: z4.array(researchIssueCodeSchema).max(64),
    skillCount: z4.number().int().min(0).max(64),
    sourceCount: z4.number().int().min(0).max(256),
    unitCount: z4.number().int().min(0).max(512)
  }).strict().nullable()
}).strict();

// app/server/research/provider.ts
var RESEARCH_SEARCH_POLICY = Object.freeze({
  policyId: "openrouter-web-search-exa-fast-v2",
  engine: "exa",
  mode: "fast",
  maxUses: 10,
  maxResults: 5,
  maxTotalResults: 50,
  maxCharacters: 2e3
});
var RESEARCH_PROVIDER_VERSIONS = Object.freeze({
  promptVersion: "research-prompt-v2",
  inputSchemaVersion: "research-input-v1",
  outputSchemaVersion: "research-output-v1",
  qualityVersion: "research-quality-v1",
  modelConfigVersion: "research-model-config-v2"
});
var RESEARCH_PROVIDER_LIMITS = Object.freeze({ requestBytes: 262144, responseBytes: 524288, contentBytes: 196608 });
var roleSchema = z5.string().min(2).max(640).regex(/^[^\u0000-\u001f\u007f-\u009f]+$/u).transform((value) => value.normalize("NFKC").trim().replace(/\s+/gu, " ")).pipe(z5.string().min(2).max(160));
var requestSchema = z5.object({ role: roleSchema, locale: z5.enum(["en-US", "zh-CN"]) }).strict();
function fitsUtf8(value, maximum) {
  return value.length <= maximum && new TextEncoder().encode(value).byteLength <= maximum;
}

// app/server/research/executor/begin.ts
import { z as z8 } from "zod";

// app/server/research/execution-policy.ts
var KIMI_RESEARCH_EXECUTION_POLICY = Object.freeze({
  profileId: "kimi-low-output32k-v3",
  model: "moonshotai/kimi-k3",
  reasoningEffort: "low",
  maxOutputTokens: 32768,
  outputPolicyVersion: "kimi-complete-quality-v2",
  researchTimeoutMs: 12e5,
  activeTtlMs: 126e4
});

// app/server/research/executor/job.ts
import { z as z7 } from "zod";

// app/server/research/executor/auth.ts
import { z as z6 } from "zod";
var BRIDGE_AUTH_PROTOCOL = "arc-research-bridge-v1";
var contextSchema = z6.object({
  direction: z6.enum(["site-to-executor", "executor-to-site"]),
  kind: z6.enum(["request", "response"]),
  method: z6.enum(["GET", "POST"]),
  path: z6.string().min(1).max(256).regex(/^\/[A-Za-z0-9/_-]*$/u),
  audience: z6.string().max(256).refine((value) => {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && url.origin === value && !url.username && !url.password;
    } catch {
      return false;
    }
  }),
  jobId: z6.union([z6.uuid(), z6.literal("collection")]),
  status: z6.number().int().min(200).max(599).nullable()
}).strict().refine((value) => value.kind === "request" ? value.status === null : value.status !== null);

// app/server/research/executor/job.ts
var BRIDGE_EXECUTOR_MODE = "cloudflare-workflow-v1";
var BRIDGE_QUEUE_TTL_MS = 12e4;
var time = z7.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var fingerprint = z7.string().length(35).regex(/^p2-[0-9a-f]{32}$/u);
var requestId = z7.string().min(1).max(256).refine((value) => value === value.trim() && !/[\u0000-\u001f\u007f]/u.test(value));
var bridgeJobSchema = z7.object({
  protocol: z7.literal(BRIDGE_AUTH_PROTOCOL),
  executor: z7.literal(BRIDGE_EXECUTOR_MODE),
  jobId: z7.uuid(),
  runId: researchPackageSchema.shape.id,
  requestId,
  inputFingerprint: fingerprint,
  configFingerprint: fingerprint,
  policyId: z7.literal(KIMI_RESEARCH_EXECUTION_POLICY.profileId),
  role: z7.string().min(2).max(640),
  locale: z7.enum(["en-US", "zh-CN"]),
  createdAt: time.max(
    Number.MAX_SAFE_INTEGER - BRIDGE_QUEUE_TTL_MS - KIMI_RESEARCH_EXECUTION_POLICY.activeTtlMs
  ),
  queueExpiresAt: time
}).strict().refine(
  (value) => value.queueExpiresAt === value.createdAt + BRIDGE_QUEUE_TTL_MS
);

// app/server/research/executor/begin.ts
var BridgeBeginError = class extends Error {
  constructor(code) {
    super(`Research bridge begin failure: ${code}`);
    this.code = code;
    this.name = "BridgeBeginError";
  }
};
var MAX_SAFE_TIME = Number.MAX_SAFE_INTEGER;
var ACTIVE_TTL_MS = KIMI_RESEARCH_EXECUTION_POLICY.activeTtlMs;
var RESEARCH_TIMEOUT_MS = KIMI_RESEARCH_EXECUTION_POLICY.researchTimeoutMs;
var time2 = z8.number().int().min(0).max(MAX_SAFE_TIME);
var grantSchema = z8.object({
  protocol: z8.literal(BRIDGE_AUTH_PROTOCOL),
  jobId: z8.uuid(),
  requestHash: z8.string().length(64).regex(/^[0-9a-f]{64}$/u),
  beganAt: time2.max(MAX_SAFE_TIME - ACTIVE_TTL_MS),
  executionExpiresAt: time2
}).strict().refine((value) => value.executionExpiresAt === value.beganAt + ACTIVE_TTL_MS);
var replySchema = z8.object({
  grant: grantSchema,
  observedAt: time2,
  remainingMs: time2.max(ACTIVE_TTL_MS)
}).strict().refine((value) => value.observedAt >= value.grant.beganAt && value.remainingMs === Math.max(0, value.grant.executionExpiresAt - value.observedAt));
function invalidMessage() {
  throw new BridgeBeginError("invalid-message");
}
function parseBridgeBeginGrant(input) {
  try {
    const bytes = new TextEncoder().encode(canonicalJson(input));
    if (bytes.byteLength > BRIDGE_BODY_LIMITS.status) throw new Error();
    return Object.freeze(grantSchema.parse(decodeBridgeJson(bytes)));
  } catch {
    return invalidMessage();
  }
}

// app/server/research/executor/receipt.ts
var BRIDGE_RECEIPT_RETENTION_MS = 864e5;
var BridgeReceiptError = class extends Error {
  constructor(code) {
    super(`Research bridge receipt failure: ${code}`);
    this.code = code;
    this.name = "BridgeReceiptError";
  }
};
var safeTime = z9.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
var actualModelSchema = z9.string().min(1).max(128).regex(/^[a-zA-Z0-9][a-zA-Z0-9._:/-]*$/u).nullable();
var responseOutcomeSchema = z9.object({
  kind: z9.literal("response"),
  content: z9.string().min(1).max(RESEARCH_PROVIDER_LIMITS.contentBytes).refine(
    (value) => value.trim().length > 0 && fitsUtf8(value, RESEARCH_PROVIDER_LIMITS.contentBytes)
  ),
  annotations: z9.array(providerCitationAnnotationSchema).max(256),
  actualModel: actualModelSchema,
  usage: providerUsageSchema.nullable()
}).strict();
var errorOutcomeSchema = z9.object({
  kind: z9.literal("error"),
  code: z9.enum([
    "missing-key",
    "timeout",
    "rate",
    "balance",
    "unavailable",
    "filtered",
    "invalid-transport"
  ]),
  retryable: z9.boolean(),
  charged: z9.union([z9.boolean(), z9.literal("unknown")]),
  actualModel: actualModelSchema,
  usage: providerUsageSchema.nullable()
}).strict();
var responseMetadataOutcomeSchema = responseOutcomeSchema.omit({
  content: true,
  annotations: true
});
var receiptHashSchema = z9.string().length(64).regex(/^[0-9a-f]{64}$/u);
var receiptMetadataSchema = z9.object({
  grant: z9.unknown(),
  receiptHash: receiptHashSchema,
  producedAt: safeTime.max(Number.MAX_SAFE_INTEGER - BRIDGE_RECEIPT_RETENTION_MS),
  latencyMs: safeTime,
  outcome: z9.discriminatedUnion("kind", [responseMetadataOutcomeSchema, errorOutcomeSchema])
}).strict();
var receiptSchema = z9.object({
  grant: z9.unknown(),
  producedAt: safeTime.max(Number.MAX_SAFE_INTEGER - BRIDGE_RECEIPT_RETENTION_MS),
  latencyMs: safeTime,
  outcome: z9.discriminatedUnion("kind", [responseOutcomeSchema, errorOutcomeSchema])
}).strict();
function invalidMessage2() {
  throw new BridgeReceiptError("invalid-message");
}
function parseBridgeProviderReceipt(input) {
  try {
    const bytes = new TextEncoder().encode(canonicalJson(input));
    if (bytes.byteLength > BRIDGE_BODY_LIMITS.result) throw new Error();
    const value = receiptSchema.parse(decodeBridgeJson(bytes));
    const grant = parseBridgeBeginGrant(value.grant);
    const usage = value.outcome.usage === null ? null : Object.freeze({ ...value.outcome.usage });
    const outcome = value.outcome.kind === "response" ? Object.freeze({
      ...value.outcome,
      annotations: Object.freeze(value.outcome.annotations.map(
        (annotation) => Object.freeze({ ...annotation })
      )),
      usage
    }) : Object.freeze({ ...value.outcome, usage });
    return Object.freeze({
      grant,
      producedAt: value.producedAt,
      latencyMs: value.latencyMs,
      outcome
    });
  } catch {
    return invalidMessage2();
  }
}
function encodeBridgeProviderReceipt(input) {
  const bytes = new TextEncoder().encode(canonicalJson(parseBridgeProviderReceipt(input)));
  if (bytes.byteLength > BRIDGE_BODY_LIMITS.result) return invalidMessage2();
  return bytes;
}
function decodeBridgeProviderReceipt(bytes) {
  try {
    const actualBytes = bridgeByteLength(bytes);
    if (actualBytes === 0 || actualBytes > BRIDGE_BODY_LIMITS.result) throw new Error();
    return parseBridgeProviderReceipt(decodeBridgeJson(bytes));
  } catch {
    return invalidMessage2();
  }
}
async function hashBridgeProviderReceipt(input) {
  const bytes = encodeBridgeProviderReceipt(input);
  try {
    const digest = new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bytes));
    return Array.from(digest, (value) => value.toString(16).padStart(2, "0")).join("");
  } catch {
    throw new BridgeReceiptError("unavailable");
  }
}
function parseBridgeReceiptMetadata(input) {
  try {
    const bytes = new TextEncoder().encode(canonicalJson(input));
    if (bytes.byteLength === 0 || bytes.byteLength > BRIDGE_BODY_LIMITS.status) throw new Error();
    const value = receiptMetadataSchema.parse(decodeBridgeJson(bytes));
    const grant = parseBridgeBeginGrant(value.grant);
    const usage = value.outcome.usage === null ? null : Object.freeze({ ...value.outcome.usage });
    const outcome = Object.freeze({ ...value.outcome, usage });
    return Object.freeze({
      grant,
      receiptHash: value.receiptHash,
      producedAt: value.producedAt,
      latencyMs: value.latencyMs,
      outcome
    });
  } catch {
    return invalidMessage2();
  }
}
async function summarizeBridgeProviderReceipt(input) {
  const receipt = parseBridgeProviderReceipt(input);
  const hashPromise = hashBridgeProviderReceipt(receipt);
  const receiptHash = await hashPromise;
  return parseBridgeReceiptMetadata({
    grant: receipt.grant,
    receiptHash,
    producedAt: receipt.producedAt,
    latencyMs: receipt.latencyMs,
    outcome: receipt.outcome.kind === "response" ? {
      kind: receipt.outcome.kind,
      actualModel: receipt.outcome.actualModel,
      usage: receipt.outcome.usage
    } : receipt.outcome
  });
}
export {
  BRIDGE_BODY_LIMITS,
  bridgeByteLength,
  canonicalJson,
  decodeBridgeJson,
  decodeBridgeProviderReceipt,
  encodeBridgeProviderReceipt,
  parseBridgeReceiptMetadata,
  summarizeBridgeProviderReceipt
};
