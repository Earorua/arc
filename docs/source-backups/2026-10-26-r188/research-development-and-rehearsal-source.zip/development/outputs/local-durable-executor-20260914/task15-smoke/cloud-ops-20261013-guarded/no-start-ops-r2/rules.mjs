// Bounded successor: every r1 rule is unchanged; only Workflow description parsing is added.
export * from '../no-start-ops-r1/rules.mjs';
import {assert,same,workers,workflowNames,legacyWorkflowIds,newWorkflow,uuid} from '../no-start-ops-r1/rules.mjs';
const workflowLabels=['Name','Id','Script Name','Class Name','Created On','Modified On'];
const versionLabels=['Id','Created On','Modified On'];
const timestamp=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u.test(value)&&Number.isFinite(Date.parse(value));
export function assertWorkflowDefinitionProjection(p,name){
 assert(workflowNames.includes(name)&&p.name===name&&Array.isArray(p.fields)&&same(p.fields.map(x=>x.field),workflowLabels),'EXACT_WORKFLOW_SECTION_REQUIRED');
 const top=Object.fromEntries(p.fields.map(x=>[x.field,x.value]));
 assert(top.Name===name&&top['Script Name']===workers.executor&&top['Class Name']==='ResearchWorkflow'&&uuid(top.Id),'WORKFLOW_IDENTITY_MISMATCH');
 assert(name===newWorkflow?!Object.values(legacyWorkflowIds).includes(top.Id):top.Id===legacyWorkflowIds[name],'WORKFLOW_ID_MISMATCH');
 assert(timestamp(top['Created On'])&&timestamp(top['Modified On'])&&Date.parse(top['Created On'])<=Date.parse(top['Modified On']),'WORKFLOW_TIMESTAMPS_INVALID');
 const v=p.latestVersion;
 assert(v&&same(Object.keys(v).sort(),['createdOn','id','modifiedOn'])&&uuid(v.id)&&v.id!==top.Id&&timestamp(v.createdOn)&&timestamp(v.modifiedOn),'LATEST_VERSION_SECTION_INVALID');
 // Pinned Wrangler prints the Workflow timestamps in both sections, not version timestamps.
 assert(v.createdOn===top['Created On']&&v.modifiedOn===top['Modified On'],'LATEST_VERSION_TIMESTAMPS_MISMATCH');
 return p;
}
export function projectWorkflowDefinition(stdout,name){
 assert(typeof stdout==='string'&&Buffer.byteLength(stdout)<=131072,'BOUNDED_WORKFLOW_OUTPUT_REQUIRED');
 const lines=stdout.replace(/\u001b\[[0-9;]*m/gu,'').split(/\r?\n/u).filter(line=>line.trim()!=='');
 const starts=lines.flatMap((line,i)=>/^Name:\s/u.test(line)?[i]:[]);
 assert(starts.length===1,'UNIQUE_WORKFLOW_SECTION_REQUIRED');const first=starts[0];
 assert(!lines.slice(0,first).some(line=>/^\s*(?:Name|Id|Script Name|Class Name|Created On|Modified On|Latest Version):/u.test(line)),'UNEXPECTED_WORKFLOW_SECTION_PREFIX');
 const body=lines.slice(first);assert(body.length===10&&body[6]==='Latest Version:','EXACT_WORKFLOW_AND_LATEST_VERSION_SECTIONS');
 const read=(line,label,indent)=>{const prefix=' '.repeat(indent)+label+':';assert(line.startsWith(prefix)&&/^\s+\S/u.test(line.slice(prefix.length)),'EXACT_SECTION_FIELD_REQUIRED');const value=line.slice(prefix.length).trim();assert(value.length<=256,'BOUNDED_FIELD_REQUIRED');return value;};
 const fields=workflowLabels.map((field,i)=>({field,value:read(body[i],field,0)}));
 const latest=versionLabels.map((field,i)=>read(body[i+7],field,2));
 return assertWorkflowDefinitionProjection({name,fields,latestVersion:{id:latest[0],createdOn:latest[1],modifiedOn:latest[2]}},name);
}
