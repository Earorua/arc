// Pure schema safety rules; expected values alone are never native evidence.
import {createHash} from 'node:crypto';
import {assert,same,newDatabases,emptySql} from '../no-start-ops-r2/rules.mjs';
export * from '../no-start-ops-r2/rules.mjs';
export const hash=x=>createHash('sha256').update(x).digest('hex');
export const roles=['site','executor'];
export const bindings={site:'SMOKE_SITE_DB',executor:'EXECUTOR_DB'};
export const schemaSql='SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name LIMIT 512';
export const ledgerSql='SELECT id,name FROM d1_migrations ORDER BY id LIMIT 64';
export const applyCommand=(role,path)=>['d1','migrations','apply',bindings[role],'--remote','--config',path];
export const queryCommand=(role,path,sql)=>['d1','execute',bindings[role],'--remote','--config',path,'--json','--command',sql];
export function assertTarget(role,id){assert(roles.includes(role)&&id===newDatabases[role],'EXACT_NEW_DATABASE_REQUIRED');}
export function assertImmediate(reads,empty,role,versions,now=Date.now()){
 const recent=o=>o?.ok===true&&Number.isFinite(Date.parse(o.startedAt))&&Date.parse(o.startedAt)<=Date.parse(o.endedAt)&&Date.parse(o.endedAt)<=now&&now-Date.parse(o.startedAt)<120000;
 assert(same(reads.map(x=>x.role),roles)&&reads.every(x=>recent(x)&&x.versionId===versions[x.role]),'BOTH_CURRENT_VERSIONS_UNCHANGED');
 assert(recent(empty)&&empty.databaseId===newDatabases[role]&&empty.sqlSha256===hash(emptySql)&&same(empty.rows,[])&&empty.rowsWritten===0&&empty.changedDb===false,'IMMEDIATE_TARGET_NOT_PROVEN_EMPTY');
}
export function assertMigrationBytes(migrations,bytes,names){
 assert(migrations.length===bytes.length&&same(migrations.map(m=>m.name),names)&&new Set(names).size===names.length&&names.every((n,i)=>new RegExp('^'+String(i).padStart(4,'0')+'_[a-z0-9_]+\\.sql$','u').test(n)),'EXACT_CONTIGUOUS_MIGRATION_NAMES');
 for(const [i,m] of migrations.entries())assert(hash(bytes[i])===m.sha256&&(m.bytes===undefined||m.bytes===bytes[i].length),'MIGRATION_BYTES_CHANGED');
}
export function schemaQueries(exp){
 const tables=exp.counts.map(c=>c.table_name);assert(new Set(tables).size===tables.length&&tables.every(t=>/^[a-z][a-z0-9_]*$/u.test(t)),'SAFE_APP_TABLES');
 return [{kind:'schema',sql:schemaSql},{kind:'all-application-table-counts',sql:'SELECT '+tables.map(t=>`(SELECT count(*) FROM ${t}) AS ${t}`).join(',')},{kind:'migration-ledger',sql:ledgerSql},...exp.seedQueries.map((s,i)=>({kind:`seed-${i+1}`,sql:s.sql}))];
}
export function databaseQueries(phase,role,exp){
 assert(['pre-executor','pre-site','final'].includes(phase)&&roles.includes(role),'FIXED_COLLECTION_PHASE');
 return phase==='pre-executor'||phase==='pre-site'&&role==='site'?[{kind:'new-database-empty',sql:emptySql}]:schemaQueries(exp);
}
export function projectQuery(exp,query,stdout){
 assert(schemaQueries(exp).some(q=>same(q,query)),'EXACT_READ_ONLY_SQL');
 const data=JSON.parse(stdout);assert(Array.isArray(data)&&data.length===1&&data[0].success===true&&Array.isArray(data[0].results)&&data[0].meta?.rows_written===0&&data[0].meta?.changed_db===false,'NATIVE_READ_ONLY_METADATA_REQUIRED');
 const rows=data[0].results,kind=query.kind,keys=(r,n)=>same(Object.keys(r).sort(),[...n].sort());let projection;
 if(kind==='schema'){
  assert(rows.length<512&&rows.every(r=>keys(r,['type','name','tbl_name','sql'])&&['table','index','trigger','view'].includes(r.type)&&/^[_a-zA-Z][_a-zA-Z0-9]*$/u.test(r.name)&&/^[_a-zA-Z][_a-zA-Z0-9]*$/u.test(r.tbl_name)&&(r.sql===null||typeof r.sql==='string')),'SCHEMA_PROJECTION');
  projection={listingComplete:true,rows:rows.map(r=>({type:r.type,name:r.name,tbl_name:r.tbl_name,sqlSha256:r.sql===null?null:hash(r.sql)}))};
 }else if(kind==='all-application-table-counts'){
  const tables=exp.counts.map(c=>c.table_name);assert(rows.length===1&&keys(rows[0],tables)&&tables.every(t=>Number.isSafeInteger(rows[0][t])&&rows[0][t]>=0),'COUNT_PROJECTION');projection={rows:tables.map(t=>({table_name:t,row_count:rows[0][t]}))};
 }else if(kind==='migration-ledger'){
  assert(rows.length<64&&rows.every(r=>keys(r,['id','name'])&&Number.isSafeInteger(r.id)&&/^\d{4}_[a-z0-9_]+\.sql$/u.test(r.name)),'LEDGER_PROJECTION');projection={rows};
 }else{
  const seed=exp.seedQueries[Number(kind.slice(5))-1];
  // Seeds have no user content. Reject unknown fields and unapproved values before persistence.
  assert(rows.length<8&&rows.every(r=>seed.rows.some(s=>same(r,s))),'SAFE_EXACT_SEED_PROJECTION');projection={rows};
 }
 return {...projection,rowsWritten:0,changedDb:false};
}
export function schemaChecks(observations,role,exp){
 const used=observations.filter(o=>o.role===role),queries=schemaQueries(exp),obs=Object.fromEntries(used.map(o=>[o.kind,o])),schema=obs.schema?.rows??[];
 const systemTables=new Set(['_cf_KV','d1_migrations','sqlite_sequence']),system=schema.filter(s=>systemTables.has(s.tbl_name)),application=schema.filter(s=>!systemTables.has(s.tbl_name));
 const counts=obs['all-application-table-counts']?.rows??[],checks={
  completeUniqueReadKinds:same(used.map(o=>o.kind).sort(),queries.map(q=>q.kind).sort()),
  exactNewTarget:used.every(o=>o.databaseId===newDatabases[role]),
  schemaComplete:obs.schema?.listingComplete===true,
  exactSchemaSqlHashes:same(application,exp.schema),
  exactSystemObjects:same(system.map(s=>s.name).sort(),['_cf_KV','d1_migrations','sqlite_autoindex_d1_migrations_1','sqlite_sequence'].sort()),
  exactApplicationCounts:same(counts,exp.counts)&&counts.length===(role==='site'?49:9),
  exactMigrationLedger:same(obs['migration-ledger']?.rows,exp.ledger),
  exactAllSeedFields:exp.seedQueries.every((s,i)=>same(obs[`seed-${i+1}`]?.rows,s.rows)),
  exactReadOnlyMetadataAndSql:queries.every(q=>{const o=obs[q.kind];return o?.ok===true&&o.rowsWritten===0&&o.changedDb===false&&o.sqlSha256===hash(q.sql);}),
 };
 return {checks,allChecksPassed:Object.values(checks).every(Boolean),systemSchemaObjects:system,applicationTableCount:counts.length,migrationLedgerRows:obs['migration-ledger']?.rows?.length??0};
}
