// Future fixed read-only entrypoint. A failed stage is immutable and cannot be resumed.
import assert from 'node:assert/strict';
import {existsSync,mkdirSync} from 'node:fs';
import {join,dirname,basename} from 'node:path';
import {base,loadToolingContext,fastReverify,ref,read,write,exactDirectory,main} from './context.mjs';
import {N,OPERATION,stages,observationPath,hash,databases,bucket,emptySql} from './rules.mjs';
import {commandsFor,assertCommand} from './read-plans.mjs';
import {createReadTransport} from './read-transport.mjs';
import * as project from './project.mjs';
import {loadStageDependencies,requestFor,attemptFor,nativeStart,checkpoint,evaluateObservation} from './records.mjs';
import {readConfig} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/mapping.mjs';
const iso=()=>new Date().toISOString();
export async function run(argv){
 assert.ok(Array.isArray(argv)&&argv.length===1&&stages.includes(argv[0]),'EXACT_FIXED_STAGE_ARGUMENT');const stage=argv[0],directory=observationPath(stage);
 assert.equal(existsSync(directory),false,'EXCLUSIVE_STAGE_DIRECTORY');const ctx=await loadToolingContext(),dependency=loadStageDependencies(ctx,stage,Date.now());
 const cfg=Object.fromEntries(Object.entries(dependency.state.configs).map(([r,v])=>[r,read(v)])),options=base.g.neutralRead();fastReverify(ctx,dependency.pins,dependency.directories);
 mkdirSync(dirname(directory),{recursive:true});mkdirSync(directory);
 // All accepted graph loading and dependency evaluation precede this actual clock.
 const q=requestFor(ctx,stage,dependency,Date.now()),journal=[];
 for(const role of ['site','executor']){const written=write(q.readonlyConfigs[role].path,readConfig(role,cfg[role]));assert.deepEqual(written,q.readonlyConfigs[role]);journal.push(written);}
 const request=write(join(directory,'request.json'),q);journal.push(request);const attemptValue=attemptFor(ctx,q,request,iso()),attempt=write(join(directory,'attempt.json'),attemptValue);journal.push(attempt);
 const commands=commandsFor(q),exportPins=[];
 const check=args=>{fastReverify(ctx,[...dependency.pins,...journal,...exportPins],dependency.directories);exactDirectory(directory,journal.map(r=>basename(r.path)));assert.equal(q.deadlineAt,q.preparedAt+120000);assert.equal(hash(JSON.stringify(commandsFor(q))),q.commandsSha256);if(args)assertCommand(q,args);assert.ok(Date.now()<q.deadlineAt,'IMMUTABLE_READ_DEADLINE');};
 const n=nativeStart(ctx,q,request,attempt,iso());let transport=null;
 try{
  check();transport=createReadTransport({request:q,cli:base.g.FIXED.wrapper.path,cwd:options.cwd,env:options.env,remainingMs:q.deadlineAt-Date.now(),beforeSpawn:check});
  for(const command of commands){
   const o={id:command.id,startedAt:iso(),commandSha256:hash(JSON.stringify(command.args))};
   const v=command.kind==='export'?n.observations.find(x=>x.id===command.role+'-current-version'&&x.ok):null;
   if(command.kind==='export')assert.ok(v?.versionId===q.expectedVersions[command.role]&&v.exportTypeGatePassed===true&&v.sensitiveTypesPass===true,'VERSION_TYPE_GATE_BEFORE_EXPORT');
   const projection=(stdout,stderr,folder)=>{switch(command.kind){
    case 'deployment':return project.projectDeployment(stdout,command.role,q.expectedVersions[command.role]);
    case 'version':return project.projectVersion(stdout,command.role,q.expectedVersions[command.role],cfg[command.role]);
    case 'export':return {...project.projectExport(folder,command.role,cfg[command.role]),precedingVersionId:v.versionId};
    case 'definition':return project.projectWorkflowDefinition(stdout,command.name);
    case 'roster':return project.projectRoster(stdout+stderr,command.name);
    case 'd1':return {...project.projectD1(stdout,command.query),databaseId:base.g.FIXED.databases[command.query.role],sqlSha256:command.query.sqlSha256};
    case 'empty':return {...project.projectEmptyDatabase(stdout),databaseId:databases[command.role],sqlSha256:hash(emptySql)};
    case 'privacy-dev':assert.ok(stdout.includes('Public access via the r2.dev URL is disabled.'));return {bucket:stage.startsWith('pre-')?base.g.FIXED.bucket:bucket,devUrlEnabled:false};
    case 'privacy-domains':assert.ok(stdout.includes('There are no custom domains connected to this bucket.'));return {bucket:stage.startsWith('pre-')?base.g.FIXED.bucket:bucket,customDomainCount:0};
    default:throw Error('UNREVIEWED_READ');
   }};
   Object.assign(o,await transport.read(command.args,projection,{exportTypeGatePassed:v?.exportTypeGatePassed===true}));o.endedAt=iso();n.observations.push(o);exportPins.push(...(o.exportReferences??[]));journal.push(write(join(directory,'checkpoint-'+n.observations.length+'.json'),checkpoint(n,n.observations.length)));if(!o.ok)break;
  }
 }catch{n.failureCode='COLLECTION_FAILED';}
 n.endedAt=iso();n.transport=transport?.status()??null;n.allReadsSucceeded=!n.failureCode&&n.transport?.halted===null&&n.observations.length===commands.length&&n.observations.every(o=>o.ok)&&Date.now()<=q.deadlineAt;
 const nativeReference=write(join(directory,'native.json'),n);journal.push(nativeReference);assert.equal(n.allReadsSucceeded,true,'COMPLETE_NATIVE_REQUIRED');
 fastReverify(ctx,[...dependency.pins,...journal,...exportPins],dependency.directories);
 const proof=evaluateObservation(ctx,stage,dependency,{q,n,a:attemptValue,requestReference:request,attemptReference:attempt,nativeReference,readonlyValues:Object.fromEntries(['site','executor'].map(r=>[r,readConfig(r,cfg[r])]))},Date.now());
 const reference=write(join(directory,'result.json'),proof);journal.push(reference);exactDirectory(directory,journal.map(r=>basename(r.path)));fastReverify(ctx,[...dependency.pins,...journal,...exportPins],dependency.directories);
 return {reference,stage,allChecksPassed:true,task15Accepted:false,platformInvocationAbsenceProved:false,newWorkflowId:proof.mapping.newWorkflowId??null};
}
await main(import.meta.url,run);
