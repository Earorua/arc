import test from 'node:test';import assert from 'node:assert/strict';import {readFile,access,mkdir} from 'node:fs/promises';import {resolve} from 'node:path';import {randomUUID} from 'node:crypto';
import {WORKSPACE,OPS,OUTPUT,sha256,inspectAcceptedBytes}from './accepted-bytes.mjs';
const gate=()=>import('./review-gate.mjs'),store=()=>import('./assemble.mjs');
const ref=(name,d='0')=>({path:OPS+'/'+name,sha256:d.repeat(64)});
const inputs={implementation:ref('implementation-manifest-r1.json'),derivation:ref('derivation-r1.json','1'),runtimeInventory:ref('runtime-dependencies-r1.json','2'),contract:ref('review-contract-r1.md','3')};
const json=x=>Buffer.from(JSON.stringify(x));
function reviews(){
 const spec={schemaVersion:'arc-snapshot-driver-artifact-review-v1',reviewType:'SPEC',status:'passed',reviewedAt:'2026-10-18T12:00:00.000Z',...inputs,findings:[]};const specBytes=json(spec);const specReview={path:OPS+'/spec-review-r1.json',sha256:sha256(specBytes)};
 const quality={...spec,reviewType:'QUALITY',reviewedAt:'2026-10-18T12:01:00.000Z',specReview};const qualityBytes=json(quality);const qualityReview={path:OPS+'/quality-review-r1.json',sha256:sha256(qualityBytes)};
 const root={schemaVersion:'arc-snapshot-driver-artifact-root-acceptance-v1',status:'ACCEPTED_FOR_LOCAL_BYTE_ASSEMBLY',rootReviewed:true,acceptedAt:'2026-10-18T12:02:00.000Z',...inputs,specReview,qualityReview,outputDirectory:OUTPUT,localAssemblyOnly:true,cloudMutationAuthorized:false};
 return {specBytes,qualityBytes,rootBytes:json(root)};
}
test('fixed CLI accepts only inspect assemble verify with no paths or commands',async()=>{
 const m=await store();for(const mode of ['inspect','assemble','verify'])assert.equal(m.parseCli([mode]),mode);
 for(const args of [[],['prepare'],['assemble','--output','C:/elsewhere'],['verify','x'],['inspect','--help']])assert.throws(()=>m.parseCli(args),/ARGUMENTS/);
});
test('review chain binds separate SPEC QUALITY and root to identical frozen bytes',async()=>{
 const m=await gate(),r=reviews();const result=m.validateReviewRecords(r,inputs);
 assert.equal(result.spec.sha256,sha256(r.specBytes));assert.equal(result.quality.sha256,sha256(r.qualityBytes));assert.equal(result.root.sha256,sha256(r.rootBytes));
});
for(const name of ['quality-before-spec','root-before-quality','changed-spec-reference','wrong-output','unsupported-field','unresolved-finding','wrong-scope','changed-runtime-reference'])test('review gate rejects '+name,async()=>{
 const m=await gate(),r=reviews();const s=JSON.parse(r.specBytes),q=JSON.parse(r.qualityBytes),a=JSON.parse(r.rootBytes);
 if(name==='quality-before-spec')q.reviewedAt='2026-10-18T11:59:00.000Z';
 if(name==='root-before-quality')a.acceptedAt='2026-10-18T11:59:00.000Z';
 if(name==='changed-spec-reference')q.specReview.sha256='f'.repeat(64);
 if(name==='wrong-output')a.outputDirectory='C:/outside';
 if(name==='unsupported-field')a.skipChecks=true;
 if(name==='unresolved-finding')s.findings=['fix needed'];
 if(name==='wrong-scope')a.cloudMutationAuthorized=true;
 if(name==='changed-runtime-reference')a.runtimeInventory.sha256='f'.repeat(64);
 r.specBytes=json(s);r.qualityBytes=json(q);r.rootBytes=json(a);
 assert.throws(()=>m.validateReviewRecords(r,inputs),/REVIEW/);
});
test('read-only operational gate refuses missing reviews without invoking materialization',async()=>{
 const m=await gate();await assert.rejects(m.loadReviewGate(await inspectAcceptedBytes()),/REVIEW/);await assert.rejects(access(resolve(WORKSPACE,OUTPUT)),{code:'ENOENT'});
});
test('offline writer uses exact accepted bytes and preserves a consumed fixture directory',async()=>{
 const m=await store(),label='exclusive-'+randomUUID();const first=await m.writeOfflineFixture(label);const before=await readFile(resolve(WORKSPACE,first.report));
 assert.equal(first.offlineFixture,true);assert.ok(first.report.includes('/offline-snapshot-assembly-fixture-'));
 const r=JSON.parse(before);assert.equal(r.offlineFixture,true);assert.equal(r.validationScope,'offline-driver-compatibility-only');
 assert.equal(r.site.sha256,sha256(await readFile(resolve(WORKSPACE,r.site.output))));assert.equal(r.executor.sha256,sha256(await readFile(resolve(WORKSPACE,r.executor.output))));
 await assert.rejects(m.writeOfflineFixture(label),/OUTPUT_CONSUMED/);assert.deepEqual(await readFile(resolve(WORKSPACE,first.report)),before);
 await assert.rejects(access(resolve(WORKSPACE,OUTPUT)),{code:'ENOENT'});
});
test('offline writer rejects path-like labels and pre-existing partial output',async()=>{
 const m=await store();for(const label of ['../escape','C:/escape','label/child','label\\child',''])await assert.rejects(m.writeOfflineFixture(label),/OFFLINE_LABEL/);
 const label='partial-'+randomUUID();const dir=resolve(WORKSPACE,'outputs/local-durable-executor-20260914/task15-smoke/build/cloud/offline-snapshot-assembly-fixture-'+label);
 await mkdir(dir);await assert.rejects(m.writeOfflineFixture(label),/OUTPUT_CONSUMED/);
});

// BEGIN r2 canonical-time regression tests (pure, correctly rehashed review chains).
function reviewsAt(specTime,qualityTime,rootTime){
 const original=reviews(),s=JSON.parse(original.specBytes),q=JSON.parse(original.qualityBytes),a=JSON.parse(original.rootBytes);
 s.reviewedAt=specTime;const specBytes=json(s),specReview={path:OPS+'/spec-review-r1.json',sha256:sha256(specBytes)};
 q.reviewedAt=qualityTime;q.specReview=specReview;const qualityBytes=json(q),qualityReview={path:OPS+'/quality-review-r1.json',sha256:sha256(qualityBytes)};
 a.acceptedAt=rootTime;a.specReview=specReview;a.qualityReview=qualityReview;
 return {specBytes,qualityBytes,rootBytes:json(a)};
}
for(const stage of ['SPEC','QUALITY','root'])for(const invalid of [
 '2026-02-30T12:00:00.000Z','2026-02-29T12:00:00.000Z','2026-04-31T12:00:00.000Z','2026-03-01T24:00:00.000Z','2026-13-01T12:00:00.000Z'
])test('canonical time rejects '+stage+' '+invalid+' with rehashed chain',async()=>{
 const m=await gate(),parsed=Date.parse(invalid),base=Number.isFinite(parsed)?parsed:Date.parse('2026-03-01T12:00:00.000Z'),index=['SPEC','QUALITY','root'].indexOf(stage);
 const times=[0,1,2].map(i=>new Date(base+(i-index)*60000).toISOString());times[index]=invalid;
 assert.throws(()=>m.validateReviewRecords(reviewsAt(...times),inputs),{message:'REVIEW_TIME'});
});
for(const valid of ['2024-02-29T12:00:00.000Z','2000-02-29T12:00:00.000Z','2026-02-28T23:59:58.000Z','2026-12-31T23:59:58.000Z'])test('canonical time accepts leap/calendar control '+valid,async()=>{
 const m=await gate(),base=Date.parse(valid),r=reviewsAt(...[0,1,2].map(i=>new Date(base+i*1000).toISOString()));
 const result=m.validateReviewRecords(r,inputs);assert.equal(result.root.sha256,sha256(r.rootBytes));
});
for(const stage of ['QUALITY','root'])test('canonical time retains '+stage+' chronological order with rehashed chain',async()=>{
 const m=await gate(),times=['2026-10-18T12:00:00.000Z','2026-10-18T12:01:00.000Z','2026-10-18T12:02:00.000Z'];
 times[stage==='QUALITY'?1:2]='2026-10-18T11:59:00.000Z';
 assert.throws(()=>m.validateReviewRecords(reviewsAt(...times),inputs),{message:'REVIEW_ORDER'});
});
// END r2 canonical-time regression tests.
