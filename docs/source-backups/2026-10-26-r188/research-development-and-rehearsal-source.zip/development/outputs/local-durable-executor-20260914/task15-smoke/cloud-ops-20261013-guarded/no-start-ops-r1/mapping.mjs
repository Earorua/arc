// Pure native evidence evaluation, narrowly derived from C5 evaluate.mjs.
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {assert,same,workers,workflowNames,newDatabases,bucket,emptySql,assertFourWorkflows,assertStopped,assertFreshGate,assertSettingsStable} from './rules.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex'),digest=x=>typeof x==='string'&&/^[a-f0-9]{64}$/u.test(x);
const canonical=v=>Array.isArray(v)?v.map(canonical).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,canonical(x)])):v;
const equivalent=(a,b)=>same(canonical(a),canonical(b));
export const readConfig=(role,c)=>({name:workers[role],account_id:'54eaadb89014252836694203c1e22546',send_metrics:false,d1_databases:c.d1_databases.map(d=>({binding:d.binding,database_id:d.database_id,database_name:d.database_name}))});
export function commandsFor(q){
 const cfg=role=>['--config',resolve(q.directory,`wrangler.${role}.readonly.json`)];
 return Object.fromEntries([
  ...Object.keys(workers).flatMap(role=>[[role+'-current-deployment',['deployments','list',...cfg(role),'--json']],[role+'-current-version',['versions','view',q.expectedVersions[role],...cfg(role),'--json']],[role+'-final-deployment',['deployments','list',...cfg(role),'--json']],[role+'-export',['init','--from-dash',workers[role],'--no-delegate-c3']],[role+'-new-database-empty',['d1','execute',role==='site'?'SMOKE_SITE_DB':'EXECUTOR_DB','--remote','--config',q.emptyConfigs[role].path,'--json','--command',emptySql]]]),
  ...workflowNames.flatMap(name=>[[name+'-definition',['workflows','describe',name,...cfg('executor')]],[name+'-instances',['workflows','instances','list',name,'--page','1','--per-page','100',...cfg('executor')]]]),
  ['r2-dev-url',['r2','bucket','dev-url','get',bucket,...cfg('executor')]],['r2-custom-domains',['r2','bucket','domain','list',bucket,...cfg('executor')]]]);
}
export function assertRead(o,start,end,command){
 const a=Date.parse(o.startedAt),b=Date.parse(o.endedAt);
 assert(o.ok===true&&Number.isFinite(a)&&Number.isFinite(b)&&a>=start&&b>=a&&b<=end&&o.commandSha256===hash(JSON.stringify(command)),'READ_LINKAGE');
 assert(Array.isArray(o.attempts)&&o.attempts.length>=1&&o.attempts.length<=3,'READ_ATTEMPT_BOUNDS');
 let previous=a;
 for(const [i,t] of o.attempts.entries()){
  const x=Date.parse(t.startedAt),y=Date.parse(t.endedAt),last=i===o.attempts.length-1;
  assert(t.attempt===i+1&&x>=previous&&y>=x&&y<=b&&t.childCloseConfirmed===true&&t.rawContentPersisted===false&&t.childTimeoutMs>0&&t.childTimeoutMs<=45000&&digest(t.stdoutSha256)&&digest(t.stderrSha256)&&Number.isSafeInteger(t.stdoutBytes)&&t.stdoutBytes>=0&&Number.isSafeInteger(t.stderrBytes)&&t.stderrBytes>=0&&t.outputOverflow===false,'READ_ATTEMPT_INVALID');
  assert(last?t.exitCode===0&&t.failureKind===null&&t.timedOut===false:['transport-error','transport-timeout'].includes(t.failureKind),'READ_RETRY_INVALID');previous=y+(last?0:1000);
 }
}
export function evaluateMapping(n,q,{configs,baseline},now=Date.now()){
 const checks={},check=(name,fn)=>{try{checks[name]=fn()===true;}catch{checks[name]=false;}};
 const obs=id=>n.observations.find(o=>o.id===id&&o.ok),start=Date.parse(n.startedAt),end=Date.parse(n.endedAt),commands=commandsFor(q),nativeSettings={},mappedWorkers={};let inventory=null;
 check('completeIndependentCollection',()=>{
  assert(n.phase===q.phase&&n.allReadsSucceeded===true&&Array.isArray(n.observations)&&n.observations.length===18&&same(n.observations.map(x=>x.id).sort(),Object.keys(commands).filter(k=>!k.endsWith('-export')).sort())&&Array.isArray(n.exports)&&n.exports.length===2&&same(n.exports.map(x=>x.role).sort(),['executor','site']),'COMPLETE_UNIQUE_READS');
  assertFreshGate(start,end,now);assert(end-start<=720000,'COLLECTION_WALL_BUDGET');
  const t=n.transport;assert(t?.halted===null&&t.budgetExhausted===false&&t.maxAttempts===3&&t.backoffMs===1000&&t.childTimeoutMs===45000&&t.closeGraceMs===1000&&t.collectorBudgetMs===720000&&Number.isFinite(t.elapsedMs)&&t.elapsedMs>=0&&t.elapsedMs<720000,'TRANSPORT_BOUNDS');
  for(const o of n.observations)assertRead(o,start,end,commands[o.id]);for(const e of n.exports)assertRead(e,start,end,commands[e.role+'-export']);return true;
 });
 for(const role of ['site','executor']){
  const expected=configs[role],deployment=obs(role+'-current-deployment'),version=obs(role+'-current-version'),final=obs(role+'-final-deployment'),exported=n.exports.find(e=>e.role===role&&e.ok),actual=exported?.projection;
  const fields={
   exactRevision:()=>deployment.worker===workers[role]&&equivalent(deployment.versions,[{versionId:q.expectedVersions[role],percentage:100}])&&version.versionId===q.expectedVersions[role]&&version.worker===workers[role]&&final.versionId===q.expectedVersions[role]&&final.worker===workers[role]&&final.deploymentId===deployment.deploymentId,
   readOrder:()=>Date.parse(version.startedAt)>=Date.parse(deployment.endedAt)&&Date.parse(exported.startedAt)>=Date.parse(version.endedAt)&&Date.parse(final.startedAt)>=Date.parse(exported.endedAt)&&exported.precedingVersionId===q.expectedVersions[role],
   exactFrozenArtifact:()=>exported.entrySha256===q.artifacts[role].sha256&&exported.matchesFreshCandidate===true&&exported.moduleFiles.length===1&&exported.moduleFiles[0].sha256===q.artifacts[role].sha256&&digest(exported.configSha256),
   exactBindingValuesAndTypes:()=>{
    const bindings=[...Object.entries(expected.vars).map(([name,text])=>({name,type:'plain_text',...(name==='ARC_AI_IP_HASH_SALT'?{}:{value:text})})),...(expected.secrets?.required??[]).map(name=>({name,type:'secret_text'})),...(expected.d1_databases??[]).map(b=>({name:b.binding,type:'d1',id:b.database_id})),...(expected.r2_buckets??[]).map(b=>({name:b.binding,type:'r2_bucket',bucketName:b.bucket_name})),...(expected.services??[]).map(b=>({name:b.binding,type:'service',service:b.service,environment:b.environment??'production'})),...(expected.workflows??[]).map(b=>({name:b.binding,type:'workflow',workflowName:b.name,className:b.class_name,scriptName:b.script_name??null}))];
    return new Set(version.bindings.map(b=>b.name)).size===bindings.length&&equivalent(version.bindings,bindings);
   },
   requiredSecretsAndFixture:()=>version.sensitiveTypesPass===true&&version.syntheticSaltMatchesFixture===true&&version.exportTypeGatePassed===true,
   exactOrdinaryVars:()=>same(actual.vars,Object.fromEntries(Object.entries(expected.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT'))),
   exactWorker:()=>actual.name===expected.name,
   exactD1:()=>equivalent(actual.d1_databases.map(b=>({binding:b.binding,id:b.database_id})),expected.d1_databases.map(b=>({binding:b.binding,id:b.database_id}))),
   exactR2:()=>equivalent(actual.r2_buckets,(expected.r2_buckets??[]).map(b=>({binding:b.binding,bucket_name:b.bucket_name}))),
   exactServices:()=>equivalent(actual.services.map(b=>({...b,environment:b.environment??'production'})),expected.services.map(b=>({...b,environment:b.environment??'production'}))),
   exactWorkflowDeclarations:()=>equivalent(actual.workflows,expected.workflows??[]),
   exactWorkersDev:()=>actual.workers_dev===expected.workers_dev,
   previewsDisabled:()=>actual.preview_urls===false&&expected.preview_urls===false,
   exactRoutes:()=>same(actual.routes,expected.routes??[]),
   actualSchedulesExact:()=>exported.actualSchedulesRead===true&&same(actual.triggers.crons,[])&&same(expected.triggers?.crons??[],[]),
   exactCompatibility:()=>actual.compatibility_date===expected.compatibility_date&&equivalent(actual.compatibility_flags,expected.compatibility_flags??[]),
   stoppedSettings:()=>{assertStopped(actual,role);assertStopped(expected,role);return true;},
   nativeSettingsPreserved:()=>{nativeSettings[role]={limits:actual.limits,observability:actual.observability};assertSettingsStable(baseline.nativeSettings[role],nativeSettings[role]);return true;},
  };
  for(const [name,fn] of Object.entries(fields))check(role+'.'+name,fn);
  mappedWorkers[role]={name:workers[role],versionId:version?.versionId??null,artifactSha256:exported?.entrySha256??null};
  check(role+'.newDatabaseEmpty',()=>{const o=obs(role+'-new-database-empty');return o.databaseId===newDatabases[role]&&o.sqlSha256===hash(emptySql)&&same(o.rows,[])&&o.rowsWritten===0&&o.changedDb===false;});
 }
 check('fourWorkflowIdentityAndRosters',()=>{inventory=assertFourWorkflows(n.observations,baseline);return true;});
 check('newBucketPrivate',()=>obs('r2-dev-url')?.bucket===bucket&&obs('r2-dev-url').devUrlEnabled===false&&obs('r2-custom-domains')?.bucket===bucket&&obs('r2-custom-domains').customDomainCount===0);
 check('phaseBridgeKeyIds',()=>q.phase==='mixed'||q.phase==='paired'&&['ARC_AI_RESEARCH_SITE_TO_EXECUTOR_KEY_ID','ARC_AI_RESEARCH_EXECUTOR_TO_SITE_KEY_ID'].every(k=>n.exports.find(e=>e.role==='site').projection.vars[k]===n.exports.find(e=>e.role==='executor').projection.vars[k]));
 const allChecksPassed=Object.values(checks).every(x=>x===true);
 return {checks,allChecksPassed,workers:mappedWorkers,nativeSettings,workflows:allChecksPassed?inventory.workflows:null,rosters:allChecksPassed?inventory.rosters:null,newWorkflowId:allChecksPassed?inventory.newWorkflowId:null,emptyDatabasesVerified:allChecksPassed,activationAuthorized:false,schemasApplied:false};
}
