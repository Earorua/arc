// Pure fixed-operation rules. Source r1/r2 rules supply unchanged output/type checks only.
import assert from 'node:assert/strict';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {projectVersionBindings} from '../../cloud-ops-20261013-guarded/no-start-ops-r1/rules.mjs';
export {projectEmptyDatabase,deployCommand,assertStopped,projectOperationOutput,assertOperationProjection,currentDeployment} from '../../cloud-ops-20261013-guarded/no-start-ops-r1/rules.mjs';
export {projectVersionBindings};
export const N=import.meta.dirname,O=resolve(N,'..'),W=resolve(O,'../../../..'),S=resolve(O,'../cloud-ops-20261013-guarded/scenario-ops-r9');
export const OPERATION='arc-v8-snapshot-no-start-operations-20261017-r1';
export const ACCOUNT='54eaadb89014252836694203c1e22546';
export const workers=Object.freeze({site:'arc-v8-smoke-site-20260921',executor:'arc-v8-smoke-executor-20260921'});
export const oldVersions=Object.freeze({site:'1b4b751d-36fb-4e92-9997-885fbbc810d5',executor:'5717d119-0ee9-4c96-9725-1dec323d7733'});
export const artifactHashes=Object.freeze({site:'443e7fd5d9a54e42f5a321f24d8b5c9a3bc12f47aa222702e665bd2f030c6993',executor:'b8a8faea136b335f58042f2bf7106ecbb13db30add7a78c16e200d6e192e4cfb'});
export const legacyWorkflowIds=Object.freeze({'arc-v8-smoke-workflow-20260921':'c4747dc0-68bb-4d73-b60d-54fb768778b6','arc-v8-smoke-workflow-20261005-replay':'6905d906-51de-4047-8d9b-876649c47a18','arc-v8-smoke-workflow-20261012-ack':'12d6d5d6-0e05-4a97-99ef-4558d09d089e','arc-v8-smoke-workflow-20261013-guarded':'47253f45-0338-4304-90f7-39558abdce51'});
export const newWorkflow='arc-v8-smoke-workflow-20261017-snapshot',workflowNames=Object.freeze([...Object.keys(legacyWorkflowIds),newWorkflow]);
export const databases=Object.freeze({site:'ab1c37a2-dd68-482d-8cbf-4175cfd4480b',executor:'ea89c802-37ba-496d-960f-b4e1403c3afe'}),bucket='arc-v8-smoke-receipts-20261017-snapshot';
export const emptySql="SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' AND name != '_cf_KV' ORDER BY type,name";
export const stages=Object.freeze(['pre-first','pre-second','mixed','paired']);
export const hash=x=>createHash('sha256').update(x).digest('hex'),same=isDeepStrictEqual,serialize=v=>JSON.stringify(v,null,2)+'\n';
export const digest=x=>typeof x==='string'&&/^[a-f0-9]{64}$/u.test(x),uuid=x=>typeof x==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u.test(x);
export function utc(x){assert.ok(typeof x==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(x)&&Number.isSafeInteger(Date.parse(x))&&new Date(Date.parse(x)).toISOString()===x,'EXACT_UTC_TIME');return Date.parse(x);}
export function keys(value,names){assert.deepEqual(Object.keys(value).sort(),[...names].sort(),'EXACT_FIELDS');}
export function observationPath(stage){assert.ok(stages.includes(stage),'FIXED_STAGE');return join(N,'observations',stage);}
export function deploymentPath(role){assert.ok(Object.hasOwn(workers,role),'FIXED_ROLE');return join(N,'deployments',role);}
export const preparationPath=join(N,'prepared'),acceptancePath=join(N,'root-tooling-acceptance-r1.json');
export function assertFresh(start,end,now){const a=utc(start),b=utc(end);assert.ok(Number.isSafeInteger(now)&&a<=b&&b<=now&&now-a<900000,'FRESH_ACTUAL_COLLECTION_START');}
export function assertFreshPair(first,second,now){assertFresh(first.startedAt,first.endedAt,now);assertFresh(second.startedAt,second.endedAt,now);assert.ok(utc(second.startedAt)>=utc(first.endedAt)+60000,'FULL_SIXTY_SECOND_GAP');}
export function deriveState(stage,entries,deployments={}){
 assert.ok(stages.includes(stage),'FIXED_STAGE');
 if(stage.startsWith('pre-')){assert.deepEqual(deployments,{});return {versions:oldVersions,configs:Object.fromEntries(Object.entries(entries).map(([r,e])=>[r,e.sourceConfig]))};}
 assert.ok(uuid(deployments.executor?.versionId)&&deployments.executor.versionId!==oldVersions.executor,'ACTUAL_EXECUTOR_RESULT_REQUIRED');
 if(stage==='mixed')assert.equal(deployments.site,null,'NO_SITE_RESULT_FOR_MIXED');
 else assert.ok(uuid(deployments.site?.versionId)&&deployments.site.versionId!==oldVersions.site,'ACTUAL_SITE_RESULT_REQUIRED');
 return {versions:{site:stage==='paired'?deployments.site.versionId:oldVersions.site,executor:deployments.executor.versionId},configs:{site:stage==='paired'?entries.site.config:entries.site.sourceConfig,executor:entries.executor.config}};
}
export function expectedBindings(c){return [...Object.entries(c.vars).map(([name,value])=>({name,type:'plain_text',...(name==='ARC_AI_IP_HASH_SALT'?{}:{value})})),...c.secrets.required.map(name=>({name,type:'secret_text'})),...c.d1_databases.map(b=>({name:b.binding,type:'d1',id:b.database_id})),...(c.r2_buckets??[]).map(b=>({name:b.binding,type:'r2_bucket',bucketName:b.bucket_name})),...c.services.map(b=>({name:b.binding,type:'service',service:b.service,environment:b.environment??'production'})),...(c.workflows??[]).map(b=>({name:b.binding,type:'workflow',workflowName:b.name,className:b.class_name,scriptName:b.script_name??null}))];}
// Mechanically retained six-field/three-field Wrangler 4.92.0 formatter contract.
const workflowLabels=['Name','Id','Script Name','Class Name','Created On','Modified On'],versionLabels=['Id','Created On','Modified On'];
const timestamp=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u.test(v)&&Number.isFinite(Date.parse(v));
export function assertWorkflowDefinitionProjection(p,name){
 assert.ok(workflowNames.includes(name)&&p.name===name&&Array.isArray(p.fields)&&same(p.fields.map(x=>x.field),workflowLabels),'EXACT_WORKFLOW_SECTION_REQUIRED');
 const top=Object.fromEntries(p.fields.map(x=>[x.field,x.value]));
 assert.ok(top.Name===name&&top['Script Name']===workers.executor&&top['Class Name']==='ResearchWorkflow'&&uuid(top.Id),'WORKFLOW_IDENTITY_MISMATCH');
 assert.ok(name===newWorkflow?!Object.values(legacyWorkflowIds).includes(top.Id):top.Id===legacyWorkflowIds[name],'WORKFLOW_ID_MISMATCH');
 assert.ok(timestamp(top['Created On'])&&timestamp(top['Modified On'])&&Date.parse(top['Created On'])<=Date.parse(top['Modified On']),'WORKFLOW_TIMESTAMPS_INVALID');
 const v=p.latestVersion;assert.ok(v&&same(Object.keys(v).sort(),['createdOn','id','modifiedOn'])&&uuid(v.id)&&v.id!==top.Id&&timestamp(v.createdOn)&&timestamp(v.modifiedOn),'LATEST_VERSION_SECTION_INVALID');
 assert.ok(v.createdOn===top['Created On']&&v.modifiedOn===top['Modified On'],'LATEST_VERSION_TIMESTAMPS_MISMATCH');return p;
}
export function projectWorkflowDefinition(stdout,name){
 assert.ok(typeof stdout==='string'&&Buffer.byteLength(stdout)<=131072,'BOUNDED_WORKFLOW_OUTPUT_REQUIRED');
 const lines=stdout.replace(/\u001b\[[0-9;]*m/gu,'').split(/\r?\n/u).filter(line=>line.trim()!=='');
 const starts=lines.flatMap((line,i)=>/^Name:\s/u.test(line)?[i]:[]);assert.equal(starts.length,1,'UNIQUE_WORKFLOW_SECTION_REQUIRED');const first=starts[0];
 assert.ok(!lines.slice(0,first).some(line=>/^\s*(?:Name|Id|Script Name|Class Name|Created On|Modified On|Latest Version):/u.test(line)),'UNEXPECTED_WORKFLOW_SECTION_PREFIX');
 const body=lines.slice(first);assert.ok(body.length===10&&body[6]==='Latest Version:','EXACT_WORKFLOW_AND_LATEST_VERSION_SECTIONS');
 const read=(line,label,indent)=>{const prefix=' '.repeat(indent)+label+':';assert.ok(line.startsWith(prefix)&&/^\s+\S/u.test(line.slice(prefix.length)),'EXACT_SECTION_FIELD_REQUIRED');const value=line.slice(prefix.length).trim();assert.ok(value.length<=256,'BOUNDED_FIELD_REQUIRED');return value;};
 const fields=workflowLabels.map((field,i)=>({field,value:read(body[i],field,0)})),latest=versionLabels.map((field,i)=>read(body[i+7],field,2));
 return assertWorkflowDefinitionProjection({name,fields,latestVersion:{id:latest[0],createdOn:latest[1],modifiedOn:latest[2]}},name);
}
export function assertFiveWorkflows(observations,baseline,{phase,previousMapping=null,versions,executorStartedAt}){
 assert.ok(phase==='mixed'||phase==='paired');const workflows={},rosters={},workflowLatestVersions={};
 for(const name of workflowNames){
  const select=suffix=>{const all=observations.filter(o=>o.id===name+suffix);assert.ok(all.length===1&&all[0].ok,'COMPLETE_UNIQUE_WORKFLOW_READ');return all[0];};
  const d=select('-definition'),r=select('-instances');assertWorkflowDefinitionProjection(d,name);
  const top=Object.fromEntries(d.fields.map(x=>[x.field,x.value])),v=d.latestVersion;
  assert.ok(!Object.values(versions).includes(top.Id)&&!Object.values(versions).includes(v.id),'WORKFLOW_ID_IS_NOT_WORKER_REVISION');
  assert.ok(Date.parse(v.modifiedOn)<=utc(d.endedAt),'NONFUTURE_NATIVE_WORKFLOW_TIME');
  if(name!==newWorkflow){assert.equal(top.Id,baseline.workflows[name].id);assert.equal(v.createdOn,baseline.workflowLatestVersions[name].createdOn,'PRESERVED_WORKFLOW_CREATION');assert.ok(Date.parse(v.modifiedOn)>=Date.parse(baseline.workflowLatestVersions[name].modifiedOn),'NONDECREASING_WORKFLOW_MODIFIED');}
  else assert.ok(Date.parse(v.createdOn)>=utc(executorStartedAt),'NEW_WORKFLOW_AFTER_EXECUTOR_ATTEMPT');
  assert.ok(r.name===name&&r.availableListComplete===true&&Array.isArray(r.rows)&&r.rows.length<100&&new Set(r.rows.map(x=>x.instanceId)).size===r.rows.length,'COMPLETE_WORKFLOW_ROSTER');
  assert.deepEqual(r.rows,name===newWorkflow?[]:baseline.rosters[name],'EXACT_PRESERVED_ROSTERS');
  workflows[name]={id:top.Id,worker:top['Script Name'],className:top['Class Name']};rosters[name]=r.rows;workflowLatestVersions[name]=v;
 }
 const ids=Object.values(workflows).map(x=>x.id),latest=Object.values(workflowLatestVersions).map(x=>x.id);
 assert.equal(new Set(ids).size,5,'FIVE_UNIQUE_ACTUAL_WORKFLOW_IDS');assert.equal(new Set(latest).size,5,'FIVE_UNIQUE_LATEST_VERSIONS');assert.ok(latest.every(x=>!ids.includes(x)),'DISTINCT_WORKFLOW_AND_VERSION_IDS');
 if(phase==='paired'){assert.ok(previousMapping,'ACTUAL_MIXED_MAPPING_REQUIRED');for(const [key,value]of Object.entries({workflows,rosters,workflowLatestVersions}))assert.deepEqual(value,previousMapping[key],'PAIRED_PRESERVES_MIXED_WORKFLOWS');}
 return structuredClone({workflows,rosters,workflowLatestVersions,newWorkflowId:workflows[newWorkflow].id});
}
