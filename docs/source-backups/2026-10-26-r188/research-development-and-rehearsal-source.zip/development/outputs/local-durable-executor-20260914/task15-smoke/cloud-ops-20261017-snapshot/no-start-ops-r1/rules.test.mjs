import test from 'node:test';
import assert from 'node:assert/strict';
import {moduleFor,required,baseline,workflowText,uuid,clone,request,mappingFixture,originals,finalConfigs} from './offline-fixtures.mjs';
const r=await moduleFor('rules'),p=await moduleFor('read-plans'),ev=await moduleFor('evaluate');
const NEW='arc-v8-smoke-workflow-20261017-snapshot',names=[...Object.keys(baseline.workflows),NEW];
for(const name of names)test('six top fields and three distinct latest-version fields: '+name,()=>{
 const id=baseline.workflows[name]?.id??uuid(800),d=required(r,'projectWorkflowDefinition')(workflowText(name,id,uuid(700)),name);
 assert.equal(d.fields[1].value,id);assert.equal(d.latestVersion.id,uuid(700));
});
for(const [label,change]of [['same ID',s=>s.replaceAll(uuid(700),uuid(800))],['duplicate top field',s=>s.replace('Latest Version:','Id: '+uuid(900)+'\nLatest Version:')],['wrong indent',s=>s.replace('  Id:',' Id:')],['timestamp mismatch',s=>s.replace(/  Modified On:.*/u,'  Modified On: 2026-10-17T09:00:00.000Z')],['unrecognized field',s=>s+'Token: secret\n'],['wrong owner',s=>s.replace('arc-v8-smoke-executor-20260921','production')]])test('Workflow parser refuses '+label,()=>assert.throws(()=>required(r,'projectWorkflowDefinition')(change(workflowText(NEW,uuid(800),uuid(700))),NEW)));
test('native empty result must establish exact readonly empty contract',()=>assert.deepEqual(required(r,'projectEmptyDatabase')(JSON.stringify([{success:true,results:[],meta:{rows_written:0,changed_db:false}}])),{rows:[],rowsWritten:0,changedDb:false}));
for(const [label,value]of [['nonempty',[{success:true,results:[{name:'jobs'}],meta:{rows_written:0,changed_db:false}}]],['wrote',[{success:true,results:[],meta:{rows_written:1,changed_db:false}}]],['changed',[{success:true,results:[],meta:{rows_written:0,changed_db:true}}]],['two results',[{success:true,results:[],meta:{rows_written:0,changed_db:false}},{success:true,results:[],meta:{rows_written:0,changed_db:false}}]]])test('empty database refuses '+label,()=>assert.throws(()=>required(r,'projectEmptyDatabase')(JSON.stringify(value))));
for(const stage of ['pre-first','pre-second','mixed','paired'])test('exact fixed ordered plan '+stage,()=>{
 const q=request(stage),commands=required(p,'commandsFor')(q);assert.equal(commands.length,stage.startsWith('pre')?27:22);assert.equal(new Set(commands.map(c=>c.id)).size,commands.length);
 assert.deepEqual(commands.slice(-2).map(c=>c.id),['site-final-deployment','executor-final-deployment']);
 for(const c of commands)required(p,'assertCommand')(q,c.args);
 if(!stage.startsWith('pre'))assert.deepEqual(commands.filter(c=>c.kind==='empty').map(c=>c.args.at(-1)),[r.emptySql,r.emptySql]);
});
for(const args of [['workflows','trigger','anything'],['d1','execute','EXECUTOR_DB','--command','DELETE FROM jobs'],['deploy'],['init','--from-dash','other-worker','--no-delegate-c3']])test('command allowlist rejects '+args.join(' '),()=>assert.throws(()=>required(p,'assertCommand')(request(),args)));
test('mapping derives only old Site and actual new Executor',()=>{
 const entries={site:{sourceConfig:{s:1},config:{s:2}},executor:{sourceConfig:{e:1},config:{e:2}}};
 const d={executor:{versionId:uuid(900)},site:null};const state=required(r,'deriveState')('mixed',entries,d);
 assert.deepEqual(state.versions,{site:baseline.versions.site,executor:uuid(900)});assert.deepEqual(state.configs,{site:{s:1},executor:{e:2}});
 assert.throws(()=>r.deriveState('mixed',entries,{...d,site:{versionId:uuid(901)}}));assert.throws(()=>r.deriveState('paired',entries,d));
});
test('fresh pair is measured from first actual start',()=>{
 const a={startedAt:'2026-10-17T08:00:00.000Z',endedAt:'2026-10-17T08:00:10.000Z'},b={startedAt:'2026-10-17T08:01:10.000Z',endedAt:'2026-10-17T08:01:20.000Z'};
 required(r,'assertFreshPair')(a,b,Date.parse('2026-10-17T08:14:59.999Z'));
 assert.throws(()=>r.assertFreshPair(a,b,Date.parse('2026-10-17T08:15:00.000Z')));
 assert.throws(()=>r.assertFreshPair(a,{...b,startedAt:'2026-10-17T08:01:09.999Z'},Date.parse(b.endedAt)));
 assert.throws(()=>r.assertFreshPair(a,b,Date.parse(a.endedAt)));
});
test('complete mapping preserves repaired artifact, four rosters and new empty Workflow',()=>{
 const q=request(),f=mappingFixture(required(p,'commandsFor')(q),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));
 const result=required(ev,'evaluateMapping')(f.n,f.q,f.context,f.now);assert.equal(result.allChecksPassed,true);assert.equal(result.newWorkflowId,uuid(800));assert.equal(result.rosters[names[3]][0].instanceId,'00000000-0000-4000-8000-000000000151');
});
const changes={duplicate:f=>f.n.observations[1]=f.n.observations[0],missing:f=>f.n.observations.pop(),reordered:f=>f.n.observations.reverse(),late:f=>f.n.endedAt=new Date(f.q.deadlineAt+1).toISOString(),renewed:f=>f.q.deadlineAt++,future:f=>f.now=f.q.preparedAt-1,artifact:f=>f.n.observations.find(o=>o.id==='site-export').entrySha256='0'.repeat(64),binding:f=>f.n.observations.find(o=>o.id==='executor-current-version').bindings.pop(),cron:f=>f.n.observations.find(o=>o.id==='executor-export').projection.triggers.crons=['* * * * *'],d1:f=>f.n.observations.find(o=>o.id==='site-new-database-empty').databaseId='wrong',r2:f=>f.n.observations.find(o=>o.id==='r2-dev-url').devUrlEnabled=true,oldRoster:f=>f.n.observations.find(o=>o.id===names[3]+'-instances').rows=[],newRoster:f=>f.n.observations.find(o=>o.id===NEW+'-instances').rows=[{instanceId:uuid(2)}],unclosed:f=>f.n.observations[0].attempts[0].childCloseConfirmed=false,earlierModified:f=>{const o=f.n.observations.find(o=>o.id===names[0]+'-definition');o.fields[5].value='2026-09-22T00:00:00.000Z';o.latestVersion.modifiedOn=o.fields[5].value;}};
for(const [label,change]of Object.entries(changes))test('mapping refuses '+label,()=>{const f=mappingFixture(required(p,'commandsFor')(request()),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));change(f);assert.throws(()=>required(ev,'evaluateMapping')(f.n,f.q,f.context,f.now));});
test('paired cannot drift mixed Workflow latest version',()=>{
 const f=mappingFixture(required(p,'commandsFor')(request()),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));const mixed=required(ev,'evaluateMapping')(f.n,f.q,f.context,f.now);
 const projection=f.n.observations.find(o=>o.id===names[0]+'-definition');projection.latestVersion.id=uuid(987);
 assert.throws(()=>required(r,'assertFiveWorkflows')(f.n.observations,f.context.baseline,{phase:'paired',previousMapping:mixed,versions:f.q.expectedVersions,executorStartedAt:f.context.executorStartedAt}));
});
test('fifteen-minute mapping freshness starts at request creation, before journal writes',()=>{
 const f=mappingFixture(required(p,'commandsFor')(request()),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));
 f.now=f.q.preparedAt+900000;assert.throws(()=>required(ev,'evaluateMapping')(f.n,f.q,f.context,f.now));
});
test('malformed native attempt timestamps are rejected',()=>{
 const f=mappingFixture(required(p,'commandsFor')(request()),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));
 f.n.observations[0].attempts[0].startedAt=f.n.observations[0].attempts[0].startedAt.replace('Z','+00:00');assert.throws(()=>required(ev,'evaluateMapping')(f.n,f.q,f.context,f.now));
});
test('confirmed timeout then successful read preserves the recognized retry',()=>{
 const f=mappingFixture(required(p,'commandsFor')(request()),required(r,'expectedBindings'),required(r,'projectWorkflowDefinition'));
 const n=f.n;for(const [i,o]of n.observations.entries()){const start=f.q.preparedAt+100+i*2000;o.startedAt=new Date(start).toISOString();o.endedAt=new Date(start+1001).toISOString();o.attempts[0].startedAt=o.startedAt;o.attempts[0].endedAt=o.endedAt;}
 n.endedAt=new Date(f.q.preparedAt+100+n.observations.length*2000).toISOString();f.now=Date.parse(n.endedAt)+1;const o=n.observations[0],last=o.attempts[0];last.attempt=2;last.startedAt=new Date(Date.parse(o.startedAt)+1000).toISOString();last.endedAt=o.endedAt;o.attempts.unshift({...last,attempt:1,startedAt:o.startedAt,endedAt:o.startedAt,elapsedMs:0,exitCode:null,signal:'SIGTERM',timedOut:true,failureKind:'transport-timeout'});
 assert.equal(required(ev,'evaluateMapping')(n,f.q,f.context,f.now).allChecksPassed,true);
});
