// Load the accepted local graph once; live callbacks only rehash its bound file references.
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,lstatSync,writeFileSync,existsSync} from 'node:fs';
import {join,resolve,dirname,relative,isAbsolute} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {findPackageJSON} from 'node:module';
import * as base from '../closed-predecessor.mjs';
import {loadManifestInputs} from '../snapshot-manifest-inputs.mjs';
import {transformConfig} from '../snapshot-manifest-transform.mjs';
import {N,O,W,S,OPERATION,ACCOUNT,oldVersions,artifactHashes,hash,serialize,digest,utc,preparationPath,acceptancePath,assertOperationProjection,deployCommand} from './rules.mjs';
export {base};
export const ANCHORS=Object.freeze({
 plan:{path:join(W,'docs/superpowers/plans/2026-10-17-arc-v8-snapshot-no-start-operations.md'),sha256:'710d819fd238438e33730fe3fc4e3bd5f6b41bc093e14749d89bd006226f401f'},
 materialization:{path:join(O,'root-no-start-materialization-acceptance-r1.json'),sha256:'d7534ebf3e26f4aedbc14328efdeb53bf93e147bc5d48b99038262e868877e1c'},
});
export const moduleNames=Object.freeze(['rules.mjs','context.mjs','read-plans.mjs','read-transport.mjs','write-transport.mjs','project.mjs','evaluate.mjs','records.mjs','collect.mjs','deploy.mjs','prepare.mjs']);
export function verify(r){assert.ok(r&&typeof r.path==='string'&&isAbsolute(r.path)&&digest(r.sha256),'EXACT_ABSOLUTE_PIN');const stat=lstatSync(r.path);assert.ok(stat.isFile()&&!stat.isSymbolicLink(),'ORDINARY_PINNED_FILE');const bytes=readFileSync(r.path);assert.equal(hash(bytes),r.sha256,'BOUND_INPUT_BYTES_CHANGED');return bytes;}
export const ref=p=>{p=resolve(p);const r={path:p,sha256:hash(readFileSync(p))};verify(r);return r;};
export const read=r=>JSON.parse(verify(r).toString('utf8').replace(/^\uFEFF/u,''));
export function exactDirectory(path,names){const stat=lstatSync(path);assert.ok(stat.isDirectory()&&!stat.isSymbolicLink(),'ORDINARY_INPUT_DIRECTORY');assert.deepEqual(readdirSync(path).sort(),[...names].sort(),'EXACT_DIRECTORY_MEMBERSHIP');for(const name of names){const file=lstatSync(join(path,name));assert.ok(file.isFile()&&!file.isSymbolicLink(),'ORDINARY_DIRECTORY_MEMBERS');}}
export function uniquePins(refs){const map=new Map();for(const r of refs){const value={path:resolve(r.path),sha256:r.sha256};if(map.has(value.path))assert.deepEqual(map.get(value.path),value,'NO_CONFLICTING_INPUT_PINS');map.set(value.path,value);}return [...map.values()].sort((a,b)=>a.path.localeCompare(b.path));}
function references(value,out=[]){if(value&&typeof value==='object'){if(typeof value.path==='string'&&digest(value.sha256))out.push({path:resolve(W,value.path),sha256:value.sha256});else for(const v of Object.values(value))references(v,out);}return out;}
export function assertFixedAnchors(){for(const r of Object.values(ANCHORS))verify(r);}
export function assertFinalConfig(role,original,config,entry){
 assert.deepEqual(config,transformConfig(role,original).config,'PURE_EXACT_FINAL_CONFIG_DELTA');
 assert.equal(entry.config.path,join(O,'no-start-r1','wrangler.'+role+'.jsonc'));assert.equal(hash(serialize(config)),entry.config.sha256,'EXACT_FINAL_CONFIG_BYTES');
 assert.equal(config.main,entry.artifact.path);assert.equal(entry.artifact.sha256,artifactHashes[role]);return true;
}
export function runtimeReferences(){
 const seen=new Set(),refs=[],leaves=[base.g.FIXED.wrapper,base.g.FIXED.cli,base.g.FIXED.preload];
 const leafPaths=new Set(leaves.map(r=>resolve(r.path)));
 // Fixed computed import targets, independently checked by the AST regression.
 // Traverse their literal imports too; codecs and reconstructed evaluators are not leaves.
 const dynamicRoots=[base.g.FIXED.codec,base.g.FIXED.receiptProjector,base.g.FIXED.closedReconstruction.reconstruction,
  {path:join(W,'outputs/local-durable-executor-20261015/closed-r5-successor-r1/reconstruct.mjs'),sha256:'1d742828fd885db18d002a87512497a8d978f9eec64c2b75849fa4be3fcdec42'},
  {path:resolve(S,'../scenario-ops-r6/terminal-diagnostics.mjs'),sha256:'0e48fbaf01e57c9834adf481a0945a64ba613dcbe41cff2cd0e7fef0e90d60ef'}];
 function visit(path){path=resolve(path);if(seen.has(path))return;seen.add(path);refs.push(ref(path));if(leafPaths.has(path)||!/[.][cm]?js$/u.test(path))return;
  if(path.endsWith('.js')&&path.startsWith(join(W,'node_modules/zod')+'\\')){const metadata=findPackageJSON(pathToFileURL(path));assert.equal(read(ref(metadata)).type,'module','ESM_RUNTIME_PACKAGE_FORMAT');visit(metadata);}
  const source=readFileSync(path,'utf8'),patterns=[/\b(?:import|export)\s+(?:[\w*$,\s{}]+?\s+from\s*)?['"]([^'"]+)['"]/gu,/\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/gu];
  for(const pattern of patterns)for(const match of source.matchAll(pattern)){
   const specifier=match[1];if(specifier.startsWith('node:'))continue;
   if(specifier==='zod'){
    const metadata=findPackageJSON(specifier,pathToFileURL(path));assert.equal(metadata,join(W,'node_modules/zod/package.json'),'FIXED_PACKAGE_FROM_ACTUAL_IMPORTER');assert.equal(metadata,findPackageJSON(specifier,import.meta.url),'SAME_ESM_PACKAGE_RESOLUTION');
    const pkg=read(ref(metadata)),target=fileURLToPath(import.meta.resolve(specifier));assert.equal(pkg.version,'4.4.3');assert.equal(pkg.type,'module');assert.equal(pkg.exports['.'].import,'./index.js');assert.equal(target,resolve(dirname(metadata),pkg.exports['.'].import),'ACTUAL_ESM_IMPORT_TARGET');visit(metadata);visit(target);
   }else{assert.ok(specifier.startsWith('.')||specifier.startsWith('file:'),'FIXED_LOCAL_RUNTIME_IMPORT');visit(specifier.startsWith('file:')?fileURLToPath(specifier):resolve(dirname(path),specifier));}
  }
 }
 for(const name of moduleNames)visit(join(N,name));for(const root of [...leaves,...dynamicRoots]){verify(root);visit(root.path);}
 for(const [revision,names]of [[6,['guards','evaluate','mapping','terminal-contract','recovery']],[5,['guards','evaluate','mapping','project','read-plans','terminal-contract','recovery']]])for(const name of names)visit(resolve(S,'../scenario-ops-r'+revision,name+'.mjs'));
 return uniquePins(refs);
}
const contexts=new WeakMap();
export async function loadAcceptedInputs(){
 assertFixedAnchors();assert.equal(process.versions.node,'24.14.1','PINNED_NODE_RUNTIME');
 const a=read(ANCHORS.materialization);assert.equal(a.schemaVersion,'arc-snapshot-no-start-materialization-acceptance-v1');assert.equal(a.rootReviewed,true);assert.equal(a.specPassed,true);assert.equal(a.qualityPassed,true);assert.equal(a.accountId,ACCOUNT);assert.ok(utc(a.acceptedAt)<=Date.now());
 // This loader has no output-absence predicate. Its separate recheckManifestInputs
 // is deliberately never called after the accepted materialization.
 const inputs=await loadManifestInputs(),ctx=inputs.ctx,artifacts=read(a.artifacts),linkage=read(a.linkage),tooling=read(a.tooling),spec=read(a.reviews.spec),quality=read(a.reviews.quality);
 assert.deepEqual(a.resourceCreationAcceptance,inputs.anchors.resourceAcceptance);assert.deepEqual(a.resources,inputs.resources);assert.deepEqual(a.migrations,inputs.migrations);assert.equal(a.migrations.length,18);assert.deepEqual(a.migrationManifest,inputs.anchors.migrationManifest);
 assert.deepEqual(a.reviews,{spec:tooling.specReview,quality:tooling.qualityReview});assert.equal(spec.status,'PASS');assert.equal(quality.status,'PASS');assert.equal(spec.kind,'SPEC');assert.equal(quality.kind,'QUALITY');assert.notEqual(spec.reviewerId,quality.reviewerId);assert.deepEqual(quality.priorReview,a.reviews.spec);assert.equal(spec.priorReview,null);
 assert.ok(utc(spec.reviewedAt)<utc(quality.reviewedAt)&&utc(quality.reviewedAt)<=utc(tooling.acceptedAt)&&utc(tooling.acceptedAt)<=utc(a.acceptedAt),'ORDERED_ACCEPTED_MANIFEST_REVIEWS');
 assert.deepEqual(spec.implementationFiles,a.implementationFiles);assert.deepEqual(quality.implementationFiles,a.implementationFiles);assert.deepEqual(tooling.implementationFiles,a.implementationFiles);
 assert.deepEqual(artifacts.resources,inputs.resources);assert.deepEqual(linkage.resourceCreationAcceptance,inputs.anchors.resourceAcceptance);assert.deepEqual(linkage.inputReferences,inputs.inputReferences);assert.deepEqual(linkage.historicalPair,inputs.historicalPair);assert.equal(linkage.historicalPair.authorizationForNewMutation,false);assert.deepEqual(linkage.migrations,inputs.migrations);assert.deepEqual(linkage.artifacts,a.artifacts);
 assert.deepEqual(linkage.sourceConfigs,inputs.sourceConfigs);assert.deepEqual(linkage.sourceArtifacts,inputs.artifacts);assert.deepEqual(artifacts.proposedWorkflows,a.proposedWorkflows);assert.equal(artifacts.workflowCreated,false);assert.equal(linkage.schemaAccepted,false);assert.equal(linkage.task15Accepted,false);
 const configs={},dryPins=[];
 for(const role of ['site','executor']){
  const entry=a.entries[role];assert.deepEqual(entry.sourceConfig,inputs.sourceConfigs[role]);assert.deepEqual(entry.artifact,inputs.artifacts[role]);configs[role]=read(entry.config);assertFinalConfig(role,inputs.originals[role],configs[role],entry);verify(entry.artifact);
  assert.deepEqual(artifacts.configs.find(x=>x.role===role),{role,config:entry.config,sourceConfig:entry.sourceConfig,artifact:entry.artifact});
  const attempt=read(entry.dryRunAttempt),result=read(entry.dryRun);assert.equal(attempt.schemaVersion,'arc-snapshot-local-dry-run-attempt-v1');assert.equal(result.schemaVersion,'arc-snapshot-local-dry-run-result-v1');
  for(const v of [attempt,result]){assert.equal(v.role,role);assert.deepEqual(v.config,entry.config);assert.deepEqual(v.artifact,entry.artifact);}
  assert.deepEqual(result.attempt,entry.dryRunAttempt);assert.equal(result.commandSucceeded,true);assert.equal(result.mutationAttempted,false);assert.equal(result.childCloseConfirmed,true);assert.equal(result.exitCode,0);assert.equal(result.rawContentPersisted,false);assert.ok(digest(result.stdoutSha256)&&digest(result.stderrSha256));assertOperationProjection(result.projection,'dry-run',configs[role]);
  assert.deepEqual(attempt.wrapper,base.g.FIXED.wrapper);assert.deepEqual(attempt.cli,base.g.FIXED.cli);assert.deepEqual(attempt.command,[...deployCommand(attempt.shortConfig.path),'--dry-run']);assert.equal(attempt.shortConfig.sha256,entry.config.sha256);verify(attempt.shortConfig);assert.equal(attempt.cloudMutationAllowed,false);assert.equal(attempt.providerCalls,0);assert.equal(attempt.controlCalls,0);
  assert.ok(utc(attempt.at)<=utc(result.startedAt)&&utc(result.startedAt)<=utc(result.endedAt)&&utc(result.endedAt)<=utc(a.acceptedAt));dryPins.push(...references(attempt));
 }
 assert.deepEqual(linkage.deltas,['site','executor'].map(role=>{const t=transformConfig(role,inputs.originals[role]);return {role,changes:t.changes,reverseComparisonPassed:t.reverseComparisonPassed};}));
 const packageRef=ref(resolve(base.g.FIXED.wrapper.path,'../../package.json'));assert.equal(read(packageRef).version,'4.92.0','PINNED_WRANGLER_VERSION');
 const runtimePins=runtimeReferences(),inputPins=uniquePins([...inputs.inputReferences,...ctx.dispatchPins,...ctx.c.currentReferences(),...Object.values(ANCHORS),...references(a),...references(artifacts),...references(linkage),...dryPins,packageRef]);
 const directories=[{path:join(O,'no-start-r1'),names:['wrangler.site.jsonc','wrangler.executor.jsonc','artifacts.json','linkage.json']},{path:join(O,'provision-r1'),names:['siteD1','executorD1','receipts'].flatMap(r=>[r+'-attempt.json',r+'-result.json'])},...inputs.observationDirectories,...['site','executor'].map(role=>({path:dirname(inputs.migrations.find(m=>m.role===role).path),names:inputs.migrations.filter(m=>m.role===role).map(m=>m.name)}))];
 const value={base:ctx,entries:a.entries,configs,originals:inputs.originals,materialization:a,runtimePins,inputPins,directories,baseline:{...ctx.second.mapping,nativeSettings:ctx.c.schema.mapping.nativeSettings},historicalObjects:inputs.anchors.objects};
 contexts.set(value,{pins:uniquePins([...runtimePins,...inputPins]),directories:structuredClone(directories)});fastReverify(value);return value;
}
export function fastReverify(ctx,more=[],directories=[]){
 const bound=contexts.get(ctx);assert.ok(bound,'ACCEPTED_DISK_CONTEXT_REQUIRED');
 for(const r of uniquePins([...bound.pins,...more]))verify(r);for(const d of [...bound.directories,...directories])exactDirectory(d.path,d.names);return true;
}
export function write(path,value){path=resolve(path);const part=relative(N,path);assert.ok(part&&!part.startsWith('..')&&!isAbsolute(part),'NEW_PACKAGE_OUTPUT_ONLY');writeFileSync(path,serialize(value),{flag:'wx'});return ref(path);}
export const reviewPaths={spec:join(N,'spec-review-r2.json'),quality:join(N,'quality-review-r2.json')};
export const evidenceNames=Object.freeze(['offline-child-guard.cjs','offline-fixtures.mjs','rules.test.mjs','transport.test.mjs','context.test.mjs','state.test.mjs','actual-context.test.mjs','rules-red-r3.log','rules-green-r1.log','transport-red-r1.log','transport-green-attempt-r1.log','context-red-r1.log','state-red-r1.log','journal-window-red-r1.log','journal-window-green-r1.log','attempt-metadata-red-r2.log','attempt-metadata-green-r1.log','immediate-pair-red-r1.log','immediate-pair-green-r1.log','predecessor-recompute-r1.log','actual-context-r1.log','focused-green-r1.log','syntax-r1.log','cli-refusals-r1.log','derivation-r1.json','implementation-report-r1.md','spec-review-r1.json','spec-review-r1.md','spec-dynamic-import-audit-r1.log','runtime-inventory-r2.mjs','runtime-closure.test.mjs','runtime-closure-red-r2.log','runtime-closure-red-r2-complete.log','runtime-closure-green-r2.log','focused-green-r2.log','syntax-r2.log','cli-refusals-r2.log','derivation-r2.json','implementation-report-r2.md']);
export function reviewInputs(ctx){return {runtimePins:ctx.runtimePins,inputPins:ctx.inputPins,testPins:[...evidenceNames.map(name=>ref(join(N,name))),...['package.json','dist/acorn.mjs'].map(name=>ref(join(W,'node_modules/acorn',name)))]};}
export function assertReviews(ctx,spec,quality,specReference,qualityReference,now=Date.now()){
 const expected=reviewInputs(ctx);
 for(const [kind,value,reference,path]of [['SPEC',spec,specReference,reviewPaths.spec],['QUALITY',quality,qualityReference,reviewPaths.quality]]){
  assert.equal(reference.path,path);verify(reference);assert.equal(value.schemaVersion,'arc-snapshot-no-start-review-v1');assert.equal(value.operationId,OPERATION);assert.equal(value.kind,kind);assert.equal(value.status,'PASS');assert.ok(typeof value.reviewerId==='string'&&value.reviewerId.length>2);assert.deepEqual(value.plan,ANCHORS.plan);assert.deepEqual(value.materialization,ANCHORS.materialization);
  for(const key of ['runtimePins','inputPins','testPins'])assert.deepEqual(value[key],expected[key],'EXACT_REVIEWED_'+key);assert.ok(utc(value.reviewedAt)<=now);
 }
 assert.equal(spec.priorReview,null);assert.deepEqual(quality.priorReview,specReference);assert.notEqual(spec.reviewerId,quality.reviewerId);assert.ok(utc(spec.reviewedAt)<utc(quality.reviewedAt),'SPEC_THEN_DIFFERENT_QUALITY');
 return {...expected,reviewReferences:{spec:specReference,quality:qualityReference}};
}
export function loadReviews(ctx){const s=ref(reviewPaths.spec),q=ref(reviewPaths.quality);return assertReviews(ctx,read(s),read(q),s,q);}
export async function loadToolingContext(){
 // Fail before graph load or output if root has not accepted the prepared package.
 const acceptanceReference=ref(acceptancePath),a=read(acceptanceReference),ctx=await loadAcceptedInputs(),reviews=loadReviews(ctx);
 const pref=ref(join(preparationPath,'preparation.json')),p=read(pref);exactDirectory(preparationPath,['preparation.json','wrangler.site.empty.json','wrangler.executor.empty.json']);
 const {buildPreparation}=await import('./prepare.mjs'),expected=buildPreparation({...ctx,...reviews},p.preparedAt);assert.deepEqual(p,expected.record,'EXACT_ACTUAL_PREPARATION');for(const file of expected.files)assert.equal(hash(readFileSync(file.path)),hash(file.bytes),'PREPARED_BYTES_CHANGED');
 assert.equal(a.schemaVersion,'arc-snapshot-no-start-tooling-acceptance-v1');assert.equal(a.operationId,OPERATION);for(const k of ['rootReviewed','specPassed','qualityPassed'])assert.equal(a[k],true);assert.deepEqual(a.plan,ANCHORS.plan);assert.deepEqual(a.materialization,ANCHORS.materialization);assert.deepEqual(a.preparation,pref);assert.deepEqual(a.reviews,reviews.reviewReferences);for(const key of ['runtimePins','inputPins','testPins'])assert.deepEqual(a[key],reviews[key]);
 assert.ok(utc(read(reviews.reviewReferences.quality).reviewedAt)<=utc(p.preparedAt)&&utc(p.preparedAt)<=utc(a.acceptedAt)&&utc(a.acceptedAt)<=Date.now(),'REVIEW_THEN_PREPARATION_THEN_ROOT');
 Object.assign(ctx,{preparation:p,preparationReference:pref,acceptance:a,acceptanceReference,...reviews});const bound=contexts.get(ctx);bound.pins=uniquePins([...bound.pins,pref,acceptanceReference,...Object.values(reviews.reviewReferences),...reviews.testPins,...Object.values(p.emptyConfigs)]);bound.directories.push({path:preparationPath,names:expected.files.map(f=>f.path.slice(preparationPath.length+1))});fastReverify(ctx);return ctx;
}
export async function main(url,run){if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===url){try{console.log(serialize(await run(process.argv.slice(2))));}catch{console.error(JSON.stringify({operationId:OPERATION,disposition:'STOP_RECONCILE_NO_RETRY',rawDiagnosticPersisted:false}));process.exitCode=1;}}}
