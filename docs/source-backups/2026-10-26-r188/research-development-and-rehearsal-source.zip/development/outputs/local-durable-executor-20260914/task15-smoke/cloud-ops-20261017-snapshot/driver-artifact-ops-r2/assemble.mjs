import {mkdir,writeFile,readFile,realpath,readdir,lstat}from 'node:fs/promises';
import {resolve,dirname}from 'node:path';
import {fileURLToPath}from 'node:url';
import {isDeepStrictEqual}from 'node:util';
import {WORKSPACE,OPS,OUTPUT,sha256,inspectAcceptedBytes,deriveAssemblyReport,validateAssemblyReport}from './accepted-bytes.mjs';
import {loadReviewGate}from './review-gate.mjs';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const demand=(condition,code)=>{if(!condition)fail(code);};
const FILES=['site.js','site.metafile.json','executor.js','executor.metafile.json','report.json'];
const encode=value=>JSON.stringify(value,null,2)+'\n';
export function parseCli(args){demand(Array.isArray(args)&&args.length===1&&['inspect','assemble','verify'].includes(args[0]),'ARGUMENTS');return args[0];}
async function storedBytes(directory,report){
 const absolute=resolve(WORKSPACE,directory);demand(await realpath(absolute)===absolute,'OUTPUT_PATH');
 for(const role of ['site','executor'])for(const kind of ['output','metafile']){
  const expected=directory+'/'+role+(kind==='output'?'.js':'.metafile.json');demand(report[role][kind]===expected,'OUTPUT_PATH');
  const file=resolve(WORKSPACE,expected);demand(await realpath(file)===file,'OUTPUT_PATH');const stat=await lstat(file);demand(stat.isFile()&&!stat.isSymbolicLink(),'OUTPUT_TYPE');
  demand(sha256(await readFile(file))===report[role][kind==='output'?'sha256':'metafileSha256'],'OUTPUT_DIGEST');
 }
}
async function writeExclusive(directory,snapshot,report,recheck){
 const target=resolve(WORKSPACE,directory);demand(await realpath(dirname(target))===dirname(target),'OUTPUT_PATH');
 try{await mkdir(target);}catch(error){if(error.code==='EEXIST')fail('OUTPUT_CONSUMED');throw error;}
 demand(await realpath(target)===target,'OUTPUT_PATH');
 const refs=report.provenance.acceptedReferences;
 for(const role of ['site','executor'])for(const suffix of ['Artifact','Metafile']){
  const path=directory+'/'+role+(suffix==='Artifact'?'.js':'.metafile.json');
  await writeFile(resolve(WORKSPACE,path),snapshot.files[refs[role+suffix].path],{flag:'wx'});
 }
 await storedBytes(directory,report);
 await recheck();
 // A passed record is emitted only after the actual copies and all current dependencies verify.
 await writeFile(resolve(target,'report.json'),encode(report),{flag:'wx'});
 demand(isDeepStrictEqual((await readdir(target)).sort(),[...FILES].sort()),'OUTPUT_MEMBERSHIP');
 return {report:directory+'/report.json',sha256:sha256(await readFile(resolve(target,'report.json'))),offlineFixture:report.offlineFixture===true};
}
export async function assembleReviewedBytes(){
 const inspected=await inspectAcceptedBytes(),reviews=await loadReviewGate(inspected),report=deriveAssemblyReport(inspected.snapshot,reviews);
 return writeExclusive(OUTPUT,inspected.snapshot,report,async()=>{
  const current=await inspectAcceptedBytes();const currentReviews=await loadReviewGate(current);demand(isDeepStrictEqual(currentReviews,reviews),'REVIEW_CHANGED');validateAssemblyReport(report,current.snapshot,currentReviews);
 });
}
export async function verifyWrittenAssembly(){
 const inspected=await inspectAcceptedBytes(),reviews=await loadReviewGate(inspected),target=resolve(WORKSPACE,OUTPUT);
 demand(await realpath(target)===target,'OUTPUT_PATH');demand(isDeepStrictEqual((await readdir(target)).sort(),[...FILES].sort()),'OUTPUT_MEMBERSHIP');
 const reportPath=resolve(target,'report.json');demand(await realpath(reportPath)===reportPath,'OUTPUT_PATH');const reportStat=await lstat(reportPath);demand(reportStat.isFile()&&!reportStat.isSymbolicLink(),'OUTPUT_TYPE');
 const report=JSON.parse(await readFile(reportPath));validateAssemblyReport(report,inspected.snapshot,reviews);await storedBytes(OUTPUT,report);
 return {status:'LOCAL_ASSEMBLY_VERIFIED',report:OUTPUT+'/report.json',sha256:sha256(await readFile(resolve(target,'report.json'))),cloudElapsedProved:false,task15Accepted:false};
}
// This finite fixture API has no path, command, credentials or transport arguments.
// Its output is always labelled offline and cannot pass validateAssemblyReport().
export async function writeOfflineFixture(label){
 demand(typeof label==='string'&&/^[a-z0-9][a-z0-9-]{0,69}$/.test(label),'OFFLINE_LABEL');
 const directory='outputs/local-durable-executor-20260914/task15-smoke/build/cloud/offline-snapshot-assembly-fixture-'+label;
 const inspected=await inspectAcceptedBytes();const synthetic={root:{path:OPS+'/root-tooling-acceptance-r1.json',sha256:'0'.repeat(64)},spec:{path:OPS+'/spec-review-r1.json',sha256:'1'.repeat(64)},quality:{path:OPS+'/quality-review-r1.json',sha256:'2'.repeat(64)}};
 const report=deriveAssemblyReport(inspected.snapshot,synthetic);report.report=directory+'/report.json';
 for(const role of ['site','executor']){report[role].output=directory+'/'+role+'.js';report[role].metafile=directory+'/'+role+'.metafile.json';}
 report.validationScope='offline-driver-compatibility-only';report.offlineFixture=true;report.cloudExecutionAuthorized=false;report.reviews={scope:'OFFLINE_FIXTURE_NO_REVIEWS_OR_OPERATIONAL_AUTHORITY'};
 return writeExclusive(directory,inspected.snapshot,report,async()=>{const current=await inspectAcceptedBytes();demand(isDeepStrictEqual(current.readDependencies,inspected.readDependencies),'SOURCE_CHANGED');});
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
  const mode=parseCli(process.argv.slice(2));
  const result=mode==='assemble'?await assembleReviewedBytes():mode==='verify'?await verifyWrittenAssembly():await inspectAcceptedBytes().then(x=>({status:x.status,counts:x.counts,operationalAssemblyCreated:false}));
  console.log(JSON.stringify(result));
 }catch(error){console.log(JSON.stringify({status:'refused',code:/^[A-Z_]+$/.test(error.code??'')?error.code:'LOCAL_OPERATION_UNAVAILABLE'}));process.exitCode=1;}
}
