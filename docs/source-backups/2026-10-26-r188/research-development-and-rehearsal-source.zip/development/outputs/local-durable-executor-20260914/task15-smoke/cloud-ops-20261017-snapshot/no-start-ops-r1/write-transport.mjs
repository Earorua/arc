// Exactly one deploy child. No retries, no arbitrary command, and unknown outcome is retained.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {FIXED} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/guards.mjs';
import {workers,uuid,deployCommand,projectOperationOutput,assertOperationProjection} from './rules.mjs';
export const limits=Object.freeze({childMs:90000,closeGraceMs:1000,maxBytes:524288,maxAttempts:1});
export async function deployOnce({role,config,shortConfig,expectedVersion,cwd,env,beforeSpawn,runtime={}}){
 assert.ok(Object.hasOwn(workers,role)&&config.name===workers[role]&&uuid(expectedVersion),'FIXED_DEPLOY_ROLE');
 assert.ok(typeof beforeSpawn==='function','IMMEDIATE_DISPATCH_GUARD_REQUIRED');
 const io={spawn,now:()=>performance.now(),wallNow:()=>new Date().toISOString(),setTimeout,clearTimeout,...runtime};
 const result={commandStartedAt:null,commandEndedAt:null,commandSucceeded:false,mutationAttempted:false,exitCode:null,versionId:null,childCloseConfirmed:false,commandFailureKind:null,rawContentPersisted:false,disposition:'STOP_RECONCILE_NO_RETRY',childTimeoutMs:90000};
 try{beforeSpawn();}catch{result.commandFailureKind='dispatch-pins';return result;}
 return await new Promise(resolveResult=>{
  let child,timer,closeTimer,finished=false,reason=null,kept=0,stdoutBytes=0,stderrBytes=0;const stdout=[],stderr=[],outHash=createHash('sha256'),errHash=createHash('sha256');
  const started=io.now();result.commandStartedAt=io.wallNow();result.mutationAttempted=true;
  const finish=(code,signal,closed)=>{
   if(finished)return;finished=true;io.clearTimeout(timer);io.clearTimeout(closeTimer);
   result.commandEndedAt=io.wallNow();result.exitCode=Number.isInteger(code)?code:null;result.childCloseConfirmed=closed;
   result.elapsedMs=Math.max(0,io.now()-started);result.stdoutSha256=outHash.digest('hex');result.stderrSha256=errHash.digest('hex');result.stdoutBytes=stdoutBytes;result.stderrBytes=stderrBytes;
   if(!closed)reason='shutdown-unconfirmed';if(!reason&&(code!==0||signal))reason='command-failed';
   if(!reason){
    try{
     const out=Buffer.concat(stdout).toString('utf8'),err=Buffer.concat(stderr).toString('utf8');
     const projection=projectOperationOutput(out,err,'deploy',config);assertOperationProjection(projection,'deploy',config);
     const text=out.replace(/\u001b\[[0-9;]*m/gu,''),labels=text.match(/Current Version ID:/gu)??[],matches=[...text.matchAll(/^\s*Current Version ID:\s*([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})\s*$/gmu)];
     assert.ok(labels.length===1&&matches.length===1&&uuid(matches[0][1])&&matches[0][1]!==expectedVersion,'UNIQUE_ACTUAL_NEW_VERSION_REQUIRED');
     result.outputProjection=projection;result.versionId=matches[0][1];result.commandSucceeded=true;result.disposition='NEW_VERSION_REQUIRES_NATIVE_MAPPING';
    }catch{reason='projection';}
   }
   result.commandFailureKind=reason;
   for(const b of [...stdout,...stderr])b.fill(0);resolveResult(result);
  };
  const terminate=kind=>{if(finished||closeTimer!==undefined)return;reason=kind;closeTimer=io.setTimeout(()=>finish(null,null,false),1000);try{child.kill();}catch{/* close confirmation remains required */}};
  try{child=io.spawn(process.execPath,[FIXED.wrapper.path,...deployCommand(shortConfig.path)],{cwd,env,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});}
  catch{reason='spawn-unknown';finish(null,null,false);return;}
  timer=io.setTimeout(()=>terminate('child-timeout'),90000);
  for(const [stream,list,digest,key]of [[child.stdout,stdout,outHash,'stdout'],[child.stderr,stderr,errHash,'stderr']]){
   stream.on('data',chunk=>{if(finished)return;const b=Buffer.from(chunk);digest.update(b);if(key==='stdout')stdoutBytes+=b.length;else stderrBytes+=b.length;if(kept+b.length<=524288){list.push(b);kept+=b.length;}if(stdoutBytes+stderrBytes>524288)terminate('output-overflow');});
   stream.on('error',()=>terminate('stream-unknown'));
  }
  child.on('error',()=>terminate('child-unknown'));child.on('close',(code,signal)=>finish(code,signal,true));
 });
}
