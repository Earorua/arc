import {readFile,realpath,lstat}from 'node:fs/promises';
import {resolve}from 'node:path';
import {isDeepStrictEqual}from 'node:util';
import {WORKSPACE,OPS,OUTPUT,sha256,assertWorkspacePath}from './accepted-bytes.mjs';
const fail=code=>{throw Object.assign(new Error(code),{code});};
const demand=(condition,code='REVIEW_INVALID')=>{if(!condition)fail(code);};
const equal=(a,b,code='REVIEW_REFERENCE')=>demand(isDeepStrictEqual(a,b),code);
const exact=(object,fields)=>demand(object&&typeof object==='object'&&!Array.isArray(object)&&isDeepStrictEqual(Object.keys(object).sort(),[...fields].sort()),'REVIEW_FIELDS');
const fixed={implementation:OPS+'/implementation-manifest-r1.json',derivation:OPS+'/derivation-r1.json',runtimeInventory:OPS+'/runtime-dependencies-r1.json',contract:OPS+'/review-contract-r1.md'};
const common=['schemaVersion','reviewType','status','reviewedAt',...Object.keys(fixed),'findings'];
const iso=value=>{demand(typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value),'REVIEW_TIME');const parsed=Date.parse(value);demand(Number.isFinite(parsed)&&new Date(parsed).toISOString()===value,'REVIEW_TIME');return parsed;};
export const IMPLEMENTATION_NAMES=['accepted-bytes.mjs','accepted-pins.json','review-gate.mjs','assemble.mjs','accepted-bytes.test.mjs','assembly.test.mjs','driver-offline.test.mjs','offline-evidence.mjs','review-contract-r1.md'];
export const RUNTIME_NAMES=['accepted-bytes.mjs','accepted-pins.json','review-gate.mjs','assemble.mjs'];
export function validateReviewRecords(records,expected){
 exact(records,['specBytes','qualityBytes','rootBytes']);exact(expected,Object.keys(fixed));
 for(const key of Object.keys(fixed)){exact(expected[key],['path','sha256']);demand(expected[key].path===fixed[key]&&/^[0-9a-f]{64}$/.test(expected[key].sha256),'REVIEW_REFERENCE');}
 let spec,quality,root;try{spec=JSON.parse(records.specBytes);quality=JSON.parse(records.qualityBytes);root=JSON.parse(records.rootBytes);}catch{fail('REVIEW_JSON');}
 exact(spec,common);exact(quality,[...common,'specReview']);
 for(const [review,type]of [[spec,'SPEC'],[quality,'QUALITY']]){
  demand(review.schemaVersion==='arc-snapshot-driver-artifact-review-v1'&&review.reviewType===type&&review.status==='passed','REVIEW_STATUS');equal(review.findings,[],'REVIEW_FINDINGS');
  for(const key of Object.keys(fixed))equal(review[key],expected[key]);
 }
 const specRef={path:OPS+'/spec-review-r1.json',sha256:sha256(records.specBytes)},qualityRef={path:OPS+'/quality-review-r1.json',sha256:sha256(records.qualityBytes)};
 equal(quality.specReview,specRef);demand(iso(quality.reviewedAt)>=iso(spec.reviewedAt),'REVIEW_ORDER');
 exact(root,['schemaVersion','status','rootReviewed','acceptedAt',...Object.keys(fixed),'specReview','qualityReview','outputDirectory','localAssemblyOnly','cloudMutationAuthorized']);
 demand(root.schemaVersion==='arc-snapshot-driver-artifact-root-acceptance-v1'&&root.status==='ACCEPTED_FOR_LOCAL_BYTE_ASSEMBLY'&&root.rootReviewed===true&&root.localAssemblyOnly===true&&root.cloudMutationAuthorized===false,'REVIEW_ROOT_SCOPE');
 equal(root.outputDirectory,OUTPUT,'REVIEW_OUTPUT');for(const key of Object.keys(fixed))equal(root[key],expected[key]);equal(root.specReview,specRef);equal(root.qualityReview,qualityRef);
 demand(iso(root.acceptedAt)>=iso(quality.reviewedAt),'REVIEW_ORDER');
 return {root:{path:OPS+'/root-tooling-acceptance-r1.json',sha256:sha256(records.rootBytes)},spec:specRef,quality:qualityRef};
}
async function read(path){
 assertWorkspacePath(path);const absolute=resolve(WORKSPACE,path);demand(await realpath(absolute)===absolute,'REVIEW_PATH');const stat=await lstat(absolute);demand(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=10_000_000,'REVIEW_FILE');return readFile(absolute);
}
async function verifyReference(ref){exact(ref,['path','sha256']);const bytes=await read(ref.path);demand(sha256(bytes)===ref.sha256,'REVIEW_DIGEST');return bytes;}
export async function loadReviewGate(inspected){
 try{
  const records={specBytes:await read(OPS+'/spec-review-r1.json'),qualityBytes:await read(OPS+'/quality-review-r1.json'),rootBytes:await read(OPS+'/root-tooling-acceptance-r1.json')};
  const artifacts={},bodies={};for(const [key,path]of Object.entries(fixed)){bodies[key]=await read(path);artifacts[key]={path,sha256:sha256(bodies[key])};}
  const refs=validateReviewRecords(records,artifacts);
  const manifest=JSON.parse(bodies.implementation);exact(manifest,['schemaVersion','scope','files']);demand(manifest.schemaVersion==='arc-snapshot-driver-artifact-implementation-v1'&&manifest.scope==='local-tooling-only','REVIEW_IMPLEMENTATION');
  equal(manifest.files.map(r=>r.path).sort(),IMPLEMENTATION_NAMES.map(n=>OPS+'/'+n).sort(),'REVIEW_IMPLEMENTATION_MEMBERSHIP');for(const ref of manifest.files)await verifyReference(ref);
  const runtime=JSON.parse(bodies.runtimeInventory);exact(runtime,['schemaVersion','nodeVersion','runtimeFiles','readDependencies','historicalReadDependencies','offlineValidationEvidence']);
  demand(runtime.schemaVersion==='arc-snapshot-driver-artifact-runtime-v1'&&runtime.nodeVersion===process.version&&process.version==='v24.14.1','REVIEW_RUNTIME');
  equal(runtime.runtimeFiles.map(r=>r.path).sort(),[...RUNTIME_NAMES.map(n=>OPS+'/'+n),'package.json'].sort(),'REVIEW_RUNTIME_MEMBERSHIP');for(const ref of runtime.runtimeFiles)await verifyReference(ref);
  equal(runtime.readDependencies,inspected.readDependencies,'REVIEW_READ_DEPENDENCIES');
  const pins=JSON.parse(await read(OPS+'/accepted-pins.json'));equal(runtime.historicalReadDependencies,pins.historicalReferences,'REVIEW_HISTORICAL_DEPENDENCIES');
  demand(runtime.offlineValidationEvidence.path===OPS+'/offline-dependencies-r1.json','REVIEW_OFFLINE_EVIDENCE');await verifyReference(runtime.offlineValidationEvidence);
  const derivation=JSON.parse(bodies.derivation);demand(derivation.schemaVersion==='arc-snapshot-driver-artifact-derivation-v1'&&derivation.status==='IMPLEMENTED_OFFLINE_NOT_MATERIALIZED'&&derivation.operationalAssemblyCreated===false,'REVIEW_DERIVATION');
  return refs;
 }catch(error){if(String(error.code).startsWith('REVIEW'))throw error;fail('REVIEW_UNAVAILABLE');}
}
