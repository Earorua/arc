// Entry point accepts a pinned, prepared request. No network is contacted on import.
import {existsSync,mkdtempSync} from 'node:fs';
import {resolve} from 'node:path';
import {spawn} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {FIXED,here,root,assert,hash,ref,verify,write,utc,inputReference,createValidationContext,assertCurrentPins,neutralRead,main} from './guards.mjs';
import {validateRequest,prepareImmediateGap,assertReadBudget} from './prepare-observation.mjs';
import {createReadTransport} from './read-transport.mjs';
import {runReadSchedule} from './read-schedule.mjs';
import {projectD1,projectWorkflow,projectWorkflowDefinition,projectRoster,projectDeployment,projectVersion,projectExport,projectScheduled} from './project.mjs';
import {assertPrerequisites} from './evaluate.mjs';
import {assertLiveFaultContinuation} from './fault-continuation.mjs';
export async function collectImmediateFaultGap(c,spec){return collect(c,prepareImmediateGap(c,spec));}
export async function collect(c,reference){
 const input=validateRequest(c,reference,{dispatch:true}),{q,commands}=input;assertPrerequisites(c,input,Date.now());if(q.phase==='fault-gap')assertLiveFaultContinuation(c,q,{claim:true});
 const target=resolve(q.directory,q.phase==='scheduled'?'scheduled-metadata.json':'native-evidence.json'),journal=resolve(q.directory,'collection-attempt.json');assert(!existsSync(target)&&!existsSync(journal),'EXCLUSIVE_COLLECTION_CONSUMED');
 const options=neutralRead(),attempt=write(journal,{schemaVersion:'arc-snapshot-scenario-collection-attempt-v1',at:new Date().toISOString(),request:reference,collector:ref(resolve(here,'collect.mjs')),transport:ref(resolve(here,'read-transport.mjs')),preload:FIXED.preload,commandsSha256:q.commandsSha256,deadlineAt:q.collectionDeadlineAt,cloudMutations:0,controlCalls:0,providerCalls:0});
 const report={schemaVersion:'arc-snapshot-scenario-native-v1',request:reference,attempt,phase:q.phase,scenarioId:q.scenarioId,startedAt:new Date().toISOString(),deadlineAt:q.collectionDeadlineAt,collector:ref(resolve(here,'collect.mjs')),transportHelper:ref(resolve(here,'read-transport.mjs')),preload:FIXED.preload,observations:[],cloudMutations:0,workerControlCalls:0,providerCalls:0};
 const pins=[reference,...Object.values(q.configs),...Object.values(q.readonlyConfigs),...Object.values(q.tools),q.preparation,q.materials];
 let stopNewDispatch=false;
 const recheck=()=>{assert(!stopNewDispatch,'READ_DISPATCH_STOPPED_AFTER_PEER_FAILURE');assertCurrentPins(c,pins);assertPrerequisites(c,input,Date.now());assertReadBudget(q,input.clock,Date.now());assert(Date.now()<q.collectionDeadlineAt,'CURRENT_STAGE_DEADLINE');if(q.phase==='fault-gap')assertLiveFaultContinuation(c,q);};
 const transport=createReadTransport({request:q,cli:FIXED.wrapper.path,cwd:options.cwd,env:options.env,remainingMs:Math.max(1,q.collectionDeadlineAt-Date.now()),beforeSpawn:recheck});
 let checkpoint=0;
 try{
  if(q.phase==='scheduled'){const result=await observeScheduled(q,commands[0].args,options,recheck);Object.assign(report,result,{allReadsSucceeded:result.childCloseConfirmed&&result.failureKind===null});}
  else {
   const readOne=async command=>{
   assert(Date.now()<q.collectionDeadlineAt,'CURRENT_STAGE_DEADLINE'); // Complete current pins are checked once immediately before each actual attempt below.
   const o={id:command.id,startedAt:new Date().toISOString(),commandSha256:hash(JSON.stringify(command.args))};
   const expected=command.role?c.read(q.configs[command.role]):null;
   const version=command.kind==='export'?report.observations.find(x=>x.id===command.role+'-current-version'&&x.ok):null;
   const project=(stdout,stderr,folder)=>{
    switch(command.kind){
     case 'd1':return {...projectD1(stdout,command.query),databaseId:FIXED.databases[command.query.role],sqlSha256:command.query.sqlSha256};
     case 'instance':return projectWorkflow(stdout,command.scenarioId);
     case 'definition':return projectWorkflowDefinition(stdout,command.name);
     case 'roster':return projectRoster(stdout+stderr,command.name);
     case 'deployment':return projectDeployment(stdout,command.role,q.expectedVersions[command.role]);
     case 'version':return projectVersion(stdout,command.role,q.expectedVersions[command.role],expected);
     case 'export':return {...projectExport(folder,command.role,expected),precedingVersionId:version.versionId};
     case 'privacy-dev':assert(stdout.includes('Public access via the r2.dev URL is disabled.'),'PRIVATE_R2_DEV');return {bucket:FIXED.bucket,devUrlEnabled:false};
     case 'privacy-domains':assert(stdout.includes('There are no custom domains connected to this bucket.'),'PRIVATE_R2_DOMAINS');return {bucket:FIXED.bucket,customDomainCount:0};
     default:throw Error('UNREVIEWED_PROJECTION');
    }
   };
   Object.assign(o,await transport.read(command.args,project,{exportTypeGatePassed:version?.exportTypeGatePassed===true}));o.endedAt=new Date().toISOString();return o;

   };
   const checkpointResult=observations=>{report.observations=observations;write(resolve(q.directory,`checkpoint-${++checkpoint}.json`),{...report,complete:false});};
   if(['fault-gap','acceptance'].includes(q.phase)){for(const command of commands){const o=await readOne(command);checkpointResult([...report.observations,o]);if(!o.ok)break;}}
   else{const scheduled=await runReadSchedule(commands,{read:readOne,onFailure:()=>{stopNewDispatch=true;},onComplete:(_value,observations)=>checkpointResult(observations)});report.observations=scheduled.observations;report.scheduling=scheduled.schedule;if(scheduled.failureKind)report.failureKind=scheduled.failureKind;}
  }
 }catch{report.failureKind='guard-or-collection';}
 report.transport=transport.status();report.endedAt=new Date().toISOString();if(q.phase!=='scheduled')report.allReadsSucceeded=!report.failureKind&&!report.transport.halted&&report.observations.length===commands.length&&report.observations.every(o=>o.ok)&&Date.now()<=q.collectionDeadlineAt;
 if(q.phase==='scheduled'){report.invocationAbsenceClaimed=false;report.applicationSettlementProved=false;}
 const saved=write(target,report);return {reference:saved,allReadsSucceeded:report.allReadsSucceeded};
}
// Separate scheduled metadata observation: bounded 95s, confirmed close, no log/body persistence.
export function scheduledDuration(q,now){const duration=Math.min(95000,q.collectionDeadlineAt-now-1000);assert(Number.isSafeInteger(duration)&&duration>0,'SCHEDULED_STAGE_BUDGET');return duration;}
export function observeScheduled(q,args,options,beforeSpawn,runtime={}){const io={spawn,now:Date.now,setTimeout,clearTimeout,...runtime};return new Promise(resolveResult=>{
 beforeSpawn();const duration=scheduledDuration(q,io.now());let child,buffer='',bytes=0,stderrBytes=0,finished=false,closing=false,timer,closeTimer,failureKind=null;const records=[];
 const finish=(closed,code)=>{if(finished)return;finished=true;io.clearTimeout(timer);io.clearTimeout(closeTimer);if(!closed)failureKind='shutdown-unconfirmed';resolveResult({records,stdoutBytes:bytes,stderrBytes,exitCode:Number.isInteger(code)?code:null,childCloseConfirmed:closed,failureKind,rawContentPersisted:false,observationDurationMs:duration,invocationAbsenceClaimed:false});};
 const stop=reason=>{if(closing||finished)return;closing=true;if(reason)failureKind=reason;closeTimer=io.setTimeout(()=>finish(false,null),1000);try{child.kill();}catch{}};
 try{child=io.spawn(process.execPath,[FIXED.wrapper.path,...args],{cwd:options.cwd,env:options.env,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});}catch{finish(false,null);return;}
 timer=io.setTimeout(()=>stop(null),duration);
 function parse(){let start=-1,depth=0,string=false,escape=false;for(let i=0;i<buffer.length;i++){const ch=buffer[i];if(start<0){if(ch==='{'){start=i;depth=1;}continue;}if(string){if(escape)escape=false;else if(ch==='\\')escape=true;else if(ch==='"')string=false;continue;}if(ch==='"')string=true;else if(ch==='{')depth++;else if(ch==='}')depth--;if(depth!==0)continue;const raw=buffer.slice(start,i+1);buffer=buffer.slice(i+1);i=-1;start=-1;try{const v=JSON.parse(raw);if(v?.event?.scheduledTime!==undefined){records.push(projectScheduled(v));if(records.length>=16)stop(null);}}catch{stop('projection');}}}
 child.stdout.on('data',chunk=>{if(finished)return;bytes+=chunk.length;if(bytes>262144){stop('output-overflow');return;}buffer+=chunk.toString('utf8');parse();});child.stderr.on('data',chunk=>{stderrBytes+=chunk.length;if(stderrBytes>8192)stop('output-overflow');});child.stdout.on('error',()=>stop('transport-error'));child.stderr.on('error',()=>stop('transport-error'));child.on('error',()=>stop('transport-error'));child.on('close',code=>{if(!closing&&code!==0)failureKind='transport-error';finish(true,code);});
 });}
await main(import.meta.url,async()=>{assert(process.argv.length===4,'EXACT_REQUEST_PATH_SHA_NO_COLD_FAULT_CAPTURE');const c=await createValidationContext(),reference=inputReference(process.argv[2],process.argv[3]);assert(c.read(reference).phase!=='fault-gap','RETAINED_FAULT_CONTINUATION_REQUIRED');const result=await collect(c,reference);console.log(JSON.stringify(result));if(!result.allReadsSucceeded)process.exitCode=1;});
