// Native projections are recomputed into decisions. Caller-provided passed/ready booleans
// never substitute for a hash-bound complete collector/operation/control chain.
import {performance} from 'node:perf_hooks';
import {resolve,dirname} from 'node:path';
import {existsSync,readdirSync} from 'node:fs';
import {FIXED,here,G,root,assert,same,hash,digest,integer,uuid,utc,jsonRef,ref,verify,write,inputReference,createValidationContext,assertContext,assertLocalNativeWork,assertFresh,assertCurrentPins,assertMaterials,assertSuccessorBindings,main} from './guards.mjs';
import {checkHandoff,checkQuiet,checkReplayTimes,STAGES,observerNeed,LIMITS} from './budget.mjs';
import {assertCompletionScope,OUTSTANDING_KEYS,SCENARIO_IDS} from './contracts.mjs';
import {SCENARIOS,commandsFor,fullMapping,assertObservationPolicy} from './read-plans.mjs';
import {assertCollection,evaluateMapping,readConfig} from './mapping.mjs';
import {assertCursorRows} from './project.mjs';
import {validateRequest,loadPreparation,loadClock,historicalReadPhase,assertReadBudget} from './prepare-observation.mjs';
import {assertRead} from './mapping.mjs';
import {strictCommand} from './prepare.mjs';
import {assertOperationProjection} from '../no-start-ops-r1/rules.mjs';
import {assertTransition} from './contracts.mjs';
import {verifyReceipt} from './receipt.mjs';
import {replayReserveMs,fixedOperationDeadline} from './profile.mjs';
import {verifyRosterPreparation} from './roster.mjs';
import {assertNoRecoveryControl,incompleteOutcome} from './recovery.mjs';
import {canonicalJson} from '../../cloud-ops-20261005-replay/long-followup-preparation-r1/r2-preparation/production-codec.mjs';
import {projectDiagnostic} from '../../../../local-durable-executor-20261014/deployment-diagnostic-r1/project.mjs';
import diagnosticEnums from '../../../../local-durable-executor-20261014/deployment-diagnostic-r1/enums.cjs';
import {assertTerminalAuthority,assertTerminalReadiness,loadTerminalTemplate} from './attended-proof.mjs';
export const row=(n,id)=>{const o=n.observations.find(x=>x.id===id&&x.ok);assert(o&&o.rowsWritten===0&&o.changedDb===false&&o.rows.length===1,'EXACT_ONE_NATIVE_ROW_'+id);return o.rows[0];};
// This is a closed, unused baseline for this one successor, never a post-write state
// or a maintenance-close proof. Only loadClosedBaseline may supply dispatch evidence.
export function assertClosedBaseline(b,gate,{now,configs,closedConfigs,expectedVersions,retainedObserver}){
 assertSuccessorBindings(b);
 assert(b.schemaVersion==='arc-snapshot-successor-baseline-acceptance-v1'&&b.rootReviewed===true&&b.disposition==='CLOSED_EMPTY_UNUSED_BASELINE_ACCEPTED'&&b.epoch===FIXED.epoch,'ROOT_SUCCESSOR_BASELINE_ACCEPTANCE');
 assert(gate.phase==='preactivation'&&gate.allChecksPassed===true&&!gate.reconciliation&&!gate.incompleteClosure&&!gate.request.incompleteClosure&&same(gate.request.state,FIXED.currentClosedAcceptance)&&gate.request.clockReference===null&&gate.request.clock===null,'ACTUAL_SUCCESSOR_PREACTIVATION_BASELINE');
 assert(expectedVersions&&same(b.currentClosedAcceptance,FIXED.currentClosedAcceptance)&&same(b.gate,gate.reference)&&same(b.nativeEvidence,gate.nativeReference)&&same(b.expectedVersions,expectedVersions)&&same(gate.mapping.versions,expectedVersions)&&same(b.configs,configs)&&same(gate.mapping.configs,configs)&&same(gate.request.configs,configs),'EXACT_BASELINE_PAIR_CONFIG_GATE');
 assertFresh(gate.startedAt,gate.endedAt,now);assert(utc(gate.endedAt)<=utc(b.acceptedAt)&&utc(b.acceptedAt)<=now&&integer(gate.request.readinessStartedAt)&&gate.request.readinessStartedAt<=utc(gate.startedAt)&&now<gate.request.readinessStartedAt+300000&&now<gate.request.deadlineAt,'CURRENT_BASELINE_READINESS_WINDOW');
 const executor=closedConfigs.executor,site=closedConfigs.site;
 assert(executor.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW==='false'&&executor.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED==='false'&&same(executor.triggers.crons,[])&&!Object.hasOwn(site.vars,'SMOKE_REPLAY_APPROVAL_JSON')&&!Object.hasOwn(site.vars,'SMOKE_REPLAY_INVENTORY_SHA256'),'EXACT_CLOSED_UNROSTERED_BASELINE');
 const scope=gate.scope;
 assert(scope.safeToClose===true&&same(scope.scope.observedScenarioIds,[])&&same(Object.keys(scope.scope.outstanding).sort(),[...OUTSTANDING_KEYS].sort())&&OUTSTANDING_KEYS.every(k=>scope.scope.outstanding[k]===0)&&same(scope.capacity,retainedObserver)&&scope.capacity.rowsUsed+observerNeed({remainingMs:LIMITS.totalMs,unmatchedStarts:0})<=256&&scope.capacity.unmatchedStarts===0&&same(gate.mapping.rosters[FIXED.workflowName],[]),'UNUSED_BASELINE_SCOPE_OBSERVER');
 assert(row(gate.native,'executor-global-lifecycle').jobs===0&&row(gate.native,'site-global-lifecycle').executions===0&&same(gate.native.observations.find(x=>x.id==='executor-job-roster')?.rows,[])&&same(gate.native.observations.find(x=>x.id==='executor-accepted-deadlines')?.rows,[]),'EMPTY_BASELINE_JOB_EXECUTION_INSTANCE_SCOPE');
 return b;
}
export function assertUnusedSuccessorScope(){
 for(const name of ['controls','handoffs','receipts','clocks']){const path=resolve(here,name);assert(!existsSync(path)||readdirSync(path).length===0,'UNUSED_SNAPSHOT_CONTROL_RECEIPT_CLOCK_SCOPE');}
 for(const name of ['roster-preparation.json','replay-approval.json','replay-native-evidence.json','wrangler.site-roster.json'])assert(!existsSync(resolve(here,name)),'UNUSED_SNAPSHOT_ROSTER_SCOPE');
 for(const id of SCENARIO_IDS)for(const mode of ['start','status','replay'])assert(!existsSync(resolve(G,'..',`cloud-snapshot-${id}-${mode}-${FIXED.sequence}`)),'UNUSED_SNAPSHOT_DRIVER_REPORT_SCOPE');
}
export function loadClosedBaseline(c,reference,{gateReference=null,now=Date.now(),dispatch=false}={}){
 assertContext(c);assert(reference?.path===FIXED.baselinePath,'FIXED_EXCLUSIVE_SUCCESSOR_BASELINE_PATH');
 const b=c.read(reference),gate=loadGate(c,b.gate,{fresh:false});
 assert(gateReference===null||same(b.gate,gateReference),'BASELINE_BINDS_ACTUAL_DECISION_GATE');
 assertClosedBaseline(b,gate,{now,configs:c.configRefs,closedConfigs:c.configs,expectedVersions:c.currentClosed.currentVersions,retainedObserver:c.currentClosed.retainedObserver});
 assertTerminalAuthority(c,b,gate,now);
 // Current unused scope is a first-dispatch precondition, not historical provenance.
 // Both live activation checks in operate.mjs explicitly require dispatch:true.
 if(dispatch)assertUnusedSuccessorScope();return {record:b,gate,reference};
}
export function assertActivationBaseline(d,gate,baseline){
 assert(d.sequence===FIXED.sequence&&baseline&&baseline.reference.path===FIXED.baselinePath&&same(d.baseline,baseline.reference)&&same(d.gate,gate.reference)&&same(baseline.record.gate,gate.reference)&&same(baseline.gate.reference,gate.reference)&&baseline.record.sequence===FIXED.sequence,'ACTIVATION_REQUIRES_EXACT_SUCCESSOR_BASELINE');
}
export function assertDiagnosticRecord(r){
 const p=r.diagnosticProjection;
 assert([null,'command-exit','command-timeout','output-limit','command-error','shutdown-unconfirmed'].includes(r.commandFailureKind),'FINITE_COMMAND_FAILURE_KIND');
 assert(same(r.diagnosticHelpers,FIXED.diagnostics)&&p&&same(Object.keys(p).sort(),['schema','stdoutSha256','stderrSha256','transportCodes','cloudflareCodes','events','unknownDiagnostic','truncated'].sort())&&p.schema==='arc-deployment-diagnostic-v1'&&digest(r.stdoutSha256)&&digest(r.stderrSha256)&&p.stdoutSha256===r.stdoutSha256&&p.stderrSha256===r.stderrSha256&&typeof p.unknownDiagnostic==='boolean'&&typeof p.truncated==='boolean','EXACT_DIAGNOSTIC_PROVENANCE_SCHEMA_HASHES');
 assert(Array.isArray(p.transportCodes)&&p.transportCodes.every(x=>typeof x==='string'&&diagnosticEnums.TRANSPORT_CODES.includes(x))&&Array.isArray(p.cloudflareCodes)&&p.cloudflareCodes.every(x=>diagnosticEnums.CLOUDFLARE_CODES.includes(x))&&Array.isArray(p.events)&&p.events.length<=diagnosticEnums.MAX_EVENTS,'FINITE_DIAGNOSTIC_ENUMS');
 const rebuilt=projectDiagnostic({stdout:p.transportCodes.join('\n')+'\n'+p.cloudflareCodes.map(x=>`[code: ${x}]`).join('\n'),stderr:p.events.map(x=>'ARC_NET_META '+JSON.stringify(x)).join('\n')});
 assert(same(rebuilt.transportCodes,p.transportCodes)&&same(rebuilt.cloudflareCodes,p.cloudflareCodes)&&same(rebuilt.events,p.events)&&(!rebuilt.unknownDiagnostic||p.unknownDiagnostic),'EXACT_DIAGNOSTIC_EVENT_SCHEMA');return p;
}
export function assertCapacity(r){const keys=['total_rows','start_rows','end_rows','remaining_rows','first_at','last_at','unmatched_start_rows'];assert(same(Object.keys(r).sort(),keys.sort()),'COMPLETE_CAPACITY_FIELDS');for(const k of keys.filter(k=>!['first_at','last_at'].includes(k)))assert(integer(r[k]),'CAPACITY_INTEGER');assert(r.total_rows<=256&&r.start_rows+r.end_rows===r.total_rows&&r.remaining_rows===256-r.total_rows&&r.unmatched_start_rows<=r.start_rows&&r.unmatched_start_rows===r.start_rows-r.end_rows,'CAPACITY_ARITHMETIC');assert(r.total_rows===0?r.first_at===null&&r.last_at===null:integer(r.first_at)&&integer(r.last_at)&&r.first_at<=r.last_at,'CAPACITY_TIMES');return {rowsUsed:r.total_rows,unmatchedStarts:r.unmatched_start_rows};}
export function assertQuiet({start,contacts,now}){assert(start.childCloseConfirmed===true&&Array.isArray(contacts),'CONFIRMED_CLIENT_EXIT');const exit=utc(start.confirmedExitAt);let last=null;for(const contact of contacts){const a=utc(contact.startedAt),b=utc(contact.endedAt);assert(a<=b&&b<=now,'CONTACT_TIME');last=Math.max(last??0,b);}const quiet=checkQuiet({now,clientExitedAt:exit,lastCloudContactAt:last,contactRequested:false});assert(quiet.canAdvance,'QUIET_INCOMPLETE');return quiet;}
export function normalizeAcceptance(id,start,observations){const s=SCENARIOS[id];assert(s,'FIXED_SCENARIO');
 if(start.status==='accepted'&&start.accepted===true){const v=start.view;assert(v?.scenarioId===id&&v.jobId===s.jobId&&v.backgroundAccepted===true&&integer(v.acceptedAt)&&digest(v.requestHash),'ACCEPTED_DRIVER_IDENTITY');return {jobId:s.jobId,requestHash:v.requestHash,acceptedAt:v.acceptedAt,basis:'driver',resubmitAllowed:false};}
 assert(start.status==='pending'&&start.accepted===false&&start.reason==='acceptance-unknown','ACTUAL_UNKNOWN_ACCEPTANCE');const get=k=>{const values=observations.filter(x=>x.id===k&&x.ok);assert(values.length===1,'ACTUAL_ACCEPTANCE_CARDINALITY');return values[0];},w=get('workflow');assert(w.instance.workflowName===FIXED.workflowName&&w.instance.instanceId===s.jobId,'MATCHED_WORKFLOW');const rows=['executor-job','site-acceptance'].map(k=>{const x=get(k);assert(x.rowsWritten===0&&x.changedDb===false&&x.rows?.length===1,'CROSS_STORE_ACCEPTANCE');return x.rows[0];});
 assert(rows.every(r=>r.job_id===s.jobId&&digest(r.request_hash)&&integer(r.workflow_accepted_at))&&rows[0].request_hash===rows[1].request_hash&&rows[0].workflow_accepted_at===rows[1].workflow_accepted_at&&rows[1].workflow_id===s.jobId,'MATCHED_PERSISTED_ACCEPTANCE');return {jobId:s.jobId,requestHash:rows[0].request_hash,acceptedAt:rows[0].workflow_accepted_at,basis:'pending-driver-plus-native',resubmitAllowed:false};
}
export function evaluateGap(n,id){assert(id==='after-r2'||id==='after-d1','FAULT_SCENARIO');const e=row(n,'executor-gap'),s=row(n,'site-run-execution'),imports=n.observations.find(o=>o.id==='site-import').rows,w=n.observations.find(o=>o.id==='workflow');
 const rawGapObserved=e.scenario_present===1&&e.job_present===1&&e.fault_marker===id&&integer(e.fault_at)&&e.provider_calls===1&&e.repair_calls===0&&e.rejections===0&&e.delivery_completed_at===null&&s.state!=='ready'&&imports.every(r=>r.phase<5)&&e.receipt_present===(id==='after-r2'?0:1)&&w.instance.status==='complete'&&w.reference?.state==='unavailable'&&w.reference.receiptHash===null;
 return {scenarioId:id,rawGapObserved,faultAt:e.fault_at,receiptPresent:e.receipt_present,disposition:rawGapObserved?'REAL_GAP_OBSERVED':'MISSED_OR_UNRESOLVED_GAP',controlRecoveryAllowed:false};}
export function assertFaultSettlementWindow(q,gap,now){
 assertObservationPolicy(q);assert(q.phase==='fault-settlement'&&gap.phase==='fault-gap'&&gap.allChecksPassed===true&&gap.gap?.rawGapObserved===true&&gap.gap.scenarioId===q.scenarioId&&gap.request.scenarioId===q.scenarioId&&same(gap.request.start,q.start),'REAL_ORIGINAL_FAULT_GAP');
 const earliestAt=utc(gap.endedAt)+60000;assert(integer(earliestAt)&&integer(now)&&now>=earliestAt,'ORIGINAL_GAP_DELAY_BEFORE_SETTLEMENT');
 if(Object.hasOwn(q,'preparedAt'))assert(integer(q.preparedAt)&&q.preparedAt>=earliestAt&&q.preparedAt<=now,'ORIGINAL_SETTLEMENT_PREPARATION_AFTER_GAP_DELAY');
 return earliestAt;
}
function assertBudgetAccounting(n,id,observedScenarioIds,proof,now){
 const o=n.observations.find(x=>x.id==='site-budget-buckets'&&x.ok),ids=observedScenarioIds;
 assert(Array.isArray(ids)&&ids.length>=1&&ids.length<=3&&new Set(ids).size===ids.length&&ids.every(x=>Object.hasOwn(SCENARIOS,x))&&ids.includes(id),'FIXED_OBSERVED_BUDGET_SCOPE');
 assert(o&&o.rowsWritten===0&&o.changedDb===false&&Array.isArray(o.rows)&&same(o.rows.map(b=>b.scenario_id).sort(),[...ids].sort()),'EXACT_OBSERVED_BUDGET_RESERVATIONS');
 const rows=o.rows;for(const key of ['reservation_hash','run_hash','job_id'])assert(new Set(rows.map(b=>b[key])).size===ids.length,'UNIQUE_BUDGET_'+key);
 for(const b of rows){
  assert(b.job_id===SCENARIOS[b.scenario_id].jobId&&digest(b.request_hash)&&digest(b.run_hash)&&digest(b.reservation_hash)&&b.binding_matches===1&&b.status==='settled'&&b.settled_micros===1,'EXACT_BOUND_BUDGET_SETTLEMENT');
  assert(b.global_reservations===ids.length&&b.global_reserved===0&&b.global_settled===ids.length*2,'EXACT_GLOBAL_BUDGET_TOTALS');
  assert(integer(b.created_at)&&b.created_at<=now&&digest(b.day_bucket_hash)&&digest(b.month_bucket_hash)&&b.day_bucket_hash!==b.month_bucket_hash,'ORIGINAL_BUDGET_IDENTITIES');
  const date=new Date(b.created_at);assert(Number.isFinite(date.valueOf()),'ORIGINAL_BUDGET_DATE');const iso=date.toISOString(),periods={day:Date.parse(iso.slice(0,10)+'T00:00:00.000Z'),month:Date.parse(iso.slice(0,7)+'-01T00:00:00.000Z')};
  for(const kind of ['day','month']){const peers=rows.filter(x=>x[kind+'_bucket_hash']===b[kind+'_bucket_hash']);
   assert(b[kind+'_scope']==='site'&&b[kind+'_kind']===kind&&b[kind+'_period_start']===periods[kind]&&b[kind+'_reserved']===0&&b[kind+'_settled']===peers.length,'EXACT_ORIGINAL_PERIOD_BUDGET');
  }
 }
 const current=rows.find(b=>b.scenario_id===id);assert(current.run_hash===proof.run_hash&&current.request_hash===proof.request_hash,'ORIGINAL_RUN_BUDGET_BINDING');
}
export function scenarioProof(n,id,{acceptance,start=null,gap=null,contacts=[],quiet=null,observedScenarioIds,now}){
 const s=SCENARIOS[id],r=row(n,'executor-receipt'),j=row(n,'executor-job'),e=row(n,'executor-scenario'),site=row(n,'site-run-execution'),i=row(n,'site-import'),a=row(n,'site-acceptance'),delivery=row(n,'executor-delivery'),ack=row(n,'executor-acceptance-delivery'),audit=row(n,'site-audit'),account=row(n,'site-accounting'),proof=row(n,'site-replay-proof'),metadata=row(n,'executor-replay-metadata'),w=n.observations.find(x=>x.id==='workflow');
 assert(acceptance.jobId===s.jobId&&j.job_id===s.jobId&&j.request_hash===acceptance.requestHash&&j.workflow_accepted_at===acceptance.acceptedAt&&a.workflow_accepted_at===acceptance.acceptedAt&&a.request_hash===j.request_hash&&a.workflow_id===s.jobId,'ORIGINAL_ACCEPTANCE_CHAIN');
 assert(integer(j.began_at)&&j.execution_expires_at===j.began_at+1260000&&j.began_at<j.queue_expires_at&&j.dispatch_state==='claimed'&&j.dispatch_at>=j.accepted_at,'ORIGINAL_GRANT_CHAIN');
 assert(e.provider_calls===1&&e.repair_calls===0&&e.rejections===0&&(id==='long'?e.fault_marker===null&&e.fault_at===null:e.fault_marker===id&&integer(e.fault_at)),'EXACT_PROVIDER_FAULT_COUNTS');
 assert(w.instance.instanceId===s.jobId&&w.instance.workflowName===FIXED.workflowName&&w.instance.status==='complete'&&w.steps.length===1&&w.steps[0].attempts.length===1&&w.steps[0].attempts[0].state==='success','ONE_WORKFLOW_ATTEMPT');
 assert(r.receipt_hash===r.metadata_receipt_hash&&r.grant_job_id===s.jobId&&r.grant_request_hash===j.request_hash&&r.began_at===j.began_at&&r.execution_expires_at===j.execution_expires_at&&r.outcome_kind==='response'&&r.actual_model==='moonshotai/kimi-k3'&&r.error_code===null,'EXECUTOR_RECEIPT');
 assert(same([r.prompt_tokens,r.completion_tokens,r.total_tokens,r.cost_micros,r.web_search_requests],[10,20,30,1,2])&&integer(r.latency_ms)&&r.produced_at>=r.began_at&&r.produced_at<=r.execution_expires_at,'ACTUAL_RECEIPT_USAGE_TIMING');
 assert(site.state==='ready'&&site.execution_mode==='cloudflare-workflow-v1'&&site.request_hash===j.request_hash&&site.began_at===j.began_at&&site.execution_expires_at===j.execution_expires_at&&site.active_slot===null&&site.active_expires_at===null&&site.error_code===null&&site.package_present===1&&site.package_identity_matches===1&&site.quota_key_matches===1&&/^p2-[a-f0-9]{32}$/u.test(site.config_fingerprint)&&/^p2-[a-f0-9]{32}$/u.test(site.content_fingerprint),'ACTUAL_SITE_READY');
 assert(i.phase===5&&i.mode==='body'&&i.request_hash===j.request_hash&&i.receipt_hash===r.receipt_hash&&i.metadata_receipt_hash===r.receipt_hash&&i.began_at===j.began_at&&i.execution_expires_at===j.execution_expires_at&&i.decision_cleared===1&&i.resolution_present===1&&i.config_fingerprint===site.config_fingerprint,'SETTLED_IMPORT');
 assert(delivery.receipt_hash===r.receipt_hash&&integer(delivery.completed_at)&&delivery.stopped_code===null&&integer(ack.acknowledged_at)&&ack.stopped_code===null&&integer(r.site_acknowledged_at)&&integer(r.body_removed_at)&&r.cleanup_requested_at===r.body_removed_at,'ACTUAL_DELIVERY_CLEANUP');
 assert(Object.entries(account).every(([k,v])=>k==='job_id'?v===s.jobId:v===1),'EXACT_ACCOUNTING');assertBudgetAccounting(n,id,observedScenarioIds,proof,now);
 assert(audit.status==='accepted'&&audit.purpose==='role-research'&&audit.provider==='openrouter'&&audit.model==='moonshotai/kimi-k3'&&audit.latency_ms===r.latency_ms&&audit.error_code===null&&same([audit.cost_micros,audit.total_tokens,audit.web_search_requests],[1,30,2]),'MATCHED_AUDIT_USAGE');
 assert(n.observations.find(x=>x.id==='site-expiry-recovery').rows.length===0,'NO_EXPIRY_RECOVERY');
 assert(proof.receipt_hash===r.receipt_hash&&proof.request_hash===j.request_hash&&proof.accepted_at===acceptance.acceptedAt&&proof.began_at===j.began_at&&proof.execution_expires_at===j.execution_expires_at&&proof.metadata_sha256===metadata.metadata_sha256&&proof.receipt_hash===metadata.receipt_hash&&same(proof.metadata,metadata.metadata),'CROSS_STORE_CANONICAL_METADATA');
 for(const key of ['scenarios','runs','executions','imports','packages','acceptances','quota_reserved','quota_accepted','budgets','audits','settled_micros'])assert(proof[key]===1,'EXACT_REPLAY_COUNT_'+key);assert(proof.quota_rows===2&&proof.package_expires_at>now&&proof.package_expires_at>proof.database_time,'LIVE_PACKAGE_EXPIRY');
 const expiry=Date.parse(new Date(proof.run_created_at+14*86400000).toISOString().slice(0,10)+'T00:00:00.000Z');assert(proof.package_expires_at===expiry,'ORIGINAL_CALENDAR_DAY_EXPIRY');
 let cronCausation=false;
 if(id==='long')assert(quiet&&utc(n.startedAt)>=quiet.quietEndsAt&&r.latency_ms>=1170000&&r.latency_ms<1200000,'LONG_QUIET_AND_PROVIDER_ELAPSED');
 else{assert(gap?.rawGapObserved===true&&gap.faultAt===e.fault_at,'REAL_GAP_REQUIRED');assert(start?.scenarioId===id,'EXACT_FAULT_START_SCENARIO');assertFaultContactOrder(start,contacts,{beforeGap:false,now:utc(n.startedAt)});const crons=n.observations.find(x=>x.id==='executor-cron-pairs').rows;cronCausation=crons.some(c=>c.outcome==='ok'&&c.started_at<=delivery.completed_at&&c.ended_at>=delivery.completed_at&&c.ended_at>=e.fault_at&&c.delivery_completed_at===delivery.completed_at&&i.updated_at>=e.fault_at&&i.updated_at<=c.ended_at);assert(cronCausation,'CORRELATED_CRON_DELIVERY_IMPORT');}
 return {scenarioId:id,jobId:s.jobId,requestHash:j.request_hash,receiptHash:r.receipt_hash,receiptMetadataSha256:proof.metadata_sha256,runHash:proof.run_hash,packageHash:proof.package_hash,acceptedAt:acceptance.acceptedAt,beganAt:j.began_at,executionExpiresAt:j.execution_expires_at,queueExpiresAt:j.queue_expires_at,packageExpiresAt:proof.package_expires_at,runCreatedAt:proof.run_created_at,accounting:account,providerCalls:1,repairCalls:0,cronCausation,causationScope:id==='long'?'independent-elapsed-workflow':'native-gap-plus-correlated-cron-delivery-import',receiptExpected:{jobId:s.jobId,requestHash:j.request_hash,d1:{metadata:metadata.metadata,cleanupRequestedAt:metadata.cleanup_requested_at,bodyRemovedAt:metadata.body_removed_at}}};
}
export function faultSettlementOutcome(n,id,options,{allowIncomplete=false}={}){
 assert(['after-r2','after-d1'].includes(id),'FAULT_SCENARIO');
 try{
  assert(n.allReadsSucceeded===true,'COMPLETE_NATIVE_SETTLEMENT');
  const acceptance=normalizeAcceptance(id,options.start.report,n.observations);
  return {allChecksPassed:true,scenarioProof:scenarioProof(n,id,{...options,acceptance})};
 }catch{assert(allowIncomplete,'SCENARIO_NOT_PROVED');return {allChecksPassed:false,disposition:'INCOMPLETE_NATIVE_SETTLEMENT'};}
}
export function scopeFromNative(n,mapping){const executor=row(n,'executor-global-lifecycle'),site=row(n,'site-global-lifecycle'),roster=n.observations.find(o=>o.id==='executor-job-roster').rows,instances=mapping.rosters[FIXED.workflowName];
 assert(executor.jobs===site.executions&&executor.jobs===roster.length&&same(roster.map(x=>x.job_id).sort(),instances.map(x=>x.instanceId).sort()),'EXACT_JOB_WORKFLOW_EXECUTION_SCOPE');const observed=SCENARIO_IDS.filter(id=>roster.some(r=>r.job_id===SCENARIOS[id].jobId)),terminal=observed.filter(id=>instances.some(x=>x.instanceId===SCENARIOS[id].jobId&&['complete','completed','errored','terminated'].includes(x.status)));
 const counters={...executor,...site},outstanding=Object.fromEntries(OUTSTANDING_KEYS.map(k=>[k,counters[k]])),scope={expectedScenarioIds:SCENARIO_IDS,observedScenarioIds:observed,outstanding,terminal},deadlines=n.observations.find(o=>o.id==='executor-accepted-deadlines').rows;assert(same(deadlines.map(x=>x.job_id),roster.map(x=>x.job_id))&&deadlines.every(x=>x.began_at===null?x.execution_expires_at===null:integer(x.began_at)&&x.execution_expires_at===x.began_at+1260000),'ACTUAL_ACCEPTED_DEADLINE_ROSTER');return {scope,...assertCompletionScope(scope),capacity:assertCapacity(row(n,'cron-capacity-and-unmatched')),latestExecutionExpiresAt:deadlines.length?Math.max(...deadlines.map(x=>x.execution_expires_at??0)):null,missingGrant:deadlines.some(x=>x.began_at===null)};}
export function assertReplayReply(reply,step,id){
 const common=['schemaVersion','scenarioId','step','completed'];
 const bridge=['submit','status'].includes(step),ownerB=step.startsWith('owner-b');
 const keys=ownerB?[...common,'isNull']:bridge?[...common,'identity','original','receipt','checks']:[...common,'identity','checks'];
 assert(reply?.schemaVersion==='arc-smoke-replay-v1'&&reply.scenarioId===id&&reply.step===step&&reply.completed===true&&same(Object.keys(reply).sort(),keys.sort()),'EXACT_PRODUCTION_REPLAY_REPLY');
 if(ownerB){assert(reply.isNull===true,'OWNER_B_NULL');return;}
 const checks=bridge?['approvalMatched','settled','acceptedProofMatched','grantMatched','receiptMatched']:['approvalMatched','settled','runMatched','packageMatched','ready','backgroundAccepted'];
 assert(reply.checks&&same(Object.keys(reply.checks).sort(),checks.sort())&&Object.values(reply.checks).every(v=>v===true),'EXACT_PRODUCTION_REPLAY_CHECKS');
}
export function replayNativeProof(n,id,now){
 const p=row(n,id+':site-replay-proof'),m=row(n,id+':executor-replay-metadata'),a=row(n,id+':site-accounting'),counter=row(n,id+':executor-scenario');
 assert(p.job_id===SCENARIOS[id].jobId&&counter.job_id===p.job_id&&counter.provider_calls===1&&counter.repair_calls===0&&counter.rejections===0,'NATIVE_REPLAY_PROVIDER_IDENTITY');
 for(const key of ['scenarios','runs','executions','imports','packages','acceptances','quota_reserved','quota_accepted','budgets','audits','settled_micros'])assert(p[key]===1,'EXACT_REPLAY_BASELINE_'+key);
 const accounting=['job_id','quota_reserved','quota_accepted','budget_reservations','budget_settled','settled_micros','packages','audits'];assert(same(Object.keys(a).sort(),accounting.sort())&&Object.entries(a).every(([k,v])=>k==='job_id'?v===p.job_id:v===1),'EXACT_REPLAY_ACCOUNTING');
 assert(p.quota_rows===2&&p.package_expires_at>now&&m.job_id===p.job_id&&m.receipt_hash===p.receipt_hash&&m.metadata_sha256===p.metadata_sha256&&same(m.metadata,p.metadata)&&hash(canonicalJson(p.metadata))===p.metadata_sha256,'ORIGINAL_REPLAY_METADATA_EXPIRY');
 assert(p.metadata.grant.jobId===p.job_id&&p.metadata.grant.requestHash===p.request_hash&&p.metadata.grant.beganAt===p.began_at&&p.metadata.grant.executionExpiresAt===p.execution_expires_at&&p.metadata.receiptHash===p.receipt_hash,'ORIGINAL_REPLAY_METADATA_GRANT');return p;
}
export function assertReplayReport(report,id,proof,startedAfter,finishedBefore){
 assert(report.mode==='replay'&&report.scenarioId===id&&report.status==='passed'&&report.steps?.length===6,'COMPLETE_SIX_SIGNED_REPLIES');assert(same(report.steps.map(x=>x.step),['submit','status','owner-a-recover','owner-a-get','owner-b-recover','owner-b-get']),'EXACT_REPLAY_STEP_ORDER');let previous=startedAfter;
 for(const x of report.steps){const reply=x.reply;assertReplayReply(reply,x.step,id);assert(x.result==='completed'&&integer(x.startedAt)&&integer(x.finishedAt)&&x.startedAt>=previous&&x.finishedAt>=x.startedAt&&x.finishedAt<=finishedBefore,'REPLAY_COMPLETED_ORDER');previous=x.finishedAt;
  if(!x.step.startsWith('owner-b')){assert(same(reply.identity,{jobId:proof.job_id,requestHash:proof.request_hash,runHash:proof.run_hash,packageHash:proof.package_hash}),'REPLAY_ORIGINAL_IDENTITY');if(['submit','status'].includes(x.step))assert(same(reply.original,{acceptedAt:proof.accepted_at,beganAt:proof.began_at,executionExpiresAt:proof.execution_expires_at,queueExpiresAt:proof.queue_expires_at})&&same(Object.keys(reply.receipt).sort(),['bodyState','metadataSha256','receiptHash'])&&reply.receipt.receiptHash===proof.receipt_hash&&reply.receipt.metadataSha256===proof.metadata_sha256&&['available','removed'].includes(reply.receipt.bodyState),'REPLAY_ORIGINAL_GRANT_RECEIPT');}
 }return previous;
}
export function compareReplay(before,after,reports){
 assert(['post-site-roster','reconcile-site-roster'].includes(before?.phase)&&after?.phase==='replay-after'&&utc(after.startedAt)>=utc(before.endedAt),'ACTUAL_REPLAY_WINDOWS');const allowedId=id=>id.includes(':')||id==='executor-job-roster'||id.endsWith('-global-lifecycle');
 assert(same(before.mapping.versions,after.mapping.versions)&&same(before.mapping.configs,after.mapping.configs),'SAME_ACTUAL_ROSTER_REVISION_AND_EXECUTOR_PAIR_DURING_REPLAY');
 const normalized=n=>n.observations.filter(o=>allowedId(o.id)).map(o=>({id:o.id,rows:o.rows.map(r=>Object.fromEntries(Object.entries(r).filter(([k])=>k!=='database_time')))}));
 assert(same(normalized(before),normalized(after)),'REPLAY_NATIVE_EFFECTS_CHANGED');for(const name of Object.keys(before.mapping.rosters))assert(same(before.mapping.rosters[name],after.mapping.rosters[name]),'REPLAY_WORKFLOW_ROSTER_CHANGED');
 assert(Array.isArray(reports)&&same(reports.map(r=>r.scenarioId),SCENARIO_IDS),'THREE_ORDERED_REPLAY_REPORTS');let previous=utc(before.endedAt);
 for(const [index,id] of SCENARIO_IDS.entries()){const proof=replayNativeProof(before,id,utc(after.endedAt));previous=assertReplayReport(reports[index],id,proof,previous,utc(after.startedAt));}
 return {allChecksPassed:true,signedSteps:18,exactlyOnce:true};
}
export function assertDrain(first,second,closeEndedAt){assert(utc(first.startedAt)>=closeEndedAt+931000&&utc(second.startedAt)>=utc(first.endedAt)+60000,'ACTUAL_DELAYED_DRAIN_WINDOWS');assert(first.scope.safeToClose&&second.scope.safeToClose,'NATIVE_SETTLED_SCOPE');
 for(const native of [first.native,second.native])for(const id of ['executor-maintenance-cursors','site-maintenance-cursors'])assertCursorRows(id,native.observations.find(o=>o.id===id)?.rows);
 const ids=['executor-global-lifecycle','site-global-lifecycle','executor-maintenance-cursors','site-maintenance-cursors','cron-capacity-and-unmatched','cron-recent-events','executor-job-roster'];for(const id of ids)assert(same(first.native.observations.find(o=>o.id===id)?.rows,second.native.observations.find(o=>o.id===id)?.rows),'STABLE_COMPLETE_DRAIN_STATE');
 for(const n of [first.native,second.native]){const lease=row(n,'executor-maintenance-lease');assert(lease.lease_current===0&&lease.lease_until<=lease.observed_database_time_ms,'NO_CURRENT_LEASE');}const omitTime=r=>Object.fromEntries(Object.entries(r).filter(([k])=>k!=='observed_database_time_ms'));assert(same(omitTime(row(first.native,'executor-maintenance-lease')),omitTime(row(second.native,'executor-maintenance-lease'))),'STABLE_LEASE_GENERATION');assert(same(first.mapping,second.mapping),'STABLE_DRAIN_MAPPING');return {applicationSettled:true,platformInvocationAbsenceProved:false,...(first.permanentIncomplete||second.permanentIncomplete?{permanentIncomplete:true,disposition:'INCOMPLETE'}:{})};}

export function readinessHandoff({clock,native,capacity,now,readinessStartedAt,mode,scenarioId,expectedVersions,earliestPackageExpiresAt=null,latestExecutionExpiresAt=null,closedProof}){
 assert(Object.hasOwn(SCENARIOS,scenarioId)&&['start','status','replay'].includes(mode),'FIXED_SIGNED_HANDOFF');assertFresh(native.startedAt,native.endedAt,now);assert(integer(readinessStartedAt)&&readinessStartedAt<=now&&now-readinessStartedAt<900000,'OPERATOR_READINESS_AGE');
 const handoff=checkHandoff({...clock,now,...capacity,latestExecutionExpiresAt,prospectiveStart:mode==='start',earliestPackageExpiresAt,remainingReplayMs:mode==='replay'?replayReserveMs('replay'):0,nativeMaintenanceClosedProof:closedProof,expectedExecutorVersion:expectedVersions.executor});assert(handoff.canAdvance&&handoff.cloudContactAllowed&&handoff.operationDeadlineAt-now>=65000,'HANDOFF_BUDGET_OR_65S_CHILD_RESERVE');
 return {schemaVersion:'arc-snapshot-signed-handoff-v1',scenarioId,mode,jobId:SCENARIOS[scenarioId].jobId,reportName:`cloud-snapshot-${scenarioId}-${mode}-${FIXED.sequence}`,originalClocks:clock,expectedVersions,nativeStartedAt:native.startedAt,nativeEndedAt:native.endedAt,readinessStartedAt,deadlineAt:Math.min(handoff.operationDeadlineAt,utc(native.startedAt)+900000,readinessStartedAt+900000,earliestPackageExpiresAt??Infinity),inputAllowanceMs:mode==='replay'?45000:60000,childReserveMs:65000,handoff};
}

// Only these three complete applied readbacks serve two adjacent purposes. The
// original native record, phase, identities and freshness are never rewritten.
export function assertSharedRead(gate,purpose){
 const phases={'long-start':['post-activate','reconcile-activate'],replay:['post-site-roster','reconcile-site-roster'],'maintenance-close':['post-admission-close','reconcile-admission-close']};
 assert(phases[purpose]?.includes(gate?.phase)&&gate.allChecksPassed===true&&!gate.permanentIncomplete&&!gate.request?.incompleteClosure&&gate.reconciliation?.outcome!=='predecessor-still-observed'&&(!gate.phase.startsWith('reconcile-')||gate.reconciliation?.appliedProved===true),'COMPLETE_APPLIED_FIXED_SHARED_READ');
 assert(gate.scope?.safeToClose===true&&!gate.scope.missingGrant,'SHARED_READ_SETTLED_SCOPE');
}
export function operationGateBudget(c,d,gate,now){
 assertContext(c);
 if(d.kind==='maintenance-close'&&['post-admission-close','reconcile-admission-close'].includes(gate.phase)){
  assertSharedRead(gate,'maintenance-close');assertFresh(gate.startedAt,gate.endedAt,now);
  assert(d.clockReference&&same(d.gate,gate.reference),'SHARED_CLOSE_ACTUAL_GATE_REFERENCE');
  const clock=loadClock(c,d.clockReference),record=c.read(d.clockReference),source=c.read(gate.request.clockReference);
  assert(clock.stage==='maintenance-close'&&same(record.stageSource,d.gate)&&clock.stageStartedAt===utc(gate.endedAt)&&same(record.activationResult,source.activationResult)&&clock.activationStartedAt===source.activationStartedAt&&clock.activationStartedAt===gate.request.clock.activationStartedAt,'SHARED_CLOSE_ORIGINAL_NEXT_STAGE_CLOCK');
  const budget=checkHandoff({...clock,now,...gate.scope.capacity,latestExecutionExpiresAt:gate.scope.latestExecutionExpiresAt,prospectiveStart:false,earliestPackageExpiresAt:null,remainingReplayMs:0,expectedExecutorVersion:gate.mapping.versions.executor});
  assert(budget.canAdvance&&budget.cloudContactAllowed,'SHARED_CLOSE_STAGE_OR_CAPACITY');
  return {...budget,sharedRead:'post-admission-close-to-maintenance-close',gate:d.gate,clockReference:d.clockReference};
 }
 assert(gate.phase===(d.kind==='activate'?'preactivation':'pre-'+d.kind),'EXACT_PRE_OPERATION_GATE');
 assertReadBudget(gate.request,gate.request.clock,now);return {operationDeadlineAt:gate.request.deadlineAt,sharedRead:null,gate:d.gate,clockReference:gate.request.clockReference};
}
export function assertSignedPrerequisites({scenarioId,mode,clock,gate,completedIds=[]}){
 assert(!gate.request?.incompleteClosure,'RECOVERY_FORBIDS_SIGNED_CONTROL');
 assert(Object.hasOwn(SCENARIOS,scenarioId)&&['start','status','replay'].includes(mode),'FIXED_SIGNED_MODE');
 const stage=mode==='replay'?'replay':scenarioId==='long'?(mode==='start'?'activation':'long-proof'):scenarioId;assert(clock.stage===stage,'EXACT_SIGNED_STAGE');
 const previous=SCENARIO_IDS.slice(0,SCENARIO_IDS.indexOf(scenarioId));
 assert(gate.scope&&!gate.scope.missingGrant,'ACTUAL_NATIVE_SCOPE_AND_GRANTS');
 if(mode==='start'){if(scenarioId==='long')assertSharedRead(gate,'long-start');else assert(gate.phase==='prestart','FAULT_PRESTART_NATIVE');assert(gate.scope.safeToClose&&same(gate.scope.scope.observedScenarioIds,previous)&&same(completedIds,previous),'EXACT_SETTLED_PREVIOUS_SCENARIOS_BEFORE_START');}
 if(mode==='status')assert(['long-proof','fault-settlement'].includes(gate.phase)&&gate.scenarioProof?.scenarioId===scenarioId,'INDEPENDENT_NATIVE_PROOF_BEFORE_STATUS');
 if(mode==='replay'){assertSharedRead(gate,'replay');assert(gate.scope.fullScenarioCompletion&&same(gate.scope.scope.observedScenarioIds,SCENARIO_IDS)&&same(completedIds,SCENARIO_IDS),'ALL_THREE_SETTLED_BEFORE_REPLAY');}
}
export function assertCompletedStatus(p,status,receiptEndedAt,now){const v=status.report.view;
 assert(v&&same(Object.keys(v).sort(),['acceptedAt','backgroundAccepted','jobId','requestHash','scenarioId','settled','state']),'EXACT_FROZEN_SAFE_STATUS');
 assert(utc(status.startedAt)>=receiptEndedAt&&utc(status.endedAt)<=now&&status.report.status==='accepted'&&status.report.accepted===true&&v.scenarioId===p.scenarioId&&v.state==='ready'&&v.backgroundAccepted===true&&v.settled===true&&v.jobId===p.jobId&&v.requestHash===p.requestHash&&v.acceptedAt===p.acceptedAt,'ACTUAL_ORIGINAL_STATUS_AFTER_NATIVE_AND_R2');
}
export function completedProofs(c,sources,ids,{now=Date.now()}={}){
 assert(Array.isArray(sources)&&same(sources.map(x=>x.scenarioId),ids),'EXACT_ORDERED_COMPLETED_PROOF_SOURCES');
 return sources.map(source=>{const gate=loadGate(c,source.nativeGate,{fresh:false}),p=gate.scenarioProof;assert(gate.allChecksPassed&&p?.scenarioId===source.scenarioId,'REAL_NATIVE_SCENARIO_PROOF');const r=verifyReceipt(c,source.receipt,source.nativeGate,p),status=loadControl(c,source.status,'status',source.scenarioId),v=status.report.view;
  assertCompletedStatus(p,status,utc(r.endedAt),now);return p;});
}
function signedValue(c,spec,now,preview=false){assertContext(c);assertNoRecoveryControl(c,now);const {scenarioId:id,mode}=spec;assertMaterials(spec.materials,c);const gate=loadGate(c,spec.nativeGate,{fresh:false}),clock=loadClock(c,spec.clockReference),state=loadState(c,spec.state);assertFresh(gate.startedAt,gate.endedAt,now);assert(same(gate.mapping.versions,state.versions)&&same(gate.mapping.configs,state.configs),'SIGNED_CURRENT_ACTUAL_STATE');
 const readiness=preview?{userReadyAt:now}:c.read(spec.readiness);let terminalReadiness=null;
 if(!preview){assert(spec.readiness.path===resolve(here,'handoffs',id+'-'+mode+'-readiness.json')&&readiness.schemaVersion==='arc-snapshot-attended-readiness-v1'&&readiness.rootReviewed===true&&same(readiness.nativeGate,spec.nativeGate)&&same(readiness.materials,spec.materials)&&readiness.scenarioId===id&&readiness.mode===mode&&integer(readiness.userReadyAt)&&readiness.userReadyAt>=utc(gate.endedAt)&&readiness.userReadyAt<=now,'ACTUAL_ATTENDED_READINESS_SOURCE');terminalReadiness=assertTerminalReadiness(c,readiness,spec,gate,now);}
 const previous=SCENARIO_IDS.slice(0,SCENARIO_IDS.indexOf(id)),required=mode==='replay'?SCENARIO_IDS:mode==='start'?previous:[],proofs=completedProofs(c,spec.completed??[],required,{now});assertSignedPrerequisites({scenarioId:id,mode,clock,gate,completedIds:proofs.map(x=>x.scenarioId)});
 if(mode==='start'&&id==='long')assert(same(spec.state,spec.nativeGate)&&same(spec.clockReference,gate.request.clockReference),'LONG_SHARED_ACTIVATION_STATE_AND_CLOCK');
 const config=c.read(gate.mapping.configs.executor);assert(config.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED==='true'&&same(config.triggers.crons,['* * * * *'])&&(mode!=='start'||config.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW==='true'),'ACTIVE_CONFIG_BEFORE_SIGNED_CONTROL');
 let earliestPackageExpiresAt=null;
 if(mode==='status'){const r=verifyReceipt(c,spec.receipt,spec.nativeGate,gate.scenarioProof);assert(utc(r.endedAt)<=now,'NATIVE_R2_BEFORE_STATUS');}
 if(mode==='replay'){
  assert(same(spec.state,spec.nativeGate)&&same(c.read(spec.clockReference).stageSource,spec.nativeGate)&&same(gate.request.rosterPreparation,spec.rosterPreparation)&&same(gate.request.completed,spec.completed),'REPLAY_SHARED_POST_ROSTER_SOURCES');
  assert(['post-site-roster','reconcile-site-roster'].includes(state.reference&&loadGate(c,state.reference,{fresh:false}).phase),'ACTUAL_SITE_ROSTER_DEPLOYMENT');const prep=verifyRosterPreparation(c,spec.rosterPreparation,{now}),approval=c.read(prep.approval),evidence=c.read(prep.evidence),site=c.read(gate.mapping.configs.site);
  assert(spec.rosterPreparation.path===resolve(here,'roster-preparation.json')&&prep.schemaVersion==='arc-snapshot-roster-preparation-v1'&&prep.evidence.sha256===approval.nativeEvidenceSha256&&same(evidence.proofs,spec.completed)&&same(evidence.inventory,FIXED.inventory)&&approval.inventorySha256===FIXED.inventory.sha256&&same(JSON.parse(site.vars.SMOKE_REPLAY_APPROVAL_JSON),approval)&&site.vars.SMOKE_REPLAY_INVENTORY_SHA256===FIXED.inventory.sha256&&verify(prep.approval).length<=4096,'ACTUAL_HOST_NATIVE_DEPLOYED_ROSTER');
  const keys=['scenarioId','jobId','requestHash','receiptHash','receiptMetadataSha256','runHash','packageHash','acceptedAt','beganAt','executionExpiresAt'];assert(same(approval.scenarios,proofs.map(p=>Object.fromEntries(keys.map(k=>[k,p[k]])))),'ALL_ORIGINAL_APPROVAL_IDENTITIES');
  earliestPackageExpiresAt=Math.min(...proofs.map(p=>p.packageExpiresAt));for(const p of proofs){const native=replayNativeProof(gate.native,p.scenarioId,now);assert(native.run_hash===p.runHash&&native.package_hash===p.packageHash&&native.receipt_hash===p.receiptHash&&native.metadata_sha256===p.receiptMetadataSha256&&native.accepted_at===p.acceptedAt&&native.began_at===p.beganAt&&native.execution_expires_at===p.executionExpiresAt&&native.package_expires_at===p.packageExpiresAt,'CURRENT_REPLAY_NATIVE_ORIGINAL_PROOF');}
  assert(Array.isArray(spec.priorReplays)&&same(spec.priorReplays.map(x=>x.scenarioId),previous),'EXACT_PRIOR_REPLAY_SEQUENCE');let previousReplayEnd=utc(gate.endedAt);for(const item of spec.priorReplays){const exit=loadControl(c,item.reference,'replay',item.scenarioId);assert(exit.report.status==='passed'&&exit.report.steps.length===6&&exit.report.steps.every(x=>x.result==='completed')&&same(c.read(exit.handoff).spec.nativeGate,spec.nativeGate)&&utc(exit.endedAt)<=now,'NO_PARTIAL_REPLAY_CONTINUATION');assert(same(exit.expectedVersions,state.versions)&&utc(exit.startedAt)>=previousReplayEnd,'ORDERED_CURRENT_PAIR_REPLAY');previousReplayEnd=assertReplayReport(exit.report,item.scenarioId,replayNativeProof(gate.native,item.scenarioId,now),previousReplayEnd,utc(exit.endedAt));previousReplayEnd=utc(exit.endedAt);}
 }
 const handoff=readinessHandoff({clock,native:gate,capacity:gate.scope.capacity,now,readinessStartedAt:readiness.userReadyAt,mode,scenarioId:id,expectedVersions:state.versions,earliestPackageExpiresAt,latestExecutionExpiresAt:gate.scope.latestExecutionExpiresAt});
 if(terminalReadiness)handoff.deadlineAt=Math.min(handoff.deadlineAt,terminalReadiness.t.validUntil);
 // Deadline derives only from original clocks/native/readiness; evaluation time never renews it.
 return {...handoff,spec,nativeEvidence:gate.nativeReference,proofReferences:spec.completed??[],materials:spec.materials,inventory:FIXED.inventory,driver:FIXED.driver,approval:mode==='replay'?c.read(spec.rosterPreparation).approval:null};
}
export function prepareSignedHandoff(c,spec){const value=signedValue(c,spec,Date.now());return write(resolve(here,'handoffs',spec.scenarioId+'-'+spec.mode+'.json'),value);}
// In-memory prerequisite check only; cannot create a handoff or readiness record.
export function previewSignedHandoff(c,spec,now=Date.now()){return {...signedValue(c,spec,now,true),status:'LOCAL_PREREQUISITE_PREVIEW_NOT_USER_READINESS'};}
export function validateSignedHandoff(c,reference,{now=Date.now(),dispatch=false}={}){const stored=c.read(reference);assert(reference.path===resolve(here,'handoffs',stored.scenarioId+'-'+stored.mode+'.json'),'FIXED_EXCLUSIVE_HANDOFF_PATH');const recomputed=signedValue(c,stored.spec,now);const stable=x=>{const {handoff,...rest}=x;return rest;};assert(same(stable(stored),stable(recomputed))&&now<stored.deadlineAt&&stored.deadlineAt-now>=65000,'ORIGINAL_SIGNED_HANDOFF_CANNOT_RENEW');if(dispatch){assert(!existsSync(resolve(G,'..',stored.reportName))&&!existsSync(resolve(here,'controls',stored.scenarioId+'-'+stored.mode+'-exit.json')),'SIGNED_REPORT_ALREADY_CONSUMED');assertCurrentPins(c,[reference]);assert(stored.deadlineAt-Date.now()>=65000,'POST_PIN_SIGNED_CHILD_RESERVE');}return stored;}

const cached=new WeakMap();
function cache(c){assertContext(c);if(!cached.has(c))cached.set(c,new Map());return cached.get(c);}
export function assertReadPredecessor(phase,native,now){if(historicalReadPhase(phase))assert(utc(native.startedAt)<=utc(native.endedAt)&&utc(native.endedAt)<=now,'HISTORICAL_PREDECESSOR_TIME');else assertFresh(native.startedAt,native.endedAt,now);}
export function assertClosedState(gate,operation,config){
 assert(['post-maintenance-close','reconcile-maintenance-close'].includes(gate.phase)&&gate.scope.safeToClose&&gate.reconciliation?.outcome!=='predecessor-still-observed','ACTUAL_CLOSED_NATIVE_SCOPE');
 const version=gate.mapping.versions.executor;
 assert(operation.kind==='maintenance-close'&&operation.mode==='deploy'&&operation.childCloseConfirmed===true&&utc(operation.endedAt)<=utc(gate.startedAt),'ACTUAL_MAINTENANCE_CLOSE_PROVENANCE');
 assert(gate.phase==='reconcile-maintenance-close'?operation.commandSucceeded===false&&operation.mutationAttempted===true&&gate.request.reconciledVersion===version:operation.commandSucceeded===true&&operation.versionId===version,'ACTUAL_CLOSED_NATIVE_REVISION');
 assert(config.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW==='false'&&config.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED==='false'&&same(config.triggers.crons,[]),'ACTUAL_MAINTENANCE_DISABLED');return version;
}
export function closedProofFromGate(c,gateRef){assertContext(c);const gate=loadGate(c,gateRef,{fresh:false}),operation=loadOperation(c,gate.request.operation,{allowUnknown:gate.phase==='reconcile-maintenance-close'}),config=c.read(gate.mapping.configs.executor),version=assertClosedState(gate,operation,config);return {closeResultSha256:gate.request.operation.sha256,nativeEvidenceSha256:gate.nativeReference.sha256,executorVersion:version,closeEndedAt:utc(operation.endedAt),nativeStartedAt:utc(gate.startedAt),nativeEndedAt:utc(gate.endedAt),admission:'false',maintenance:'false',crons:[],scope:gate.scope.scope};}
// Only completed successful activation history is reusable. Current review and
// standalone helper/short-config bytes remain checks on every access.
const activationResults=new WeakMap();
export function loadOperation(c,reference,{allowUnknown=false}={}){
 assertContext(c);reference=Object.freeze({path:reference.path,sha256:reference.sha256});
 const retained=activationResults.get(c)?.get(allowUnknown);
 if(retained&&same(reference,retained.value.reference)){c.verify(reference);const helpers=new Set();for(const a of retained.attempts){loadPreparation(c,a.preparation);const helper=JSON.stringify([a.helper.path,a.helper.sha256]);if(!helpers.has(helper)){verify(a.helper);helpers.add(helper);}verify(a.shortConfig);}return retained.value;}
 const r=c.read(reference),a=c.read(r.attempt);let activationPrerequisites;assert(['activate','admission-close','maintenance-close','site-roster'].includes(r.kind)&&['dry-run','deploy'].includes(r.mode),'FIXED_OPERATION_RESULT');
 const path=resolve(here,`${r.kind}-${r.mode}-result.json`),attemptPath=resolve(here,`${r.kind}-${r.mode}-attempt.json`);assert(reference.path===path&&r.attempt.path===attemptPath&&r.schemaVersion==='arc-snapshot-scenario-operation-result-v1'&&a.schemaVersion==='arc-snapshot-scenario-operation-attempt-v1'&&a.kind===r.kind&&a.mode===r.mode&&same(a.helper,ref(resolve(here,'operate.mjs')))&&same(a.config,r.config)&&same(a.artifact,r.artifact)&&same(a.decision,r.decision)&&same(a.predecessorGate,r.predecessorGate)&&a.noAutomaticRetry===true,'EXCLUSIVE_ACTUAL_OPERATION_CHAIN');
 assert(r.sequence===FIXED.sequence&&a.sequence===FIXED.sequence&&same(a.diagnosticHelpers,FIXED.diagnostics),'EXACT_OPERATION_SUCCESSOR_SEQUENCE');assertDiagnosticRecord(r);
 const p=loadPreparation(c,a.preparation),role=r.kind==='site-roster'?'site':'executor';assert(same(r.artifact,c.artifacts[role])&&same(a.command,strictCommand(a.shortConfig.path,r.mode))&&a.commandSha256===hash(JSON.stringify(a.command))&&a.shortConfig.sha256===r.config.sha256,'EXACT_OPERATION_SOURCE_CONFIG_COMMAND');verify(a.shortConfig);const config=c.read(r.config);
 assert(r.kind==='site-roster'?same(r.config,verifyRosterPreparation(c,a.rosterPreparation,{now:utc(r.commandStartedAt??r.startedAt)}).config):same(r.config,p.configs[r.kind]),'FIXED_STATIC_OR_ROSTER_CONFIG');assert(integer(a.entrypointStartedAt)&&a.entrypointStartedAt<=utc(a.at)&&a.operationDeadlineAt===fixedOperationDeadline('configuration',a.entrypointStartedAt,r.mode==='deploy'?c.read(a.decision).validUntil:Number.MAX_SAFE_INTEGER)&&utc(a.at)<=utc(r.startedAt)&&utc(r.startedAt)<=utc(r.endedAt)&&(!r.commandSucceeded||utc(r.endedAt)<=a.operationDeadlineAt),'ACTUAL_OPERATION_TIMES_AND_WHOLE_DEADLINE');
 if(r.mode==='deploy'){
  const d=c.read(r.decision),pre=loadGate(c,r.predecessorGate,{fresh:false});assert(d.schemaVersion==='arc-snapshot-scenario-operation-decision-v1'&&d.rootReviewed===true&&d.disposition==='DEPLOY_EXACT_CONFIG_ONCE'&&d.kind===r.kind&&same(d.gate,r.predecessorGate)&&same(d.config,r.config)&&same(d.expectedVersions,pre.mapping.versions)&&same(a.expectedVersions,pre.mapping.versions),'ROOT_BOUND_ACTUAL_PREDECESSOR');assertMaterials(d.materials,c);if(pre.request.incompleteClosure)assert(same(r.incompleteClosure,pre.request.incompleteClosure)&&same(d.incompleteClosure,r.incompleteClosure)&&r.permanentIncomplete===true,'ACTUAL_OPERATION_PERMANENT_INCOMPLETE');else assert(!r.incompleteClosure&&!r.permanentIncomplete&&!d.incompleteClosure,'NO_UNBOUND_OPERATION_RECOVERY');
  assert(d.sequence===FIXED.sequence,'EXACT_DECISION_SUCCESSOR_SEQUENCE');
  if(r.kind==='activate'){const baseline=loadClosedBaseline(c,d.baseline,{gateReference:r.predecessorGate,now:utc(r.commandStartedAt)});assertTerminalAuthority(c,d,pre,utc(r.commandStartedAt));assertActivationBaseline(d,pre,baseline);assert(same(a.baseline,d.baseline)&&same(r.baseline,d.baseline)&&integer(d.userReadyAt)&&d.userReadyAt<=utc(d.reviewedAt)&&utc(r.commandStartedAt)-d.userReadyAt<900000&&d.validUntil<=d.userReadyAt+900000,'ORIGINAL_SUCCESSOR_BASELINE_ATTENDED_DISPATCH');activationPrerequisites=[];for(const kind of ['admission-close','maintenance-close']){const closure=loadOperation(c,d.closureDryRuns[kind]);assert(closure.kind===kind&&closure.mode==='dry-run'&&same(closure.config,p.configs[kind]),'RECONSTRUCTED_BOTH_CLOSURE_DRY_RUNS');activationPrerequisites.push(closure);}}
  const dispatchDeadlineAt=r.kind==='maintenance-close'&&['post-admission-close','reconcile-admission-close'].includes(pre.phase)?operationGateBudget(c,d,pre,utc(r.commandStartedAt)).operationDeadlineAt:pre.request.deadlineAt;
  assert(r.mutationAttempted===true&&utc(r.commandStartedAt)>=utc(r.startedAt)&&utc(r.commandStartedAt)>=utc(pre.endedAt)&&utc(r.commandStartedAt)<d.validUntil&&d.validUntil<=dispatchDeadlineAt&&d.validUntil<=utc(pre.startedAt)+900000&&utc(d.reviewedAt)>=utc(pre.endedAt)&&utc(d.reviewedAt)<=utc(r.commandStartedAt),'ACTUAL_DISPATCH_FINITE_WINDOW');
  assert(r.predecessors.length===2&&same(r.predecessors.map(x=>x.role),['site','executor']),'BOTH_IMMEDIATE_PREDECESSORS');for(const o of r.predecessors){assertRead(o,utc(r.startedAt),utc(r.commandStartedAt),['deployments','list','--config',resolve(pre.request.directory,`wrangler.${o.role}.readonly.json`),'--json']);assert(o.versionId===pre.mapping.versions[o.role]&&utc(r.commandStartedAt)-utc(o.startedAt)<120000,'CURRENT_PAIR_AT_DISPATCH');}
  assertTransition({kind:r.kind,beforeConfig:c.read(pre.mapping.configs[role]),afterConfig:config,now:utc(r.commandStartedAt),nativeSettledProof:r.kind==='maintenance-close'?{nativeEvidenceSha256:pre.nativeReference.sha256,nativeStartedAt:utc(pre.startedAt),nativeEndedAt:utc(pre.endedAt),scope:pre.scope.scope}:undefined});
  const dry=loadOperation(c,d.dryRun);assert(dry.mode==='dry-run'&&dry.kind===r.kind&&same(dry.config,r.config),'MATCHING_ACTUAL_DRY_RUN');if(activationPrerequisites)activationPrerequisites.push(dry);
 }
 assert(r.childCloseConfirmed===true&&integer(r.childTimeoutMs)&&r.childTimeoutMs>0&&r.childTimeoutMs<=90000&&utc(r.commandStartedAt)<=utc(r.commandEndedAt)&&utc(r.commandEndedAt)<=utc(r.endedAt),'CONFIRMED_MUTATION_CHILD_EXIT_BEFORE_RECONCILIATION');
 if(!allowUnknown||r.commandSucceeded){assert(r.commandSucceeded===true&&r.commandFailureKind===null&&r.exitCode===0&&digest(r.stdoutSha256)&&digest(r.stderrSha256)&&integer(r.childTimeoutMs)&&r.childTimeoutMs>0&&r.childTimeoutMs<=90000,'ACTUAL_SUCCESSFUL_CLOSED_COMMAND');assertOperationProjection(r.outputProjection,r.mode,config);assert(utc(r.commandStartedAt)<=utc(r.commandEndedAt)&&utc(r.commandEndedAt)<=utc(r.endedAt),'COMMAND_TIME_ORDER');if(r.mode==='deploy')assert(uuid(r.versionId)&&r.versionId!==a.expectedVersions[role],'ACTUAL_NEW_DEPLOYMENT_REVISION');}
 if(activationPrerequisites&&r.commandSucceeded===true){const value=Object.freeze({...r,reference}),attempts=Object.freeze([a,...activationPrerequisites.map(operation=>c.read(operation.attempt))]);if(!activationResults.has(c))activationResults.set(c,new Map());activationResults.get(c).set(allowUnknown,Object.freeze({value,attempts}));return value;}
 return {...r,reference};
}
export function stateFromGate(gate,reference){assert(['post-activate','post-admission-close','post-maintenance-close','post-site-roster','reconcile-activate','reconcile-admission-close','reconcile-maintenance-close','reconcile-site-roster'].includes(gate.phase)&&gate.reconciliation?.outcome!=='predecessor-still-observed','APPLIED_POST_OPERATION_STATE_REQUIRED');return {...gate.mapping,incompleteClosure:gate.request.incompleteClosure??null,reference};}
export function reconciliationOutcome(result,state){if(!state.reconciliation)return result;const reconciliation={...state.reconciliation,appliedProved:state.reconciliation.expectsNewRevision,observedInterval:{startedAt:result.startedAt,endedAt:result.endedAt}};return reconciliation.appliedProved?{...result,reconciliation}:{...result,reconciliation,nativeChecksPassed:result.nativeChecksPassed??result.allChecksPassed,allChecksPassed:false,permanentIncomplete:true,disposition:'UNRESOLVED_PREDECESSOR_STILL_CURRENT'};}
export function loadState(c,reference){assertContext(c);if(same(reference,FIXED.currentClosedAcceptance))return {versions:c.currentClosed.currentVersions,configs:c.configRefs,workflowLatestVersions:c.currentClosed.workflowLatestVersions,reference};return stateFromGate(loadGate(c,reference,{fresh:false}),reference);}
export function assertOwnedControlExit(attempt,exit,attemptReference){
 assert(attemptReference?.path===resolve(here,'controls',exit.scenarioId+'-'+exit.mode+'-attempt.json')&&same(exit.attempt,attemptReference)&&attempt.schemaVersion==='arc-snapshot-control-attempt-v1'&&uuid(attempt.invocationId)&&exit.invocationId===attempt.invocationId&&integer(attempt.processId)&&attempt.processId>0,'EXACT_EXCLUSIVE_ORIGINAL_CONTROL_ATTEMPT');
 for(const key of ['scenarioId','mode','handoff','materials','inventory','driver','launcher','expectedVersions'])assert(same(attempt[key],exit[key]),'ORIGINAL_CONTROL_ATTEMPT_BINDING_'+key);
 assert(attempt.noAutomaticRetry===true&&exit.noAutomaticRetry===true&&attempt.controlCredentialMode==='secure-masked-tty'&&attempt.providerCallsAllowed===false&&exit.childCloseConfirmed===true&&utc(attempt.at)<=utc(exit.startedAt)&&utc(exit.startedAt)<=utc(exit.confirmedExitAt)&&exit.endedAt===exit.confirmedExitAt&&utc(exit.confirmedExitAt)<=utc(exit.observedAt),'ORIGINAL_CONFIRMED_DISPATCH_ONLY');return true;
}
const historicalControls=new WeakMap();
export function loadControl(c,reference,mode,id){
 assertContext(c);const bounded=id==='long'&&['start','status'].includes(mode);if(bounded)reference=Object.freeze({path:reference.path,sha256:reference.sha256});
 const retained=bounded?historicalControls.get(c)?.get(mode):null;
 if(retained&&same(reference,retained.value.reference)){
  for(const r of [reference,retained.value.attempt,retained.reportReference,retained.value.handoff])c.verify(r);
  assertNoRecoveryControl(c,retained.startedAt);
  assert(same(loadClock(c,retained.handoff.spec.clockReference),retained.clock),'ORIGINAL_SOURCE_STAGE_CLOCK_CANNOT_RENEW');
  const t=loadTerminalTemplate(c,retained.readiness.reviewedPolicy,id+':'+mode,{now:retained.startedAt,historical:true});assert(retained.startedAt<t.validUntil,'ORIGINAL_TEMPLATE_EXPIRY');
  if(mode==='status'){const gate=loadGate(c,retained.handoff.spec.nativeGate,{fresh:false});verifyReceipt(c,retained.handoff.spec.receipt,retained.handoff.spec.nativeGate,gate.scenarioProof);}
  c.verify(retained.hostHelper);return retained.value;
 }
 const exit=c.read(reference);assert(reference.path===resolve(here,'controls',id+'-'+mode+'-exit.json'),'FIXED_CONFIRMED_EXIT_PATH');assert(exit.schemaVersion==='arc-snapshot-control-exit-v1'&&exit.scenarioId===id&&exit.mode===mode&&exit.childCloseConfirmed===true&&same(exit.inventory,FIXED.inventory)&&same(exit.driver,FIXED.driver),'ACTUAL_CONFIRMED_CONTROL_EXIT');
 assertOwnedControlExit(c.read(exit.attempt),exit,exit.attempt);
 const materials=assertMaterials(exit.materials,c),launcher=materials.launchers.find(x=>x.role===id+':'+mode);assert(launcher&&exit.launcher.path===launcher.path&&exit.launcher.sha256===launcher.sha256,'EXACT_REVIEWED_MASKED_LAUNCHER');
 const report=c.read(exit.report),reportName=`cloud-snapshot-${id}-${mode}-${FIXED.sequence}`;assert(exit.report.path===resolve(G,'..',reportName,'report.json')&&report.mode===mode&&report.accountId===FIXED.accountId&&same(report.resources,c.inventory.resources)&&report.artifactReportSha256===FIXED.report.sha256&&report.cloudElapsedProved===false,'ORIGINAL_DRIVER_REPORT_EPOCH');
 assert(utc(exit.startedAt)<=utc(exit.confirmedExitAt)&&exit.endedAt===exit.confirmedExitAt,'ACTUAL_CLIENT_EXIT_CLOCK');const handoff=validateSignedHandoff(c,exit.handoff,{now:utc(exit.startedAt)});assert(handoff.schemaVersion==='arc-snapshot-signed-handoff-v1'&&handoff.scenarioId===id&&handoff.mode===mode&&handoff.reportName===reportName&&utc(exit.startedAt)<handoff.deadlineAt&&handoff.deadlineAt-utc(exit.startedAt)>=65000&&same(exit.expectedVersions,handoff.expectedVersions),'SIGNED_DISPATCH_IMMUTABLE_HANDOFF');
 assert(digest(report.hostHelperSha256),'ACTUAL_DRIVER_HOST_HELPER');c.verify({path:resolve(dirname(exit.report.path),'host-helper.mjs'),sha256:report.hostHelperSha256});
 if(mode==='start')assert(report.scenarioId===id&&(report.status==='accepted'&&report.accepted===true||report.status==='pending'&&report.accepted===false&&report.reason==='acceptance-unknown'),'ACTUAL_ACCEPTED_OR_DISPATCHED_UNKNOWN_START');
 if(mode==='replay'){assert(report.inventorySha256===FIXED.inventory.sha256&&report.approvalFileSha256===handoff.approval.sha256&&report.nativeEvidenceSha256===c.read(handoff.approval).nativeEvidenceSha256,'ACTUAL_REPLAY_HOST_APPROVAL');for(let i=0;i<report.steps.length;i++)if(report.steps[i].result==='completed')assert(same(c.read({path:resolve(dirname(exit.report.path),'step-'+(i+1)+'.json'),sha256:hash(JSON.stringify(report.steps[i]))}),report.steps[i]),'DURABLE_ORIGINAL_REPLAY_STEP');}
 const value={...exit,report,reference,...(mode==='start'?{acceptanceConfirmation:startAcceptanceConfirmation(exit)}:{})};
 if(bounded&&report.status==='accepted'&&report.accepted===true){
  if(mode==='status'){
   const gate=loadGate(c,handoff.spec.nativeGate,{fresh:false}),receipt=c.read(handoff.spec.receipt);
   // Incomplete status remains a valid uncached loadControl return; its caller still rejects completion.
   try{assertCompletedStatus(gate.scenarioProof,value,utc(receipt.endedAt),utc(exit.endedAt));}catch(error){if(['EXACT_FROZEN_SAFE_STATUS','ACTUAL_ORIGINAL_STATUS_AFTER_NATIVE_AND_R2'].includes(error.message))return value;throw error;}
  }
  if(value.acceptanceConfirmation){Object.freeze(value.acceptanceConfirmation.interval);Object.freeze(value.acceptanceConfirmation);}
  Object.freeze(value);const clock=c.read(handoff.spec.clockReference),record=Object.freeze({value,handoff,readiness:c.read(handoff.spec.readiness),reportReference:exit.report,startedAt:utc(exit.startedAt),clock:Object.freeze({activationStartedAt:clock.activationStartedAt,stage:clock.stage,stageStartedAt:clock.stageStartedAt}),hostHelper:Object.freeze({path:resolve(dirname(exit.report.path),'host-helper.mjs'),sha256:report.hostHelperSha256})});
  if(!historicalControls.has(c))historicalControls.set(c,new Map());historicalControls.get(c).set(mode,record);
 }
 return value;
}
export function startAcceptanceConfirmation(exit){assert(exit.mode==='start'&&exit.childCloseConfirmed===true&&same(exit.driver,FIXED.driver)&&exit.endedAt===exit.confirmedExitAt&&utc(exit.startedAt)<=utc(exit.confirmedExitAt),'ACTUAL_BOUNDED_START_INVOCATION');return {driver:FIXED.driver,statusHandler:FIXED.statusHandler,clarification:FIXED.integrationClarifications,possibleInternalStatusProbes:true,maximumInternalStatusProbes:2,exactProbeCount:null,interval:{startedAt:exit.startedAt,confirmedExitAt:exit.confirmedExitAt}};}
export function assertFaultContactOrder(start,contacts,{beforeGap,now}){
 assert(['after-r2','after-d1'].includes(start.scenarioId)&&start.mode==='start'&&utc(start.endedAt)<=now,'ACTUAL_FAULT_START_INTERVAL');const prior=SCENARIO_IDS.slice(0,SCENARIO_IDS.indexOf(start.scenarioId));
 for(const contact of contacts){const a=utc(contact.startedAt),b=utc(contact.endedAt);assert(a<=b&&b<=now,'ACTUAL_CONTACT_INTERVAL');if(same(contact.reference,start.reference)){assert(contact.mode==='start'&&contact.scenarioId===start.scenarioId&&contact.startedAt===start.startedAt&&contact.endedAt===start.endedAt,'EXACT_CURRENT_START_CONTACT');continue;}
  if(['start','status','recover','result','replay'].includes(contact.mode))assert(prior.includes(contact.scenarioId)&&b<=utc(start.startedAt),'NO_INDEPENDENT_CONTROL_OVERLAPPING_OR_AFTER_FAULT_START');
  if(beforeGap)assert(b<=utc(start.startedAt),'IMMEDIATE_GAP_BEFORE_LATER_CONTACT');
 }
 return start.acceptanceConfirmation??startAcceptanceConfirmation(start);
}
export function actualContacts(c,reference){const ledger=c.read(reference);assert(ledger.schemaVersion==='arc-snapshot-contact-ledger-v1'&&ledger.rootReviewed===true&&ledger.noUnrecordedCloudContacts===true&&Array.isArray(ledger.records)&&ledger.records.length<=128,'COMPLETE_ROOT_CONTACT_LEDGER');
 return ledger.records.map(item=>{const r=c.read(item.reference);assert(utc(r.startedAt)<=utc(r.endedAt),'ACTUAL_CONTACT_TIMES');const mode=r.schemaVersion==='arc-snapshot-control-exit-v1'?r.mode:r.schemaVersion==='arc-snapshot-scenario-native-v1'?'native':r.schemaVersion==='arc-snapshot-receipt-evidence-v1'?'receipt':null;assert(mode&&(!item.mode||item.mode===mode),'ACTUAL_TYPED_CONTACT_MODE');return {startedAt:r.startedAt,endedAt:r.endedAt,mode,scenarioId:r.scenarioId??null,reference:item.reference};});}
export function assertPrerequisites(c,input,now){const {q,state}=input;
 if(q.phase==='preactivation')return;
 if(q.phase.startsWith('post-')||q.phase.startsWith('reconcile-')){const reconcile=q.phase.startsWith('reconcile-'),operation=loadOperation(c,q.operation,{allowUnknown:reconcile});assert(operation.kind===q.phase.slice(reconcile?10:5)&&operation.mode==='deploy','ACTUAL_OPERATION_BEFORE_READBACK');return;}
 const pre=loadGate(c,q.preflight,{fresh:false,allowIncomplete:Boolean(q.incompleteClosure)});assertReadPredecessor(q.incompleteClosure?'drain-first':q.phase,pre,now);assert(same(pre.mapping.versions,state.versions),'CURRENT_PREFLIGHT_REVISIONS');assert(same(q.capacity,pre.scope.capacity)&&q.latestExecutionExpiresAt===pre.scope.latestExecutionExpiresAt,'ACTUAL_PREFLIGHT_CAPACITY_AND_DEADLINES');if(q.phase==='prestart'){const ids=SCENARIO_IDS.slice(0,SCENARIO_IDS.indexOf(q.scenarioId));completedProofs(c,q.completed??[],ids,{now});assert(same(pre.scope.scope.observedScenarioIds,ids)&&pre.scope.safeToClose,'SETTLED_PREVIOUS_SCENARIOS_BEFORE_PRESTART');}
 if(['fault-gap','acceptance','long-proof','fault-settlement'].includes(q.phase)){
  const start=loadControl(c,q.start,'start',q.scenarioId);assert(utc(start.endedAt)<=now&&same(start.expectedVersions,state.versions),'CURRENT_ORIGINAL_START');
  if(q.phase==='fault-gap'){assert(q.scenarioId!=='long'&&pre.phase==='prestart','FRESH_PRESTART_BEFORE_GAP');const contacts=actualContacts(c,q.contacts);assertFaultContactOrder(start,contacts,{beforeGap:true,now});}
  if(q.phase==='long-proof'){const contacts=actualContacts(c,q.contacts);const quiet=assertQuiet({start,contacts,now});if(start.report.status==='pending'){const acceptance=loadGate(c,q.acceptance,{fresh:false});assert(acceptance.phase==='acceptance'&&same(acceptance.request.start,q.start)&&contacts.some(x=>same(x.reference,acceptance.nativeReference)),'UNKNOWN_ACCEPTANCE_CONTACT_IN_QUIET_BASIS');}assert(quiet.canAdvance,'REAL_QUIET');}
  if(q.phase==='fault-settlement'){const gap=loadGate(c,q.gap,{fresh:false});assertFaultSettlementWindow(q,gap,now);const contacts=actualContacts(c,q.contacts);assertFaultContactOrder(start,contacts,{beforeGap:false,now});}
 }
 if(q.phase==='drain-first'||q.phase==='drain-second'||q.phase==='scheduled'){const closed=closedProofFromGate(c,q.closedGate);assert(q.maintenanceClose.sha256===closed.closeResultSha256&&same(state.versions.executor,closed.executorVersion)&&now>=closed.closeEndedAt+931000,'ACTUAL_MAINTENANCE_CLOSE_HORIZON');if(q.phase==='drain-second'){const first=loadGate(c,q.firstDrain,{fresh:false});assert(first.phase==='drain-first'&&same(first.request.maintenanceClose,q.maintenanceClose)&&now>=utc(first.endedAt)+60000,'DISTINCT_DELAYED_SECOND_READ');}}
}
export function assertScheduledEvidence(n,q,closeEndedAt){const start=utc(n.startedAt),end=utc(n.endedAt);
 assert(start>=closeEndedAt+931000&&end>=start&&end<=q.collectionDeadlineAt&&end-start<=96000&&n.allReadsSucceeded===true&&n.childCloseConfirmed===true&&n.failureKind===null&&n.rawContentPersisted===false,'BOUNDED_ACTUAL_SCHEDULED_OBSERVATION');
 assert(integer(n.stdoutBytes)&&n.stdoutBytes<=262144&&integer(n.stderrBytes)&&n.stderrBytes<=8192&&integer(n.observationDurationMs)&&n.observationDurationMs>0&&n.observationDurationMs<=95000&&Array.isArray(n.records)&&n.records.length<=16,'BOUNDED_SCHEDULED_METADATA');
 for(const r of n.records)assert(same(Object.keys(r).sort(),['cron','eventTimestamp','outcome','scheduledTime','scriptName','scriptVersionId'])&&r.scriptName===FIXED.workers.executor&&r.scriptVersionId===q.expectedVersions.executor&&integer(r.scheduledTime)&&(r.eventTimestamp===null||integer(r.eventTimestamp))&&(r.cron===null||r.cron==='* * * * *')&&['ok','exception','canceled','exceededCpu','exceededMemory','unknown'].includes(r.outcome),'EXACT_SAFE_SCHEDULED_METADATA');
 return {applicationSettlementProved:false,platformInvocationAbsenceProved:false,observedInvocationCount:n.records.length,actualObservationMs:end-start};
}
export function evaluateNative(c,reference,{now=Date.now(),fresh=true,allowIncomplete=false}={}){const localStarted=performance.now();
 const n=c.read(reference),input=validateRequest(c,n.request,{now,dispatch:false}),{q,state}=input,a=c.read(n.attempt);assert(reference.path===resolve(q.directory,q.phase==='scheduled'?'scheduled-metadata.json':'native-evidence.json')&&n.attempt.path===resolve(q.directory,'collection-attempt.json')&&a.schemaVersion==='arc-snapshot-scenario-collection-attempt-v1'&&same(a.request,n.request)&&same(a.collector,n.collector)&&same(a.transport,n.transportHelper)&&same(n.collector,ref(resolve(here,'collect.mjs')))&&same(n.transportHelper,ref(resolve(here,'read-transport.mjs')))&&same(n.preload,FIXED.preload)&&same(a.preload,FIXED.preload)&&a.commandsSha256===q.commandsSha256&&a.deadlineAt===q.collectionDeadlineAt&&n.deadlineAt===q.collectionDeadlineAt&&utc(n.startedAt)>=utc(a.at),'ACTUAL_EXCLUSIVE_COMPLETE_NATIVE_CHAIN');
 if(q.phase==='scheduled'){assertPrerequisites(c,input,utc(n.startedAt));if(fresh)assertFresh(n.startedAt,n.endedAt,now);const scheduled=assertScheduledEvidence(n,q,closedProofFromGate(c,q.closedGate).closeEndedAt);if(fresh)assertLocalNativeWork(c,localStarted);return incompleteOutcome({phase:q.phase,request:q,native:n,nativeReference:reference,startedAt:n.startedAt,endedAt:n.endedAt,allChecksPassed:true,scheduled},q.incompleteClosure);}
 assertCollection(n,q,now,{fresh});assertPrerequisites(c,input,utc(n.startedAt));
 const result={phase:q.phase,request:q,native:n,nativeReference:reference,startedAt:n.startedAt,endedAt:n.endedAt,allChecksPassed:true,...(q.incompleteClosure?{incompleteClosure:q.incompleteClosure,permanentIncomplete:true,disposition:'INCOMPLETE'}:{})};
 if(q.phase==='fault-gap'){result.gap={...evaluateGap(n,q.scenarioId),startAcceptanceConfirmation:loadControl(c,q.start,'start',q.scenarioId).acceptanceConfirmation};result.allChecksPassed=result.gap.rawGapObserved;if(!result.allChecksPassed)result.disposition='MISSED_OR_UNRESOLVED_GAP';}
 else if(q.phase==='acceptance'){const start=loadControl(c,q.start,'start',q.scenarioId);result.acceptance=normalizeAcceptance(q.scenarioId,start.report,n.observations);}
 else{
  result.mapping=evaluateMapping(n,q,{configs:Object.fromEntries(Object.entries(q.configs).map(([k,v])=>[k,c.read(v)])),baseline:c.schema.mapping,baselineObservedAt:c.acceptance.observedAt,previousLatestVersions:state.workflowLatestVersions,allowNewLatestVersions:(q.phase.startsWith('post-')||q.phase.startsWith('reconcile-'))&&!q.phase.endsWith('site-roster')&&state.reconciliation?.outcome!=='predecessor-still-observed'},fresh?now:utc(n.endedAt));result.scope=scopeFromNative(n,result.mapping);
  if(q.phase==='long-proof'){const start=loadControl(c,q.start,'start',q.scenarioId),accepted=start.report.status==='accepted'?normalizeAcceptance(q.scenarioId,start.report,n.observations):loadGate(c,q.acceptance,{fresh:false}).acceptance,contacts=actualContacts(c,q.contacts),quiet=assertQuiet({start,contacts,now:utc(n.startedAt)});try{result.scenarioProof=scenarioProof(n,q.scenarioId,{acceptance:accepted,start,gap:null,contacts,quiet,observedScenarioIds:result.scope.scope.observedScenarioIds,now:utc(n.endedAt)});}catch{assert(allowIncomplete,'SCENARIO_NOT_PROVED');result.allChecksPassed=false;result.disposition='INCOMPLETE_NATIVE_SETTLEMENT';}}
  if(q.phase==='fault-settlement'){const start=loadControl(c,q.start,'start',q.scenarioId),contacts=actualContacts(c,q.contacts),gap=loadGate(c,q.gap,{fresh:false}).gap;Object.assign(result,faultSettlementOutcome(n,q.scenarioId,{start,gap,contacts,observedScenarioIds:result.scope.scope.observedScenarioIds,now:utc(n.endedAt)},{allowIncomplete}));}
  if(q.phase==='preactivation')assert(result.scope.safeToClose&&result.scope.scope.observedScenarioIds.length===0&&same(result.scope.capacity,c.currentClosed.retainedObserver)&&result.scope.capacity.unmatchedStarts===0&&result.scope.capacity.rowsUsed+observerNeed({remainingMs:LIMITS.totalMs,unmatchedStarts:0})<=256,'INITIAL_EMPTY_FULL_SCOPE');
  if(['pre-maintenance-close','post-maintenance-close','reconcile-maintenance-close','drain-first','drain-second'].includes(q.phase)&&state.reconciliation?.outcome!=='predecessor-still-observed'&&!result.scope.safeToClose){assert(q.phase==='pre-maintenance-close'&&q.incompleteClosure&&allowIncomplete,'NO_OUTSTANDING_BEFORE_MAINTENANCE_OFF');result.allChecksPassed=false;result.disposition='INCOMPLETE_UNSETTLED';}
  if(q.phase==='drain-second')result.drain=assertDrain(loadGate(c,q.firstDrain,{fresh:false}),result,closedProofFromGate(c,q.closedGate).closeEndedAt);
  if(q.phase==='replay-after'){const before=loadGate(c,q.replayBefore,{fresh:false}),reports=q.replays.map(x=>loadControl(c,x.reference,'replay',x.scenarioId).report);result.replay=compareReplay({...before.native,mapping:before.mapping},{...n,mapping:result.mapping},reports);}
 }
 if(fresh)assertLocalNativeWork(c,localStarted);return reconciliationOutcome(incompleteOutcome(result,q.incompleteClosure),state);
}
export function loadGate(c,reference,{fresh=true,allowIncomplete=false}={}){assertContext(c);const key=reference.path+'\0'+reference.sha256+'\0'+allowIncomplete;let result=cache(c).get(key);
 if(!result){const stored=c.read(reference);assert(stored.schemaVersion==='arc-snapshot-scenario-gate-v1'&&same(stored.evaluator,ref(resolve(here,'evaluate.mjs'))),'ACTUAL_GATE_EVALUATOR');result=evaluateNative(c,stored.nativeEvidence,{now:utc(stored.endedAt),fresh:false,allowIncomplete});assert(reference.path===resolve(result.request.directory,'gate-evaluation.json')&&same(stored.result,result)&&stored.startedAt===result.startedAt&&stored.endedAt===result.endedAt&&stored.allChecksPassed===result.allChecksPassed,'RECOMPUTED_COMPLETE_NATIVE_GATE');result={...result,reference};cache(c).set(key,result);}
 if(fresh)assertFresh(result.startedAt,result.endedAt,Date.now());return result;}
void main(import.meta.url,async()=>{const command=process.argv[2];if(['handoff','validate-handoff'].includes(command)){assert(process.argv.length===5,'EXACT_HANDOFF_SPEC_PATH_SHA');const c=await createValidationContext(),r=inputReference(process.argv[3],process.argv[4]);console.log(JSON.stringify(command==='handoff'?{handoff:prepareSignedHandoff(c,c.read(r))}:validateSignedHandoff(c,r,{dispatch:true})));return;}assert(process.argv.length===4,'EXACT_NATIVE_PATH_SHA');const c=await createValidationContext(),nativeEvidence=inputReference(process.argv[2],process.argv[3]),result=evaluateNative(c,nativeEvidence,{allowIncomplete:true});console.log(JSON.stringify({gate:write(resolve(result.request.directory,'gate-evaluation.json'),{schemaVersion:'arc-snapshot-scenario-gate-v1',nativeEvidence,evaluator:ref(resolve(here,'evaluate.mjs')),startedAt:result.startedAt,endedAt:result.endedAt,allChecksPassed:result.allChecksPassed,result})}));if(!result.allChecksPassed)process.exitCode=1;});
