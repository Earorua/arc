// Fixed evidence DAG. Saved records are recomputed; no previous epoch is dispatch authority.
import assert from 'node:assert/strict';
import {join} from 'node:path';
import {base,ANCHORS,read,ref,verify,exactDirectory,fastReverify,uniquePins} from './context.mjs';
import {N,OPERATION,oldVersions,workers,hash,serialize,utc,keys,observationPath,deploymentPath,deriveState,assertFresh,assertFreshPair,assertOperationProjection,deployCommand,uuid,digest} from './rules.mjs';
import {commandsFor} from './read-plans.mjs';
import {assertCollection,evaluateMapping} from './evaluate.mjs';
import {assertRead,readConfig} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/mapping.mjs';
const file=(directory,name)=>{const reference=ref(join(directory,name));return {reference,value:read(reference)};};
export const decisionPath=role=>{deploymentPath(role);return join(N,role+'-decision-r1.json');};
export function requestFor(ctx,stage,dependency,now){
 const directory=observationPath(stage);assert.ok(Number.isSafeInteger(now)&&now>=utc(ctx.acceptance.acceptedAt),'ACTUAL_POST_ACCEPTANCE_CLOCK');
 if(stage.startsWith('pre-')){assert.ok(now>=ctx.base.closeEndedAt+931000&&now>=utc(dependency.previous.endedAt)+60000,'ACTUAL_DELAYED_CLOSED_READ');if(stage==='pre-second')assertFresh(dependency.previous.startedAt,dependency.previous.endedAt,now);}
 const q={schemaVersion:'arc-snapshot-no-start-request-v1',operationId:OPERATION,stage,phase:stage==='pre-first'?'drain-first':stage==='pre-second'?'drain-second':stage,scenarioId:null,readPlanSelectorOnly:true,directory,preparedAt:now,deadlineAt:now+120000,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,collector:ref(join(N,'collect.mjs')),expectedVersions:dependency.state.versions,configs:dependency.state.configs,artifacts:Object.fromEntries(Object.entries(ctx.entries).map(([r,e])=>[r,e.artifact])),emptyConfigs:ctx.preparation.emptyConfigs,dependencyReferences:dependency.references,readonlyConfigs:{}};
 for(const role of ['site','executor']){const value=readConfig(role,stage.startsWith('pre-')?ctx.originals[role]:stage==='mixed'&&role==='site'?ctx.originals.site:ctx.configs[role]);q.readonlyConfigs[role]={path:join(directory,'wrangler.'+role+'.readonly.json'),sha256:hash(serialize(value))};}
 q.commandsSha256=hash(JSON.stringify(commandsFor(q)));return q;
}
export function attemptFor(ctx,q,request,at){return {schemaVersion:'arc-snapshot-no-start-read-attempt-v1',operationId:OPERATION,stage:q.stage,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,collector:q.collector,transport:ref(join(N,'read-transport.mjs')),wrapper:base.g.FIXED.wrapper,cli:base.g.FIXED.cli,preload:base.g.FIXED.preload,request,at,deadlineAt:q.deadlineAt,commandsSha256:q.commandsSha256,dependencyReferences:q.dependencyReferences};}
export function nativeStart(ctx,q,request,attempt,startedAt){return {schemaVersion:q.stage.startsWith('pre-')?'arc-guarded-scenario-native-v1':'arc-snapshot-no-start-native-v1',operationId:OPERATION,stage:q.stage,phase:q.phase,scenarioId:null,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,collector:q.collector,transportHelper:ref(join(N,'read-transport.mjs')),wrapper:base.g.FIXED.wrapper,cli:base.g.FIXED.cli,preload:base.g.FIXED.preload,request,attempt,startedAt,observations:[],cloudMutations:0,workerControlCalls:0,providerCalls:0,originalR9GatePassed:false};}
export function checkpoint(native,count){const {endedAt,transport,allReadsSucceeded,failureCode,...value}=native;return {...value,observations:native.observations.slice(0,count)};}
export function assertCheckpoints(native,values){assert.equal(values.length,native.observations.length,'ALL_EXCLUSIVE_CHECKPOINTS');for(const [i,value]of values.entries())assert.deepEqual(value,checkpoint(native,i+1),'EVERY_EXCLUSIVE_ORDERED_CHECKPOINT');}
export function evaluateObservation(ctx,stage,dependency,bundle,now){
 const {q,n,a,requestReference,attemptReference,nativeReference,readonlyValues}=bundle;
 assert.deepEqual(q,requestFor(ctx,stage,dependency,q.preparedAt),'EXACT_NEW_PACKAGE_REQUEST');
 for(const [value,reference,name]of [[q,requestReference,'request.json'],[a,attemptReference,'attempt.json'],[n,nativeReference,'native.json']]){assert.equal(reference.path,join(q.directory,name));assert.equal(reference.sha256,hash(serialize(value)),'EXACT_SERIALIZED_OBSERVATION');assert.equal(value.operationId,OPERATION,'NEW_OPERATION_IDENTITY');}
 assert.deepEqual(a,attemptFor(ctx,q,requestReference,a.at),'EXACT_COLLECTION_ATTEMPT');
 const expected=nativeStart(ctx,q,requestReference,attemptReference,n.startedAt);for(const [key,value]of Object.entries(expected))if(key!=='observations')assert.deepEqual(n[key],value,'EXACT_NATIVE_'+key);
 assert.ok(q.preparedAt<=utc(a.at)&&utc(a.at)<=utc(n.startedAt),'ORDERED_ACTUAL_COLLECTION_START');
 for(const role of ['site','executor']){assert.equal(hash(serialize(readonlyValues[role])),q.readonlyConfigs[role].sha256);assert.deepEqual(readonlyValues[role],readConfig(role,read(q.configs[role])),'EXACT_READONLY_CONFIG');}
 assertCollection(n,q,now);let mapping,scope=null,drain=null;
 if(stage.startsWith('pre-')){
  // Reuse the native projection schema, never an older operation identity/result.
  mapping=base.policy.evaluateRepairMapping(n,q,base.mappingContext(ctx.base.c,ctx.base.state),now);scope=base.closedScope(n,mapping);
  const current={native:n,mapping,scope,startedAt:n.startedAt,endedAt:n.endedAt};drain=base.e.assertDrain(dependency.previous,current,ctx.base.closeEndedAt);if(stage==='pre-second')assertFreshPair(dependency.previous,current,now);
 }else mapping=evaluateMapping(n,q,{configs:Object.fromEntries(Object.entries(q.configs).map(([role,r])=>[role,read(r)])),baseline:ctx.baseline,previousMapping:dependency.previousMapping,executorStartedAt:dependency.deployments.executor.commandStartedAt},now);
 return {schemaVersion:'arc-snapshot-no-start-proof-v1',operationId:OPERATION,stage,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,evaluator:ref(join(N,'records.mjs')),request:requestReference,attempt:attemptReference,nativeReference,dependencyReferences:q.dependencyReferences,collectionStartedAt:new Date(q.preparedAt).toISOString(),startedAt:n.startedAt,endedAt:n.endedAt,mapping,scope,drain,allChecksPassed:true,applicationSettled:stage.startsWith('pre-'),task15Accepted:false,originalR9GatePassed:false,platformInvocationAbsenceProved:false,historicalObjects:ctx.historicalObjects,objectsListedByThisOperation:false};
}
export function loadStageDependencies(ctx,stage,now){
 if(stage==='pre-first')return {state:deriveState(stage,ctx.entries),previous:{...ctx.base.second,reference:base.ANCHORS.second},deployments:{},references:{previous:base.ANCHORS.second},pins:[],directories:[]};
 if(stage==='pre-second'){const first=loadObservation(ctx,'pre-first',now);return {state:deriveState(stage,ctx.entries),previous:first,deployments:{},references:{previous:first.reference},pins:first.pins,directories:first.directories};}
 const executor=loadDeployment(ctx,'executor',now),site=stage==='paired'?loadDeployment(ctx,'site',now):null;
 const deployments={executor,site};return {state:deriveState(stage,ctx.entries,deployments),deployments,previousMapping:site?.gate.mapping??null,references:{executor:executor.reference,site:site?.reference??null,mixed:site?.gate.reference??null},pins:uniquePins([...executor.pins,...(site?.pins??[])]),directories:[...executor.directories,...(site?.directories??[])]};
}
export function loadObservation(ctx,stage,now=Date.now()){
 const directory=observationPath(stage),q=file(directory,'request.json'),n=file(directory,'native.json'),a=file(directory,'attempt.json'),result=file(directory,'result.json');
 const dependency=loadStageDependencies(ctx,stage,now),commands=commandsFor(q.value),names=commands.map((_,i)=>'checkpoint-'+(i+1)+'.json');
 const directoryNames=['request.json','attempt.json','native.json','result.json','wrangler.site.readonly.json','wrangler.executor.readonly.json',...names];exactDirectory(directory,directoryNames);
 const configs=Object.fromEntries(['site','executor'].map(role=>[role,file(directory,'wrangler.'+role+'.readonly.json')])),checkpoints=names.map(name=>file(directory,name));
 const proof=evaluateObservation(ctx,stage,dependency,{q:q.value,n:n.value,a:a.value,requestReference:q.reference,attemptReference:a.reference,nativeReference:n.reference,readonlyValues:Object.fromEntries(Object.entries(configs).map(([r,v])=>[r,v.value]))},now);
 assert.deepEqual(result.value,proof,'RECOMPUTED_NATIVE_PROOF');assertCheckpoints(n.value,checkpoints.map(x=>x.value));
 const pins=uniquePins([q.reference,n.reference,a.reference,result.reference,...Object.values(configs).map(x=>x.reference),...checkpoints.map(x=>x.reference),...n.value.observations.flatMap(x=>x.exportReferences??[]),...dependency.pins]);
 const directories=[...dependency.directories,{path:directory,names:directoryNames}];fastReverify(ctx,pins,directories);return {...proof,reference:result.reference,native:n.value,pins,directories};
}
export function loadGate(ctx,role,now){
 if(role==='executor'){const second=loadObservation(ctx,'pre-second',now),first=loadObservation(ctx,'pre-first',now);assertFreshPair(first,second,now);return {...second,firstReference:first.reference,startedAt:first.collectionStartedAt,versions:oldVersions,pins:uniquePins([...first.pins,...second.pins]),directories:[...first.directories,...second.directories]};}
 assert.equal(role,'site');const mixed=loadObservation(ctx,'mixed',now);return {...mixed,startedAt:mixed.collectionStartedAt,firstReference:null,versions:mixed.mapping.versions};
}
export function assertRootDecision(ctx,role,d,gate,now,operation=ref(join(N,'deploy.mjs'))){
 keys(d,['schemaVersion','operationId','role','rootReviewed','disposition','tooling','preparation','materialization','operation','config','artifact','dryRun','dryRunAttempt','gate','firstGate','expectedVersions','windowStart','reviewedAt','validUntil','workerControlCallsAllowed','providerCallsAllowed']);
 assert.equal(d.schemaVersion,'arc-snapshot-no-start-decision-v1');assert.equal(d.operationId,OPERATION);assert.equal(d.role,role);assert.equal(d.rootReviewed,true);assert.equal(d.disposition,'DEPLOY_EXACT_NO_START_ONCE');assert.deepEqual(d.tooling,ctx.acceptanceReference);assert.deepEqual(d.preparation,ctx.preparationReference);assert.deepEqual(d.materialization,ANCHORS.materialization);assert.deepEqual(d.operation,operation);
 for(const key of ['config','artifact','dryRun','dryRunAttempt'])assert.deepEqual(d[key],ctx.entries[role][key],'EXACT_DEPLOY_'+key);
 assert.deepEqual(d.gate,gate.reference);assert.deepEqual(d.firstGate,gate.firstReference);assert.deepEqual(d.expectedVersions,gate.versions);assert.equal(d.windowStart,gate.startedAt,'FIRST_ACTUAL_COLLECTION_START');assert.equal(d.workerControlCallsAllowed,false);assert.equal(d.providerCallsAllowed,false);
 const start=utc(gate.startedAt),end=utc(gate.endedAt),reviewed=utc(d.reviewedAt),until=utc(d.validUntil);assertFresh(gate.startedAt,gate.endedAt,now);assert.ok(end<=reviewed&&reviewed<=now&&now<until&&until<=start+900000,'ORIGINAL_GATE_DECISION_WINDOW');return d;
}
export function immediateRequest(ctx,role,gate,now){return {schemaVersion:'arc-snapshot-no-start-immediate-v1',operationId:OPERATION,stage:'immediate-'+role,scenarioId:null,role,expectedVersions:gate.versions,preparedAt:now,deadlineAt:now+120000,preparation:ctx.preparationReference,acceptance:ctx.acceptanceReference,gate:gate.reference};}
export function assertImmediatePredecessors(reads,q,startedAt,commandStartedAt,transport){
 const commands=commandsFor(q),start=utc(startedAt),end=utc(commandStartedAt);assert.equal(q.deadlineAt,q.preparedAt+120000);assert.ok(q.preparedAt<=start&&end<=q.deadlineAt,'IMMEDIATE_PAIR_WINDOW');assert.deepEqual(reads.map(x=>x.id),commands.map(x=>x.id));let last=start;
 assert.ok(transport?.halted===null&&transport.budgetExhausted===false&&transport.maxAttempts===3&&transport.backoffMs===1000&&transport.childTimeoutMs===45000&&transport.closeGraceMs===1000&&transport.collectorBudgetMs>0&&transport.collectorBudgetMs<=120000&&transport.elapsedMs>=0&&transport.elapsedMs<=transport.collectorBudgetMs,'COMPLETE_BOUNDED_IMMEDIATE_TRANSPORT');
 for(const [i,o]of reads.entries()){assertRead(o,start,end,commands[i].args);assert.ok(utc(o.startedAt)>=last&&end-utc(o.startedAt)<120000,'FRESH_IMMEDIATE_CURRENT_REVISION');assert.equal(o.worker,workers[commands[i].role]);assert.equal(o.versionId,q.expectedVersions[commands[i].role]);for(const a of o.attempts){utc(a.startedAt);utc(a.endedAt);assert.ok(a.stdoutBytes+a.stderrBytes<=131072&&Number.isFinite(a.elapsedMs)&&a.elapsedMs>=0&&a.elapsedMs<=a.childTimeoutMs+1000);}last=utc(o.endedAt);}
}
export function loadDeployment(ctx,role,now=Date.now()){
 const directory=deploymentPath(role),r=file(directory,'result.json'),a=file(directory,'attempt.json'),q=file(directory,'request.json'),value=r.value,attempt=a.value;
 assert.equal(value.schemaVersion,'arc-snapshot-no-start-deploy-result-v1');assert.equal(value.operationId,OPERATION);assert.equal(value.role,role);assert.equal(value.commandSucceeded,true,'SUCCESSFUL_EXCLUSIVE_DEPLOYMENT_REQUIRED');assert.equal(value.mutationAttempted,true);assert.equal(value.exitCode,0);assert.equal(value.childCloseConfirmed,true);assert.equal(value.commandFailureKind,null);assert.equal(value.disposition,'NEW_VERSION_REQUIRES_NATIVE_MAPPING');assert.equal(value.nativeMappingVerified,false);assert.equal(value.rawContentPersisted,false);assert.ok(uuid(value.versionId)&&value.versionId!==oldVersions[role]);assert.ok(utc(value.endedAt)<=now);
 const at=utc(value.commandStartedAt),gate=loadGate(ctx,role,at),decisionReference=ref(decisionPath(role)),decision=read(decisionReference);assertRootDecision(ctx,role,decision,gate,at);assert.deepEqual(attempt.decision,decisionReference);assert.deepEqual(value.decision,decisionReference);
 assert.deepEqual(attempt.request,q.reference);assert.deepEqual(value.request,q.reference);assert.deepEqual(value.attempt,a.reference);assert.deepEqual(q.value,immediateRequest(ctx,role,gate,q.value.preparedAt));
 assert.equal(attempt.schemaVersion,'arc-snapshot-no-start-deploy-attempt-v1');assert.equal(attempt.operationId,OPERATION);assert.equal(attempt.role,role);assert.equal(attempt.noRetry,true);assert.equal(attempt.maximumWrites,1);assert.deepEqual(attempt.operation,ref(join(N,'deploy.mjs')));assert.deepEqual(attempt.transport,ref(join(N,'write-transport.mjs')));assert.deepEqual(attempt.wrapper,base.g.FIXED.wrapper);assert.deepEqual(attempt.cli,base.g.FIXED.cli);assert.deepEqual(attempt.preload,base.g.FIXED.preload);
 for(const obj of [attempt,value]){assert.deepEqual(obj.preparation,ctx.preparationReference);assert.deepEqual(obj.acceptance,ctx.acceptanceReference);assert.deepEqual(obj.config,ctx.entries[role].config);assert.deepEqual(obj.artifact,ctx.entries[role].artifact);assert.deepEqual(obj.predecessorGate,gate.reference);assert.equal(obj.workerControlCalls,0);assert.equal(obj.providerCalls,0);}
 assert.deepEqual(attempt.command,deployCommand(attempt.shortConfig.path));assert.equal(attempt.shortConfig.sha256,ctx.entries[role].config.sha256);verify(attempt.shortConfig);
 assertOperationProjection(value.outputProjection,'deploy',ctx.configs[role]);assert.ok(digest(value.stdoutSha256)&&digest(value.stderrSha256)&&value.stdoutBytes+value.stderrBytes<=524288);assert.equal(value.childTimeoutMs,90000);assert.ok(value.elapsedMs>=0&&value.elapsedMs<=91000,'BOUNDED_SINGLE_DEPLOY_CHILD');
 assert.ok(q.value.preparedAt<=utc(attempt.at)&&utc(attempt.at)<=utc(value.startedAt)&&utc(value.startedAt)<=at&&at<=utc(value.commandEndedAt)&&utc(value.commandEndedAt)<=utc(value.endedAt),'ACTUAL_ORDERED_DEPLOYMENT');
 const reads=['site','executor'].map(role=>file(directory,'predecessor-'+role+'.json'));assert.deepEqual(value.predecessors,reads.map(x=>x.value));assertImmediatePredecessors(value.predecessors,q.value,value.startedAt,value.commandStartedAt,value.predecessorTransport);
 const directories=[...gate.directories,{path:directory,names:['request.json','attempt.json','predecessor-site.json','predecessor-executor.json','result.json']}];
 const pins=uniquePins([r.reference,a.reference,q.reference,decisionReference,attempt.shortConfig,...reads.map(x=>x.reference),...gate.pins]);fastReverify(ctx,pins,directories);return {...value,reference:r.reference,gate,pins,directories};
}
