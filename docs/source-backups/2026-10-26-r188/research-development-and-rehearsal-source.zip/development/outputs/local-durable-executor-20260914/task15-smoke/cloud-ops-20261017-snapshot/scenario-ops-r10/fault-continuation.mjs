// Fixed in-process continuation only. Task3 owns the masked child; this module never reads stdin or C.
import {existsSync} from 'node:fs';import {resolve} from 'node:path';import {performance} from 'node:perf_hooks';
import {here,G,FIXED,assert,same,utc,integer,uuid,ref,write,assertContext,assertCurrentPins,createValidationContext,main} from './guards.mjs';
import {validateSignedHandoff,loadGate,loadControl,actualContacts,assertFaultContactOrder,normalizeAcceptance} from './evaluate.mjs';
import {collectImmediateFaultGap} from './collect.mjs';
import {CONTROL_BOUNDS} from './profile.mjs';
export const FAULT_WAIT_MS=60000+65000+CONTROL_BOUNDS.faultArmAndPostInput,FAULT_WATCH_INTERVAL_MS=25;
const windows=new WeakMap(),continuations=new WeakMap(),live=new WeakMap();
// Pure one-use policy object. It cannot dispatch; the operational permit below additionally binds a real context.
export function faultWindow({attempt,attemptReference,handoff,now}){
 assert(['after-r2','after-d1'].includes(attempt?.scenarioId)&&attempt.mode==='start'&&handoff.scenarioId===attempt.scenarioId&&handoff.mode==='start','FIXED_FAULT_START');
 assert(uuid(attempt.invocationId)&&integer(attempt.processId)&&attempt.processId>0&&attempt.noAutomaticRetry===true&&same(attempt.expectedVersions,handoff.expectedVersions),'OWNED_ORIGINAL_ATTEMPT');
 const a=utc(attempt.at);assert(integer(now)&&a<=now&&integer(handoff.deadlineAt)&&handoff.inputAllowanceMs===60000&&handoff.childReserveMs===65000,'ORIGINAL_FINITE_FAULT_WINDOW');
 assert(utc(handoff.nativeStartedAt)<=utc(handoff.nativeEndedAt)&&utc(handoff.nativeEndedAt)<=now&&now-utc(handoff.nativeStartedAt)<900000&&integer(handoff.readinessStartedAt)&&handoff.readinessStartedAt<=now&&now-handoff.readinessStartedAt<900000,'FRESH_ORIGINAL_FAULT_PREFLIGHT');
 const deadlineAt=Math.min(a+FAULT_WAIT_MS,handoff.deadlineAt,utc(handoff.nativeStartedAt)+900000,handoff.readinessStartedAt+900000);
 assert(Number.isSafeInteger(deadlineAt)&&deadlineAt>now&&integer(handoff.originalClocks?.stageStartedAt)&&handoff.originalClocks.stage===attempt.scenarioId,'ORIGINAL_FAULT_STAGE');
 const window=Object.freeze({scenarioId:attempt.scenarioId,deadlineAt,armedAt:now,originalStageStartedAt:handoff.originalClocks.stageStartedAt});
 windows.set(window,{attempt:structuredClone(attempt),attemptReference:structuredClone(attemptReference),used:false});return window;
}
export function consumeFaultWindow(window,exit,report,now){
 const state=windows.get(window);assert(state,'OPAQUE_IN_PROCESS_FAULT_WINDOW');assert(!state.used,'FAULT_CONTINUATION_CONSUMED');state.used=true;
 const {attempt,attemptReference}=state;
 assert(integer(now)&&now>=window.armedAt&&now<window.deadlineAt,'ORIGINAL_FAULT_WATCH_DEADLINE');
 assert(exit.scenarioId===window.scenarioId&&exit.mode==='start'&&same(exit.attempt,attemptReference)&&exit.invocationId===attempt.invocationId&&same(exit.handoff,attempt.handoff)&&same(exit.expectedVersions,attempt.expectedVersions)&&exit.noAutomaticRetry===true,'EXACT_OWNED_FAULT_EXIT');
 assert(exit.childCloseConfirmed===true&&utc(exit.startedAt)>=window.armedAt&&utc(exit.startedAt)<=utc(exit.confirmedExitAt)&&exit.endedAt===exit.confirmedExitAt&&utc(exit.endedAt)<=utc(exit.observedAt)&&utc(exit.observedAt)<=now,'CONFIRMED_ORIGINAL_DISPATCH_CLOSED');
 assert(report.scenarioId===window.scenarioId&&report.mode==='start','ORIGINAL_FAULT_DRIVER_REPORT');
 if(report.status==='accepted'&&report.accepted===true){normalizeAcceptance(window.scenarioId,report,[]);return {disposition:'ORIGINAL_ACCEPTANCE_NATIVE_GAP',resubmitAllowed:false};}
 assert(report.status==='pending'&&report.accepted===false&&report.reason==='acceptance-unknown','DISPATCHED_ACCEPTANCE_UNKNOWN_ONLY');
 return {disposition:'ORIGINAL_IDENTITY_READ_RECONCILIATION_ONLY',resubmitAllowed:false};
}
export function armFaultContinuation(c,scenarioId){
 assertContext(c);assert(['after-r2','after-d1'].includes(scenarioId),'FIXED_FAULT_CONTINUATION_ROLE');
 const attemptReference=ref(resolve(here,'controls',scenarioId+'-start-attempt.json')),attempt=c.read(attemptReference),now=Date.now();
 assert(attempt.schemaVersion==='arc-snapshot-control-attempt-v1'&&attempt.scenarioId===scenarioId&&attempt.mode==='start'&&same(attempt.inventory,FIXED.inventory)&&same(attempt.driver,FIXED.driver)&&attempt.controlCredentialMode==='secure-masked-tty'&&attempt.providerCallsAllowed===false,'ACTUAL_OWNED_FAULT_ATTEMPT');
 const handoff=validateSignedHandoff(c,attempt.handoff,{now,dispatch:true}),pre=loadGate(c,handoff.spec.nativeGate,{fresh:true});
 assert(same(attempt.materials,handoff.materials)&&same(attempt.expectedVersions,handoff.expectedVersions)&&attempt.reportPath===resolve(G,'..',handoff.reportName,'report.json'),'EXACT_FAULT_ATTEMPT_HANDOFF');
 const contacts=handoff.spec.contacts;assert(contacts?.path===resolve(here,'handoffs',scenarioId+'-start-contacts.json'),'FIXED_PRESTART_CONTACT_LEDGER');actualContacts(c,contacts);
 assert(pre.phase==='prestart'&&same(pre.mapping.versions,handoff.expectedVersions),'CURRENT_NATIVE_PAIR_BEFORE_FAULT_START');
 const window=faultWindow({attempt,attemptReference,handoff,now}),pins=assertCurrentPins(c,[attemptReference,attempt.handoff,contacts]);assert(Date.now()<window.deadlineAt,'FAULT_ARMING_WITHIN_ORIGINAL_DEADLINE');
 const journal=write(resolve(here,'controls',scenarioId+'-gap-continuation-attempt.json'),{schemaVersion:'arc-snapshot-fault-continuation-attempt-v1',attempt:attemptReference,handoff:attempt.handoff,scenarioId,armedAt:window.armedAt,deadlineAt:window.deadlineAt,originalClocks:handoff.originalClocks,prevalidationMs:c.validation.elapsedMs,armingPinRecheckMs:pins.elapsedMs,stdin:'ignored',cloudCallsWhileWaiting:0,noAutomaticRetry:true});
 const token=Object.freeze({scenarioId,deadlineAt:window.deadlineAt});continuations.set(token,{c,window,attemptReference,handoff,contacts,journal,used:false});return token;
}
export async function captureFaultGap(c,token){
 assertContext(c);const bound=continuations.get(token);assert(bound?.c===c&&!bound.used,'ORIGINAL_RETAINED_CONTEXT_AND_ONE_USE');bound.used=true;
 const exitPath=resolve(here,'controls',token.scenarioId+'-start-exit.json'),started=performance.now();
 while(!existsSync(exitPath)){assert(Date.now()<token.deadlineAt,'ORIGINAL_FAULT_WATCH_DEADLINE');await new Promise(done=>setTimeout(done,Math.min(FAULT_WATCH_INTERVAL_MS,Math.max(1,token.deadlineAt-Date.now()))));}
 const start=ref(exitPath),exit=c.read(start),report=c.read(exit.report),decision=consumeFaultWindow(bound.window,exit,report,Date.now());
 // All byte, current pair, freshness and original stage checks are repeated before the first transport.
 const pins=assertCurrentPins(c,[bound.attemptReference,bound.handoff.spec.nativeGate,start,exit.report,bound.journal]),original=loadControl(c,start,'start',token.scenarioId);
 assert(same(original.expectedVersions,bound.handoff.expectedVersions),'FAULT_CURRENT_PAIR_CANNOT_DRIFT');assertFaultContactOrder(original,actualContacts(c,bound.contacts),{beforeGap:true,now:Date.now()});assert(Date.now()<token.deadlineAt,'POST_PIN_ORIGINAL_FAULT_DEADLINE');
 const permit={scenarioId:token.scenarioId,journal:bound.journal,deadlineAt:bound.handoff.deadlineAt,claimed:false};live.set(c,permit);
 let capture;try{capture=await collectImmediateFaultGap(c,{start,contacts:bound.contacts,continuation:bound.journal,continuationDeadlineAt:permit.deadlineAt});}finally{live.delete(c);}
 const result=write(resolve(here,'controls',token.scenarioId+'-gap-continuation-result.json'),{schemaVersion:'arc-snapshot-fault-continuation-result-v1',attempt:bound.journal,start,decision,immediatePinRecheckMs:pins.elapsedMs,waitAndCaptureMs:performance.now()-started,capture,noAutomaticRetry:true});return {result,...capture};
}
export function assertLiveFaultContinuation(c,q,{claim=false}={}){const p=live.get(c);assert(p&&p.scenarioId===q.scenarioId&&same(p.journal,q.continuation)&&q.continuationDeadlineAt===p.deadlineAt&&Date.now()<p.deadlineAt,'LIVE_RETAINED_FAULT_CONTEXT_REQUIRED');if(claim){assert(!p.claimed,'LIVE_FAULT_COLLECTION_CONSUMED');p.claimed=true;}else assert(p.claimed,'LIVE_FAULT_COLLECTION_NOT_CLAIMED');}
await main(import.meta.url,async()=>{assert(process.argv.length===3&&['after-r2','after-d1'].includes(process.argv[2]),'FIXED_FAULT_WATCH_ROLE_ONLY');const c=await createValidationContext(),token=armFaultContinuation(c,process.argv[2]);console.log(JSON.stringify({disposition:'FAULT_CONTINUATION_ARMED',scenarioId:token.scenarioId,deadlineAt:token.deadlineAt,stdin:'ignored'}));const result=await captureFaultGap(c,token);console.log(JSON.stringify(result));if(!result.allReadsSucceeded)process.exitCode=1;});
