// Safe native projections; export is permitted only after the collector's version type gate.
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,lstatSync} from 'node:fs';
import {resolve,relative,sep} from 'node:path';
import {workers,artifactHashes,hash,same} from './rules.mjs';
export {projectWorkflowDefinition,projectEmptyDatabase} from './rules.mjs';
export {projectDeployment,projectVersion,projectRoster} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/project.mjs';
export {projectD1} from '../../../../local-durable-executor-20261016/completed-ack-snapshot-cloud-tools-r3/policy.mjs';
export function projectExport(folder,role,expected){
 assert.ok(Object.hasOwn(workers,role));const dir=resolve(folder,workers[role]),configPath=resolve(dir,'wrangler.jsonc');
 for(const path of [folder,dir,resolve(dir,'src')]){const stat=lstatSync(path);assert.ok(stat.isDirectory()&&!stat.isSymbolicLink(),'ORDINARY_EXPORT_DIRECTORY');}
 const configStat=lstatSync(configPath);assert.ok(configStat.isFile()&&!configStat.isSymbolicLink()&&configStat.size<=65536,'BOUNDED_ORDINARY_EXPORT_CONFIG');
 const bytes=readFileSync(configPath),c=JSON.parse(bytes);assert.ok(c.name===expected.name&&same(c.vars,expected.vars),'EXACT_EXPORT_PLAIN_VALUES');
 const allowed=['name','main','workers_dev','preview_urls','compatibility_date','compatibility_flags','vars','services','d1_databases','r2_buckets','workflows','routes','triggers','limits','observability'];
 assert.ok(Object.keys(c).every(k=>allowed.includes(k))&&typeof c.main==='string'&&resolve(dir,c.main).startsWith(resolve(dir,'src')+sep),'EXACT_SUPPORTED_NATIVE_CONFIG');
 const files=[],exportReferences=[{path:configPath,sha256:hash(bytes)}];
 function walk(path){for(const item of readdirSync(path,{withFileTypes:true})){const child=resolve(path,item.name);assert.ok(child.startsWith(dir+sep)&&!item.isSymbolicLink(),'EXPORT_CONTAINMENT');if(item.isDirectory())walk(child);else{assert.ok(item.isFile(),'ORDINARY_EXPORT_MODULE');const value=readFileSync(child),sha256=hash(value);files.push({path:relative(dir,child).replaceAll('\\','/'),bytes:value.length,sha256});exportReferences.push({path:child,sha256});}}}
 walk(resolve(dir,'src'));const entry=files.find(f=>resolve(dir,f.path)===resolve(dir,c.main));assert.ok(files.length===1&&entry?.sha256===artifactHashes[role],'EXACT_UNCHANGED_BUNDLE');
 return {configSha256:hash(bytes),moduleFiles:files,entrySha256:entry.sha256,exportReferences,actualSchedulesRead:true,projection:{name:c.name,workers_dev:c.workers_dev??null,preview_urls:c.preview_urls??null,routes:c.routes??[],triggers:{crons:c.triggers?.crons??[]},vars:Object.fromEntries(Object.entries(c.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT')),d1_databases:c.d1_databases??[],r2_buckets:c.r2_buckets??[],services:c.services??[],workflows:c.workflows??[],compatibility_date:c.compatibility_date??null,compatibility_flags:c.compatibility_flags??[],limits:c.limits??null,observability:c.observability??null}};
}
