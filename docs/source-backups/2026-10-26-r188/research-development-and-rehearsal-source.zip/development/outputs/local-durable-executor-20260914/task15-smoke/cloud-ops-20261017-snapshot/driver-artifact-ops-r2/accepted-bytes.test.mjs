import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const H=import.meta.dirname, W=resolve(H,'../../../../..');
const O='outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261017-snapshot/driver-artifact-ops-r2';
const OUT='outputs/local-durable-executor-20260914/task15-smoke/build/cloud/task15-snapshot-cloud-20261017-r1';
const hash=b=>createHash('sha256').update(b).digest('hex');
const moduleUrl=new URL('./accepted-bytes.mjs',import.meta.url);
const api=()=>import(moduleUrl);
const gate={root:{path:O+'/root-tooling-acceptance-r1.json',sha256:'0'.repeat(64)},spec:{path:O+'/spec-review-r1.json',sha256:'1'.repeat(64)},quality:{path:O+'/quality-review-r1.json',sha256:'2'.repeat(64)}};

// Synthetic review references are kept only in memory or explicitly offline driver fixtures.
test('fixed verifier exists and verifies the actual accepted bytes without writing an assembly',async()=>{
 const m=await api(); const inspected=await m.inspectAcceptedBytes();
 assert.equal(inspected.status,'READ_ONLY_VERIFIED');
 assert.deepEqual(inspected.counts,{site:136,executor:124,union:160,overlays:5});
 await assert.rejects(access(resolve(W,OUT)),{code:'ENOENT'});
});
test('repaired input membership substitutes exactly five overlay paths with their actual byte digests',async()=>{
 const m=await api();const {snapshot}=await m.inspectAcceptedBytes();const r=m.deriveAssemblyReport(snapshot,gate);
 const original=JSON.parse(await readFile(resolve(W,'outputs/local-durable-executor-20260914/task15-smoke/build/cloud/task15-maintenance-stop-cloud-20261012-r1/report.json')));
 const repaired=JSON.parse(await readFile(resolve(W,'outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/report.json')));
 const overlays=new Map(repaired.changedInputs.map(x=>[x.source,x.overlay.path.slice(W.length+1).replaceAll('\\','/')]));
 const site=original.site.inputs.map(p=>overlays.get(p)??p).sort();
 assert.deepEqual(r.site.inputs,site);assert.deepEqual(r.executor.inputs,original.executor.inputs);
 assert.deepEqual(Object.keys(r.inputHashes).sort(),[...new Set([...site,...original.executor.inputs])].sort());
 for(const [p,d]of Object.entries(r.inputHashes))assert.equal(hash(await readFile(resolve(W,p))),d,p);
 for(const [source,overlay]of overlays){assert.ok(!r.site.inputs.includes(source));assert.equal(r.inputHashes[source],undefined);assert.ok(r.site.inputs.includes(overlay));}
 assert.equal(r.overlayDerivation.length,5);assert.equal(r.report,OUT+'/report.json');
 assert.deepEqual(r.aliasEdges,original.aliasEdges);assert.deepEqual(r.timing,original.timing);assert.deepEqual(r.policy,original.policy);
 assert.equal(r.validationScope,'accepted-byte-assembly-only');assert.equal(r.recompiled,false);assert.equal(r.newProductTestsRun,false);
 assert.equal(r.cloudElapsedProved,false);assert.equal(r.task15Accepted,false);assert.equal(r.cloudCalls,0);assert.equal(r.controlCalls,0);assert.equal(r.providerCalls,0);
 assert.equal(r.nativeArtifactEquality.observedAt,'2026-10-17T09:30:39.804Z');assert.equal(r.nativeArtifactEquality.freshnessRenewed,false);
 assert.equal(r.site.sha256,'443e7fd5d9a54e42f5a321f24d8b5c9a3bc12f47aa222702e665bd2f030c6993');
 assert.equal(r.executor.sha256,'b8a8faea136b335f58042f2bf7106ecbb13db30add7a78c16e200d6e192e4cfb');
 assert.equal(m.validateAssemblyReport(r,snapshot,gate),true);
});
for(const name of ['source','overlay','metafile','artifact','native','repaired-report'])test('rejects changed '+name+' bytes',async()=>{
 const m=await api();const {snapshot}=await m.inspectAcceptedBytes();
 const paths={source:'worker/research-executor/runtime.ts',overlay:'outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/site-import.ts',metafile:'outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/site.metafile.json',artifact:'outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/site.js',native:'outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261017-snapshot/no-start-ops-r1/observations/paired/native.json','repaired-report':'outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/report.json'};
 snapshot.files[paths[name]]=Buffer.concat([snapshot.files[paths[name]],Buffer.from(' ')]);
 assert.throws(()=>m.deriveAssemblyReport(snapshot,gate),/DIGEST/);
});
for(const name of ['omitted-overlay','extra-overlay','outside-workspace'])test('rejects '+name+' snapshot membership',async()=>{
 const m=await api();const {snapshot}=await m.inspectAcceptedBytes();const p='outputs/local-durable-executor-20261016/completed-ack-snapshot-artifact-r3/site-import.ts';
 if(name==='omitted-overlay')delete snapshot.files[p];
 else snapshot.files[name==='extra-overlay'?'unexpected-overlay.ts':'../outside.ts']=Buffer.from('x');
 assert.throws(()=>m.deriveAssemblyReport(snapshot,gate),/MEMBERSHIP|PATH/);
});
const mutations={
 'wrong artifact digest':r=>r.site.sha256='f'.repeat(64),
 'omitted role input':r=>r.site.inputs.pop(),
 'extra role input':r=>r.site.inputs.push('app/unrelated.ts'),
 'original name with overlay digest':r=>{const m=r.overlayDerivation[0];r.inputHashes[m.source]=m.actualSha256;delete r.inputHashes[m.overlay];},
 'wrong input digest':r=>r.inputHashes[r.site.inputs[0]]='f'.repeat(64),
 'omitted input digest':r=>delete r.inputHashes[r.site.inputs[0]],
 'extra input digest':r=>r.inputHashes['app/unrelated.ts']='f'.repeat(64),
 'wrong policy':r=>r.policy.retries=1,
 'wrong alias':r=>r.aliasEdges.pop(),
 'wrong output':r=>r.site.output=OUT+'/../escape.js',
 'wrong report path':r=>r.report='C:/outside/report.json',
 'changed review reference':r=>r.reviews.spec.sha256='f'.repeat(64),
 'unsupported success claim':r=>r.broadSuitePassed=true,
 'renewed historical observation':r=>r.nativeArtifactEquality.observedAt=new Date().toISOString(),
};
for(const [name,mutate]of Object.entries(mutations))test('strict report rejects '+name,async()=>{
 const m=await api();const {snapshot}=await m.inspectAcceptedBytes();const report=m.deriveAssemblyReport(snapshot,gate);mutate(report);
 assert.throws(()=>m.validateAssemblyReport(report,snapshot,gate),/ASSEMBLY_REPORT/);
});
test('historical whitelist verifies five accepted integration sources and eighteen native export files read-only',async()=>{
 const m=await api();const inspected=await m.inspectAcceptedBytes();
 assert.equal(Object.keys(inspected.snapshot.historicalFiles).length,23);
 const r=m.deriveAssemblyReport(inspected.snapshot,gate);
 assert.equal(r.provenance.historicalVerifiedReferences.length,23);
 assert.equal(r.provenance.historicalVerifiedReferences.filter(x=>x.purpose==='accepted-overlay-source').length,5);
 assert.equal(r.provenance.historicalVerifiedReferences.filter(x=>x.purpose==='accepted-native-export').length,18);
 for(const x of r.provenance.historicalVerifiedReferences){assert.equal(hash(await readFile(x.path)),x.sha256);assert.ok(!r.provenance.historicalExternalPathsNotRead.includes(x.path));}
});
for(const name of ['changed','omitted','extra'])test('historical whitelist rejects '+name+' archival bytes',async()=>{
 const m=await api();const {snapshot}=await m.inspectAcceptedBytes();
 assert.ok(snapshot.historicalFiles,'historical verifier missing');
 const key=Object.keys(snapshot.historicalFiles)[0];
 if(name==='changed')snapshot.historicalFiles[key]=Buffer.from('changed');
 if(name==='omitted')delete snapshot.historicalFiles[key];
 if(name==='extra')snapshot.historicalFiles['C:/outside/unlisted.ts']=Buffer.from('x');
 assert.throws(()=>m.deriveAssemblyReport(snapshot,gate),/HISTORICAL_DIGEST|HISTORICAL_MEMBERSHIP/);
});
