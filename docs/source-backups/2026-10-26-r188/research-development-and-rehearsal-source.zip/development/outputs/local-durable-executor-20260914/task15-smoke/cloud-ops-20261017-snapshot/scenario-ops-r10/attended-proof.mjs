// Fixed local attended handoff contract. Imports do not dispatch or write.
import {resolve} from 'node:path';
import {FIXED,here,G,assert,same,integer,uuid,utc,ref,assertContext,assertMaterials} from './guards.mjs';
import {SCENARIOS} from './read-plans.mjs';
import {CONTROL_BOUNDS} from './profile.mjs';
// Task3 supplies independently reviewed measured bounds; no historical reserve is adopted.
export const FIRST_ENTRY_PACKAGE_MAX_MS=86400000;
export const LATER_ROLE_TEMPLATE_MAX_MS=900000;
export const PREPARATION_ALLOWANCE_MS=905000; // Outer policy only; future Task3 measured full handoff must fit.
export const AUTHORITY_MODE='ROOT_PRE_REVIEWED_FIXED_POLICY_AUTOMATED_NATIVE_GATE';
export function assertMeasuredTiming(c,t){
 const m=assertMaterials(t.materials,c);assert(same(t.timingContract,m.timingContract),'SAME_REVIEWED_TIMING_CONTRACT');const timing=c.read(m.timingContract);
 assert(timing.schemaVersion==='arc-snapshot-attended-timing-v1'&&timing.actualMeasurements===true&&timing.reviewed===true&&same(timing.task2Profile,c.read(m.task2Acceptance).profile),'ACTUAL_TASK3_FULL_HANDOFF_MEASUREMENT');
 for(const key of ['inspectChildMs','acknowledgeChildMs','readinessValidatorMs','localValidationReserveMs','totalHandoffMs'])assert(integer(timing[key])&&timing[key]>0,'FINITE_MEASURED_TASK3_PATHS');
 assert(t.localValidationReserveMs===timing.localValidationReserveMs&&timing.localValidationReserveMs>=timing.inspectChildMs+timing.acknowledgeChildMs+timing.readinessValidatorMs&&timing.totalHandoffMs>=timing.localValidationReserveMs,'FULL_MEASURED_VALIDATION_RESERVE');return true;
}
export function assertTemplateWindow(role,reviewedAt,validUntil,now,{historical=false}={}){
 const maximum=fixedRole(role).first?FIRST_ENTRY_PACKAGE_MAX_MS:LATER_ROLE_TEMPLATE_MAX_MS;
 assert([reviewedAt,validUntil,now].every(integer)&&reviewedAt<validUntil&&validUntil-reviewedAt<=maximum&&reviewedAt<=now&&(historical||now<validUntil),'FINITE_ROOT_TERMINAL_TEMPLATE');
 return validUntil;
}
export function preparationDeadline(validUntil,invokedAt){
 assert(integer(validUntil)&&integer(invokedAt)&&integer(invokedAt+PREPARATION_ALLOWANCE_MS)&&invokedAt<validUntil,'ORIGINAL_PREPARATION_ALLOWANCE');
 return Math.min(validUntil,invokedAt+PREPARATION_ALLOWANCE_MS);
}
export function fixedRole(role){
 assert(typeof role==='string'&&Object.keys(SCENARIOS).flatMap(id=>['start','status','replay'].map(mode=>id+':'+mode)).includes(role),'FIXED_TERMINAL_ROLE');
 const [scenarioId,mode]=role.split(':'),stem=scenarioId+'-'+mode,reportName=`cloud-snapshot-${stem}-${FIXED.sequence}`;
 return {role,scenarioId,mode,jobId:SCENARIOS[scenarioId].jobId,reportName,first:role==='long:start',templatePath:resolve(here,'templates',stem+'.json'),shellAttemptPath:resolve(here,'terminal',stem+'-shell-attempt.json'),shellFailurePath:resolve(here,'terminal',stem+'-shell-failure.json'),invocationPath:resolve(here,'terminal',stem+'-invocation.json'),preparedPath:resolve(here,'terminal',stem+'-prepared.json'),acknowledgementPath:resolve(here,'terminal',stem+'-acknowledgement.json'),failurePath:resolve(here,'terminal',stem+'-failure.json'),readinessPath:resolve(here,'handoffs',stem+'-readiness.json'),handoffPath:resolve(here,'handoffs',stem+'.json'),attemptPath:resolve(here,'controls',stem+'-attempt.json'),exitPath:resolve(here,'controls',stem+'-exit.json'),reportPath:resolve(G,'..',reportName,'report.json'),launcherPath:resolve(here,'run-'+stem+'-masked-once-r1.ps1'),commandPath:resolve(here,stem+'-command-r1.ps1')};
}
export function assertAcknowledgement(e,{now,first}){
 assert(uuid(e.invocationId)&&integer(e.processId)&&e.processId>0&&[e.invokedAt,e.preparedAt,e.nativeEndedAt,e.promptedAt,e.userReadyAt,e.acknowledgementDeadlineAt,now].every(integer),'ACTUAL_LOCAL_ACK_IDENTITY_CLOCKS');
 assert(e.invokedAt<=e.preparedAt&&e.nativeEndedAt<=e.preparedAt&&e.preparedAt<=e.promptedAt&&e.promptedAt<=e.userReadyAt&&e.userReadyAt<=now&&e.userReadyAt<e.acknowledgementDeadlineAt&&e.acknowledgementDeadlineAt-e.promptedAt<=CONTROL_BOUNDS.acknowledgement&&now-e.userReadyAt<900000,'ACTUAL_POST_NATIVE_ACK_ORDER_DEADLINE');
 assert(first?integer(e.initialAcknowledgedAt)&&e.invokedAt<=e.initialAcknowledgedAt&&e.initialAcknowledgedAt<=e.nativeEndedAt:e.initialAcknowledgedAt===null,'INITIAL_ACK_BEFORE_FIRST_PIPELINE');return e;
}
export function terminalPins(role){const r=fixedRole(role);return Object.fromEntries(['terminal-contract.mjs','terminal-prepare.mjs','terminal-entry.ps1','prepare-terminal-template.mjs','launcher-contract.json',r.launcherPath,r.commandPath].map(path=>[path.includes('\\')||path.includes('/')?path.split(/[\\/]/u).at(-1):path,ref(resolve(here,path))]));}
export function loadTerminalTemplate(c,reference,role,{now=Date.now(),historical=false}={}){
 assertContext(c);const r=fixedRole(role),t=c.read(reference);
 assert(reference.path===r.templatePath&&t.schemaVersion==='arc-snapshot-terminal-template-v1'&&t.rootReviewed===true&&t.authorityMode===AUTHORITY_MODE&&t.sequence===FIXED.sequence&&t.epoch===FIXED.epoch&&same(t.identity,r)&&same(t.currentClosedAcceptance,FIXED.currentClosedAcceptance),'FIXED_ROOT_TERMINAL_POLICY');
 assertTemplateWindow(role,utc(t.reviewedAt),t.validUntil,now,{historical});
 assert(t.userReadyAt===undefined&&same(t.pins,terminalPins(role))&&assertMeasuredTiming(c,t)&&t.noAutomaticRetry===true&&t.providerCallsAllowed===false,'ROOT_TEMPLATE_PINS_NO_FUTURE_ATTENDANCE');
 for(const pin of Object.values(t.pins))c.verify(pin);assertMaterials(t.materials,c);
 assert(t.spec===null?r.first:!r.first&&t.spec.scenarioId===r.scenarioId&&t.spec.mode===r.mode&&t.spec.readiness===undefined&&t.spec.userReadyAt===undefined&&same(t.spec.materials,t.materials),'FIXED_TEMPLATE_ROLE_AND_PREREQUISITES');return t;
}
export function assertTerminalAuthority(c,record,gate,now){
 assert(record.authorityMode===AUTHORITY_MODE&&record.reviewedPolicy&&record.futureNativeManuallyReviewed===false,'EXPLICIT_PRE_REVIEWED_FIXED_AUTHORITY');
 const t=loadTerminalTemplate(c,record.reviewedPolicy,'long:start',{now,historical:true});
 assert(same(t.materials,record.materials??gate.request.materials)&&same(t.preparation,gate.request.preparation)&&same(record.reviewedPolicy,gate.request.terminalPolicy)&&now<t.validUntil,'SAME_POLICY_PREPARATION_MATERIALS_WINDOW');
 const r=fixedRole('long:start');assert(record.terminalInvocation?.path===r.invocationPath,'ACTUAL_INITIAL_TERMINAL_INVOCATION_REFERENCE');const invocation=c.read(record.terminalInvocation),shell=c.read(invocation.shellAttempt);
 assert(same(invocation.reviewedPolicy,record.reviewedPolicy)&&invocation.identity.role==='long:start'&&invocation.initialAcknowledgedAt===gate.request.readinessStartedAt&&invocation.initialAcknowledgedAt<=utc(gate.startedAt)&&invocation.invocationId===shell.invocationId&&invocation.processId===shell.processId&&invocation.invokedAt===shell.invokedAt&&invocation.invokedAt<=invocation.initialAcknowledgedAt&&invocation.shellAttempt.path===r.shellAttemptPath&&(record.userReadyAt===undefined||record.userReadyAt===invocation.initialAcknowledgedAt),'INITIAL_ACK_BINDS_AUTOMATED_AUTHORITY');return t;
}
export function assertTerminalReadiness(c,readiness,spec,gate,now){
 const role=spec.scenarioId+':'+spec.mode,r=fixedRole(role),t=loadTerminalTemplate(c,readiness.reviewedPolicy,role,{now,historical:true});
 assert(readiness.authorityMode===AUTHORITY_MODE&&readiness.userAttendanceSource==='ACTUAL_LOCAL_ENTER_AFTER_NATIVE_GATE'&&readiness.futureNativeManuallyReviewed===false&&readiness.acknowledgement?.path===r.acknowledgementPath,'ACTUAL_LOCAL_READINESS_PROVENANCE');
 const ack=c.read(readiness.acknowledgement),prepared=c.read(ack.prepared),invocation=c.read(prepared.invocation);
 const {readiness:ignoredReadiness,...unreadySpec}=spec;
 assert(ack.prepared.path===r.preparedPath&&prepared.invocation.path===r.invocationPath&&same(invocation.reviewedPolicy,readiness.reviewedPolicy)&&same(prepared.reviewedPolicy,readiness.reviewedPolicy)&&same(prepared.spec,unreadySpec)&&same(prepared.nativeGate,spec.nativeGate),'EXACT_EXCLUSIVE_LOCAL_PREPARATION');
 assert(invocation.schemaVersion==='arc-snapshot-terminal-invocation-v1'&&prepared.schemaVersion==='arc-snapshot-terminal-prepared-v1'&&ack.schemaVersion==='arc-snapshot-terminal-acknowledgement-v1'&&same(invocation.pins,t.pins)&&same(invocation.identity,r)&&invocation.invocationId===ack.invocationId&&invocation.processId===ack.processId&&ack.invokedAt===invocation.invokedAt&&ack.initialAcknowledgedAt===invocation.initialAcknowledgedAt&&ack.preparedAt===prepared.preparedAt&&ack.nativeEndedAt===utc(gate.endedAt)&&ack.acknowledgementDeadlineAt===prepared.acknowledgementDeadlineAt&&readiness.userReadyAt===ack.userReadyAt,'ACTUAL_LOCAL_EVENT_BINDINGS');
 assertAcknowledgement(ack,{now,first:r.first});assert(now<t.validUntil&&ack.userReadyAt<t.validUntil,'ORIGINAL_TEMPLATE_EXPIRY');return {t,ack,prepared,invocation};
}
