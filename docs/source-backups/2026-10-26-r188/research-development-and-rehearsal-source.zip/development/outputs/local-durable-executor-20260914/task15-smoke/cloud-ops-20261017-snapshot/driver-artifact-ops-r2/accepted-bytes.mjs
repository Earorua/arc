// Fixed accepted-byte verification. No network, child process, credentials or compilation.
import { createHash } from 'node:crypto';
import { readFile, realpath, lstat } from 'node:fs/promises';
import { resolve, relative, sep, isAbsolute } from 'node:path';
import { isDeepStrictEqual } from 'node:util';

export const WORKSPACE=resolve(import.meta.dirname,'../../../../..');
export const OPS='outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261017-snapshot/driver-artifact-ops-r2';
export const OUTPUT='outputs/local-durable-executor-20260914/task15-smoke/build/cloud/task15-snapshot-cloud-20261017-r1';
const pinDigest='9bde895b6d3a52ea077236175f8b95209e32c50965cf79dd110d6ecc0160cd43';
export const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const fail=code=>{throw Object.assign(new Error(code),{code});};
const demand=(condition,code)=>{if(!condition)fail(code);};
const equal=(a,b,code)=>demand(isDeepStrictEqual(a,b),code);
const keys=(o,list,code)=>demand(o&&typeof o==='object'&&!Array.isArray(o)&&isDeepStrictEqual(Object.keys(o).sort(),[...list].sort()),code);
const sorted=values=>[...values].sort();
const portable=path=>relative(WORKSPACE,resolve(WORKSPACE,path)).split(sep).join('/');
export function assertWorkspacePath(path){
 demand(typeof path==='string'&&path.length>0&&!isAbsolute(path)&&!path.includes('\\')&&!path.includes(':')&&path===portable(path)&&!path.startsWith('../'),'WORKSPACE_PATH');return path;
}
async function readFixed(path){
 assertWorkspacePath(path);const target=resolve(WORKSPACE,path);const actual=await realpath(target);
 demand(actual===target,'WORKSPACE_PATH');const stat=await lstat(target);demand(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=10_000_000,'FILE_TYPE_OR_LIMIT');return readFile(target);
}
const pinBytes=await readFixed(OPS+'/accepted-pins.json');
demand(sha256(pinBytes)===pinDigest,'PINS_DIGEST');
const pins=JSON.parse(pinBytes);
const referenceEqual=(actual,expected,code)=>{keys(actual,['path','sha256'],code);equal({path:portable(actual.path),sha256:actual.sha256},expected,code);};
const timing={long:{headersMs:1140000,bodyMs:30000},'after-r2':{headersMs:10,bodyMs:10},'after-d1':{headersMs:10,bodyMs:10}};
const policy={timeout:'21 minutes',retries:0,providerDeadlineMs:1200000,executionLeaseMs:1260000};
const runtime='worker/research-executor/runtime.ts',wrapper='worker/research-executor-smoke/runtime.ts';
const aliases=[{kind:'runtime-bypass',importer:wrapper,specifier:'../research-executor/runtime',original:runtime,resolved:runtime},
 ...['worker/research-executor/index.ts','worker/research-executor/workflow.ts'].map(importer=>({kind:'runtime-rewrite',importer,specifier:'./runtime',original:runtime,resolved:wrapper}))];

function unpack(snapshot){
 keys(snapshot,['files','historicalFiles'],'SNAPSHOT_MEMBERSHIP');
 equal(sorted(Object.keys(snapshot.historicalFiles??{})),sorted(pins.historicalReferences.map(r=>r.path)),'HISTORICAL_MEMBERSHIP');
 for(const ref of pins.historicalReferences)demand(snapshot.historicalFiles[ref.path] instanceof Uint8Array&&sha256(snapshot.historicalFiles[ref.path])===ref.sha256,'HISTORICAL_DIGEST');demand(snapshot.files&&typeof snapshot.files==='object'&&!Array.isArray(snapshot.files),'SNAPSHOT_MEMBERSHIP');
 for(const path of Object.keys(snapshot.files))assertWorkspacePath(path);
 const bytes=ref=>{const value=snapshot.files[ref.path];demand(value instanceof Uint8Array,'SNAPSHOT_MEMBERSHIP');demand(sha256(value)===ref.sha256,'REFERENCE_DIGEST');return value;};
 for(const ref of Object.values(pins.references))bytes(ref);
 const json=name=>JSON.parse(Buffer.from(bytes(pins.references[name])).toString('utf8'));
 const original=json('originalBuildReport'),repaired=json('repairedSiteReport');
 const expectedFiles=sorted(new Set([...Object.values(pins.references).map(r=>r.path),...Object.keys(original.inputHashes),...pins.overlays.map(o=>o.overlay)]));
 equal(sorted(Object.keys(snapshot.files)),expectedFiles,'SNAPSHOT_MEMBERSHIP');
 for(const [path,sha]of Object.entries(original.inputHashes)){assertWorkspacePath(path);bytes({path,sha256:sha});}
 for(const overlay of pins.overlays)bytes({path:overlay.overlay,sha256:overlay.actualSha256});
 equal(original.timing,timing,'TIMING');equal(original.policy,policy,'POLICY');equal(original.aliasEdges,aliases,'ALIASES');
 demand(original.status==='passed'&&original.profile==='cloud'&&original.deployable===true&&original.cloudElapsedProved===false,'ORIGINAL_REPORT');
 referenceEqual(repaired.original,pins.references.originalBuildReport,'ORIGINAL_REFERENCE');
 referenceEqual(repaired.localAcceptance,pins.references.localRepairAcceptance,'REPAIR_ACCEPTANCE_REFERENCE');
 referenceEqual(repaired.artifact,pins.references.siteArtifact,'SITE_REFERENCE');referenceEqual(repaired.metafile,pins.references.siteMetafile,'METAFILE_REFERENCE');
 for(const [field,pin]of [['helper','repairDerivationHelper'],['manifest','repairManifest'],['previousReport','previousSiteReport'],['previousArtifact','previousSiteArtifact']])referenceEqual(repaired[field],pins.references[pin],'REPAIR_REFERENCE');
 demand(repaired.previousOverlays.length===2,'PREVIOUS_OVERLAYS');repaired.previousOverlays.forEach((r,i)=>referenceEqual(r,pins.references['previousOverlay'+i],'PREVIOUS_OVERLAYS'));
 equal(repaired.changedInputs.map(x=>({source:x.source,beforeSha256:x.beforeSha256,overlay:portable(x.overlay.path),actualSha256:x.overlay.sha256})),pins.overlays,'OVERLAY_MEMBERSHIP');
 demand(repaired.baselineByteIdentical===true&&repaired.unchangedInputCount===131&&repaired.newProductionInputCount===3,'OVERLAY_DERIVATION');
 const repair=json('localRepairAcceptance');demand(repair.status==='LOCAL_PAIR_ACCEPTED_NOT_DEPLOYED','LOCAL_REPAIR_ACCEPTANCE');
 const metas={site:json('siteMetafile'),executor:json('executorMetafile'),originalSite:json('originalSiteMetafile')};
 const membership=graph=>sorted(Object.keys(graph.inputs));
 equal(sorted(original.site.inputs),membership(metas.originalSite),'ORIGINAL_SITE_MEMBERSHIP');
 equal(sorted(original.site.inputs),membership(metas.site),'REPAIRED_SITE_MEMBERSHIP');
 equal(sorted(original.executor.inputs),membership(metas.executor),'EXECUTOR_MEMBERSHIP');
 equal(sorted(Object.keys(original.inputHashes)),sorted(new Set([...original.site.inputs,...original.executor.inputs])),'ORIGINAL_INPUT_HASH_MEMBERSHIP');
 for(const [role,prefix]of [['site','originalSite'],['executor','executor']]){
  equal({path:original[role].output,sha256:original[role].sha256},pins.references[prefix+'Artifact'],'ORIGINAL_ARTIFACT');
  equal({path:original[role].metafile,sha256:original[role].metafileSha256},pins.references[prefix+'Metafile'],'ORIGINAL_METAFILE');
 }
 const substitute=new Map(pins.overlays.map(o=>[o.source,o.overlay]));
 for(const overlay of pins.overlays){demand(original.site.inputs.includes(overlay.source),'OVERLAY_SOURCE');equal(original.inputHashes[overlay.source],overlay.beforeSha256,'OVERLAY_BEFORE');}
 const siteInputs=original.site.inputs.map(p=>substitute.get(p)??p).sort(),executorInputs=[...original.executor.inputs];
 const inputHashes=Object.fromEntries(sorted(new Set([...siteInputs,...executorInputs])).map(path=>[path,sha256(snapshot.files[path])]));
 equal({site:siteInputs.length,executor:executorInputs.length,union:Object.keys(inputHashes).length,overlays:substitute.size},pins.counts,'INPUT_COUNTS');
 const acceptance=json('nativeAcceptance'),native=json('pairedNative'),proof=json('pairedProof');
 demand(acceptance.status==='CLOSED_PAIR_NATIVE_MAPPING_ACCEPTED'&&acceptance.rootReviewed===true&&acceptance.specPassed===true&&acceptance.qualityPassed===true,'NATIVE_ACCEPTANCE');
 equal(acceptance.accountId,pins.accountId,'NATIVE_ACCOUNT');equal(acceptance.observedAt,pins.nativeObservedAt,'NATIVE_TIME');equal(acceptance.acceptedAt,pins.nativeAcceptedAt,'NATIVE_TIME');
 equal(acceptance.mapping.versions,pins.versions,'NATIVE_VERSIONS');equal(proof.mapping.versions,pins.versions,'NATIVE_VERSIONS');
 referenceEqual(acceptance.pairedProof,pins.references.pairedProof,'NATIVE_REFERENCE');referenceEqual(acceptance.pairedNative,pins.references.pairedNative,'NATIVE_REFERENCE');referenceEqual(proof.nativeReference,pins.references.pairedNative,'NATIVE_REFERENCE');
 demand(proof.allChecksPassed===true&&native.allReadsSucceeded===true&&native.endedAt===pins.nativeObservedAt,'NATIVE_PROOF');
 const uniqueObservation=id=>{const items=native.observations.filter(x=>x.id===id);demand(items.length===1&&items[0].ok===true,'NATIVE_OBSERVATION');return items[0];};
 const roles={};
 for(const role of ['site','executor']){
  const artifact=pins.references[role+'Artifact'],meta=pins.references[role+'Metafile'];
  referenceEqual(acceptance.entries[role].artifact,artifact,'NATIVE_ARTIFACT');
  const exported=uniqueObservation(role+'-export');equal(exported.entrySha256,artifact.sha256,'NATIVE_ARTIFACT');
  demand(exported.precedingVersionId===pins.versions[role],'NATIVE_VERSION');
  for(const suffix of ['-current-deployment','-current-version','-final-deployment'])equal(uniqueObservation(role+suffix).versionId,pins.versions[role],'NATIVE_VERSION');
  equal(exported.moduleFiles,[{path:'src/'+role+'.js',bytes:bytes(artifact).length,sha256:artifact.sha256}],'NATIVE_MODULES');
  const outputGraphs=Object.values(metas[role].outputs);demand(outputGraphs.length===1,'METAFILE_OUTPUTS');
  const graph=outputGraphs[0];demand(graph.bytes===bytes(artifact).length,'METAFILE_BYTES');demand(Object.keys(graph.inputs).every(path=>Object.hasOwn(metas[role].inputs,path)),'OUTPUT_INPUT_MEMBERSHIP');
  equal(sorted(graph.exports),role==='site'?['default']:['ResearchWorkflow','default'],'METAFILE_EXPORTS');
  roles[role]={output:OUTPUT+'/'+role+'.js',sha256:artifact.sha256,bytes:bytes(artifact).length,metafile:OUTPUT+'/'+role+'.metafile.json',metafileSha256:meta.sha256,inputs:role==='site'?siteInputs:executorInputs,exports:sorted(graph.exports)};
 }
 // Historical reports are pinned as records. Embedded archival files are not current read dependencies.
 const unread=new Set();
 const visit=value=>{if(typeof value==='string'&&isAbsolute(value)&&portable(value).startsWith('../')&&!pins.historicalReferences.some(r=>r.path===value))unread.add(value);else if(Array.isArray(value))value.forEach(visit);else if(value&&typeof value==='object')Object.values(value).forEach(visit);};
 for(const document of [repaired,repair,acceptance,native,proof])visit(document);
 return {original,repaired,roles,inputHashes,unread:sorted(unread)};
}

export async function inspectAcceptedBytes(){
 const files={};for(const ref of Object.values(pins.references))files[ref.path]=await readFixed(ref.path);
 demand(sha256(files[pins.references.originalBuildReport.path])===pins.references.originalBuildReport.sha256,'REFERENCE_DIGEST');
 const original=JSON.parse(files[pins.references.originalBuildReport.path].toString('utf8'));
 for(const path of new Set([...Object.keys(original.inputHashes),...pins.overlays.map(o=>o.overlay)]))if(!Object.hasOwn(files,path))files[path]=await readFixed(path);
 const historicalFiles={};
 for(const ref of pins.historicalReferences){const actual=await realpath(ref.path);demand(actual===ref.path,'HISTORICAL_PATH');const stat=await lstat(ref.path);demand(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=10_000_000,'HISTORICAL_FILE');historicalFiles[ref.path]=await readFile(ref.path);}
 const snapshot={files,historicalFiles};const details=unpack(snapshot);
 return {status:'READ_ONLY_VERIFIED',counts:{...pins.counts},snapshot,readDependencies:sorted(Object.keys(files)).map(path=>({path,sha256:sha256(files[path])})),historicalExternalPathsNotRead:details.unread};
}
function reviewRefs(value){
 keys(value,['root','spec','quality'],'REVIEW_REFERENCES');
 for(const [key,name]of [['root','root-tooling-acceptance-r1'],['spec','spec-review-r1'],['quality','quality-review-r1']]){
  keys(value[key],['path','sha256'],'REVIEW_REFERENCES');demand(value[key].path===OPS+'/'+name+'.json'&&/^[0-9a-f]{64}$/.test(value[key].sha256),'REVIEW_REFERENCES');
 }
 return structuredClone(value);
}
export function deriveAssemblyReport(snapshot,reviews){
 const data=unpack(snapshot);return {
  schemaVersion:'arc-snapshot-accepted-byte-assembly-v1',status:'passed',profile:'cloud',deployable:true,report:OUTPUT+'/report.json',
  validationScope:'accepted-byte-assembly-only',recompiled:false,newProductTestsRun:false,cloudElapsedProved:false,cloudCalls:0,controlCalls:0,providerCalls:0,task15Accepted:false,
  timing:structuredClone(data.original.timing),policy:structuredClone(data.original.policy),aliasEdges:structuredClone(data.original.aliasEdges),
  site:data.roles.site,executor:data.roles.executor,inputHashes:data.inputHashes,overlayDerivation:structuredClone(pins.overlays),
  provenance:{acceptedReferences:structuredClone(pins.references),historicalSourceInventory:{report:structuredClone(pins.references.originalBuildReport),field:'sourceHashes',scope:'historical-provenance-only; not effective repaired inputs'},
   overlaySourceNamesInMetafile:true,historicalVerifiedReferences:structuredClone(pins.historicalReferences),historicalVerificationScope:'Fixed read-only whitelist from accepted records; byte verification does not renew cloud freshness.',historicalExternalPathsNotRead:data.unread,embeddedHistoricalReferencesScope:'Only the bytes of the named accepted records are verified. Nested archival files listed here were not read, are not current dependencies, and grant no write authority.'},
  nativeArtifactEquality:{acceptance:structuredClone(pins.references.nativeAcceptance),proof:structuredClone(pins.references.pairedProof),native:structuredClone(pins.references.pairedNative),versions:structuredClone(pins.versions),observedAt:pins.nativeObservedAt,acceptedAt:pins.nativeAcceptedAt,freshnessRenewed:false,currentCloudStateProved:false},
  reviews:reviewRefs(reviews),
 };
}
export function validateAssemblyReport(report,snapshot,reviews){equal(report,deriveAssemblyReport(snapshot,reviews),'ASSEMBLY_REPORT');return true;}