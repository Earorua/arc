// Read-only test inventory. Resolve actual AST expressions, independently of context.mjs.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {findPackageJSON} from 'node:module';
import {parse} from '../../../../../node_modules/acorn/dist/acorn.mjs';
const N=import.meta.dirname,W=resolve(N,'../../../../..');
const roots=['rules','context','read-plans','read-transport','write-transport','project','evaluate','records','collect','deploy','prepare'].map(n=>resolve(N,n+'.mjs'));
const childArtifacts=['node_modules/wrangler/bin/wrangler.js','node_modules/wrangler/wrangler-dist/cli.js','outputs/local-durable-executor-20261012/maintenance-stop/read-connection-trace-r2.cjs'].map(p=>resolve(W,p));
const sourceGuard=resolve(N,'../../cloud-ops-20261013-guarded/scenario-ops-r9/guards.mjs');
const pin=path=>({path,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')});
function walk(node,callback,parents=[]){
 if(!node||typeof node!=='object')return;if(node.type)callback(node,parents);
 for(const value of Object.values(node)){if(Array.isArray(value))for(const child of value)walk(child,callback,[...parents,node]);else if(value&&typeof value==='object')walk(value,callback,[...parents,node]);}
}
export function inventory(){
 const files=new Map(),edges=[],dynamic=[],trees=new Map();
 function tree(path){
  if(trees.has(path))return trees.get(path);
  const source=readFileSync(path,'utf8'),ast=parse(source,{ecmaVersion:'latest',sourceType:'module',locations:true}),decls=new Map();
  for(const item of ast.body){const node=item.type==='ExportNamedDeclaration'?item.declaration:item;if(node?.type==='VariableDeclaration')for(const d of node.declarations)if(d.id.type==='Identifier')decls.set(d.id.name,d.init);}
  const result={source,ast,decls};trees.set(path,result);return result;
 }
 // This interpreter permits only data and the path operations used by fixed imports.
 // It never evaluates source code or executes an imported operational module.
 function value(node,path,bindings={}){
  assert.ok(node,'RESOLVABLE_FIXED_AST_EXPRESSION');
  if(node.type==='Literal')return node.value;
  if(node.type==='Identifier')return Object.hasOwn(bindings,node.name)?bindings[node.name]:value(tree(path).decls.get(node.name),path,bindings);
  if(node.type==='ArrayExpression')return node.elements.map(n=>value(n,path,bindings));
  if(node.type==='ObjectExpression')return Object.fromEntries(node.properties.map(p=>{assert.equal(p.type,'Property');return [p.key.name??p.key.value,value(p.value,path,bindings)];}));
  if(node.type==='BinaryExpression'&&node.operator==='+')return value(node.left,path,bindings)+value(node.right,path,bindings);
  if(node.type==='MemberExpression'){
   if(node.object.type==='MetaProperty'&&node.object.meta.name==='import'&&node.property.name==='url')return pathToFileURL(path).href;
   const expression=tree(path).source.slice(node.start,node.end);
   if(/^g\.FIXED\.(codec|receiptProjector)\.path$/u.test(expression)){
    const name=expression.split('.')[2],fixed=tree(sourceGuard).decls.get('FIXED').arguments[0];
    const property=fixed.properties.find(p=>p.key.name===name);return value(property.value,sourceGuard).path;
   }
   return value(node.object,path,bindings)[node.computed?value(node.property,path,bindings):node.property.name];
  }
  if(node.type==='CallExpression'){
   const name=node.callee.name??(node.callee.object?.name+'.'+node.callee.property?.name);
   const functions={resolve,dirname,fileURLToPath,pathToFileURL,'Object.freeze':x=>x};
   assert.ok(Object.hasOwn(functions,name),'NO_ARBITRARY_AST_CALL:'+name);return functions[name](...node.arguments.map(n=>value(n,path,bindings)));
  }
  assert.fail('UNRESOLVED_AST_EXPRESSION:'+node.type);
 }
 function local(source,specifier,kind){
  if(specifier instanceof URL)specifier=specifier.href;
  assert.equal(typeof specifier,'string');if(specifier.startsWith('node:'))return null;
  let target;
  if(specifier.startsWith('file:'))target=fileURLToPath(specifier);
  else if(specifier.startsWith('.'))target=resolve(dirname(source),specifier);
  else{
   assert.equal(specifier,'zod','NO_UNEXAMINED_BARE_RUNTIME_IMPORT');
   const metadata=findPackageJSON(specifier,pathToFileURL(source));
   assert.equal(metadata,findPackageJSON(specifier,import.meta.url),'SAME_PACKAGE_FROM_ACTUAL_IMPORTER');
   target=fileURLToPath(import.meta.resolve(specifier));
   const pkg=JSON.parse(readFileSync(metadata,'utf8'));assert.equal(target,resolve(dirname(metadata),pkg.exports['.'].import),'ACTUAL_ESM_IMPORT_CONDITION');
   edges.push({source,target:metadata,kind:'package-resolution'});visit(metadata);
  }
  target=resolve(target);edges.push({source,target,kind});visit(target);return target;
 }
 function visit(path){
  path=resolve(path);if(files.has(path))return;files.set(path,pin(path));
  if(childArtifacts.includes(path)||!/[.][cm]?js$/u.test(path))return;
  if(path.endsWith('.js')&&path.startsWith(resolve(W,'node_modules/zod')+'\\')){
   const metadata=findPackageJSON(pathToFileURL(path));assert.equal(JSON.parse(readFileSync(metadata,'utf8')).type,'module','ACTUAL_ESM_PACKAGE_FORMAT');
   edges.push({source:path,target:metadata,kind:'package-format'});visit(metadata);
  }
  const {source,ast}=tree(path);
  walk(ast,(node,parents)=>{
   if(['ImportDeclaration','ExportNamedDeclaration','ExportAllDeclaration'].includes(node.type)&&node.source)local(path,node.source.value,'literal');
   if(node.type==='ImportExpression'){
    if(node.source.type==='Literal'){local(path,node.source.value,'literal');return;}
    const map=parents.findLast(p=>p.type==='CallExpression'&&p.callee.type==='MemberExpression'&&p.callee.property.name==='map'&&p.callee.object.type==='ArrayExpression');
    const bindings=map?value(map.callee.object,path).map(n=>({[map.arguments[0].params[0].name]:n})):[{}];
    const targets=bindings.map(b=>local(path,value(node.source,path,b),'dynamic'));
    dynamic.push({source:path,line:node.loc.start.line,expression:source.slice(node.source.start,node.source.end),targets});
   }
   if(node.type==='CallExpression'&&node.callee.type==='Identifier'&&node.callee.name==='require'){
    assert.equal(node.arguments[0]?.type,'Literal','NO_UNEXAMINED_COMPUTED_REQUIRE');local(path,node.arguments[0].value,'require');
   }
  });
 }
 for(const path of [...roots,...childArtifacts])visit(path);
 const dynamicPaths=new Set();function follow(path){if(dynamicPaths.has(path))return;dynamicPaths.add(path);for(const e of edges.filter(e=>e.source===path))follow(e.target);}
 for(const entry of dynamic)for(const target of entry.targets)follow(target);
 return {references:[...files.values()].sort((a,b)=>a.path.localeCompare(b.path)),edges,dynamic:dynamic.sort((a,b)=>a.source.localeCompare(b.source)||a.line-b.line),dynamicClosure:[...dynamicPaths].sort(),childArtifacts,parser:[pin(resolve(W,'node_modules/acorn/package.json')),pin(resolve(W,'node_modules/acorn/dist/acorn.mjs'))]};
}
