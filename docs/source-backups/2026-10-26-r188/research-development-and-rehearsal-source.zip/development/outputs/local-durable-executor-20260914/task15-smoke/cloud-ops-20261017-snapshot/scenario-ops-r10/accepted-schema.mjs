// Pure evaluation: no stored success is trusted without recomputing its native evidence.
import assert from 'node:assert/strict';
import {assertRead} from './mapping.mjs';
import {commandsFor} from '../schema-ops-r1/read-plans.mjs';
import {hash,same,utc,assertFresh,workers,artifactHashes,databases,bucket,emptySql,expectedBindings,assertStopped,assertFiveWorkflows,digest,roles,initializedRoles,schemaChecks,assertEmpty} from '../schema-ops-r1/rules.mjs';
const canonical=v=>Array.isArray(v)?v.map(canonical).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,canonical(x)])):v;
export const equivalent=(a,b)=>same(canonical(a),canonical(b));
export function assertCollection(n,q,expected,now){
 const start=utc(n.startedAt),end=utc(n.endedAt),commands=commandsFor(q,expected);
 assert.ok(n.schemaVersion==='arc-snapshot-schema-native-v1'&&n.phase===q.phase&&n.stage===q.stage&&n.scenarioId===null&&n.allReadsSucceeded===true,'WHOLE_INDEPENDENT_COLLECTION_REQUIRED');
 for(const k of ['cloudMutations','workerControlCalls','providerCalls','migrations'])assert.equal(n[k],0);
 assert.ok(Number.isSafeInteger(q.preparedAt)&&q.preparedAt>=0&&q.deadlineAt===q.preparedAt+720000,'IMMUTABLE_TWELVE_MINUTE_REQUEST');
 assert.ok(q.preparedAt<=start&&start<=end&&end<=now&&end<=q.deadlineAt,'ACTUAL_COMPLETE_READ_WINDOW');assertFresh(new Date(q.preparedAt).toISOString(),n.endedAt,now);
 assert.deepEqual(n.observations.map(o=>o.id),commands.map(c=>c.id),'COMPLETE_ORDERED_COLLECTION_NO_STITCHING');
 let previous=start;
 for(const [i,o]of n.observations.entries()){
  assertRead(o,start,end,commands[i].args);assert.ok(utc(o.startedAt)>=previous,'SEQUENTIAL_COMPLETE_COLLECTION');previous=utc(o.endedAt);
  for(const a of o.attempts){
   utc(a.startedAt);utc(a.endedAt);assert.ok(a.stdoutBytes+a.stderrBytes<=(commands[i].kind==='export'?65536:131072),'READ_OUTPUT_CAP');
   assert.ok(Number.isFinite(a.elapsedMs)&&a.elapsedMs>=0&&a.elapsedMs<=a.childTimeoutMs+1000,'ACTUAL_BOUNDED_ATTEMPT_DURATION');
   if(a.failureKind==='transport-timeout')assert.ok(a.timedOut===true&&(a.signal===null||typeof a.signal==='string'&&/^[A-Z0-9]{1,32}$/u.test(a.signal)),'CONFIRMED_TIMEOUT_RETRY_METADATA');
   else assert.equal(a.signal,null,'NO_SIGNAL_SUCCESS_OR_TRANSPORT_ERROR');
  }
 }
 const t=n.transport;assert.ok(t?.halted===null&&t.budgetExhausted===false&&t.maxAttempts===3&&t.backoffMs===1000&&t.childTimeoutMs===45000&&t.closeGraceMs===1000&&t.collectorBudgetMs>0&&t.collectorBudgetMs<=720000&&Number.isFinite(t.elapsedMs)&&t.elapsedMs>=0&&t.elapsedMs<=t.collectorBudgetMs,'BOUNDED_TRANSPORT');return n;
}
export function evaluateMapping(n,q,{configs,baseline,expected,applied,executorStartedAt},now){
 const needed=initializedRoles(q.stage);assert.deepEqual(Object.keys(applied).sort(),[...needed].sort(),'EXACT_PHASE_APPLY_PREREQUISITES');assert.deepEqual(q.expectedVersions,baseline.versions,'ACTUAL_PAIRED_WORKER_IDENTITIES');assert.deepEqual(q.configs,baseline.configs,'ACTUAL_PAIRED_CONFIG_IDENTITIES');assertCollection(n,q,expected,now);const get=id=>n.observations.find(o=>o.id===id),nativeSettings={},schemas={};
 for(const role of ['site','executor']){
  const d=get(role+'-current-deployment'),v=get(role+'-current-version'),x=get(role+'-export'),f=get(role+'-final-deployment'),c=configs[role],p=x.projection;
  assert.ok(d.worker===workers[role]&&d.versionId===q.expectedVersions[role]&&f.worker===d.worker&&f.versionId===d.versionId&&f.deploymentId===d.deploymentId,'EXACT_STABLE_CURRENT_PAIR');
  assert.ok(v.worker===d.worker&&v.versionId===d.versionId&&v.exportTypeGatePassed===true&&v.sensitiveTypesPass===true&&v.syntheticSaltMatchesFixture===true&&equivalent(v.bindings,expectedBindings(c)),'EXACT_NATIVE_BINDING_TYPES_VALUES');
  assert.ok(utc(v.startedAt)>=utc(d.endedAt)&&utc(x.startedAt)>=utc(v.endedAt)&&utc(f.startedAt)>=utc(x.endedAt)&&x.precedingVersionId===v.versionId,'TYPE_GATE_BEFORE_EXPORT');
  assert.ok(x.entrySha256===artifactHashes[role]&&q.artifacts[role].sha256===artifactHashes[role]&&x.moduleFiles.length===1&&x.moduleFiles[0].sha256===artifactHashes[role]&&digest(x.configSha256),'EXACT_UNCHANGED_NATIVE_ARTIFACT');
  assert.ok(p.name===c.name&&p.workers_dev===c.workers_dev&&p.preview_urls===false&&same(p.routes,c.routes??[])&&x.actualSchedulesRead===true&&same(p.triggers.crons,[])&&same(c.triggers?.crons??[],[]),'NATIVE_PRIVACY_SCHEDULES');
  assertStopped(p,role);assertStopped(c,role);assert.equal(p.workers_dev,role==='site','SIGNED_SITE_AND_PRIVATE_EXECUTOR');
  assert.deepEqual(p.vars,Object.fromEntries(Object.entries(c.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT')),'EXACT_ORDINARY_VARIABLES');
  assert.ok(equivalent(p.d1_databases,c.d1_databases.map(({binding,database_id})=>({binding,database_id})))&&equivalent(p.r2_buckets,c.r2_buckets??[])&&equivalent(p.services.map(b=>({...b,environment:b.environment??'production'})),c.services.map(b=>({...b,environment:b.environment??'production'})))&&equivalent(p.workflows,c.workflows??[]),'EXACT_CONFIG_BINDINGS');
  assert.ok(p.compatibility_date===c.compatibility_date&&equivalent(p.compatibility_flags,c.compatibility_flags??[]),'EXACT_COMPATIBILITY');
  nativeSettings[role]={limits:p.limits,observability:p.observability};assert.deepEqual(nativeSettings[role],baseline.nativeSettings[role],'NATIVE_SETTINGS_PRESERVED');
  if(!needed.includes(role))assertEmpty(get(role+'-new-database-empty'),role);
  else {const reads=n.observations.filter(o=>o.role===role&&typeof o.kind==='string');schemas[role]=schemaChecks(reads,role,expected.roles[role]);assert.equal(schemas[role].allChecksPassed,true,'EXACT_INITIAL_SCHEMA_DATA_REQUIRED');assert.ok(applied[role]?.verifiedApplied===true&&utc(applied[role].endedAt)<=utc(n.startedAt)&&reads.every(o=>utc(o.startedAt)>=utc(applied[role].endedAt)),'POST_APPLY_NATIVE_READS_REQUIRED');}
 }
 const inventory=assertFiveWorkflows(n.observations,baseline,{phase:'paired',previousMapping:baseline,versions:q.expectedVersions,executorStartedAt});
 assert.ok(get('r2-dev-url').bucket===bucket&&get('r2-dev-url').devUrlEnabled===false&&get('r2-custom-domains').bucket===bucket&&get('r2-custom-domains').customDomainCount===0,'PRIVATE_NEW_R2');
 for(const key of ['ARC_AI_RESEARCH_SITE_TO_EXECUTOR_KEY_ID','ARC_AI_RESEARCH_EXECUTOR_TO_SITE_KEY_ID'])assert.equal(configs.site.vars[key],configs.executor.vars[key]);
 if(q.stage==='final')assert.equal(Object.values(schemas).reduce((sum,s)=>sum+s.migrationLedgerRows,0),18,'ALL_18_LEDGER_ROWS');
 return {versions:q.expectedVersions,configs:q.configs,...inventory,nativeSettings,schemas,allChecksPassed:true,emptyRoles:roles.filter(r=>!needed.includes(r)),initializedRoles:needed,initializedSchemasVerified:q.stage==='final',activationAuthorized:false,task15Accepted:false};
}
