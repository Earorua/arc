// Explicitly offline test process. No native child can escape a refusal regression.
const child = require('node:child_process');
let calls = 0;
for (const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']) {
  child[name] = () => { calls++; throw Error('OFFLINE_CHILD_DISPATCH_FORBIDDEN'); };
}
require('node:module').syncBuiltinESMExports();
process.on('exit', () => process.stderr.write(JSON.stringify({offlineChildDispatches:calls})+'\n'));
