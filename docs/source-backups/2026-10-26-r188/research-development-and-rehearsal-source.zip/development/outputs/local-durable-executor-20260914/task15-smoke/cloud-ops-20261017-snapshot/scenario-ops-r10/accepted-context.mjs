// Consume accepted records as historical evidence, without importing consumed cloud entrypoints.
import {resolve,dirname} from 'node:path';
import {readdirSync} from 'node:fs';
import {FIXED,root,here,assert,same,hash,utc} from './guards.mjs';
import {inspectAcceptedBytes,validateAssemblyReport} from '../driver-artifact-ops-r2/accepted-bytes.mjs';
import {loadReviewGate} from '../driver-artifact-ops-r2/review-gate.mjs';
import {evaluateMapping as evaluateAcceptedSchema} from './accepted-schema.mjs';
import {SOURCES} from './read-plans.mjs';
import {operationProfile,assertTimingFit} from './profile.mjs';
import {loadCurrentClosed} from './closed-baseline.mjs';
export function staticInventory(report,configs,observedAt,versions){
 for(const role of ['site','executor'])assert(configs[role]?.d1_databases?.length===1&&configs[role].d1_databases[0].database_id===FIXED.databases[role]&&configs[role].d1_databases[0].binding===(role==='site'?'SMOKE_SITE_DB':'EXECUTOR_DB'),'CURRENT_CONFIG_DATABASE_ROLE_ID');
 return {schemaVersion:'arc-smoke-isolation-v1',verified:true,isolated:true,verifiedAt:utc(observedAt),accountId:FIXED.accountId,controlOrigin:configs.site.vars.BETTER_AUTH_URL,controlKeyId:configs.site.vars.SMOKE_CONTROL_KEY_ID,artifactReportSha256:FIXED.report.sha256,resources:{
  siteWorker:{id:FIXED.workers.site,name:FIXED.workers.site,revision:versions.site,artifactSha256:FIXED.artifacts.site,entry:report.site.output,peerId:FIXED.workers.executor},
  executorWorker:{id:FIXED.workers.executor,name:FIXED.workers.executor,revision:versions.executor,artifactSha256:FIXED.artifacts.executor,entry:report.executor.output,peerId:FIXED.workers.site,public:false},
  siteD1:{name:configs.site.d1_databases[0].database_name,id:FIXED.databases.site},executorD1:{name:configs.executor.d1_databases[0].database_name,id:FIXED.databases.executor},receipts:{id:FIXED.bucket,name:FIXED.bucket,private:true},workflow:{id:FIXED.workflowId,name:FIXED.workflowName,workerId:FIXED.workers.executor},
 }};
}
export async function loadAcceptedSnapshot({load,read,seed}){
 const acceptance=read(FIXED.schemaAcceptance),task1=read(FIXED.task1),report=read(FIXED.report);
 assert(acceptance.schemaVersion==='arc-snapshot-schema-initialization-acceptance-v1'&&acceptance.status==='CLOSED_PAIR_EXACT_INITIAL_SCHEMAS_ACCEPTED'&&acceptance.rootReviewed&&acceptance.specPassed&&acceptance.qualityPassed&&acceptance.accountId===FIXED.accountId&&acceptance.initializedSchemasVerified===true&&acceptance.freshnessReusableForMutation===false,'ACTUAL_ACCEPTED_SCHEMA');
 assert(task1.status==='ACCEPTED_LOCAL_BYTE_ASSEMBLY'&&task1.rootReviewed&&task1.localAssemblyVerified===true&&task1.recompiled===false&&task1.freshnessRenewed===false&&resolve(root,task1.schemaAcceptance.path)===FIXED.schemaAcceptance.path&&task1.schemaAcceptance.sha256===FIXED.schemaAcceptance.sha256,'ACTUAL_TASK1_ACCEPTANCE');
 assert(resolve(root,task1.report.path)===FIXED.report.path&&task1.report.sha256===FIXED.report.sha256&&task1.files.length===5,'EXACT_ACCEPTED_DRIVER_REPORT');
 // The accepted Task1 validator verifies the repaired overlays, current source bytes,
 // original metafiles and native artifact equality. It performs no compilation.
 const inspected=await inspectAcceptedBytes(),reviews=await loadReviewGate(inspected);validateAssemblyReport(report,inspected.snapshot,reviews);
 for(const r of inspected.readDependencies)seed({path:resolve(root,r.path),sha256:r.sha256},inspected.snapshot.files[r.path]);
 for(const r of report.provenance.historicalVerifiedReferences)seed(r,inspected.snapshot.historicalFiles[r.path]);
 for(const r of Object.values(reviews))load(r);
 for(const r of task1.files)load(r);
 assert(same(readdirSync(dirname(FIXED.report.path)).sort(),['executor.js','executor.metafile.json','report.json','site.js','site.metafile.json']),'EXACT_FIVE_ASSEMBLED_FILES');
 // These accepted records and frozen evidence pins are data dependencies. Nested
 // archival references inside old records are not recursively turned into runtime imports.
 for(const r of acceptance.evidencePins)load(r);
 for(const r of [acceptance.plan,acceptance.expected,acceptance.migrationManifest,acceptance.toolingAcceptance,acceptance.preparation,...Object.values(acceptance.reviews),task1.plan,task1.toolingAcceptance,task1.specReview,task1.qualityReview,task1.executionEvidence])load(r);
 const schema=read(acceptance.finalProof),native=read(acceptance.finalNative),q=read(schema.request),attempt=read(schema.attempt),paired=read(acceptance.pairedAcceptance),expected=read(acceptance.expected);
 assert(same(schema.nativeReference,acceptance.finalNative)&&same(native.request,schema.request)&&same(native.attempt,schema.attempt)&&same(attempt.request,schema.request)&&attempt.commandsSha256===q.commandsSha256&&attempt.deadlineAt===q.deadlineAt&&schema.stage==='final'&&q.stage==='final'&&same(schema.mapping,acceptance.mapping)&&schema.allChecksPassed&&schema.endedAt===acceptance.observedAt,'EXACT_SCHEMA_NATIVE_CHAIN');
 const configs=Object.fromEntries(Object.entries(acceptance.entries).map(([role,e])=>[role,read(e.config)]));
 for(const role of ['site','executor']){const e=acceptance.entries[role];load(e.artifact);assert(configs[role].main===e.artifact.path&&e.artifact.sha256===report[role].sha256&&report[role].sha256===FIXED.artifacts[role]&&configs[role].d1_databases[0].database_id===FIXED.schemaDatabases[role],'ORIGINAL_CONFIG_MAIN_ACCEPTED_COPIED_BYTES_EQUAL');load({path:resolve(root,report[role].output),sha256:e.artifact.sha256});}
 const applied=Object.fromEntries(Object.entries(acceptance.applies).map(([role,r])=>[role,read(r)])),executor=read(paired.deployments.executor);
 const computed=evaluateAcceptedSchema(native,q,{configs,baseline:paired.mapping,expected,applied,executorStartedAt:executor.commandStartedAt},utc(native.endedAt));
 assert(same(computed,schema.mapping)&&computed.initializedSchemasVerified&&same(computed.versions,FIXED.versions)&&computed.newWorkflowId===FIXED.workflowId,'RECOMPUTED_ACTUAL_INITIAL_SCHEMA_MAPPING');
 for(const r of [FIXED.continuationPlan,...Object.values(SOURCES),FIXED.codec,FIXED.receiptProjector,FIXED.codecSources,FIXED.driver,FIXED.maskedLauncher,FIXED.wrapper,FIXED.cli,FIXED.preload,FIXED.metadataRule,FIXED.statusHandler,FIXED.integrationClarifications,FIXED.closureAddendum,...Object.values(FIXED.diagnostics),...Object.values(FIXED.deployMitigation)])load(r);
 const codecs=read(FIXED.codecSources);for(const group of ['productionBundleInputs','tombstoneFormatSource','runtimeDependencyInputs'])for(const [path,sha256]of Object.entries(codecs[group]))load({path:resolve(root,path),sha256});
 const currentClosed=loadCurrentClosed({load,read,schemaMapping:computed,schemaObservedAt:acceptance.observedAt});
 const inventory=staticInventory(report,currentClosed.configValues,currentClosed.observedAt,currentClosed.currentVersions),inventoryReference={path:resolve(here,'isolation-inventory.json'),sha256:hash(JSON.stringify(inventory,null,2)+'\n')};
 return {acceptance,schema,native,report,inventory,inventoryReference,inventorySha256:inventoryReference.sha256,configs:currentClosed.configValues,schemaConfigs:configs,configRefs:currentClosed.configs,artifacts:Object.fromEntries(Object.entries(acceptance.entries).map(([r,e])=>[r,e.artifact])),baseline:computed,currentClosed,historicalDirectories:acceptance.evidenceDirectories,profile:operationProfile(),assertTimingFit};
}
