// Independent QUALITY checks. Synthetic process events remain in memory only.
// No accepted-context load, operational entrypoint, preparation, or real child is used.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,lstatSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {EventEmitter} from 'node:events';
import {createReadTransport} from './read-transport.mjs';
import {deployOnce} from './write-transport.mjs';
import {commandsFor} from './read-plans.mjs';
import {runtimeReferences,reviewInputs,ANCHORS,moduleNames} from './context.mjs';
import {request,finalConfigs,uuid} from './offline-fixtures.mjs';
const N=import.meta.dirname;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=name=>JSON.parse(readFileSync(join(N,name),'utf8'));
const spec=json('spec-review-r2.json');
const pins=value=>value&&typeof value==='object'?(typeof value.path==='string'&&/^[a-f0-9]{64}$/u.test(value.sha256)?[value]:Object.values(value).flatMap(pins)):[];
function rehash(reference){
 const stat=lstatSync(reference.path);
 assert.ok(stat.isFile()&&!stat.isSymbolicLink(),reference.path);
 assert.equal(sha(readFileSync(reference.path)),reference.sha256,reference.path);
}
test('all frozen runtime, input and test references independently match actual ordinary files',()=>{
 assert.equal(sha(readFileSync(join(N,'spec-review-r2.json'))),'a9904f3c72a518ce929dfc726deedec0f733cd4abfec4f9f80760328b0d8b224');
 assert.equal(sha(readFileSync(join(N,'spec-review-r2.md'))),'2676b4b2206a96e070e03d4e7769fe76818197b783272e19ab71a7f6aada35b3');
 assert.deepEqual([spec.runtimePins.length,spec.inputPins.length,spec.testPins.length],[200,2493,41]);
 for(const key of ['runtimePins','inputPins','testPins'])for(const reference of spec[key])rehash(reference);
 for(const reference of pins({...spec,runtimePins:[],inputPins:[],testPins:[]}))rehash(reference);
 assert.deepEqual(spec.plan,ANCHORS.plan);assert.deepEqual(spec.materialization,ANCHORS.materialization);
 assert.equal(json('spec-review-r1.json').status,'FAIL');
 console.log(JSON.stringify({qualityIndependentRehash:{runtimePins:200,inputPins:2493,testPins:41,specEvidence:true,acceptedGraphLoads:0}}));
});
test('current lightweight runtime and test inventories equal the independently rehashed SPEC arrays',()=>{
 assert.deepEqual(runtimeReferences(),spec.runtimePins);
 assert.deepEqual(reviewInputs(spec),{runtimePins:spec.runtimePins,inputPins:spec.inputPins,testPins:spec.testPins});
});
test('r2 derivation preserves ten operational modules and exact imported read transport',()=>{
 const prior=json('derivation-r1.json'),current=json('derivation-r2.json');
 for(const reference of pins(current))rehash(reference);
 assert.deepEqual(current.runtimePins,spec.runtimePins);
 const old=new Map(prior.candidateModules.map(r=>[r.path,r.sha256]));
 const changed=current.candidateModules.filter(r=>old.get(r.path)!==r.sha256);
 assert.deepEqual(changed.map(r=>r.path),[join(N,'context.mjs')]);
 assert.equal(changed[0].sha256,'6e10df9685a2b7c6499ad12f828effd52d34128e3fd054ce0e08c1891b347a06');
 assert.deepEqual(current.candidateModules.map(r=>r.path).sort(),moduleNames.map(name=>join(N,name)).sort());
 const source=readFileSync(current.transportDerivation.source.path,'utf8');
 assert.equal(readFileSync(join(N,'read-transport.mjs'),'utf8'),source.replace("from './guards.mjs'","from '../../cloud-ops-20261013-guarded/scenario-ops-r9/guards.mjs'"));
});
function scheduler(outcomes){
 let tick=0,sequence=0,spawnCount=0;const jobs=new Map(),children=[],calls=[];
 const schedule=(fn,delay)=>{const id=++sequence;jobs.set(id,{at:tick+delay,fn});return id;};
 const io={now:()=>tick,wallNow:()=>new Date(1792224000000+tick).toISOString(),setTimeout:schedule,clearTimeout:id=>jobs.delete(id),spawn(executable,args,options){
  const index=spawnCount++,outcome=outcomes[index]??outcomes.at(-1);calls.push({executable,args,options});
  if(outcome.throw)throw Error('OFFLINE_SPAWN_FAILURE');
  const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();children.push(child);
  child.kill=()=>{if(outcome.killCloses)schedule(()=>child.emit('close',null,'SIGTERM'),0);};
  if(outcome.emit)schedule(()=>outcome.emit(child),outcome.delay??0);
  else if(outcome.delay!==null)schedule(()=>{if(outcome.stdout)child.stdout.emit('data',Buffer.from(outcome.stdout));if(outcome.stderr)child.stderr.emit('data',Buffer.from(outcome.stderr));if(outcome.close!==false)child.emit('close',outcome.code??0,null);},outcome.delay??0);
  return child;
 }};
 async function settle(promise){
  let done=false,value,error;promise.then(v=>{done=true;value=v;},e=>{done=true;error=e;});
  for(let turns=0;turns<200&&!done;turns++){
   await Promise.resolve();if(done)break;
   const next=[...jobs.entries()].sort((a,b)=>a[1].at-b[1].at||a[0]-b[0])[0];
   if(next){jobs.delete(next[0]);tick=next[1].at;next[1].fn();}
  }
  assert.equal(done,true,'OFFLINE_EVENT_SEQUENCE_SETTLED');if(error)throw error;return value;
 }
 return {io,calls,children,settle,advance:ms=>{tick+=ms;}};
}
function reader(s,{beforeSpawn=()=>{},remainingMs=120000}={}){
 return createReadTransport({request:request(),cli:'OFFLINE_REVIEW_ONLY',cwd:'OFFLINE',env:{},remainingMs,beforeSpawn,runtime:s.io,createExportDirectory:()=>{throw Error('EXPORT_NOT_USED');}});
}
const command=()=>commandsFor(request())[0].args;
function writer(s,extra={}){
 return deployOnce({role:'executor',config:finalConfigs.executor,shortConfig:{path:join(N,'OFFLINE_ONLY_CONFIG_NEVER_WRITTEN')},expectedVersion:uuid(900),cwd:'OFFLINE',env:{},beforeSpawn:()=>{},runtime:s.io,...extra});
}
test('read dispatch guard is rerun after backoff and can prevent a second child',async()=>{
 const s=scheduler([{code:1,stderr:'ECONNRESET'}]);let checks=0;
 const t=reader(s,{beforeSpawn:()=>{if(++checks===2)throw Error('CHANGED_PIN');}});
 const value=await s.settle(t.read(command(),()=>({safe:true})));
 assert.equal(value.failureKind,'dispatch-pins');assert.equal(value.attempts.length,1);assert.equal(checks,2);assert.equal(s.calls.length,1);
});
test('time spent rehashing before dispatch consumes the fixed read deadline',async()=>{
 const s=scheduler([{}]),t=reader(s,{remainingMs:1500,beforeSpawn:()=>s.advance(501)});
 const value=await t.read(command(),()=>({safe:true}));
 assert.equal(value.failureKind,'collector-budget');assert.equal(s.calls.length,0);assert.equal(t.status().budgetExhausted,true);
});
test('projection work cannot extend the read deadline or make late evidence successful',async()=>{
 const s=scheduler([{stdout:'{}'}]),t=reader(s,{remainingMs:2000});
 const value=await s.settle(t.read(command(),()=>{s.advance(2001);return {safe:true};}));
 assert.equal(value.failureKind,'collector-budget');assert.equal(s.calls.length,1);assert.equal(t.status().budgetExhausted,true);
});
test('a confirmed timed-out read may retry only after its one-second backoff',async()=>{
 const s=scheduler([{delay:null,killCloses:true},{stdout:'{}'}]),t=reader(s);
 const value=await s.settle(t.read(command(),()=>({safe:true})));
 assert.equal(value.ok,true);assert.equal(value.attempts.length,2);assert.equal(s.calls.length,2);
 assert.equal(value.attempts[0].failureKind,'transport-timeout');assert.equal(value.attempts[0].childCloseConfirmed,true);
 assert.equal(Date.parse(value.attempts[1].startedAt)-Date.parse(value.attempts[0].endedAt),1000);
});
test('unconfirmed read shutdown halts later commands as well as retries',async()=>{
 const s=scheduler([{delay:null,killCloses:false}]),t=reader(s);
 const first=await s.settle(t.read(command(),()=>({safe:true}))),second=await t.read(command(),()=>({safe:true}));
 assert.equal(first.failureKind,'shutdown-unconfirmed');assert.equal(second.failureKind,'shutdown-unconfirmed');assert.equal(second.attempts.length,0);assert.equal(s.calls.length,1);
});
test('the read output cap is combined across stdout and stderr and prevents projection',async()=>{
 let projections=0;const s=scheduler([{stdout:'a'.repeat(70000),stderr:'b'.repeat(70000),close:false,killCloses:true}]),t=reader(s);
 const value=await s.settle(t.read(command(),()=>{projections++;return {safe:true};}));
 assert.equal(value.failureKind,'output-overflow');assert.equal(projections,0);assert.equal(s.calls.length,1);
});
test('synchronous write spawn uncertainty is retained without retry',async()=>{
 const s=scheduler([{throw:true}]),value=await s.settle(writer(s));
 assert.equal(value.mutationAttempted,true);assert.equal(value.commandSucceeded,false);assert.equal(value.childCloseConfirmed,false);
 assert.equal(value.commandFailureKind,'shutdown-unconfirmed');assert.equal(value.disposition,'STOP_RECONCILE_NO_RETRY');assert.equal(s.calls.length,1);
});
test('late write output and close cannot change a retained unknown outcome',async()=>{
 const s=scheduler([{delay:null,killCloses:false}]),value=await s.settle(writer(s)),before=JSON.stringify(value);
 s.children[0].stdout.emit('data',Buffer.from('Current Version ID: '+uuid(999)+'\n'));s.children[0].emit('close',0,null);
 assert.equal(JSON.stringify(value),before);assert.equal(value.commandSucceeded,false);assert.equal(value.elapsedMs,91000);assert.equal(s.calls.length,1);
});
test('write stream errors and combined overflow retain one attempt and no raw content',async()=>{
 for(const outcome of [{emit:c=>c.stdout.emit('error',Error('SYNTHETIC_PRIVATE_PAYLOAD')),killCloses:true},{stdout:'x'.repeat(300000),stderr:'y'.repeat(300000),close:false,killCloses:true}]){
  const s=scheduler([outcome]),value=await s.settle(writer(s));
  assert.equal(value.commandSucceeded,false);assert.equal(value.versionId,null);assert.equal(s.calls.length,1);assert.equal(value.rawContentPersisted,false);
  assert.equal(JSON.stringify(value).includes('SYNTHETIC_PRIVATE_PAYLOAD'),false);assert.equal(Object.hasOwn(value,'stdout'),false);assert.equal(Object.hasOwn(value,'stderr'),false);
 }
});
test('plain failure output is represented by bounded metadata only',async()=>{
 const sentinel='SYNTHETIC_PRIVATE_PAYLOAD',s=scheduler([{code:1,stdout:sentinel,stderr:sentinel}]),value=await s.settle(writer(s));
 assert.equal(value.commandFailureKind,'command-failed');assert.equal(value.stdoutSha256,sha(sentinel));assert.equal(value.stderrSha256,sha(sentinel));
 assert.equal(JSON.stringify(value).includes(sentinel),false);assert.equal(value.rawContentPersisted,false);assert.equal(s.calls.length,1);
});
test('preparation and operation artifacts remain absent after all quality checks',()=>{
 for(const name of ['prepared','observations','deployments','root-tooling-acceptance-r1.json'])assert.equal(existsSync(join(N,name)),false,name);
});
