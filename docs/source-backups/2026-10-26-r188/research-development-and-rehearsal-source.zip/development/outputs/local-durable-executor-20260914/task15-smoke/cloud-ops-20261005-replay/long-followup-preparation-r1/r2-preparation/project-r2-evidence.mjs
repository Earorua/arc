import {
  BRIDGE_BODY_LIMITS,
  bridgeByteLength,
  canonicalJson,
  decodeBridgeJson,
  decodeBridgeProviderReceipt,
  encodeBridgeProviderReceipt,
  parseBridgeReceiptMetadata,
  summarizeBridgeProviderReceipt,
} from "./production-codec.mjs";

const HASH = /^[0-9a-f]{64}$/u;

export class R2ProjectionError extends Error {
  constructor(code) {
    super(`R2 evidence projection failure: ${code}`);
    this.name = "R2ProjectionError";
    this.code = code;
  }
}

function fail(code) {
  throw new R2ProjectionError(code);
}

function sameBytes(left, right) {
  if (left.byteLength !== right.byteLength) return false;
  for (let index = 0; index < left.byteLength; index += 1) {
    if (left[index] !== right[index]) return false;
  }
  return true;
}

function safeTime(value) {
  return Number.isSafeInteger(value) && value >= 0;
}

function parseExpected(input) {
  if (input === null || typeof input !== "object" || Array.isArray(input)) fail("invalid-input");
  const { jobId, requestHash, d1 } = input;
  if (typeof jobId !== "string" || typeof requestHash !== "string" || !HASH.test(requestHash)
    || d1 === null || typeof d1 !== "object" || Array.isArray(d1)) fail("invalid-input");
  let metadata;
  try {
    metadata = parseBridgeReceiptMetadata(d1.metadata);
  } catch {
    fail("invalid-input");
  }
  const { cleanupRequestedAt, bodyRemovedAt } = d1;
  if ((cleanupRequestedAt !== null && !safeTime(cleanupRequestedAt))
    || (bodyRemovedAt !== null && !safeTime(bodyRemovedAt))) fail("invalid-input");
  return Object.freeze({ jobId, requestHash, metadata, cleanupRequestedAt, bodyRemovedAt });
}

async function sha256(bytes) {
  try {
    const digest = new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bytes));
    return Array.from(digest, (value) => value.toString(16).padStart(2, "0")).join("");
  } catch {
    fail("unavailable");
  }
}

function safeOutcome(outcome) {
  return Object.freeze({
    outcomeKind: outcome.kind,
    actualModel: outcome.actualModel,
    errorCode: outcome.kind === "error" ? outcome.code : null,
    retryable: outcome.kind === "error" ? outcome.retryable : null,
    charged: outcome.kind === "error" ? outcome.charged : null,
  });
}

function safeUsage(usage) {
  return usage === null ? null : Object.freeze({ ...usage });
}

function freezeProjection(value) {
  return Object.freeze({
    ...value,
    metadata: Object.freeze(value.metadata),
    timing: Object.freeze(value.timing),
    usage: value.usage === null ? null : Object.freeze(value.usage),
    hashes: Object.freeze(value.hashes),
    matches: Object.freeze(value.matches),
  });
}

function requireMatches(matches) {
  if (Object.values(matches).some((value) => value !== true)) fail("mismatch");
  return matches;
}

function exactTombstone(input, rawBytes) {
  if (rawBytes.byteLength > BRIDGE_BODY_LIMITS.status
    || input === null || typeof input !== "object" || Array.isArray(input)) fail("invalid-object");
  const names = Object.keys(input).sort();
  if (names.length !== 3 || names[0] !== "format" || names[1] !== "metadata"
    || names[2] !== "removedAt" || input.format !== "arc-research-receipt-tombstone-v1"
    || !safeTime(input.removedAt)) fail("invalid-object");
  let metadata;
  try {
    metadata = parseBridgeReceiptMetadata(input.metadata);
  } catch {
    fail("invalid-object");
  }
  const canonicalBytes = new TextEncoder().encode(canonicalJson({
    format: "arc-research-receipt-tombstone-v1",
    metadata,
    removedAt: input.removedAt,
  }));
  return Object.freeze({ metadata, removedAt: input.removedAt, canonicalBytes });
}

export async function projectR2Evidence(rawBytes, expectedInput) {
  let bytesLength;
  try {
    bytesLength = bridgeByteLength(rawBytes);
  } catch {
    fail("invalid-input");
  }
  if (bytesLength < 1 || bytesLength > BRIDGE_BODY_LIMITS.result) fail("body-limit");
  const expected = parseExpected(expectedInput);

  let decoded;
  try {
    decoded = decodeBridgeJson(rawBytes);
  } catch {
    fail("invalid-object");
  }
  if (decoded !== null && typeof decoded === "object" && !Array.isArray(decoded)
    && decoded.format === "arc-research-receipt-tombstone-v1") {
    const tombstone = exactTombstone(decoded, rawBytes);
    if (!sameBytes(rawBytes, tombstone.canonicalBytes)) fail("noncanonical");
    const objectDigest = await sha256(rawBytes);
    const metadataMatches = canonicalJson(tombstone.metadata) === canonicalJson(expected.metadata);
    const matches = {
      jobId: tombstone.metadata.grant.jobId === expected.jobId,
      requestHash: tombstone.metadata.grant.requestHash === expected.requestHash,
      beganAt: tombstone.metadata.grant.beganAt === expected.metadata.grant.beganAt,
      executionExpiresAt: tombstone.metadata.grant.executionExpiresAt
        === expected.metadata.grant.executionExpiresAt,
      receiptHash: tombstone.metadata.receiptHash === expected.metadata.receiptHash,
      metadata: metadataMatches,
      cleanupTiming: tombstone.removedAt === expected.cleanupRequestedAt
        && tombstone.removedAt === expected.bodyRemovedAt,
    };
    requireMatches(matches);
    return freezeProjection({
      format: "arc-research-receipt-tombstone-v1",
      bytesLength,
      objectDigest,
      canonical: true,
      metadata: safeOutcome(tombstone.metadata.outcome),
      timing: {
        beganAt: tombstone.metadata.grant.beganAt,
        executionExpiresAt: tombstone.metadata.grant.executionExpiresAt,
        producedAt: tombstone.metadata.producedAt,
        latencyMs: tombstone.metadata.latencyMs,
        removedAt: tombstone.removedAt,
      },
      usage: safeUsage(tombstone.metadata.outcome.usage),
      hashes: {
        receiptHash: tombstone.metadata.receiptHash,
        receiptHashRecomputed: false,
        objectDigestMatchesReceiptHash: objectDigest === tombstone.metadata.receiptHash,
      },
      matches,
    });
  }

  let receipt;
  let canonicalBytes;
  let metadata;
  try {
    receipt = decodeBridgeProviderReceipt(rawBytes);
    canonicalBytes = encodeBridgeProviderReceipt(receipt);
    metadata = await summarizeBridgeProviderReceipt(receipt);
  } catch {
    fail("invalid-object");
  }
  if (!sameBytes(rawBytes, canonicalBytes)) fail("noncanonical");
  const objectDigest = await sha256(rawBytes);
  if (objectDigest !== metadata.receiptHash) fail("mismatch");
  const metadataMatches = canonicalJson(metadata) === canonicalJson(expected.metadata);
  const matches = {
    jobId: metadata.grant.jobId === expected.jobId,
    requestHash: metadata.grant.requestHash === expected.requestHash,
    beganAt: metadata.grant.beganAt === expected.metadata.grant.beganAt,
    executionExpiresAt: metadata.grant.executionExpiresAt
      === expected.metadata.grant.executionExpiresAt,
    receiptHash: metadata.receiptHash === expected.metadata.receiptHash,
    metadata: metadataMatches,
    cleanupTiming: expected.bodyRemovedAt === null,
  };
  requireMatches(matches);
  return freezeProjection({
    format: "receipt",
    bytesLength,
    objectDigest,
    canonical: true,
    metadata: safeOutcome(metadata.outcome),
    timing: {
      beganAt: metadata.grant.beganAt,
      executionExpiresAt: metadata.grant.executionExpiresAt,
      producedAt: metadata.producedAt,
      latencyMs: metadata.latencyMs,
      removedAt: null,
    },
    usage: safeUsage(metadata.outcome.usage),
    hashes: {
      receiptHash: metadata.receiptHash,
      receiptHashRecomputed: true,
      objectDigestMatchesReceiptHash: objectDigest === metadata.receiptHash,
    },
    matches,
  });
}
