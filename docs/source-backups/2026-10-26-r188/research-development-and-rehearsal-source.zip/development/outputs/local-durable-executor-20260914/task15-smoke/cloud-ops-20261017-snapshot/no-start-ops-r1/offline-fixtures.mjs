// SYNTHETIC OFFLINE FIXTURES ONLY. Never written as operation evidence.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
export const N=import.meta.dirname,O=resolve(N,'..'),W=resolve(O,'../../../..');
export const hash=x=>createHash('sha256').update(x).digest('hex');
export const json=p=>JSON.parse(readFileSync(p,'utf8'));
export const acceptance=json(join(O,'root-no-start-materialization-acceptance-r1.json'));
export const baseline=json(join(W,'outputs/local-durable-executor-20261016/completed-ack-snapshot-cloud-run-r3/drain-second.json')).mapping;
export const nativeSettings={site:{limits:null,observability:null},executor:{limits:null,observability:null}};
export const finalConfigs=Object.fromEntries(Object.entries(acceptance.entries).map(([r,e])=>[r,json(e.config.path)]));
export const originals=Object.fromEntries(Object.entries(acceptance.entries).map(([r,e])=>[r,json(e.sourceConfig.path)]));
export const uuid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
export const clone=structuredClone;
export async function moduleFor(name){try{return await import('./'+name+'.mjs');}catch(error){if(error.code==='ERR_MODULE_NOT_FOUND'&&error.url?.endsWith('/no-start-ops-r1/'+name+'.mjs'))return {};throw error;}}
export function required(module,name){assert.equal(typeof module[name],'function','MISSING_IMPLEMENTATION_'+name);return module[name];}
export function workflowText(name,id,latest,created='2026-10-17T08:00:00.000Z',modified=created){return 'Name: '+name+'\nId: '+id+'\nScript Name: arc-v8-smoke-executor-20260921\nClass Name: ResearchWorkflow\nCreated On: '+created+'\nModified On: '+modified+'\nLatest Version:\n  Id: '+latest+'\n  Created On: '+created+'\n  Modified On: '+modified+'\n';}
export const fakeRef=name=>({path:join(N,name),sha256:hash('OFFLINE:'+name)});
export function request(stage='mixed'){
 const phase=stage==='pre-first'?'drain-first':stage==='pre-second'?'drain-second':stage;
 const cfg=stage.startsWith('pre-')?Object.fromEntries(Object.entries(acceptance.entries).map(([r,e])=>[r,e.sourceConfig])):{site:stage==='mixed'?acceptance.entries.site.sourceConfig:acceptance.entries.site.config,executor:acceptance.entries.executor.config};
 return {stage,phase,scenarioId:null,directory:join(N,'observations',stage),preparedAt:1792224000000,deadlineAt:1792224120000,expectedVersions:{site:stage==='paired'?uuid(901):baseline.versions.site,executor:stage.startsWith('pre-')?baseline.versions.executor:uuid(900)},configs:cfg,readonlyConfigs:Object.fromEntries(['site','executor'].map(r=>[r,fakeRef('observations/'+stage+'/wrangler.'+r+'.readonly.json')])),emptyConfigs:Object.fromEntries(['site','executor'].map(r=>[r,fakeRef('prepared/wrangler.'+r+'.empty.json')])),artifacts:Object.fromEntries(Object.entries(acceptance.entries).map(([r,e])=>[r,e.artifact]))};
}
export function mappingFixture(commands,projectBindings,projectDefinition){
 const q=request(),cfg={site:originals.site,executor:finalConfigs.executor},start=q.preparedAt+1;
 const defs=Object.fromEntries([...Object.keys(baseline.workflows),'arc-v8-smoke-workflow-20261017-snapshot'].map((name,i)=>{
  const prior=baseline.workflowLatestVersions[name];return [name,projectDefinition(workflowText(name,baseline.workflows[name]?.id??uuid(800),uuid(700+i),prior?.createdOn??new Date(start).toISOString(),new Date(start).toISOString()),name)];
 }));
 const observations=commands.map((c,i)=>{
  const startedAt=new Date(start+i*3).toISOString(),endedAt=new Date(start+i*3+1).toISOString();
  const o={id:c.id,startedAt,endedAt,commandSha256:hash(JSON.stringify(c.args)),ok:true,attempts:[{attempt:1,startedAt,endedAt,elapsedMs:1,exitCode:0,signal:null,timedOut:false,outputOverflow:false,childCloseConfirmed:true,childTimeoutMs:45000,stdoutSha256:hash('offline'),stderrSha256:hash(''),stdoutBytes:7,stderrBytes:0,failureKind:null,rawContentPersisted:false}]};
  const role=c.role,v=role?q.expectedVersions[role]:null,config=cfg[role];
  if(c.kind==='deployment')Object.assign(o,{worker:config.name,versionId:v,deploymentId:uuid(role==='site'?600:601),createdOn:startedAt});
  if(c.kind==='version')Object.assign(o,{worker:config.name,versionId:v,bindings:projectBindings(config),exportTypeGatePassed:true,sensitiveTypesPass:true,syntheticSaltMatchesFixture:true});
  if(c.kind==='export')Object.assign(o,{entrySha256:q.artifacts[role].sha256,moduleFiles:[{path:'src/index.js',bytes:1,sha256:q.artifacts[role].sha256}],configSha256:hash('config'),precedingVersionId:v,actualSchedulesRead:true,projection:{name:config.name,vars:Object.fromEntries(Object.entries(config.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT')),workers_dev:config.workers_dev,preview_urls:false,routes:[],triggers:{crons:[]},d1_databases:config.d1_databases.map(({binding,database_id})=>({binding,database_id})),r2_buckets:config.r2_buckets??[],services:config.services.map(x=>({...x,environment:'production'})),workflows:config.workflows??[],compatibility_date:config.compatibility_date,compatibility_flags:[],limits:null,observability:null}});
  if(c.kind==='definition')Object.assign(o,defs[c.name]);
  if(c.kind==='roster')Object.assign(o,{name:c.name,availableListComplete:true,rows:clone(baseline.rosters[c.name]??[])});
  if(c.kind==='empty')Object.assign(o,{databaseId:acceptance.resources[c.role==='site'?'siteD1':'executorD1'].id,sqlSha256:hash(c.args.at(-1)),rows:[],rowsWritten:0,changedDb:false});
  if(c.kind==='privacy-dev')Object.assign(o,{bucket:acceptance.resources.receipts.name,devUrlEnabled:false});
  if(c.kind==='privacy-domains')Object.assign(o,{bucket:acceptance.resources.receipts.name,customDomainCount:0});return o;
 });
 const n={schemaVersion:'arc-snapshot-no-start-native-v1',phase:q.phase,stage:q.stage,scenarioId:null,startedAt:new Date(start).toISOString(),endedAt:new Date(start+commands.length*3).toISOString(),observations,allReadsSucceeded:true,cloudMutations:0,workerControlCalls:0,providerCalls:0,transport:{maxAttempts:3,backoffMs:1000,childTimeoutMs:45000,closeGraceMs:1000,collectorBudgetMs:119999,absoluteMonotonicDeadline:120000,elapsedMs:100,budgetExhausted:false,halted:null}};
 return {q,n,context:{configs:cfg,baseline:{...baseline,nativeSettings},executorStartedAt:new Date(q.preparedAt-1000).toISOString()},now:q.preparedAt+1000};
}
