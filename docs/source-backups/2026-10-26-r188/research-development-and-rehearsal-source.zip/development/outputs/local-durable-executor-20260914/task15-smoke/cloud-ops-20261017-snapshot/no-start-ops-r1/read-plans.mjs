// Exact old drain reads, plus only the new fixed mapping and immediate pair plans.
import assert from 'node:assert/strict';
import {join} from 'node:path';
import {commandsFor as oldCommands} from '../../cloud-ops-20261013-guarded/scenario-ops-r9/read-plans.mjs';
import {same,workers,workflowNames,bucket,emptySql,observationPath,preparationPath,uuid} from './rules.mjs';
export function commandsFor(q){
 assert.ok(q&&q.scenarioId===null&&Object.keys(workers).every(role=>uuid(q.expectedVersions?.[role])),'FIXED_REQUEST_PAIR');
 if(q.stage==='immediate-executor'||q.stage==='immediate-site')return ['site','executor'].map(role=>({id:role+'-current-deployment',kind:'deployment',role,args:['deployments','list','--config',join(preparationPath,'wrangler.'+role+'.empty.json'),'--json']}));
 assert.equal(q.directory,observationPath(q.stage),'FIXED_OBSERVATION_DIRECTORY');
 const cfg=role=>['--config',join(q.directory,'wrangler.'+role+'.readonly.json')];
 if(q.stage.startsWith('pre-')){assert.equal(q.phase,q.stage==='pre-first'?'drain-first':'drain-second');const all=oldCommands(q);assert.equal(all.length,27);return all;}
 assert.equal(q.phase,q.stage);assert.ok(q.phase==='mixed'||q.phase==='paired');
 for(const role of ['site','executor'])assert.equal(q.emptyConfigs?.[role]?.path,join(preparationPath,'wrangler.'+role+'.empty.json'),'FIXED_NEW_D1_CONFIG');
 const all=['site','executor'].flatMap(role=>[
  {id:role+'-current-deployment',kind:'deployment',role,args:['deployments','list',...cfg(role),'--json']},
  {id:role+'-current-version',kind:'version',role,args:['versions','view',q.expectedVersions[role],...cfg(role),'--json']},
  {id:role+'-export',kind:'export',role,args:['init','--from-dash',workers[role],'--no-delegate-c3']},
 ]);
 for(const name of workflowNames)all.push({id:name+'-definition',kind:'definition',name,args:['workflows','describe',name,...cfg('executor')]},{id:name+'-instances',kind:'roster',name,args:['workflows','instances','list',name,'--page','1','--per-page','100',...cfg('executor')]});
 for(const role of ['site','executor'])all.push({id:role+'-new-database-empty',kind:'empty',role,args:['d1','execute',role==='site'?'SMOKE_SITE_DB':'EXECUTOR_DB','--remote','--config',q.emptyConfigs[role].path,'--json','--command',emptySql]});
 all.push({id:'r2-dev-url',kind:'privacy-dev',args:['r2','bucket','dev-url','get',bucket,...cfg('executor')]},{id:'r2-custom-domains',kind:'privacy-domains',args:['r2','bucket','domain','list',bucket,...cfg('executor')]});
 all.push(...['site','executor'].map(role=>({id:role+'-final-deployment',kind:'deployment',role,args:['deployments','list',...cfg(role),'--json']})));assert.equal(all.length,22);return all;
}
export function assertCommand(q,args){assert.ok(Array.isArray(args)&&commandsFor(q).some(c=>same(c.args,args)),'EXACT_REVIEWED_READ_COMMAND');}
