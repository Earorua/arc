// Future mutation entrypoint: Executor once, then Site once, each with a root-bound fresh gate.
import assert from 'node:assert/strict';
import {existsSync,mkdirSync,mkdtempSync,writeFileSync} from 'node:fs';
import {join,dirname,basename} from 'node:path';
import {base,loadToolingContext,fastReverify,read,ref,verify,write,exactDirectory,main} from './context.mjs';
import {N,OPERATION,workers,deploymentPath,digest,hash,deployCommand,utc} from './rules.mjs';
import {decisionPath,loadGate,assertRootDecision,immediateRequest,assertImmediatePredecessors} from './records.mjs';
import {commandsFor,assertCommand} from './read-plans.mjs';
import {createReadTransport} from './read-transport.mjs';
import {deployOnce} from './write-transport.mjs';
import {projectDeployment} from './project.mjs';
const iso=()=>new Date().toISOString();
export function assertUnused(attemptExists,resultExists){assert.ok(!attemptExists&&!resultExists,'EXCLUSIVE_ATTEMPT_NO_ADOPTION');}
export async function run(argv){
 assert.ok(Array.isArray(argv)&&argv.length===2&&Object.hasOwn(workers,argv[0])&&digest(argv[1]),'EXACT_ROLE_AND_DECISION_SHA_REQUIRED');
 const [role,sha256]=argv,directory=deploymentPath(role);assertUnused(existsSync(join(directory,'attempt.json')),existsSync(join(directory,'result.json')));assert.equal(existsSync(directory),false,'EXCLUSIVE_DEPLOYMENT_DIRECTORY');
 const decisionReference={path:decisionPath(role),sha256},decision=read(decisionReference),ctx=await loadToolingContext(),gate=loadGate(ctx,role,Date.now());assertRootDecision(ctx,role,decision,gate,Date.now());
 const entry=ctx.entries[role],options=base.g.neutralRead(),deployOptions=base.g.neutralDeploy();fastReverify(ctx,[decisionReference,...gate.pins],gate.directories);
 const short=mkdtempSync('C:/Users/XF/AppData/Local/Temp/arc15-snapshot-no-start-'+role+'-'),shortPath=join(short,'wrangler.jsonc');writeFileSync(shortPath,verify(entry.config),{flag:'wx'});const shortConfig=ref(shortPath);
 mkdirSync(dirname(directory),{recursive:true});mkdirSync(directory);const journal=[];
 const q=immediateRequest(ctx,role,gate,Date.now()),request=write(join(directory,'request.json'),q);journal.push(request);
 const attemptValue={schemaVersion:'arc-snapshot-no-start-deploy-attempt-v1',operationId:OPERATION,role,at:iso(),request,decision:decisionReference,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,operation:ref(join(N,'deploy.mjs')),transport:ref(join(N,'write-transport.mjs')),wrapper:base.g.FIXED.wrapper,cli:base.g.FIXED.cli,preload:base.g.FIXED.preload,config:entry.config,artifact:entry.artifact,predecessorGate:gate.reference,shortConfig,command:deployCommand(shortConfig.path),noRetry:true,maximumWrites:1,workerControlCalls:0,providerCalls:0};
 const attempt=write(join(directory,'attempt.json'),attemptValue);journal.push(attempt);
 const result={schemaVersion:'arc-snapshot-no-start-deploy-result-v1',operationId:OPERATION,role,startedAt:iso(),request,attempt,decision:decisionReference,acceptance:ctx.acceptanceReference,preparation:ctx.preparationReference,config:entry.config,artifact:entry.artifact,predecessorGate:gate.reference,predecessors:[],commandSucceeded:false,mutationAttempted:false,exitCode:null,versionId:null,childCloseConfirmed:false,commandFailureKind:null,rawContentPersisted:false,nativeMappingVerified:false,workerControlCalls:0,providerCalls:0,disposition:'STOP_RECONCILE_NO_RETRY'};
 const recheck=()=>{fastReverify(ctx,[decisionReference,...gate.pins,...journal,shortConfig],gate.directories);exactDirectory(directory,journal.map(r=>basename(r.path)));assertRootDecision(ctx,role,read(decisionReference),gate,Date.now());assert.equal(shortConfig.sha256,entry.config.sha256);verify(shortConfig);};
 let transport=null;
 try{
  recheck();transport=createReadTransport({request:q,cli:base.g.FIXED.wrapper.path,cwd:options.cwd,env:options.env,remainingMs:q.deadlineAt-Date.now(),beforeSpawn:args=>{recheck();assertCommand(q,args);assert.ok(Date.now()<q.deadlineAt);}});
  for(const command of commandsFor(q)){
   const o={id:command.id,startedAt:iso(),commandSha256:hash(JSON.stringify(command.args))};Object.assign(o,await transport.read(command.args,stdout=>projectDeployment(stdout,command.role,gate.versions[command.role])));o.endedAt=iso();result.predecessors.push(o);journal.push(write(join(directory,'predecessor-'+command.role+'.json'),o));assert.equal(o.ok,true,'IMMEDIATE_CURRENT_REVISION_REQUIRED');
  }
  // The original gate/decision window and both immediate reads are checked again
  // inside the single write transport, immediately before spawn.
  Object.assign(result,await deployOnce({role,config:ctx.configs[role],shortConfig,expectedVersion:gate.versions[role],cwd:deployOptions.cwd,env:deployOptions.env,beforeSpawn:()=>{recheck();result.predecessorTransport=transport.status();assertImmediatePredecessors(result.predecessors,q,result.startedAt,iso(),result.predecessorTransport);}}));
 }catch{result.commandFailureKind='PREDEPLOY_GUARD_OR_READ_FAILED';}
 result.predecessorTransport??=transport?.status()??null;result.endedAt=iso();const reference=write(join(directory,'result.json'),result);if(!result.commandSucceeded)process.exitCode=1;
 return {reference,role,commandSucceeded:result.commandSucceeded,mutationAttempted:result.mutationAttempted,versionId:result.versionId,disposition:result.disposition};
}
await main(import.meta.url,run);
