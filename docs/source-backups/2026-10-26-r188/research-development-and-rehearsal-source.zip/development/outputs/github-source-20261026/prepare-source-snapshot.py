import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

W = Path.cwd().resolve()
C = Path('C:/Users/XF/.codex/worktrees/arc-v8-release-integration/v8-openrouter-research-beta')
OUT = W / 'outputs/github-source-20261026'
DEST = W / 'work/github-source-r126'
EVIDENCE = DEST / 'docs/source-backups/2026-10-26-r188'
O = W / 'outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261017-snapshot'
U = O / 'scenario-ops-r10'
E186 = W / 'outputs/local-durable-executor-20261026/long-acceptance-r186'
BRANCH = 'codex/arc-v8-source-snapshot-20261026'
BASE = '307de59b52d786214c93ec9a97380775c4a06edd'


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def long_path(p):
    return Path('\\\\?\\' + str(Path(p).absolute()))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_files(root):
    return sorted(set(filter(None, git(root, 'ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0'))))


def safe_rel(name):
    p = Path(name)
    assert not p.is_absolute() and '..' not in p.parts, name
    assert not any(v in {'.git', 'node_modules', '.wrangler', '.next', '.vinext', '.aws', '.codex', 'private-backups'} for v in p.parts), name
    assert not any(v.startswith('.env') and v != '.env.example' for v in p.parts), name
    assert not any(v.startswith('.dev.vars') for v in p.parts), name
    assert p.suffix.lower() not in {'.pem', '.key', '.p12', '.pfx', '.sqlite', '.sqlite3', '.db', '.log'}, name
    return p


assert DEST.resolve().is_relative_to(W / 'work')
assert git(DEST, 'branch', '--show-current').decode().strip() == BRANCH
assert git(DEST, 'rev-parse', 'HEAD').decode().strip() == BASE
assert not (EVIDENCE / 'source-manifest.json').exists(), 'Prepared snapshot is immutable.'

originals = {}
selected = {}


def read_source(root, relative):
    p = root / safe_rel(relative)
    physical = long_path(p)
    assert physical.is_file() and not physical.is_symlink(), str(p)
    data = physical.read_bytes()
    originals[str(p)] = digest(data)
    return data


integration_files = git_files(C)
development_files = git_files(W)
root_sources = {name: ('integration', C) for name in integration_files}
for name in development_files:
    if name.startswith('docs/'):
        root_sources[name] = ('research-development-docs', W)

entries = []
for name, (label, root) in sorted(root_sources.items()):
    data = read_source(root, name)
    selected[name] = data
    entries.append({'path': name, 'source': label, 'sha256': digest(data), 'bytes': len(data)})

# Keep the independently merged CI runtime fix from the actual remote default branch.
# Product source remains byte-identical to the integration checkout.
remote_master = git(DEST, 'rev-parse', 'origin/master').decode().strip()
ci_name = '.github/workflows/ci.yml'
ci_data = git(DEST, 'show', f'{remote_master}:{ci_name}')
selected[ci_name] = ci_data
entries = [x for x in entries if x['path'] != ci_name]
entries.append({'path': ci_name, 'source': 'remote-master', 'sourceCommit': remote_master, 'sha256': digest(ci_data), 'bytes': len(ci_data)})

archive_sources = {name: W / name for name in development_files}
extensions = {'.mjs', '.cjs', '.js', '.ts', '.tsx', '.ps1', '.py', '.sql', '.jsonc'}
freeze = json.loads((U / 'implementation-freeze-r1.json').read_text())
refs = list(freeze['tools'].values()) + freeze['runtimePins'] + freeze['inputPins'] + freeze['testPins']
for ref in refs:
    p = Path(ref['path'])
    if p.is_relative_to(W) and p.suffix in extensions and 'node_modules' not in p.parts:
        if not ('build' in p.parts and 'cloud' in p.parts):
            archive_sources[p.relative_to(W).as_posix()] = p

tool_dirs = [
    U, O / 'no-start-ops-r1', O / 'schema-ops-r1', O / 'driver-artifact-ops-r2',
    E186, E186 / 'source-archive',
    W / 'outputs/local-durable-executor-20261026/successor-r185',
    W / 'outputs/local-resource-access-20261025/public-cutover-r163',
    W / 'outputs/local-resource-access-20261026/public-config-r176',
    W / 'outputs/local-resource-access-20261026/public-cohort-r181',
]
for folder in tool_dirs:
    for p in folder.iterdir():
        if p.is_file() and (p.suffix in extensions or p.name.endswith('.sql.template')):
            archive_sources[p.relative_to(W).as_posix()] = p

# Hand-authored configuration, not runtime responses or data exports.
for folder, pattern in [(U, 'wrangler.*.json'), (W / 'outputs/local-resource-access-20261026/public-config-r176', 'site.*.json'), (W / 'outputs/local-resource-access-20261026/public-config-r176', 'executor.*.json')]:
    for p in folder.glob(pattern):
        archive_sources[p.relative_to(W).as_posix()] = p

archive_sources['.github/workflows/ci.integration-original.yml'] = C / ci_name
archive_sources['outputs/github-source-20261026/prepare-source-snapshot.py'] = Path(__file__).resolve()

record_sources = {
    'CHECKPOINT-r188.md': W / 'outputs/local-durable-executor-20261026/pause-r188/CHECKPOINT.md',
    'long-acceptance-r186-PROGRESS.md': E186 / 'PROGRESS.md',
    'original-long-final-result-paused.md': E186 / 'original-long-final-result-paused.md',
    'functional-continuation-r187-PROGRESS.md': W / 'outputs/local-durable-executor-20261026/functional-continuation-r187/PROGRESS.md',
    'remaining-smoke-continuation-plan.md': W / 'docs/superpowers/plans/2026-10-26-remaining-smoke-continuation.md',
    'public-cutover-r163-RUNBOOK.md': W / 'outputs/local-resource-access-20261025/public-cutover-r163/RUNBOOK.md',
    'public-config-r176-README.md': W / 'outputs/local-resource-access-20261026/public-config-r176/README.md',
    'public-cohort-r181-README.md': W / 'outputs/local-resource-access-20261026/public-cohort-r181/README.md',
    'public-domain-r178-README.md': W / 'outputs/local-resource-access-20261026/public-domain-r178/README.md',
}
for name, p in record_sources.items():
    data = read_source(W, p.relative_to(W).as_posix())
    target_name = (EVIDENCE / name).relative_to(DEST).as_posix()
    selected[target_name] = data
    entries.append({'path': target_name, 'source': 'r188-handoff', 'sha256': digest(data), 'bytes': len(data)})

archive_data = {}
archive_manifest = []
for name, original in sorted(archive_sources.items()):
    if original.is_relative_to(W):
        data = read_source(W, original.relative_to(W).as_posix())
    else:
        assert original == C / ci_name
        data = read_source(C, ci_name)
    archive_name = 'development/' + safe_rel(name).as_posix()
    archive_data[archive_name] = data
    archive_manifest.append({'path': archive_name, 'sha256': digest(data), 'bytes': len(data)})

# Report locations only; never print a matching credential value.
token = re.compile(r'(?:sk-or-v1-|sk-proj-|sk-ant-|gh[pousr]_|github_pat_)[A-Za-z0-9_\-]{32,}')
fixture_bytes = git(DEST, 'show', BASE + ':tests/server/research-package-validator.test.ts').decode()
known_fixture_tokens = set(token.findall(fixture_bytes))
patterns = {
    'provider-or-github-token': token,
    'google-client-secret': re.compile(r'GOCSPX-[A-Za-z0-9_\-]{20,}'),
    'google-api-key': re.compile(r'AIza[0-9A-Za-z_\-]{35}'),
    'aws-access-key': re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'private-key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
    'literal-env-credential': re.compile(r'(?im)^[ \t]*(?:OPENROUTER_API_KEY|BETTER_AUTH_SECRET|GOOGLE_CLIENT_SECRET|GITHUB_CLIENT_SECRET|ARC_AI_IP_HASH_SALT|ARC_AI_RESEARCH_\w+SECRET_HEX|SMOKE_CONTROL_SECRET_HEX)[ \t]*=[ \t]*[\"\x27]?[A-Za-z0-9_\-/+=]{12,}'),
    'signed-download-url': re.compile(r'https?://[^\s\"\x27<>]+[?&](?:X-Amz-Signature|X-Goog-Signature|sig)=[A-Za-z0-9%]{20,}', re.I),
}
findings = []
fixture_count = 0
for name, data in list(selected.items()) + list(archive_data.items()):
    if b'\0' in data:
        continue
    value = data.decode('utf-8', errors='replace')
    for rule, pattern in patterns.items():
        for match in pattern.finditer(value):
            if rule == 'provider-or-github-token' and name.endswith('tests/server/research-package-validator.test.ts') and match.group(0) in known_fixture_tokens:
                fixture_count += 1
                continue
            findings.append({'path': name, 'line': value[:match.start()].count('\n') + 1, 'rule': rule})
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'secret-scan.json').write_text(json.dumps({'filesScanned': len(selected) + len(archive_data), 'knownNegativeTestFixtures': fixture_count, 'findings': findings}, indent=2) + '\n', encoding='utf-8')
assert not findings, json.dumps(findings)

# Exact file pruning is restricted to the previous snapshot's manifested source
# files inside this disposable backup checkout. Historical backups are retained.
old_manifest = json.loads((DEST / 'docs/source-backups/2026-10-18-r126/source-manifest.json').read_text())
removed = []
for item in old_manifest['rootFiles']:
    name = item['path']
    if name not in selected and not name.startswith('docs/source-backups/'):
        target = DEST / safe_rel(name)
        assert target.resolve().is_relative_to(DEST.resolve())
        if target.is_file():
            target.unlink()
            removed.append(name)
for name, data in selected.items():
    target = long_path(DEST / safe_rel(name))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

EVIDENCE.mkdir(parents=True, exist_ok=True)
archive = EVIDENCE / 'research-development-and-rehearsal-source.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in archive_data.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 26, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data)
    z.writestr('SOURCE-MANIFEST.json', json.dumps(archive_manifest, indent=2) + '\n')

manifest = {
    'schemaVersion': 'arc-github-source-backup-v2',
    'createdAt': datetime.now(timezone.utc).isoformat(), 'checkpoint': 'r188',
    'baseCommit': BASE, 'integrationBaseCommit': git(C, 'rev-parse', 'HEAD').decode().strip(),
    'developmentBaseCommit': git(W, 'rev-parse', 'HEAD').decode().strip(),
    'branch': BRANCH,
    'rootDescription': 'Current integration source, development documentation overlay, and the already merged remote-master CI runtime fix.',
    'rootFiles': sorted(entries, key=lambda x: x['path']),
    'removedObsoleteSourcePaths': removed,
    'developmentArchive': {'path': archive.relative_to(DEST).as_posix(), 'files': len(archive_manifest), 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size},
    'excluded': ['credential files and values', 'installed dependencies', 'generated bundles', 'raw operational logs and responses', 'database and object-store data', 'full local operational evidence'],
    'operationalState': 'Release goal paused at r188. Real Research and source-quality plan passed earlier; fault/replay acceptance, cutover and public enablement remain incomplete. This source backup performs no deployment, task restart or paid model call.',
}
(EVIDENCE / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(OUT / 'original-source-hashes.json').write_text(json.dumps(originals, indent=2) + '\n', encoding='utf-8')

for name, expected in originals.items():
    assert digest(long_path(name).read_bytes()) == expected, 'Original changed: ' + name
for item in entries:
    assert digest(long_path(DEST / item['path']).read_bytes()) == item['sha256'], item['path']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in archive_manifest:
        assert digest(z.read(item['path'])) == item['sha256'], item['path']

summary = {'rootFiles': len(entries), 'archiveFiles': len(archive_manifest), 'archiveBytes': archive.stat().st_size, 'sourceFilesVerifiedUnchanged': len(originals), 'secretFindings': len(findings), 'knownNegativeTestFixtures': fixture_count, 'sourceByteVerification': 'PASS', 'archiveReadbackVerification': 'PASS', 'removedObsoleteSourcePaths': removed}
(OUT / 'preparation-verification.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
