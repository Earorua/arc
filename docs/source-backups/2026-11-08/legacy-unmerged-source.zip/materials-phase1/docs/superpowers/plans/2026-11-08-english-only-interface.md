> Superseded after source reconciliation: the current implementation and release are in `C:/Users/XF/.codex/worktrees/arc-ink-teal/ui-warm-precision`. This worktree's task-only translation edits were archived and restored to its pre-task state. See the current source's `docs/verification/2026-11-08-english-only-interface.md` for the published result. The original plan below is historical.

# English-only interface implementation plan

> **For agentic workers:** Apply the independent-domain parallel workflow; retain the existing dirty worktree and review each bounded change before integration.

**Goal:** Present all Arc-authored website text in English, remove repeated bilingual labels, and preserve readable responsive layouts.

**Architecture:** Edit the canonical Discovery source in this directory. Keep user-authored content, multilingual source metadata, stored identifiers, and pending materials work intact. Translate displayed copy, accessible labels, default content, dates, and generated-response language instructions.

**Tech Stack:** React, Vinext, TypeScript, CSS, Vitest, rendered HTML checks.

- [ ] Translate public, account, and sample pages. Collapse the sample eyebrow to `Product in action` and tab labels to `Path`, `Today`, and `Proof`.
- [ ] Translate Setup, research progress, and materials components. Send new website research requests with `locale: "en-US"`; preserve schema support for existing records.
- [ ] Translate Today, Path, Stack, Proof, history, workspace navigation, and default Flagship content. Use explicit English date formats.
- [ ] Translate learning companion UI, server messages, and default prompts. Set root HTML to `lang="en"` and Open Graph locale to `en_US`.
- [ ] Remove the unused Chinese font import. Adjust line lengths, typography, tab spacing, and responsive wrapping for the English copy.
- [ ] Update existing text assertions without reducing behavioral coverage. Run affected Vitest suites, TypeScript, production build, and rendered HTML checks.
- [ ] Review each task for complete English copy and preserved behavior, then inspect desktop and mobile rendering with the available browser tools. Record any remaining verification or publication limits.

The pre-edit app and tests are saved under `work/english-only-20261108/before` for a task-only comparison. Do not commit, deploy pending materials work, run paid research, or mutate production data as part of translation validation.
