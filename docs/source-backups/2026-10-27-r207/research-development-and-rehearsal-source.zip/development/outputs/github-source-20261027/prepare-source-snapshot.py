import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

W = Path.cwd().resolve()
C = Path('C:/Users/XF/.codex/worktrees/arc-v8-release-integration/v8-openrouter-research-beta')
OUT = W / 'outputs/github-source-20261027'
DEST = W / 'work/github-source-r126'
EVIDENCE = DEST / 'docs/source-backups/2026-10-27-r207'
P = W / 'outputs/local-resource-access-20261027/public-cutover-r199'
O = W / 'outputs/local-durable-executor-20260914/task15-smoke/cloud-ops-20261017-snapshot'
U = O / 'scenario-ops-r10'
BRANCH = 'codex/arc-v8-source-snapshot-20261027'
BASE = '7f845ef0445daffa7026ae40aa17911c7dd45578'
MASTER = '99c68c9986fec7f9a66cbed3f3e597a80ee7bba4'

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def physical(p):
    return Path('\\\\?\\' + str(Path(p).absolute()))

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git_files(root):
    return sorted(set(filter(None, git(root, 'ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0'))))

def safe_rel(name):
    p = Path(name)
    assert not p.is_absolute() and '..' not in p.parts, name
    assert not any(v in {'.git', 'node_modules', '.wrangler', '.next', '.vinext', '.aws', '.codex', 'private-backups'} for v in p.parts), name
    assert not any(v.startswith('.env') and v != '.env.example' for v in p.parts), name
    assert not any(v.startswith('.dev.vars') for v in p.parts), name
    assert p.suffix.lower() not in {'.pem', '.key', '.p12', '.pfx', '.sqlite', '.sqlite3', '.db', '.log'}, name
    return p

assert DEST.resolve().is_relative_to(W / 'work')
assert git(DEST, 'branch', '--show-current').decode().strip() == BRANCH
assert git(DEST, 'rev-parse', 'HEAD').decode().strip() == BASE
assert git(DEST, 'rev-parse', 'origin/master').decode().strip() == MASTER
assert not git(DEST, 'status', '--porcelain'), 'Backup checkout must start clean.'
assert not EVIDENCE.exists(), 'Do not overwrite an existing snapshot.'

originals, selected, archive_data = {}, {}, {}
entries = []

def read_source(root, relative):
    p = root / safe_rel(relative)
    assert physical(p).is_file() and not physical(p).is_symlink(), str(p)
    data = physical(p).read_bytes()
    originals[str(p)] = digest(data)
    return data

integration_files = git_files(C)
development_files = git_files(W)
root_sources = {name: ('integration', C) for name in integration_files}
for name in development_files:
    if name.startswith('docs/'):
        root_sources[name] = ('development-docs', W)
for name, (label, root) in sorted(root_sources.items()):
    data = read_source(root, name)
    selected[name] = data
    entries.append({'path': name, 'source': label, 'sha256': digest(data), 'bytes': len(data)})

ci_name = '.github/workflows/ci.yml'
ci_data = git(DEST, 'show', f'{MASTER}:{ci_name}')
selected[ci_name] = ci_data
entries = [x for x in entries if x['path'] != ci_name]
entries.append({'path': ci_name, 'source': 'remote-master', 'sourceCommit': MASTER, 'sha256': digest(ci_data), 'bytes': len(ci_data)})

record_sources = {
    'CHECKPOINT-r207.md': OUT / 'CHECKPOINT-r207.md',
    'PUBLIC-RELEASE-r206.md': P / 'FINAL-r206.md',
    'public-release-receipt-r206.json': P / 'release-receipt-r206.json',
    'functional-closure-r202.json': W / 'outputs/local-durable-executor-20261027/closure-reconciliation-r202/result.json',
}
for name, original in record_sources.items():
    data = read_source(W, original.relative_to(W).as_posix())
    target = (EVIDENCE / name).relative_to(DEST).as_posix()
    selected[target] = data
    entries.append({'path': target, 'source': 'release-handoff', 'sha256': digest(data), 'bytes': len(data)})

archive_sources = {name: W / name for name in development_files}
extensions = {'.mjs', '.cjs', '.js', '.ts', '.tsx', '.ps1', '.py', '.sql', '.jsonc'}
freeze = json.loads((U / 'implementation-freeze-r1.json').read_text())
for ref in list(freeze['tools'].values()) + freeze['runtimePins'] + freeze['inputPins'] + freeze['testPins']:
    p = Path(ref['path'])
    if p.is_relative_to(W) and p.suffix in extensions and 'node_modules' not in p.parts and not ('build' in p.parts and 'cloud' in p.parts):
        archive_sources[p.relative_to(W).as_posix()] = p

tool_dirs = [U, O / 'no-start-ops-r1', O / 'schema-ops-r1', O / 'driver-artifact-ops-r2']
for date, names in {
    '20261026': ['long-acceptance-r186', 'long-acceptance-r186/source-archive', 'successor-r185', 'functional-continuation-r187'],
    '20261027': ['fresh-readback-r189', 'retained-readback-r190', 'workflow-projection-diagnostic-r192', 'functional-continuation-r193', 'functional-continuation-r195', 'functional-continuation-r198', 'network-diagnostic-r197', 'network-diagnostic-r200', 'network-diagnostic-r201', 'network-diagnostic-r202', 'closure-reconciliation-r199', 'closure-reconciliation-r202'],
}.items():
    tool_dirs.extend(W / f'outputs/local-durable-executor-{date}' / name for name in names)
tool_dirs.extend([
    W / 'outputs/local-resource-access-20261025/public-cutover-r163',
    W / 'outputs/local-resource-access-20261026/public-config-r176',
    W / 'outputs/local-resource-access-20261026/public-cohort-r181',
    P,
])
for folder in tool_dirs:
    assert folder.is_dir(), folder
    for p in folder.iterdir():
        # Top-level authored programs only; never recurse into run/log/export folders.
        if p.is_file() and (p.suffix in extensions or p.name.endswith('.sql.template')):
            archive_sources[p.relative_to(W).as_posix()] = p
for folder, pattern in [
    (U, 'wrangler.*.json'),
    (W / 'outputs/local-resource-access-20261026/public-config-r176', 'site.*.json'),
    (W / 'outputs/local-resource-access-20261026/public-config-r176', 'executor.*.json'),
    (P / 'final-config-r203', '*.json'),
]:
    for p in folder.glob(pattern):
        archive_sources[p.relative_to(W).as_posix()] = p
archive_sources['.github/workflows/ci.integration-original.yml'] = C / ci_name
archive_sources['outputs/github-source-20261027/prepare-source-snapshot.py'] = Path(__file__).resolve()

archive_manifest = []
for name, original in sorted(archive_sources.items()):
    if original.is_relative_to(W):
        data = read_source(W, original.relative_to(W).as_posix())
    else:
        assert original == C / ci_name
        data = read_source(C, ci_name)
    archive_name = 'development/' + safe_rel(name).as_posix()
    archive_data[archive_name] = data
    archive_manifest.append({'path': archive_name, 'sha256': digest(data), 'bytes': len(data)})

token = re.compile(r'(?:sk-or-v1-|sk-proj-|sk-ant-|gh[pousr]_|github_pat_)[A-Za-z0-9_\-]{32,}')
known_fixture_tokens = set(token.findall(git(DEST, 'show', BASE + ':tests/server/research-package-validator.test.ts').decode()))
patterns = {
    'provider-or-github-token': token,
    'google-client-secret': re.compile(r'GOCSPX-[A-Za-z0-9_\-]{20,}'),
    'google-api-key': re.compile(r'AIza[0-9A-Za-z_\-]{35}'),
    'aws-access-key': re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'private-key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
    'literal-env-credential': re.compile(r'(?im)^[ \t]*(?:OPENROUTER_API_KEY|BETTER_AUTH_SECRET|GOOGLE_CLIENT_SECRET|GITHUB_CLIENT_SECRET|ARC_AI_IP_HASH_SALT|ARC_AI_RESEARCH_\w+SECRET_HEX|SMOKE_CONTROL_SECRET_HEX)[ \t]*=[ \t]*[\"\x27]?[A-Za-z0-9_\-/+=]{12,}'),
    'signed-download-url': re.compile(r'https?://[^\s\"\x27<>]+[?&](?:X-Amz-Signature|X-Goog-Signature|sig)=[A-Za-z0-9%]{20,}', re.I),
}
findings, fixture_count = [], 0
for name, data in list(selected.items()) + list(archive_data.items()):
    if b'\0' in data:
        continue
    value = data.decode('utf-8', errors='replace')
    for rule, pattern in patterns.items():
        for match in pattern.finditer(value):
            if rule == 'provider-or-github-token' and name.endswith('tests/server/research-package-validator.test.ts') and match.group(0) in known_fixture_tokens:
                fixture_count += 1
                continue
            findings.append({'path': name, 'line': value[:match.start()].count('\n') + 1, 'rule': rule})
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'secret-scan.json').write_text(json.dumps({'filesScanned': len(selected) + len(archive_data), 'knownNegativeTestFixtures': fixture_count, 'findings': findings}, indent=2) + '\n', encoding='utf-8')
assert not findings, json.dumps(findings)

# Prune only obsolete manifested source files in the already identified backup checkout.
old_manifest = json.loads((DEST / 'docs/source-backups/2026-10-26-r188/source-manifest.json').read_text())
removed = []
for item in old_manifest['rootFiles']:
    name = item['path']
    if name not in selected and not name.startswith('docs/source-backups/'):
        target = DEST / safe_rel(name)
        assert target.resolve().is_relative_to(DEST.resolve())
        if target.is_file():
            target.unlink()
            removed.append(name)
for name, data in selected.items():
    target = physical(DEST / safe_rel(name))
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

EVIDENCE.mkdir(parents=True, exist_ok=True)
archive = EVIDENCE / 'research-development-and-rehearsal-source.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in archive_data.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 27, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data)
    z.writestr('SOURCE-MANIFEST.json', json.dumps(archive_manifest, indent=2) + '\n')

manifest = {
    'schemaVersion': 'arc-github-source-backup-v3',
    'createdAt': datetime.now(timezone.utc).isoformat(), 'checkpoint': 'r207',
    'baseCommit': BASE, 'integrationBaseCommit': git(C, 'rev-parse', 'HEAD').decode().strip(),
    'developmentBaseCommit': git(W, 'rev-parse', 'HEAD').decode().strip(), 'branch': BRANCH,
    'rootDescription': 'Canonical released application source, current documentation, and unchanged remote-master CI workflow.',
    'rootFiles': sorted(entries, key=lambda x: x['path']), 'removedObsoleteSourcePaths': removed,
    'developmentArchive': {'path': archive.relative_to(DEST).as_posix(), 'files': len(archive_manifest), 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size},
    'excluded': ['actual credentials', 'installed dependencies', 'generated bundles', 'raw operational logs and responses', 'live database and object data', 'private backups'],
    'operationalState': 'First public release completed at r206; r207 saves progress before the user closes Codex. Production stays enabled. This source backup performs no deployment or paid model call.',
}
(EVIDENCE / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
(OUT / 'original-source-hashes.json').write_text(json.dumps(originals, indent=2) + '\n', encoding='utf-8')
for name, expected in originals.items():
    assert digest(physical(name).read_bytes()) == expected, 'Original source changed: ' + name
for item in entries:
    assert digest(physical(DEST / item['path']).read_bytes()) == item['sha256'], item['path']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in archive_manifest:
        assert digest(z.read(item['path'])) == item['sha256'], item['path']
summary = {'rootFiles': len(entries), 'archiveFiles': len(archive_manifest), 'archiveBytes': archive.stat().st_size, 'sourceFilesVerifiedUnchanged': len(originals), 'secretFindings': len(findings), 'knownNegativeTestFixtures': fixture_count, 'sourceByteVerification': 'PASS', 'archiveReadbackVerification': 'PASS', 'removedObsoleteSourcePaths': removed}
(OUT / 'preparation-verification.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
