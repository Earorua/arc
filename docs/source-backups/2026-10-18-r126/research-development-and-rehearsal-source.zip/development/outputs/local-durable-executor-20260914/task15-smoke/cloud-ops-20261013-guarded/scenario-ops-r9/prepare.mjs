import {ensureRuntimeDirectories} from './runtime-directories.mjs';
import {resolve} from 'node:path';
import {here,FIXED,assert,same,write,toolRefs,createValidationContext,assertContext,main} from './guards.mjs';
import {assertTransition} from './contracts.mjs';
import {SOURCES} from './read-plans.mjs';
export function strictCommand(path,mode){assert(['dry-run','deploy'].includes(mode)&&typeof path==='string','FIXED_OPERATION_MODE');return ['deploy','--config',path,'--no-bundle','--strict','--no-x-autoconfig','--no-x-provision','--no-x-auto-create',...(mode==='dry-run'?['--dry-run']:[])];}
export function deriveConfigs(c){assertContext(c);const activate=structuredClone(c.configs.executor);activate.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW='true';activate.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED='true';activate.triggers.crons=['* * * * *'];assertTransition({kind:'activate',beforeConfig:c.configs.executor,afterConfig:activate});
 const admission=structuredClone(activate);admission.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW='false';assertTransition({kind:'admission-close',beforeConfig:activate,afterConfig:admission});
 const maintenance=structuredClone(admission);maintenance.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED='false';maintenance.triggers.crons=[];assert(same(maintenance,c.configs.executor),'EXACT_STOPPED_CONFIG');return {activate,'admission-close':admission,'maintenance-close':maintenance};}
export function prepare(c=createValidationContext()){
 ensureRuntimeDirectories(here);
 const configs={};for(const [kind,value] of Object.entries(deriveConfigs(c)))configs[kind]=write(resolve(here,`wrangler.${kind}.json`),value);
 return write(resolve(here,'preparation.json'),{schemaVersion:'arc-guarded-scenario-preparation-v1',status:'LOCAL_PREPARATION_ONLY',inputs:FIXED,tools:toolRefs(),readSources:SOURCES,baseConfigs:c.configRefs,artifacts:c.artifacts,configs,
  rosterRecipe:{changedVars:['SMOKE_REPLAY_APPROVAL_JSON','SMOKE_REPLAY_INVENTORY_SHA256'],maxBytes:4096,requiredScenarioIds:['long','after-r2','after-d1'],dryRunAndDeployAfterActualRoster:true},validation:c.validation,cloudCalls:0,controlCalls:0,providerCalls:0});
}
await main(import.meta.url,()=>{assert(process.argv.length===2,'NO_PREPARE_ARGUMENTS');console.log(JSON.stringify({preparation:prepare()}));});
