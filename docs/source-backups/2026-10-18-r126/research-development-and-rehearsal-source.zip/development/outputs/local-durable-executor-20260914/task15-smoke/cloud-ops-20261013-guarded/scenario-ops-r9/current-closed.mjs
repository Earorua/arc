// Historical reconstruction only. No freshness, clock renewal, or operation is supplied.
import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import strict from 'node:assert/strict';
import {FIXED,assert,same,digest,utc} from './guards.mjs';
// Verify exact code before ESM initialization; each call below verifies and reconstructs again.
const componentPath=resolve(dirname(fileURLToPath(import.meta.url)),'../../../../local-durable-executor-20261016/closed-r6-successor-r1/reconstruct.mjs');
const componentSha256='398c20cbc87eeb4a6047132beea78159618232f26da0767cdbe50f33eb801925';
strict.equal(createHash('sha256').update(readFileSync(componentPath)).digest('hex'),componentSha256,'FIXED_CURRENT_CLOSED_RECONSTRUCTION_CODE');
const {reconstruct}=await import(pathToFileURL(componentPath));
export function loadCurrentClosed(read,verify){
 const reference=FIXED.currentClosedAcceptance;
 assert(digest(reference.sha256),'CURRENT_CLOSED_ANCHOR_UNAVAILABLE');
 verify(reference);for(const pin of Object.values(FIXED.closedReconstruction))verify(pin);
 const a=read(reference),pins=FIXED.closedReconstruction;
 assert(a.schemaVersion==='arc-closed-r6-root-acceptance-v1'&&a.rootReviewed===true&&a.specPassed===true&&a.qualityPassed===true&&a.disposition==='CURRENT_CLOSED_HISTORICAL_BASELINE_ACCEPTED_FOR_NEW_STATIC_CANDIDATE'&&a.epoch===FIXED.epoch&&same(a.originalSchemaAcceptance,FIXED.schemaAcceptance)&&a.task15Accepted===false&&a.operationalReadiness===false&&a.operationalSuccessorAuthorizedByThisRecord===false,'DISTINCT_ROOT_CURRENT_CLOSED_ACCEPTANCE');
 assert(same(a.reconstruction,pins.reconstruction)&&same(a.inputs,pins.inputs)&&same(a.projection,pins.projection)&&pins.reconstruction.path===componentPath&&pins.reconstruction.sha256===componentSha256,'EXACT_ACCEPTED_RECONSTRUCTION_PINS');
 const fresh=reconstruct(),expected=read(pins.projection);
 assert(same(fresh,expected),'FRESH_RECONSTRUCTION_MATCHES_ACCEPTED_PROJECTION');
 for(const name of ['currentVersions','configs','workflowLatestVersions','retainedObserver','originalSchemaAcceptance','originalRecovery','observedThrough','observationFreshness','originalR6Complete','permanentIncomplete'])assert(same(a[name],fresh[name]),'CURRENT_CLOSED_ACCEPTANCE_MAPPING');
 assert(utc(a.acceptedAt)>=utc(fresh.observedThrough)&&utc(a.acceptedAt)<=Date.now(),'ROOT_ACCEPTED_AFTER_ACTUAL_PROOFS');
 assert(fresh.originalR6Complete===false&&fresh.permanentIncomplete===true&&fresh.operationalReadiness===false&&fresh.task15Accepted===false&&fresh.operationalSuccessorAuthorized===false&&fresh.originalRecovery.renewed===false&&fresh.originalRecovery.expiredAtObservation===false&&fresh.originalRecovery.currentExpiryEvaluated===false&&fresh.originalRecovery.historicalOnly===true&&fresh.originalRecovery.deadlineAt===1792142459263&&!Object.hasOwn(fresh.originalRecovery,'expired')&&!Object.hasOwn(fresh,'originalR5Complete')&&fresh.observationFreshness==='HISTORICAL_ONLY_RECHECK_BEFORE_NEW_ACTIVATION','HISTORICAL_CLOSURE_NEVER_RENEWS_AUTHORITY');
 assert(Array.isArray(fresh.runtimeInputPins)&&fresh.runtimeInputPins.length>=1498,'RECONSTRUCTION_RUNTIME_PINS_REQUIRED');
 for(const pin of fresh.runtimeInputPins)verify(pin);
 const configValues=Object.fromEntries(Object.entries(fresh.configs).map(([role,pin])=>[role,read(pin)]));
 assert(configValues.executor.vars.ARC_RESEARCH_EXECUTOR_ACCEPT_NEW==='false'&&configValues.executor.vars.ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED==='false'&&same(configValues.executor.triggers.crons,[])&&!Object.hasOwn(configValues.site.vars,'SMOKE_REPLAY_APPROVAL_JSON')&&!Object.hasOwn(configValues.site.vars,'SMOKE_REPLAY_INVENTORY_SHA256'),'CURRENT_CLOSED_CONFIG_NO_ROSTER');
 return Object.freeze({...fresh,configValues,reference:structuredClone(reference)});
}
