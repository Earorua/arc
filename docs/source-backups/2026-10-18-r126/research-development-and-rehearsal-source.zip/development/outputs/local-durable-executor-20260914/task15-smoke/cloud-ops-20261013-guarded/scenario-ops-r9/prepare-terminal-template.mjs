// Root runs this local-only generator after reviewing exact materials and dry runs.
import {mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {FIXED,here,assert,write,jsonRef,createValidationContext,assertCurrentPins,main} from './guards.mjs';
import {fixedRole,terminalPins,loadTerminalTemplate,assertTemplateWindow,LOCAL_VALIDATION_RESERVE_MS,AUTHORITY_MODE} from './terminal-contract.mjs';
import {loadPreparation} from './prepare-observation.mjs';
import {loadOperation,previewSignedHandoff} from './evaluate.mjs';
export function prepareTerminalTemplate(c,spec){
 assert(spec.rootReviewed===true,'ACTUAL_ROOT_TEMPLATE_REVIEW');const r=fixedRole(spec.role),p=loadPreparation(c,spec.preparation),now=Date.now();
 assertTemplateWindow(r.role,now,spec.validUntil,now);
 if(r.first){assert(spec.spec===null&&spec.dryRuns&&Object.keys(spec.dryRuns).sort().join(',')==='activate,admission-close,maintenance-close','FIRST_FIXED_PIPELINE_DRY_RUNS');for(const kind of ['activate','admission-close','maintenance-close']){const result=loadOperation(c,spec.dryRuns[kind]);assert(result.kind===kind&&result.mode==='dry-run'&&result.config.sha256===p.configs[kind].sha256,'ROOT_ACCEPTED_EXACT_DRY_RUNS');}}
 else{assert(spec.dryRuns===null,'NO_OTHER_ROLE_ACTIVATION');previewSignedHandoff(c,spec.spec);}
 const measuredValidationMs=Math.max(1,Math.ceil(c.validation.elapsedMs));assert(measuredValidationMs*3+5000<LOCAL_VALIDATION_RESERVE_MS,'MEASURED_LOCAL_VALIDATION_FITS_RESERVE');
 const value={schemaVersion:'arc-guarded-terminal-template-v1',rootReviewed:true,authorityMode:AUTHORITY_MODE,sequence:FIXED.sequence,epoch:FIXED.epoch,identity:r,currentClosedAcceptance:FIXED.currentClosedAcceptance,initialAckTimeout:FIXED.initialAckTimeout,preparationDirectoryFailure:FIXED.preparationDirectoryFailure,pins:terminalPins(r.role),materials:spec.materials,preparation:spec.preparation,dryRuns:spec.dryRuns,spec:spec.spec,reviewedAt:new Date(now).toISOString(),validUntil:spec.validUntil,localValidationReserveMs:LOCAL_VALIDATION_RESERVE_MS,measuredValidationMs,noAutomaticRetry:true,providerCallsAllowed:false};
 assertCurrentPins(c,Object.values(value.pins));mkdirSync(resolve(here,'templates'),{recursive:true});const reference=write(r.templatePath,value);loadTerminalTemplate(c,reference,r.role);return reference;
}
await main(import.meta.url,()=>{assert(process.argv.length===4,'EXACT_ROOT_TEMPLATE_SPEC');const c=createValidationContext(),spec=jsonRef({path:resolve(process.argv[2]),sha256:process.argv[3]});console.log(JSON.stringify({template:prepareTerminalTemplate(c,spec),operationalReadiness:false}));});
