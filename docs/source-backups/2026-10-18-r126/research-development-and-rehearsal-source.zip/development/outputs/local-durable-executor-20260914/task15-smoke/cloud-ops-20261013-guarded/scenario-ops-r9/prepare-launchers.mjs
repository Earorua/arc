// STATIC LOCAL GENERATION ONLY. Never calls an operational entrypoint or acquires input.
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {FIXED,here,root,hash,ref,toolRefs,assert} from './guards.mjs';
import {SCENARIOS} from './read-plans.mjs';
const sourcePath=resolve(root,'scripts/run-research-cloud-smoke.ps1');
const sourceSha256='7017350c6103cbb8903afe1327959e62cb6ea98f38361de4b6c7effb29cd0957';
const priorPath=resolve(here,'../../cloud-ops-20261012-ack/launcher-preparation-r1/prepare-launchers.mjs');
const priorSha256='d208086f5b6002b47a67126d540baa4cade50e93d9093b82889a725f7a9d0d9f';
const quote=x=>{assert(typeof x==='string'&&!/["'\r\n]/u.test(x),'FIXED_LITERAL');return `'${x}'`;};
const crlf=x=>x.replace(/\r?\n/gu,'\r\n');
export function verifyDerivation(source,derived,edits){
 let inverse=derived;
 for(const {before,after} of [...edits].reverse()){
  assert(inverse.split(after).length===2,'INVERSE_UNIQUE_INSERTION');inverse=inverse.replace(after,before);
 }
 assert(Buffer.from(inverse).equals(Buffer.from(source)),'INVERSE_SOURCE_BYTES');return true;
}
export function deriveLauncher(source,settings){
 assert(hash(source)===sourceSha256,'FROZEN_SOURCE_HASH');
 const {scenarioId,mode,reportName,gatePath,gateSha256,contractPath,contractSha256}=settings;
 assert(Object.hasOwn(SCENARIOS,scenarioId)&&['start','status','replay'].includes(mode)&&reportName===`cloud-guarded-${scenarioId}-${mode}-20261016-r9`,'FIXED_ROLE');
 const edits=[];let text=source;
 const replace=(before,after)=>{assert(text.split(before).length===2,'DERIVATION_ANCHOR');edits.push({before,after});text=text.replace(before,after);};
 const insert=(anchor,insertion)=>replace(anchor,insertion+anchor);
 replace("    $smokeRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path",`    $smokeRoot = ${quote(root)}`);
 insert('try {\n    $smokeRoot',`$smokeAttempt = $null
$smokeReadyBeforeInput = $null
$smokeChildStarted = $false
$smokeDispatchAt = $null
$smokeChildClock = $null
$smokeCloseFact = $null

`);
 insert("    if ([Console]::IsInputRedirected) { throw 'Interactive terminal required' }",`    # Reviewed fixed-role gates; no credential data enters these functions.
    if ($Mode -cne ${quote(mode)} -or $Scenario -cne ${quote(scenarioId)} -or $ReportName -cne ${quote(reportName)}) { throw 'Fixed scenario role required' }
    $smokeGatePath = ${quote(gatePath)}
    $smokeContractPath = ${quote(contractPath)}
    if ((Get-FileHash -LiteralPath $smokeGatePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne '${gateSha256}' -or
        (Get-FileHash -LiteralPath $smokeContractPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne '${contractSha256}') { throw 'Reviewed readiness material changed' }
    . $smokeGatePath
    $smokeGateArguments = @{ ContractPath=$smokeContractPath; ContractSha256='${contractSha256}'; Mode=$Mode; Scenario=$Scenario; Inventory=$smokeInventory; ArtifactReport=$smokeArtifactReport; ReportName=$ReportName; Approval=$smokeApproval; SystemProxy=$UseSystemProxy.IsPresent; LauncherPath=$PSCommandPath; NodePath=$smokeNode }
    try { $smokeReadyBeforeInput = Assert-ArcScenarioReadiness @smokeGateArguments }
    catch {
        if ($_.Exception.Message -ceq 'ACTUAL_HANDOFF_REQUIRED') { [Console]::Error.WriteLine('READINESS_NO_DISPATCH_HANDOFF_MISSING') }
        else { [Console]::Error.WriteLine('READINESS_NO_DISPATCH_PROVENANCE_REFUSED') }
        throw
    }
    $smokeAttempt = New-ArcLaunchAttempt -Ready $smokeReadyBeforeInput
    $smokeInputClock = [Diagnostics.Stopwatch]::StartNew()

`);
 insert('    $smokeChild = [Diagnostics.Process]::new()',`    # Revalidate original evidence after masked input, immediately before child creation.
    Assert-ArcInputWindow -Ready $smokeReadyBeforeInput -ElapsedMs $smokeInputClock.ElapsedMilliseconds
    if ((Get-FileHash -LiteralPath $smokeGatePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne '${gateSha256}') { throw 'Reviewed readiness gate changed during input' }
    $smokeReadyAfterInput = Assert-ArcScenarioReadiness @smokeGateArguments -Previous $smokeReadyBeforeInput -Attempt $smokeAttempt
    Assert-ArcUnchangedReadiness -Before $smokeReadyBeforeInput -After $smokeReadyAfterInput
    Assert-ArcInputWindow -Ready $smokeReadyAfterInput -ElapsedMs $smokeInputClock.ElapsedMilliseconds

`);
 insert('    [void]$smokeChild.Start()',`    $smokeDispatchAt = [DateTimeOffset]::UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'")
    $smokeChildClock = [Diagnostics.Stopwatch]::StartNew()
`);
 replace('    [void]$smokeChild.Start()','    [void]$smokeChild.Start()\n    $smokeChildStarted = $true');
 insert("    if (-not $smokeDrainTask.Wait(5000)) { throw 'Driver output deadline exceeded' }",`    # Bound draining by the same absolute reserve. The frozen wait below then returns immediately.
    $smokeRemainingDrainMs = [int][Math]::Max(0, [Math]::Min(5000, 65000 - $smokeChildClock.ElapsedMilliseconds))
    if (-not $smokeDrainTask.Wait($smokeRemainingDrainMs)) { throw 'Driver output deadline exceeded' }
`);
 insert('        $smokeChild.Dispose()',`        # Kill is only a request. Share the original 65-second absolute reserve.
        if ($smokeChildStarted) {
            try { $smokeCloseFact = Get-ArcChildCloseFact -Child $smokeChild -Clock $smokeChildClock } catch { $smokeCloseFact = $null }
            if ($null -eq $smokeCloseFact -or -not $smokeCloseFact.childCloseConfirmed) { $smokeExitCode = 1 }
        }
`);
 insert('}\n\nexit $smokeExitCode',`    if ($null -ne $smokeAttempt) {
        try { Write-ArcControlExit -Ready $smokeReadyBeforeInput -Attempt $smokeAttempt -StartedAt $smokeDispatchAt -CloseFact $smokeCloseFact -LauncherExitCode $smokeExitCode }
        catch { $smokeExitCode = 1; [Console]::Error.WriteLine('Control evidence unavailable; attempt remains consumed. STOP_RECONCILE_NO_RETRY.') }
    }
`);
 verifyDerivation(source,text,edits);return {text,edits};
}
export function buildStaticArtifacts(){
 assert(hash(readFileSync(sourcePath))===sourceSha256&&hash(readFileSync(FIXED.driver.path))===FIXED.driver.sha256,'FROZEN_SOURCE_DRIVER_HASH');
 assert(hash(readFileSync(priorPath))===priorSha256,'REVIEWED_PRIOR_DERIVATION_HASH');
 const gatePath=resolve(here,'readiness.ps1'),gateSha256=hash(readFileSync(gatePath));
 const contractPath=resolve(here,'launcher-contract.json');
 const roles=Object.keys(SCENARIOS).flatMap(scenarioId=>['start','status','replay'].map(mode=>({role:scenarioId+':'+mode,scenarioId,mode,jobId:SCENARIOS[scenarioId].jobId,
  reportName:`cloud-guarded-${scenarioId}-${mode}-20261016-r9`,launcherPath:resolve(here,`run-${scenarioId}-${mode}-masked-once-r1.ps1`),commandPath:resolve(here,`${scenarioId}-${mode}-command-r1.ps1`),
  handoffPath:resolve(here,'handoffs',`${scenarioId}-${mode}.json`),readinessPath:resolve(here,'handoffs',`${scenarioId}-${mode}-readiness.json`),attemptPath:resolve(here,'controls',`${scenarioId}-${mode}-attempt.json`),exitPath:resolve(here,'controls',`${scenarioId}-${mode}-exit.json`)})));
 const contract={schemaVersion:'arc-guarded-launcher-contract-v1',status:'STATIC_CONTRACT_ONLY_NOT_READINESS_OR_CONTROL_EVIDENCE',epoch:FIXED.epoch,root,here,
  source:{path:sourcePath,sha256:sourceSha256},driver:FIXED.driver,inventory:FIXED.inventory,artifactReport:FIXED.report,task2Tools:toolRefs(),
  terminalEntry:ref(resolve(here,'terminal-entry.ps1')),terminalBackend:ref(resolve(here,'terminal-prepare.mjs')),
  evaluator:ref(resolve(here,'evaluate.mjs')),materialsPath:FIXED.materialsPath,approvalPath:resolve(here,'replay-approval.json'),
  node:{path:'C:\\Program Files\\nodejs\\node.exe',sha256:'58e74bf02fc5bbacc41dcb8bef089961cd5bddd37830b87784e4fc624d145d1f'},
  controlCredentialMode:'secure-masked-tty',providerCallsAllowed:false,childTimeoutMs:60000,childReserveMs:65000,outputDrainMs:5000,
  inputAllowanceMs:{start:60000,status:60000,replay:45000},minimumLongQuietMs:1170000,replaySteps:['submit','status','owner-a-recover','owner-a-get','owner-b-recover','owner-b-get'],totalReplaySteps:18,
  roles:roles.map(x=>({...x,reportPath:resolve(here,'../..',x.reportName,'report.json')}))};
 const contractText=JSON.stringify(contract,null,2)+'\n',contractSha256=hash(contractText),source=readFileSync(sourcePath,'utf8');
 const launchers=roles.map(role=>{
  const settings={...role,gatePath,gateSha256,contractPath,contractSha256},derived=deriveLauncher(source,settings),launcher={path:role.launcherPath,sha256:hash(derived.text)};
  const commandText=crlf(`$ErrorActionPreference = 'Stop'
try {
if ($args.Count -ne 0) { throw 'Fixed no-argument attended command only' }
$arcEntry = ${quote(contract.terminalEntry.path)}
if ((Get-FileHash -LiteralPath $arcEntry -Algorithm SHA256).Hash.ToLowerInvariant() -cne '${contract.terminalEntry.sha256}') { throw 'Reviewed terminal entry changed' }
. $arcEntry
    $arcExit = Invoke-ArcFixedTerminalCommand -Role '${role.role}' -ContractPath ${quote(contractPath)} -ContractSha256 '${contractSha256}' -LauncherPath ${quote(launcher.path)} -LauncherSha256 '${launcher.sha256}' -CommandPath $PSCommandPath
    Write-Host ('ExitCode: ' + $arcExit)
    exit $arcExit
} catch {
    [Console]::Error.WriteLine('TERMINAL_PREPARATION_REFUSED_STOP_RECONCILE_NO_RETRY')
    Write-Host 'ExitCode: 1'
    exit 1
}
`);
  return {...role,settings,...derived,launcher,command:{path:role.commandPath,sha256:hash(commandText),text:commandText}};
 });
 return {contract,contractPath,contractText,gate:{path:gatePath,sha256:gateSha256},launchers};
}
function generate(){
 assert(process.argv.length===2&&resolve(process.cwd())===root,'FIXED_WORKSPACE_NO_ARGUMENTS');
 const bundle=buildStaticArtifacts(),outputs=[{path:bundle.contractPath,text:bundle.contractText},...bundle.launchers.flatMap(x=>[{path:x.launcher.path,text:x.text},{path:x.command.path,text:x.command.text}])];
 for(const out of outputs)if(existsSync(out.path))assert(readFileSync(out.path,'utf8')===out.text,'EXISTING_STATIC_OUTPUT_CHANGED');
 for(const out of outputs)if(!existsSync(out.path))writeFileSync(out.path,out.text,{flag:'wx'});
 const manifest={schemaVersion:'arc-guarded-launcher-derivation-v1',status:'STATIC_GENERATION_ONLY_NO_OPERATIONAL_EVIDENCE',source:bundle.contract.source,driver:FIXED.driver,
  correctedPriorDerivation:{path:priorPath,sha256:priorSha256},generator:ref(resolve(here,'prepare-launchers.mjs')),readiness:bundle.gate,contract:ref(bundle.contractPath),inverseByteChecks:9,
  launchers:bundle.launchers.map(({role,scenarioId,mode,reportName,launcher,command,edits})=>({role,scenarioId,mode,reportName,launcher,command:{path:command.path,sha256:command.sha256},inversionMatchesOriginal:true,edits})),
  readinessRecordsCreated:0,credentialReads:0,controlCalls:0,providerCalls:0};
 const path=resolve(here,'launcher-derivation.json'),text=JSON.stringify(manifest,null,2)+'\n';
 if(existsSync(path))assert(readFileSync(path,'utf8')===text,'EXISTING_DERIVATION_CHANGED');else writeFileSync(path,text,{flag:'wx'});
 console.log(JSON.stringify({status:manifest.status,launchers:9,commands:9,inverseByteChecks:9,operationalEvidenceCreated:false}));
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url)generate();
