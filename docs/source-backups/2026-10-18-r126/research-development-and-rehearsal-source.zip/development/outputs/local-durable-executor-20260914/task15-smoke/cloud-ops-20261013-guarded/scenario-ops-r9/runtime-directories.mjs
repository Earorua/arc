// Fixed runtime parents only. Individual observations and evidence stay exclusive.
import {mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
const runtimeDirectoryNames = ['terminal', 'observations', 'clocks', 'receipts', 'handoffs', 'controls'];
export function ensureRuntimeDirectories(root) {
  for (const name of runtimeDirectoryNames) mkdirSync(resolve(root, name), {recursive: true});
}
