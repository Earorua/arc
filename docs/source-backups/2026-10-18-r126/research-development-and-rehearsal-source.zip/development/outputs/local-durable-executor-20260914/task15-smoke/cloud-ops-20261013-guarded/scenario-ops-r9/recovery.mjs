// One fixed incomplete-closure allowance. This never changes Task1 continuation rules.
import {existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {FIXED,here,assert,same,integer,utc,ref,write,jsonRef,assertContext,assertMaterials,createValidationContext,main} from './guards.mjs';
import {loadGate,loadOperation} from './evaluate.mjs';
import {loadClock} from './prepare-observation.mjs';
export const recoveryPath=resolve(here,'incomplete-closure.json');
export const RECOVERY_PHASES=Object.freeze(['reconcile-activate','reconcile-site-roster','pre-admission-close','post-admission-close','reconcile-admission-close','pre-maintenance-close','post-maintenance-close','reconcile-maintenance-close','drain-first','drain-second','scheduled']);
export function recoveryValue(spec,{activation,native,originalClocks,closureEntry,now}){
 assert(spec.rootReviewed===true&&['budget-or-cutoff','native-or-control-failure','operator-stop'].includes(spec.cause),'EXACT_INCOMPLETE_CLOSURE_CAUSE');
 assert(activation.kind==='activate'&&activation.mode==='deploy'&&originalClocks.activationStartedAt===utc(activation.commandStartedAt)&&originalClocks.stageStartedAt>=originalClocks.activationStartedAt&&utc(native.startedAt)<=utc(native.endedAt)&&utc(native.endedAt)<=now,'ACTUAL_RECOVERY_SOURCE_CLOCKS');
 const anchorAt=closureEntry?Math.min(utc(closureEntry.enteredAt),now):now;assert(integer(now)&&anchorAt>=originalClocks.activationStartedAt,'ORIGINAL_RECOVERY_ANCHOR');
 return {schemaVersion:'arc-guarded-incomplete-closure-v1',rootReviewed:true,epoch:FIXED.epoch,inventory:FIXED.inventory,addendum:FIXED.closureAddendum,activationResult:spec.activationResult,lastNativeGate:spec.lastNativeGate,clockReference:spec.clockReference,materials:spec.materials,cause:spec.cause,closureEntry:spec.closureEntry??null,originalClocks,createdAt:new Date(now).toISOString(),anchorAt,deadlineAt:anchorAt+3600000,disposition:'INCOMPLETE',permanentIncomplete:true};
}
export function recoveryBudget(r,{phase,now,preparedAt}){
 assert(r?.schemaVersion==='arc-guarded-incomplete-closure-v1'&&r.epoch===FIXED.epoch&&same(r.inventory,FIXED.inventory)&&same(r.addendum,FIXED.closureAddendum)&&r.permanentIncomplete===true&&r.disposition==='INCOMPLETE'&&integer(r.anchorAt)&&r.deadlineAt===r.anchorAt+3600000&&r.anchorAt<=utc(r.createdAt),'FIXED_RECOVERY_AUTHORITY');
 assert(RECOVERY_PHASES.includes(phase)&&integer(preparedAt)&&preparedAt>=utc(r.createdAt)&&preparedAt<=now&&now<r.deadlineAt,'RECOVERY_PHASE_OR_EXPIRED');const operationDeadlineAt=Math.min(r.deadlineAt,preparedAt+300000);assert(now<operationDeadlineAt,'RECOVERY_COLLECTION_EXPIRED');return {operationDeadlineAt,cloudContactAllowed:true,canAdvance:true,permanentIncomplete:true,disposition:'INCOMPLETE'};
}
export function assertRecoveryRequestBinding(q,r){assert(q.incompleteClosure&&same(q.recoveryWindow,r)&&same(q.clockReference,r.clockReference)&&same(q.clock,r.originalClocks)&&same(q.materials,r.materials)&&same(q.inventory,r.inventory)&&q.permanentIncomplete===true,'EXACT_RECOVERY_REQUEST_BINDING');}
export function incompleteOutcome(result,reference){return reference?{...result,incompleteClosure:reference,nativeChecksPassed:result.allChecksPassed,allChecksPassed:false,permanentIncomplete:true,disposition:result.allChecksPassed?'INCOMPLETE':result.disposition??'INCOMPLETE'}:result;}
function sourceValue(c,spec,now){assertContext(c);assertMaterials(spec.materials,c);const activation=loadOperation(c,spec.activationResult,{allowUnknown:true}),native=loadGate(c,spec.lastNativeGate,{fresh:false,allowIncomplete:true}),originalClocks=loadClock(c,spec.clockReference),clock=c.read(spec.clockReference);
 assert(same(clock.activationResult,spec.activationResult),'ORIGINAL_RECOVERY_ACTIVATION');
 // Unknown activation has only its actual preactivation predecessor; it does not imply success.
 if(native.phase==='preactivation')assert(same(activation.predecessorGate,spec.lastNativeGate)&&clock.stage==='activation','ORIGINAL_UNKNOWN_ACTIVATION_PREDECESSOR');
 else assert(same(c.read(native.request.clockReference).activationResult,spec.activationResult),'RECOVERY_NATIVE_ACTIVATION_LINEAGE');
 const closureEntry=spec.closureEntry?c.read(spec.closureEntry):null;if(closureEntry)assert(spec.closureEntry.path===resolve(here,'closure-entry.json')&&closureEntry.schemaVersion==='arc-guarded-closure-entry-v1'&&closureEntry.rootReviewed===true&&same(closureEntry.activationResult,spec.activationResult),'ACTUAL_EARLIER_CLOSURE_ENTRY');
 return recoveryValue(spec,{activation,native,originalClocks,closureEntry,now});
}
export function createIncompleteClosure(c,spec){assert(!existsSync(recoveryPath),'EXCLUSIVE_RECOVERY_ALREADY_CONSUMED');const path=resolve(here,'closure-entry.json'),closureEntry=existsSync(path)?ref(path):null;assert(!spec.closureEntry||same(spec.closureEntry,closureEntry),'ACTUAL_EXISTING_CLOSURE_ENTRY');return write(recoveryPath,sourceValue(c,{...spec,closureEntry},Date.now()));}
export function loadIncompleteClosure(c,reference){assert(reference?.path===recoveryPath,'FIXED_RECOVERY_PATH');const stored=c.read(reference),value=sourceValue(c,stored,utc(stored.createdAt));assert(same(stored,value),'IMMUTABLE_RECOVERY_SOURCE_BINDING');return value;}
export function assertRecoveryUse(c,reference,now){
 if(!existsSync(recoveryPath)){assert(!reference,'MISSING_RECOVERY_AUTHORITY');return null;}
 const actual=ref(recoveryPath),stored=c.read(actual);if(now<utc(stored.createdAt)){assert(!reference,'FUTURE_RECOVERY_AUTHORITY');return null;}
 assert(same(reference,actual),'PERMANENT_INCOMPLETE_AUTHORITY_REQUIRED');return loadIncompleteClosure(c,actual);
}
export function assertNoRecoveryControl(c,now){if(existsSync(recoveryPath))assert(now<utc(c.read(ref(recoveryPath)).createdAt),'INCOMPLETE_RECOVERY_FORBIDS_SIGNED_CONTROL');}
await main(import.meta.url,()=>{assert(process.argv.length===4,'EXACT_RECOVERY_SPEC_PATH_SHA');const c=createValidationContext(),spec=jsonRef({path:resolve(process.argv[2]),sha256:process.argv[3]});console.log(JSON.stringify({incompleteClosure:createIncompleteClosure(c,spec),disposition:'INCOMPLETE'}));});
