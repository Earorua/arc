// In-memory filesystem boundary only: no report, control, or operational output is created.
import test from 'node:test';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {runInNewContext} from 'node:vm';
import {assertUnusedSuccessorScope} from './evaluate.mjs';
import {G,here,assert as gateAssert} from './guards.mjs';
import {SCENARIO_IDS} from './contracts.mjs';

const modes=['start','status','replay'];
const reports=suffix=>SCENARIO_IDS.flatMap(id=>modes.map(mode=>resolve(G,'..',`cloud-guarded-${id}-${mode}-${['r7','r8','r9'].includes(suffix)?'20261016':suffix==='r6'?'20261015':'20261014'}-${suffix}`)));
function scopeWith(existing=[]){
 const present=new Set(existing),checked=[];
 // Execute the real exported function, replacing only its filesystem boundary.
 const check=runInNewContext('('+assertUnusedSuccessorScope.toString()+')',{
  resolve,G,here,SCENARIO_IDS,assert:gateAssert,
  existsSync:path=>{checked.push(path);return present.has(path);},
  readdirSync:path=>present.has(path)?['existing-evidence']:[],
 });
 return {check,checked};
}

for(const id of SCENARIO_IDS)for(const mode of modes){
 test(`dispatch refuses existing current r8 ${id}:${mode} report`,()=>{
  const path=resolve(G,'..',`cloud-guarded-${id}-${mode}-20261016-r9`);
  const {check,checked}=scopeWith([path]);
  assert.throws(()=>check({dispatch:true}),/^Error: UNUSED_SUCCESSOR_DRIVER_REPORT_SCOPE$/);
  assert.ok(checked.includes(path));
 });
}

test('dispatch checks all current and historical report roles before accepting an unused scope',()=>{
 const {check,checked}=scopeWith();
 assert.doesNotThrow(()=>check({dispatch:true}));
 for(const suffix of ['r1','r2','r3','r4','r5','r6','r7','r8','r9'])for(const path of reports(suffix))assert.ok(checked.includes(path),path);
});

test('dispatch retains rejection for each historical r1 r2 r3 report',()=>{
 for(const suffix of ['r1','r2','r3','r4'])for(const path of reports(suffix)){
  const {check}=scopeWith([path]);
  assert.throws(()=>check({dispatch:true}),/^Error: UNUSED_SUCCESSOR_DRIVER_REPORT_SCOPE$/);
 }
});

test('historical reconstruction permits legitimate current reports and operational evidence',()=>{
 const currentPaths=['controls','handoffs','receipts','clocks','roster-preparation.json','replay-approval.json','replay-native-evidence.json','wrangler.site-roster.json'].map(name=>resolve(here,name));
 const existing=[...reports('r3'),...reports('r4'),...reports('r5'),...reports('r6'),...reports('r7'),...reports('r8'),...reports('r9'),...currentPaths];
 for(const options of [undefined,{dispatch:false}]){
  const {check,checked}=scopeWith(existing);
  assert.doesNotThrow(()=>check(options));
  for(const path of existing)assert.ok(!checked.includes(path),path);
 }
});

test('historical reconstruction retains rejection for each r1 and r2 report',()=>{
 for(const suffix of ['r1','r2'])for(const path of reports(suffix)){
  const {check}=scopeWith([path]);
  assert.throws(()=>check({dispatch:false}),/^Error: UNUSED_SUCCESSOR_DRIVER_REPORT_SCOPE$/);
 }
});
