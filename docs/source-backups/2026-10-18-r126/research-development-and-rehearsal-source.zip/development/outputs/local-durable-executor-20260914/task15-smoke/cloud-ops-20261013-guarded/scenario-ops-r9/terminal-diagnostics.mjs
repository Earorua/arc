// Original r6 diagnostics are historical proof only; new bytes have distinct reset authority.
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import strict from 'node:assert/strict';
import {createHash} from 'node:crypto';
const historical={"path":"C:\\Users\\XF\\Documents\\Codex\\2026-07-26\\sites-plugin-sites-openai-bundled-2\\.worktrees\\v8-openrouter-research-beta\\outputs\\local-durable-executor-20260914\\task15-smoke\\cloud-ops-20261013-guarded\\scenario-ops-r6\\terminal-diagnostics.mjs","sha256":"0e48fbaf01e57c9834adf481a0945a64ba613dcbe41cff2cd0e7fef0e90d60ef"};
strict.equal(createHash('sha256').update(readFileSync(historical.path)).digest('hex'),historical.sha256,'EXACT_HISTORICAL_DIAGNOSTIC_CODE');
const {loadTerminalDiagnostics:original}=await import(pathToFileURL(historical.path));
export function loadTerminalDiagnostics(read,verify){verify(historical);return original(read,verify);}
