// Fixed attended command preparation. No operation occurs on import.
import {existsSync} from 'node:fs';
import {ensureRuntimeDirectories} from './runtime-directories.mjs';
import {resolve,dirname} from 'node:path';
import {FIXED,here,assert,same,integer,uuid,utc,ref,write,createValidationContext,assertCurrentPins,main} from './guards.mjs';
import {fixedRole,loadTerminalTemplate,terminalPins,AUTHORITY_MODE,acknowledgementDeadline,assertAcknowledgement,preparationDeadline} from './terminal-contract.mjs';
import {prepareObservation,createStageClock,loadPreparation} from './prepare-observation.mjs';
import {collect} from './collect.mjs';
import {evaluateNative,loadGate,loadOperation,loadClosedBaseline,previewSignedHandoff,prepareSignedHandoff,validateSignedHandoff} from './evaluate.mjs';
import {operate} from './operate.mjs';
export function assertUnusedTerminalFacts(facts){assert(Object.values(facts).every(x=>x===false),'TERMINAL_ALREADY_CONSUMED_NO_RETRY');}
function unused(r,{own=false}={}){const names=['prepared','acknowledgement','readiness','handoff','attempt','exit','failure','shellFailure',...(!own?['invocation']:[])];assertUnusedTerminalFacts({...Object.fromEntries(names.map(k=>[k,existsSync(r[k+'Path'])])),report:existsSync(dirname(r.reportPath))});}
const policyFields=reference=>({rootReviewed:true,reviewedPolicy:reference,authorityMode:AUTHORITY_MODE,futureNativeManuallyReviewed:false});
// The dependency argument is only for labelled in-memory tests; CLI never accepts it.
// The operational sequence and targets below are fixed, with no loop or retry.
export async function runFirstPreparation(c,t,invocation,dependencies={}){
 const io={prepareObservation,collect,evaluateNative,write,ref,loadGate,loadOperation,loadClosedBaseline,createStageClock,loadPreparation,operate,now:Date.now,...dependencies};
 const nativeGate=async spec=>{
  const request=io.prepareObservation(c,{...spec,terminalPolicy:t.reference}),native=await io.collect(c,request);assert(native.allReadsSucceeded,'ACTUAL_COMPLETE_TERMINAL_NATIVE');
  const result=io.evaluateNative(c,native.reference,{now:io.now()});assert(result.allChecksPassed===true,'ACTUAL_TERMINAL_NATIVE_GATE');
  return io.write(resolve(result.request.directory,'gate-evaluation.json'),{schemaVersion:'arc-guarded-scenario-gate-v1',nativeEvidence:native.reference,evaluator:io.ref(resolve(here,'evaluate.mjs')),startedAt:result.startedAt,endedAt:result.endedAt,allChecksPassed:true,result});
 };
 const preactivation=await nativeGate({phase:'preactivation',tag:'terminal-preactivation-20261016-r9',preparation:t.preparation,materials:t.materials,state:FIXED.currentClosedAcceptance,readinessStartedAt:invocation.initialAcknowledgedAt});
 const gate=io.loadGate(c,preactivation,{fresh:true}),p=io.loadPreparation(c,t.preparation);
 assert(invocation.initialAcknowledgedAt<=utc(gate.startedAt),'INITIAL_ACTUAL_ACK_PRECEDES_NATIVE');
 const baseline=io.write(FIXED.baselinePath,{schemaVersion:'arc-guarded-successor-baseline-acceptance-v1',...policyFields(t.reference),terminalInvocation:invocation.reference,disposition:'CLOSED_EMPTY_UNUSED_BASELINE_ACCEPTED',epoch:FIXED.epoch,sequence:FIXED.sequence,successorPlan:FIXED.successorPlan,predecessorHistory:FIXED.predecessorHistory,diagnostics:FIXED.diagnostics,closedReconstruction:FIXED.closedReconstruction,terminalDiagnostics:FIXED.terminalDiagnostics,inputReset:FIXED.inputReset,initialAckTimeout:FIXED.initialAckTimeout,preparationDirectoryFailure:FIXED.preparationDirectoryFailure,supersededReviewClarification:FIXED.supersededReviewClarification,currentClosedAcceptance:FIXED.currentClosedAcceptance,gate:preactivation,nativeEvidence:gate.nativeReference,expectedVersions:gate.mapping.versions,configs:gate.mapping.configs,acceptedAt:new Date(io.now()).toISOString()});
 io.loadClosedBaseline(c,baseline,{gateReference:preactivation,now:io.now(),dispatch:true});
 const decision=io.write(resolve(here,'activate-root-policy-decision-r9.json'),{schemaVersion:'arc-guarded-scenario-operation-decision-v1',...policyFields(t.reference),terminalInvocation:invocation.reference,sequence:FIXED.sequence,disposition:'DEPLOY_EXACT_CONFIG_ONCE',kind:'activate',baseline,gate:preactivation,config:p.configs.activate,expectedVersions:gate.mapping.versions,materials:t.materials,dryRun:t.dryRuns.activate,closureDryRuns:{'admission-close':t.dryRuns['admission-close'],'maintenance-close':t.dryRuns['maintenance-close']},reviewedAt:new Date(io.now()).toISOString(),userReadyAt:invocation.initialAcknowledgedAt,validUntil:Math.min(t.validUntil,gate.request.deadlineAt,utc(gate.startedAt)+900000,invocation.initialAcknowledgedAt+900000),controlCallsAllowed:false,providerCallsAllowed:false});
 const activationResult=await io.operate(c,{kind:'activate',mode:'deploy',preparation:t.preparation,decision}),activation=io.loadOperation(c,activationResult);
 assert(activation.commandSucceeded===true&&activation.childCloseConfirmed===true,'ACTUAL_SINGLE_ACTIVATION_SUCCEEDED');
 const clockReference=io.createStageClock(c,{stage:'activation',activationResult});
 const postActivate=await nativeGate({phase:'post-activate',tag:'terminal-post-activate-20261016-r9',preparation:t.preparation,materials:t.materials,state:FIXED.currentClosedAcceptance,preflight:preactivation,clockReference,operation:activationResult});
 const prestart=await nativeGate({phase:'prestart',tag:'terminal-long-prestart-20261016-r9',scenarioId:'long',preparation:t.preparation,materials:t.materials,state:postActivate,preflight:postActivate,clockReference,completed:[]});
 const post=io.loadGate(c,postActivate,{fresh:true}),last=io.loadGate(c,prestart,{fresh:true});
 assert(utc(gate.endedAt)<=utc(activation.commandStartedAt)&&utc(activation.endedAt)<=utc(post.startedAt)&&utc(post.endedAt)<=utc(last.startedAt),'ACTUAL_PRE_POST_NATIVE_PIPELINE_ORDER');
 return {spec:{scenarioId:'long',mode:'start',materials:t.materials,state:postActivate,clockReference,nativeGate:prestart,completed:[]},events:{preactivation,baseline,decision,activationResult,clockReference,postActivate,prestart}};
}
function template(c,role,sha256){const r=fixedRole(role),reference=sha256?{path:r.templatePath,sha256}:ref(r.templatePath),value=loadTerminalTemplate(c,reference,role);return {...value,reference};}
export function inspectTerminal(c,role){const r=fixedRole(role),t=template(c,role);unused(r);assertCurrentPins(c,[t.reference,...Object.values(t.pins)]);return {status:'FIXED_LOCAL_PREPARATION_ONLY',template:t.reference,validUntil:t.validUntil,first:r.first};}
function owner({invocationId,processId,invokedAt},now){assert(uuid(invocationId)&&integer(processId)&&processId>0&&process.ppid===processId&&integer(invokedAt)&&invokedAt<=now&&now-invokedAt<900000,'ACTUAL_PARENT_TERMINAL_INVOCATION');}
function failure(r,invocation,error){if(existsSync(r.invocationPath)&&!existsSync(r.failurePath))write(r.failurePath,{schemaVersion:'arc-guarded-terminal-failure-v1',invocation,observedAt:new Date().toISOString(),disposition:'STOP_RECONCILE_NO_RETRY',rawDiagnosticPersisted:false,credentialRead:false});}
export async function prepareTerminal(c,role,sha256,input){
 const r=fixedRole(role),t=template(c,role,sha256),now=Date.now();owner(input,now);unused(r);
 const prepareDeadlineAt=preparationDeadline(t.validUntil,input.invokedAt);assert(now<prepareDeadlineAt,'ORIGINAL_PREPARATION_ALLOWANCE');
 const shellAttempt=ref(r.shellAttemptPath),shell=c.read(shellAttempt);assert(shell.schemaVersion==='arc-guarded-terminal-shell-attempt-v1'&&shell.role===role&&shell.invocationId===input.invocationId&&shell.processId===input.processId&&shell.invokedAt===input.invokedAt&&same(shell.command,ref(r.commandPath))&&same(shell.contract,ref(resolve(here,'launcher-contract.json')))&&same(shell.entry,ref(resolve(here,'terminal-entry.ps1')))&&shell.noAutomaticRetry===true,'ACTUAL_EXCLUSIVE_SHELL_ENTRY');
 assert(r.first?integer(input.initialAcknowledgedAt)&&input.invokedAt<=input.initialAcknowledgedAt&&input.initialAcknowledgedAt<=now&&now-input.initialAcknowledgedAt<60000:input.initialAcknowledgedAt===null,'ACTUAL_INITIAL_TERMINAL_ACK');
 ensureRuntimeDirectories(here);
 const invocation=write(r.invocationPath,{schemaVersion:'arc-guarded-terminal-invocation-v1',...input,shellAttempt,identity:r,reviewedPolicy:t.reference,pins:terminalPins(role),recordedAt:new Date().toISOString(),noAutomaticRetry:true,userInvocationAssumption:'USER_PERSONALLY_INVOKED_RELEASED_COMMAND_IN_ATTENDED_TERMINAL'});
 try{
  const prepared=r.first?await runFirstPreparation(c,t,{...c.read(invocation),reference:invocation}):{spec:t.spec,events:null};
  const gate=loadGate(c,prepared.spec.nativeGate,{fresh:true}),preview=previewSignedHandoff(c,prepared.spec),preparedAt=Date.now();
  assert(preparedAt<prepareDeadlineAt,'ORIGINAL_PREPARATION_ALLOWANCE');
  const deadline=acknowledgementDeadline(preview,t.validUntil,preparedAt);assertCurrentPins(c,[t.reference,...Object.values(t.pins)]);
  assert(Date.now()<deadline,'POST_VALIDATION_LOCAL_ACK_DEADLINE');
  const reference=write(r.preparedPath,{schemaVersion:'arc-guarded-terminal-prepared-v1',invocation,reviewedPolicy:t.reference,...prepared,nativeGate:prepared.spec.nativeGate,nativeEndedAt:utc(gate.endedAt),preparedAt,acknowledgementDeadlineAt:deadline,originalHandoffDeadlineAt:Math.min(preview.deadlineAt,t.validUntil),readinessCreated:false});
  return {status:'ACTUAL_NATIVE_GATE_AWAITING_LOCAL_ENTER',prepared:reference,acknowledgementDeadlineAt:deadline};
 }catch(error){failure(r,invocation,error);throw error;}
}
export function acknowledgeTerminal(c,role,sha256,input){
 const r=fixedRole(role),t=template(c,role,sha256),invocationReference=ref(r.invocationPath),invocation=c.read(invocationReference);owner({...input,invokedAt:invocation.invokedAt},Date.now());
 assert(invocation.invocationId===input.invocationId&&invocation.processId===input.processId&&same(invocation.reviewedPolicy,t.reference),'OWNED_ORIGINAL_TERMINAL_INVOCATION');
 try{
  assertUnusedTerminalFacts(Object.fromEntries(['acknowledgement','readiness','handoff','attempt','exit','failure','shellFailure'].map(k=>[k,existsSync(r[k+'Path'])])));
  assert(!existsSync(dirname(r.reportPath)),'TERMINAL_REPORT_ALREADY_CONSUMED');
  const preparedReference=ref(r.preparedPath),prepared=c.read(preparedReference);assert(same(prepared.invocation,invocationReference)&&same(prepared.reviewedPolicy,t.reference),'PINNED_ACTUAL_TERMINAL_PREPARATION');
  const gate=loadGate(c,prepared.spec.nativeGate,{fresh:true}),event={schemaVersion:'arc-guarded-terminal-acknowledgement-v1',prepared:preparedReference,invocationId:input.invocationId,processId:input.processId,invokedAt:invocation.invokedAt,initialAcknowledgedAt:invocation.initialAcknowledgedAt,preparedAt:prepared.preparedAt,nativeEndedAt:utc(gate.endedAt),promptedAt:input.promptedAt,userReadyAt:input.userReadyAt,acknowledgementDeadlineAt:prepared.acknowledgementDeadlineAt};
  assertAcknowledgement(event,{now:Date.now(),first:r.first});
  const preview=previewSignedHandoff(c,prepared.spec);assert(Math.min(preview.deadlineAt,t.validUntil)===prepared.originalHandoffDeadlineAt,'ORIGINAL_TERMINAL_DEADLINE_CANNOT_RENEW');
  assertCurrentPins(c,[t.reference,preparedReference,invocationReference,...Object.values(t.pins)]);
  assert(Date.now()+preview.inputAllowanceMs+65000+75000<prepared.originalHandoffDeadlineAt,'POST_ACK_FULL_INPUT_CHILD_VALIDATOR_RESERVES');
  const acknowledgement=write(r.acknowledgementPath,event);
  const readiness=write(r.readinessPath,{schemaVersion:'arc-guarded-attended-readiness-v1',...policyFields(t.reference),scenarioId:r.scenarioId,mode:r.mode,nativeGate:prepared.spec.nativeGate,materials:t.materials,userReadyAt:event.userReadyAt,userAttendanceSource:'ACTUAL_LOCAL_ENTER_AFTER_NATIVE_GATE',acknowledgement});
  const handoff=prepareSignedHandoff(c,{...prepared.spec,readiness}),validated=validateSignedHandoff(c,handoff,{dispatch:true});
  return {status:'LOCAL_ACK_VALIDATED_PINNED_MASKED_WRAPPER_NEXT',handoff,deadlineAt:validated.deadlineAt};
 }catch(error){failure(r,invocationReference,error);throw error;}
}
await main(import.meta.url,async()=>{
 const [command,role,sha256,invocationId,pid,first,last]=process.argv.slice(2),c=createValidationContext();
 if(command==='inspect'){assert(process.argv.length===4,'FIXED_INSPECT_ARGUMENTS');console.log(JSON.stringify(inspectTerminal(c,role)));return;}
 assert(['prepare','acknowledge'].includes(command)&&process.argv.length===9,'FIXED_TERMINAL_ARGUMENTS');
 const processId=Number(pid),input=command==='prepare'?{invocationId,processId,invokedAt:Number(first),initialAcknowledgedAt:last==='none'?null:Number(last)}:{invocationId,processId,promptedAt:Number(first),userReadyAt:Number(last)};
 console.log(JSON.stringify(command==='prepare'?await prepareTerminal(c,role,sha256,input):acknowledgeTerminal(c,role,sha256,input)));
});
