// Reconstruct only the consumed r4 auth failure and the actual independent terminal verification.
// No credential access, child, network, acceptance, or retry is performed here.
import {existsSync,readdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {FIXED,G,assert,same,integer,uuid,utc,hash,verify as verifyBytes} from './guards.mjs';
import {createValidationContext as predecessorContext,toolRefs as predecessorTools,ref as predecessorRef,FIXED as HISTORICAL} from '../scenario-ops-r4/guards.mjs';
import {fixedRole as predecessorRole,loadTerminalTemplate,terminalPins} from '../scenario-ops-r4/terminal-contract.mjs';
import {commandsFor} from '../scenario-ops-r4/read-plans.mjs';
const OUT='01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b';
const ERR='fd07d7ddb817d51b8a85924ed798de7f642eb6704c214a9a4e2959291fbb0b53';
export function assertPreactivationAuthFailureRecords(v){
 const {shell:a,shellFailure:s,invocation:i,failure:f,template:t,request:q,collection:c,checkpoint:k,native:n,reproduction:e,terminalLocation:l,codexLocation:x,login:u}=v,r=predecessorRole('long:start');
 assert(a.schemaVersion==='arc-guarded-terminal-shell-attempt-v1'&&a.role===r.role&&uuid(a.invocationId)&&integer(a.processId)&&a.processId>0&&integer(a.invokedAt)&&a.noAutomaticRetry===true&&same(a.command,predecessorRef(r.commandPath))&&same(a.contract,predecessorRef(resolve(G,'scenario-ops-r4/launcher-contract.json')))&&same(a.entry,predecessorRef(resolve(G,'scenario-ops-r4/terminal-entry.ps1'))),'EXACT_R4_CONSUMED_SHELL');
 assert(i.schemaVersion==='arc-guarded-terminal-invocation-v1'&&i.invocationId===a.invocationId&&i.processId===a.processId&&i.invokedAt===a.invokedAt&&same(i.identity,r)&&same(i.shellAttempt,predecessorRef(r.shellAttemptPath))&&same(i.pins,terminalPins(r.role))&&same(i.reviewedPolicy,predecessorRef(r.templatePath))&&i.noAutomaticRetry===true&&i.userInvocationAssumption==='USER_PERSONALLY_INVOKED_RELEASED_COMMAND_IN_ATTENDED_TERMINAL','EXACT_R4_INVOCATION');
 assert(s.schemaVersion==='arc-guarded-terminal-shell-failure-v1'&&s.role===r.role&&s.invocationId===a.invocationId&&s.processId===a.processId&&same(s.shellAttempt,i.shellAttempt)&&s.disposition==='UNKNOWN_STOP_RECONCILE_NO_RETRY'&&s.noAutomaticRetry===true&&s.rawDiagnosticPersisted===false&&s.boundedCloudChildMayStillBeRunning===true,'EXACT_R4_SHELL_FAILURE');
 assert(f.schemaVersion==='arc-guarded-terminal-failure-v1'&&same(f.invocation,predecessorRef(r.invocationPath))&&f.disposition==='STOP_RECONCILE_NO_RETRY'&&f.rawDiagnosticPersisted===false&&f.credentialRead===false,'EXACT_R4_PREPARATION_FAILURE');
 assert(t.sequence==='20261014-r4'&&same(t.currentClosedAcceptance,HISTORICAL.currentClosedAcceptance)&&same(t.identity,r)&&a.invokedAt<t.validUntil&&integer(i.initialAcknowledgedAt)&&a.invokedAt<=i.initialAcknowledgedAt&&i.initialAcknowledgedAt<=utc(i.recordedAt),'EXACT_R4_ORIGINAL_POLICY');
 const dir=resolve(G,'scenario-ops-r4/observations/terminal-preactivation-20261014-r4');
 assert(q.schemaVersion==='arc-guarded-scenario-request-v1'&&q.phase==='preactivation'&&q.tag==='terminal-preactivation-20261014-r4'&&q.directory===dir&&q.scenarioId===null&&same(q.state,HISTORICAL.currentClosedAcceptance)&&same(q.terminalPolicy,i.reviewedPolicy)&&q.readinessStartedAt===i.initialAcknowledgedAt&&q.clock===null&&q.clockReference===null&&q.expectedReconciliation===null&&same(q.tools,predecessorTools()),'EXACT_R4_PREACTIVATION_REQUEST');
 const commands=commandsFor(q);
 assert(c.schemaVersion==='arc-guarded-scenario-collection-attempt-v1'&&same(c.request,predecessorRef(resolve(dir,'request.json')))&&c.commandsSha256===q.commandsSha256&&q.commandsSha256===hash(JSON.stringify(commands))&&c.deadlineAt===q.deadlineAt&&[c.cloudMutations,c.controlCalls,c.providerCalls].every(x=>x===0),'EXACT_R4_COLLECTION_ATTEMPT');
 assert(n.schemaVersion==='arc-guarded-scenario-native-v1'&&n.phase==='preactivation'&&n.scenarioId===null&&same(n.request,c.request)&&same(n.attempt,predecessorRef(resolve(dir,'collection-attempt.json')))&&same(n.collector,c.collector)&&same(n.transportHelper,c.transport)&&same(n.preload,c.preload)&&n.deadlineAt===q.deadlineAt&&n.allReadsSucceeded===false&&[n.cloudMutations,n.workerControlCalls,n.providerCalls].every(x=>x===0)&&n.observations.length===1,'ONE_R4_FAILED_READ_ONLY');
 const o=n.observations[0];assert(o.id==='site-current-deployment'&&o.commandSha256===hash(JSON.stringify(commands[0].args))&&o.ok===false&&o.failureKind==='unknown'&&o.exitCode===1&&o.timedOut===false&&o.fetchFailed===false&&o.projectionRejected===false&&o.attempts.length===1,'EXACT_FIRST_FAILED_READ');
 const b=o.attempts[0];assert(b.attempt===1&&b.exitCode===1&&b.signal===null&&b.timedOut===false&&b.outputOverflow===false&&b.childCloseConfirmed===true&&b.childTimeoutMs===45000&&b.stdoutSha256===OUT&&b.stderrSha256===ERR&&b.stdoutBytes===1&&b.stderrBytes===495&&b.failureKind==='unknown'&&b.rawContentPersisted===false&&Math.floor(b.elapsedMs)===655&&utc(b.endedAt)-utc(b.startedAt)===655,'CONFIRMED_CLOSED_KNOWN_AUTH_SIGNATURE');
 const {transport,endedAt,allReadsSucceeded,...checkpointBase}=n;assert(same(k,{...checkpointBase,complete:false})&&transport.halted===null&&transport.budgetExhausted===false&&utc(c.at)<=utc(n.startedAt)&&utc(n.startedAt)<=utc(b.startedAt)&&utc(b.endedAt)<=utc(n.endedAt)&&utc(n.endedAt)<=utc(f.observedAt)&&utc(f.observedAt)<=s.observedAt,'ORDERED_R4_FAILURE_CHECKPOINT');
 assert(e.schemaVersion==='arc-r4-isolated-empty-auth-diagnosis-v1'&&e.exitCode===1&&e.stdoutSha256===OUT&&e.stderrSha256===ERR&&e.stdoutBytes===1&&e.stderrBytes===495&&e.noninteractiveTokenRequired===true&&e.matchesOriginalStderr===true&&e.networkMetadata===false&&e.isolatedTemporaryProfile===true&&e.realCredentialFilesRead===false&&e.rawContentPersisted===false,'EXACT_EMPTY_AUTH_REPRODUCTION');
 assert(l.schemaVersion==='arc-local-auth-location-v1'&&x.schemaVersion===l.schemaVersion&&l.mode==='terminal'&&x.mode==='codex'&&l.selectedAuthFilePresent===false&&x.selectedAuthFilePresent===true&&l.selectedLocation==='xdg'&&x.selectedLocation==='xdg'&&l.selectedPathHash===x.selectedPathHash&&l.credentialContentRead===false&&x.credentialContentRead===false&&l.networkRequests===0&&x.networkRequests===0,'OBSERVED_AUTH_LOCATION_METADATA_ONLY');
 assert(u.schemaVersion==='arc-user-terminal-login-verification-v1'&&u.status==='AUTHENTICATED_EXPECTED_SITE_READ_PASSED'&&u.exitCode===0&&u.spawnError===false&&u.noninteractiveAuthenticationRequired===false&&u.rawContentPersisted===false&&u.currentDeployment.worker===FIXED.workers.site&&u.currentDeployment.versionId===FIXED.versions.site&&u.currentDeployment.deploymentId==='ac4711cc-3cdb-4b0d-a312-b5be27011ae9'&&[u.cloudMutations,u.workerControlCalls,u.providerCalls].every(x=>x===0)&&utc(u.startedAt)>Math.max(s.observedAt,utc(l.observedAt),utc(e.endedAt))&&utc(u.startedAt)<utc(u.endedAt),'ACTUAL_INDEPENDENT_TERMINAL_AUTH_PREFLIGHT');
 return true;
}
export function assertPreactivationAuthFailureScope({exists=existsSync,list=readdirSync}={}){
 const dir=resolve(G,'scenario-ops-r4'),obs=resolve(dir,'observations/terminal-preactivation-20261014-r4');
 assert(same(list(resolve(dir,'terminal')).sort(),['long-start-failure.json','long-start-invocation.json','long-start-shell-attempt.json','long-start-shell-failure.json']),'ONLY_CONSUMED_R4_TERMINAL_RECORDS');
 assert(same(list(resolve(dir,'templates')).sort(),['long-start.json'])&&same(list(resolve(dir,'observations')).sort(),['terminal-preactivation-20261014-r4'])&&same(list(obs).sort(),['checkpoint-1.json','collection-attempt.json','native-evidence.json','request.json','wrangler.executor.readonly.json','wrangler.site.readonly.json']),'ONLY_CONSUMED_R4_ONE_READ_EVIDENCE');
 for(const name of ['controls','clocks','handoffs','receipts'])assert(!exists(resolve(dir,name))||list(resolve(dir,name)).length===0,'NO_R4_CONTROL_CLOCK_HANDOFF_RECEIPT');
 for(const kind of ['activate','admission-close','maintenance-close','site-roster'])for(const outcome of ['attempt','result'])assert(!exists(resolve(dir,kind+'-deploy-'+outcome+'.json')),'NO_R4_DEPLOYMENT');
 for(const name of ['activate-deploy-attempt.json','activate-deploy-result.json','closed-baseline-acceptance.json','activate-root-policy-decision-r4.json','roster-preparation.json','replay-approval.json','replay-native-evidence.json','wrangler.site-roster.json'])assert(!exists(resolve(dir,name)),'NO_R4_ACTIVATION_OR_ROSTER');
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay']){
  const r=predecessorRole(id+':'+mode);
  for(const key of ['preparedPath','acknowledgementPath','readinessPath','handoffPath','attemptPath','exitPath'])assert(!exists(r[key]),'NO_R4_DOWNSTREAM_ROLE_RECORD');
  assert(!exists(dirname(r.reportPath)),'NO_R4_DRIVER_REPORT');
 }
 return true;
}
export function loadPreactivationAuthFailure(read,verify){
 const reference=FIXED.predecessorHistory.preactivationAuthFailure,h=read(reference);
 assert(h.schemaVersion==='arc-preactivation-auth-failure-history-v1'&&h.sequence==='20261014-r5'&&h.deeperCauseEstablished===false&&h.earlyAuthPreflight==='ACTUAL_SEPARATE_USER_TERMINAL_LOGIN_VERIFICATION'&&h.additionalNetworkCheckRequired===false&&h.task15Accepted===false,'EXACT_AUTH_SUCCESSOR_HISTORY');
 const records=Object.fromEntries(Object.entries(h.records).map(([key,pin])=>[key,read(pin)]));assertPreactivationAuthFailureRecords(records);
 for(const pin of Object.values(predecessorTools()))verify(pin);
 const c=predecessorContext();loadTerminalTemplate(c,h.records.template,'long:start',{now:records.shell.invokedAt});
 assertPreactivationAuthFailureScope();
 // Archived JSON is verified as immutable bytes, without reinterpreting repaired historical graphs.
 const snapshot=JSON.parse(verifyBytes(h.predecessorSnapshot));for(const pin of snapshot.files)verifyBytes(pin);
 return Object.freeze({reference,login:h.records.login,native:h.records.native,childCloseConfirmed:true,safePreactivationSuccessor:true,oldAttemptMustNotBeRepeated:true,deeperCauseEstablished:false,additionalNetworkCheckPerformed:false});
}
