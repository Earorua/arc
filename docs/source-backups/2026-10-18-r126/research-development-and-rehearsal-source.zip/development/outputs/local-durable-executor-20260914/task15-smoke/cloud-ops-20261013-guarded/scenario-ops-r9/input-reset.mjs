// Distinct local correction and actual ConsoleHost proof. Supplies no cloud attendance.
import {resolve} from 'node:path';
import {FIXED,here,assert,same,ref,integer,utc} from './guards.mjs';
export function loadInputReset(read,verify){
 const p=FIXED.inputReset;
 for(const pin of Object.values(p))verify(pin);
 const a=read(p.acceptance),h=read(p.hostAcceptance),e=read(p.actualResult);
 assert(a.schemaVersion==='arc-local-input-reset-root-acceptance-v1'&&a.rootReviewed===true&&a.disposition==='LOCAL_COMPONENT_ACCEPTED_ATTENDED_HOST_CHECK_PENDING'&&a.operationalReadinessCreated===false&&a.operationalSuccessorReleased===false&&a.task15Accepted===false&&a.originalR6Unchanged===true&&a.cloudCalls===0&&a.providerCalls===0&&a.credentialAccess===0,'EXACT_LOCAL_RESET_ACCEPTANCE');
 assert(same(a.candidate,p.candidate)&&same(a.source,p.source)&&same(a.hostCheck.script,p.helper)&&a.hostCheck.attendedResultPath===p.actualResult.path&&a.hostCheck.attendedPassed===false,'ORIGINAL_RESET_ACCEPTANCE_FACTS_PRESERVED');
 assert(h.schemaVersion==='arc-local-input-reset-attended-root-acceptance-v1'&&h.rootReviewed===true&&h.disposition==='ACTUAL_LOCAL_HOST_INPUT_RESET_PASSED_NOT_CLOUD_READINESS'&&same(h.componentAcceptance,p.acceptance)&&same(h.candidate,p.candidate)&&same(h.originalSource,p.source)&&same(h.helper,p.helper)&&same(h.actualResult,p.actualResult),'EXACT_ACTUAL_HOST_BINDINGS');
 assert(h.operationalReadiness===false&&h.cloudReady===false&&h.operationalSuccessorAuthorizedByThisRecord===false&&h.task15Accepted===false&&h.cloudCalls===0&&h.controlCalls===0&&h.providerCalls===0,'LOCAL_HOST_PROOF_NEVER_SUPPLIES_AUTHORITY');
 assert(e.schemaVersion==='arc-local-input-reset-host-check-v1'&&e.candidateSha256===p.candidate.sha256&&e.localOnly===true&&e.syntheticGuardCheck===false&&e.powershellMajor===5&&e.consoleHost===true&&e.inputRedirected===false&&e.outputRedirected===false&&e.bufferedBeforeReset===true&&e.resetAttempted===true&&e.resetSucceeded===true&&e.freshEnterAccepted===true&&e.accepted===true&&e.stage==='attended-check-complete'&&e.credentialReads===0&&e.credentialPrompts===0&&e.cloudCalls===0&&e.providerCalls===0&&e.operationalReadinessCreated===false,'ACTUAL_NONSYNTHETIC_UNREDIRECTED_RESET_REQUIRED');
 assert([e.startedAt,e.promptedAt,e.userReadyAt,e.endedAt].every(integer)&&e.startedAt<e.promptedAt&&e.promptedAt<e.userReadyAt&&e.userReadyAt<=e.endedAt&&utc(h.acceptedAt)>=e.endedAt,'ACTUAL_RESET_FRESH_ENTER_CHRONOLOGY');
 assert(same(h.actualEvidence,{startedAt:e.startedAt,endedAt:e.endedAt,promptedAt:e.promptedAt,userReadyAt:e.userReadyAt,consoleHost:true,powershellMajor:5,bufferedInputDiscarded:true,freshEnterAccepted:true,syntheticInput:false}),'ACTUAL_HOST_ACCEPTANCE_MAPPING');
 const entry=ref(resolve(here,'terminal-entry.ps1'));assert(entry.sha256===p.candidate.sha256,'EXACT_REVIEWED_RESET_ENTRY_BYTES');verify(entry);
 return Object.freeze({reference:structuredClone(p.acceptance),hostReference:structuredClone(p.hostAcceptance),entry,localHostBehaviorProved:true,operationalReadiness:false,cloudAttendanceProved:false,signedControlAuthority:false});
}
