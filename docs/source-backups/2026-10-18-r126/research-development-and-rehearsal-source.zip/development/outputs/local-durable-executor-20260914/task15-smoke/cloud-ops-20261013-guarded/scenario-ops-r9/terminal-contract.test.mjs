// All records below are in-memory OFFLINE fixtures; no terminal or cloud is used.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as terminal from './terminal-contract.mjs';
const a=1000000;
test('fixed terminal role rejects arbitrary roles and templates',()=>{
 assert.equal(typeof terminal.fixedRole,'function');
 assert.equal(terminal.fixedRole('long:start').reportName,'cloud-guarded-long-start-20261016-r9');
 for(const role of ['long:START','arbitrary:start','long:start:again','../long:start'])assert.throws(()=>terminal.fixedRole(role));
});
test('local acknowledgement reserves input, validation and full65s from original deadline',()=>{
 assert.equal(typeof terminal.acknowledgementDeadline,'function');
 assert.equal(terminal.acknowledgementDeadline({deadlineAt:a+600000,inputAllowanceMs:60000,childReserveMs:65000},a+900000,a),a+365000);
 assert.throws(()=>terminal.acknowledgementDeadline({deadlineAt:a+235000,inputAllowanceMs:60000,childReserveMs:65000},a+900000,a),/LOCAL_ACK/);
});
test('actual ordered native-end and local acknowledgement are required',()=>{
 assert.equal(typeof terminal.assertAcknowledgement,'function');
 const event={invocationId:'11111111-1111-4111-8111-111111111111',processId:100,invokedAt:a,initialAcknowledgedAt:a+1,preparedAt:a+3000,nativeEndedAt:a+2000,promptedAt:a+3001,userReadyAt:a+3002,acknowledgementDeadlineAt:a+4000};
 terminal.assertAcknowledgement(event,{now:a+3002,first:true});
 for(const change of [{userReadyAt:a+4000},{userReadyAt:a+1000},{promptedAt:a+1999},{initialAcknowledgedAt:null},{processId:0},{userReadyAt:a+4001}])assert.throws(()=>terminal.assertAcknowledgement({...event,...change},{now:a+3002,first:true}));
});
