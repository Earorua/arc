// Actual immutable r3 evidence, mutated only in memory for negative checks.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {root,here} from './guards.mjs';
const path=resolve(here,'precloud-expiry.mjs');
const implementation=existsSync(path)?await import(pathToFileURL(path)):null;
const diagnosis=JSON.parse(readFileSync(resolve(root,'outputs/local-durable-executor-20261014/terminal-expiry-diagnosis-r3.json'),'utf8'));
const values=()=>({diagnosis:structuredClone(diagnosis),attempt:JSON.parse(readFileSync(diagnosis.attempt.path,'utf8')),failure:JSON.parse(readFileSync(diagnosis.failure.path,'utf8')),template:JSON.parse(readFileSync(diagnosis.template.path,'utf8'))});
test('only exact expired r3 consumed-shell evidence qualifies for local successor',()=>{
 assert.equal(typeof implementation?.assertPrecloudExpiryRecords,'function');
 const records=values();assert.equal(implementation.assertPrecloudExpiryRecords(records),true);
 for(const change of [v=>v.diagnosis.disposition='GENERIC_NO_START',v=>v.diagnosis.reproducedCode='OTHER',v=>v.diagnosis.lateByMs--,v=>v.diagnosis.downstream.invocationPath=true,v=>v.diagnosis.activationExists=true,v=>v.attempt.invokedAt=v.template.validUntil-1,v=>v.failure.invocationId='11111111-1111-4111-8111-111111111111',v=>v.template.currentClosedAcceptance.sha256='0'.repeat(64)]){
  const v=values();change(v);assert.throws(()=>implementation.assertPrecloudExpiryRecords(v));
 }
});
