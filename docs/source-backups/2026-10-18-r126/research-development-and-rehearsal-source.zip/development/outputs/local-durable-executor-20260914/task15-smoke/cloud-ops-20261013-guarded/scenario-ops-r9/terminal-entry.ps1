# Fixed attended shell functions only. Dot-sourcing has no input, writes or child side effects.
# Isolated local diagnostic derivative; not a released operational entry.
function New-ArcTerminalDiagnosticContext {
    return @{stage='inspect-child';child=$null;acknowledgement=$null}
}
function Get-ArcTerminalFailureCode([Exception]$Exception) {
    $arcKnownCodes=@('ORIGINAL_PREPARATION_ALLOWANCE','ACTUAL_ATTENDED_CONSOLE_REQUIRED','TERMINAL_PIN_CHANGED','LOCAL_ACK_EXPIRED_OR_PREBUFFERED_INPUT','ONLY_ENTER_ACKNOWLEDGEMENT_ALLOWED','LOCAL_ACK_DEADLINE_EXPIRED','BOUNDED_TERMINAL_CHILD_DEADLINE','FIXED_TERMINAL_CHILD_ARGUMENT','TERMINAL_CHILD_TIMEOUT_STOP_RECONCILE','TERMINAL_CHILD_FAILED_STOP_RECONCILE','FIXED_RELEASED_TERMINAL_ROLE','TERMINAL_POST_ACK_RESERVES','MASKED_CHILD_FAILED_STOP_RECONCILE','LOCAL_ACK_BUFFER_RESET_FAILED')
    if ($null -ne $Exception -and $arcKnownCodes -ccontains $Exception.Message) { return $Exception.Message }
    return 'OTHER_LOCAL_EXCEPTION'
}
function Get-ArcTerminalFailureDiagnostic([Collections.IDictionary]$DiagnosticContext,[Exception]$Exception) {
    $arcStages=@('inspect-child','initial-enter','prepare-child','post-native-enter','acknowledge-child','post-ack-validation','masked-child','complete')
    $arcSafe=[ordered]@{schemaVersion='arc-terminal-diagnostics-v1';stage='unavailable';code=(Get-ArcTerminalFailureCode $Exception)}
    if ($null -eq $DiagnosticContext) { return $arcSafe }
    if ($DiagnosticContext.stage -is [string] -and $arcStages -ccontains $DiagnosticContext.stage) { $arcSafe.stage=$DiagnosticContext.stage }
    $arcSource=$DiagnosticContext.child
    if ($arcSource -is [Collections.IDictionary]) {
        $arcChildSafe=[ordered]@{stage='unavailable'}
        if ($arcSource.stage -is [string] -and $arcStages -ccontains $arcSource.stage) { $arcChildSafe.stage=$arcSource.stage }
        foreach($arcKey in @('started','exitedObserved','drainComplete','jsonParseSucceeded')) {
            if ($arcSource[$arcKey] -is [bool]) { $arcChildSafe[$arcKey]=$arcSource[$arcKey] }
        }
        if ($arcChildSafe.exitedObserved -eq $true -and $arcSource.exitCode -is [int]) { $arcChildSafe.exitCode=$arcSource.exitCode }
        foreach($arcKey in @('stdoutCharacters','stderrCharacters','elapsedMs')) {
            $arcNumber=$arcSource[$arcKey]
            if (($arcNumber -is [int] -or $arcNumber -is [long]) -and $arcNumber -ge 0 -and ($arcKey -ceq 'elapsedMs' -or $arcChildSafe.drainComplete -eq $true)) { $arcChildSafe[$arcKey]=$arcNumber }
        }
        $arcSafe.child=$arcChildSafe
    }
    $arcSource=$DiagnosticContext.acknowledgement
    if ($arcSource -is [Collections.IDictionary]) {
        $arcAckSafe=[ordered]@{stage='unavailable'}
        if ($arcSource.stage -is [string] -and $arcStages -ccontains $arcSource.stage) { $arcAckSafe.stage=$arcSource.stage }
        if ($arcSource.bufferedInputPresent -is [bool]) { $arcAckSafe.bufferedInputPresent=$arcSource.bufferedInputPresent }
        foreach($arcKey in @('inputBufferResetAttempted','inputBufferResetSucceeded')) { if ($arcSource[$arcKey] -is [bool]) { $arcAckSafe[$arcKey]=$arcSource[$arcKey] } }
        if ($arcSource.deadlineRemainingMs -is [int] -or $arcSource.deadlineRemainingMs -is [long]) { $arcAckSafe.deadlineRemainingMs=$arcSource.deadlineRemainingMs }
        $arcSafe.acknowledgement=$arcAckSafe
    }
    return $arcSafe
}
function Get-ArcTerminalMs { [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
function Get-ArcPreparationDeadline([long]$PackageValidUntil,[long]$InvokedAt) {
    if ($InvokedAt -lt 0 -or $PackageValidUntil -le $InvokedAt -or $InvokedAt -gt ([long]::MaxValue-905000)) { throw 'ORIGINAL_PREPARATION_ALLOWANCE' }
    return [Math]::Min($PackageValidUntil,$InvokedAt+905000)
}
function Assert-ArcAttendedConsole {
    if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected -or $Host.Name -cne 'ConsoleHost') { throw 'ACTUAL_ATTENDED_CONSOLE_REQUIRED' }
}
function Assert-ArcTerminalReference($Reference) {
    if ($null -eq $Reference -or $Reference.sha256 -cnotmatch '\A[a-f0-9]{64}\z' -or
        (Get-FileHash -LiteralPath $Reference.path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant() -cne $Reference.sha256) { throw 'TERMINAL_PIN_CHANGED' }
}
function New-ArcTerminalExclusiveJson([string]$Path,$Value) {
    $arcStream=$null
    try {
        $arcBytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 20 -Compress)+"`n")
        $arcStream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $arcStream.Write($arcBytes,0,$arcBytes.Length); $arcStream.Flush($true)
    } finally { if ($null -ne $arcStream) { $arcStream.Dispose() } }
}
function Read-ArcLocalAcknowledgement([long]$DeadlineAt, [string]$Message, [Collections.IDictionary]$DiagnosticContext=$null, [switch]$ResetBufferedInput) {
    # Default observes only; the post-native opt-in may flush buffered input without reading keys.
    if ($null -ne $DiagnosticContext) {
        try {
            $arcAckDiagnostic=[ordered]@{stage=$DiagnosticContext.stage;deadlineRemainingMs=($DeadlineAt-[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())}
            $DiagnosticContext.acknowledgement=$arcAckDiagnostic
            try { $arcAckDiagnostic.bufferedInputPresent=[Console]::KeyAvailable } catch { }
            if ($ResetBufferedInput) { $arcAckDiagnostic.inputBufferResetAttempted=$false; $arcAckDiagnostic.inputBufferResetSucceeded=$false }
        } catch { }
    }
    Assert-ArcAttendedConsole
    if ((Get-ArcTerminalMs) -ge $DeadlineAt) { throw 'LOCAL_ACK_EXPIRED_OR_PREBUFFERED_INPUT' }
    $arcBufferedInputPresent=[Console]::KeyAvailable
    if ($arcBufferedInputPresent) {
        if (-not $ResetBufferedInput) { throw 'LOCAL_ACK_EXPIRED_OR_PREBUFFERED_INPUT' }
        if ($null -ne $DiagnosticContext -and $DiagnosticContext.acknowledgement -is [Collections.IDictionary]) { $DiagnosticContext.acknowledgement.inputBufferResetAttempted=$true }
        try {
            $Host.UI.RawUI.FlushInputBuffer()
            if ([Console]::KeyAvailable) { throw 'LOCAL_ACK_BUFFER_RESET_FAILED' }
        } catch { throw 'LOCAL_ACK_BUFFER_RESET_FAILED' }
        if ($null -ne $DiagnosticContext -and $DiagnosticContext.acknowledgement -is [Collections.IDictionary]) { $DiagnosticContext.acknowledgement.inputBufferResetSucceeded=$true }
        if ((Get-ArcTerminalMs) -ge $DeadlineAt) { throw 'LOCAL_ACK_DEADLINE_EXPIRED' }
        Write-Host 'Early input was discarded. A new Enter is required. Do not paste C until the prompt appears.'
    }
    if ((Get-ArcTerminalMs) -ge $DeadlineAt) { throw 'LOCAL_ACK_DEADLINE_EXPIRED' }
    Write-Host $Message
    $arcPromptedAt=Get-ArcTerminalMs
    while ((Get-ArcTerminalMs) -lt $DeadlineAt) {
        if ([Console]::KeyAvailable) {
            $arcKey=[Console]::ReadKey($true)
            if ($arcKey.Key -ne [ConsoleKey]::Enter) { throw 'ONLY_ENTER_ACKNOWLEDGEMENT_ALLOWED' }
            $arcReadyAt=Get-ArcTerminalMs
            if ($arcReadyAt -ge $DeadlineAt) { throw 'LOCAL_ACK_DEADLINE_EXPIRED' }
            return [pscustomobject]@{promptedAt=$arcPromptedAt;userReadyAt=$arcReadyAt}
        }
        Start-Sleep -Milliseconds 50
    }
    throw 'LOCAL_ACK_DEADLINE_EXPIRED'
}
function Invoke-ArcTerminalChild($Contract, [string[]]$Values, [long]$DeadlineAt, [int]$MaximumWaitMs, [Collections.IDictionary]$DiagnosticContext=$null) {
    $arcChildDiagnostic=[ordered]@{stage='unavailable';started=$false;exitedObserved=$false;drainComplete=$false;jsonParseSucceeded=$false;elapsedMs=[long]0}
    if ($null -ne $DiagnosticContext) { try { $arcChildDiagnostic.stage=$DiagnosticContext.stage; $DiagnosticContext.child=$arcChildDiagnostic } catch { } }
    $arcDiagnosticClock=[Diagnostics.Stopwatch]::StartNew()
    try {
    Assert-ArcTerminalReference $Contract.node
    Assert-ArcTerminalReference $Contract.terminalBackend
    $arcRemaining=[Math]::Min($MaximumWaitMs,$DeadlineAt-(Get-ArcTerminalMs))
    if ($arcRemaining -le 0 -or $MaximumWaitMs -gt 905000 -or $MaximumWaitMs -le 0) { throw 'BOUNDED_TERMINAL_CHILD_DEADLINE' }
    if ($Values | Where-Object { $_ -match '["\r\n]' }) { throw 'FIXED_TERMINAL_CHILD_ARGUMENT' }
    $arcChild=[Diagnostics.Process]::new()
    try {
        $arcInfo=[Diagnostics.ProcessStartInfo]::new()
        $arcInfo.FileName=$Contract.node.path; $arcInfo.WorkingDirectory=$Contract.root
        $arcInfo.Arguments=((@($Contract.terminalBackend.path)+$Values | ForEach-Object { '"'+$_+'"' }) -join ' ')
        $arcInfo.UseShellExecute=$false; $arcInfo.CreateNoWindow=$true
        $arcInfo.RedirectStandardInput=$true; $arcInfo.RedirectStandardOutput=$true; $arcInfo.RedirectStandardError=$true
        $arcInfo.EnvironmentVariables.Remove('NODE_OPTIONS'); $arcInfo.EnvironmentVariables.Remove('NODE_PATH')
        $arcChild.StartInfo=$arcInfo
        [void]$arcChild.Start(); $arcChildDiagnostic.started=$true; $arcChild.StandardInput.Close()
        $arcOut=$arcChild.StandardOutput.ReadToEndAsync(); $arcErr=$arcChild.StandardError.ReadToEndAsync()
        if (-not $arcChild.WaitForExit([int]$arcRemaining)) { throw 'TERMINAL_CHILD_TIMEOUT_STOP_RECONCILE' }
        $arcChildDiagnostic.exitedObserved=$true; $arcChildDiagnostic.exitCode=[int]$arcChild.ExitCode
        $arcDrain=[Threading.Tasks.Task]::WhenAll([Threading.Tasks.Task[]]@($arcOut,$arcErr))
        $arcDrainMs=[int][Math]::Max(0,[Math]::Min(1000,$DeadlineAt-(Get-ArcTerminalMs)))
        $arcDrained=$arcDrain.Wait($arcDrainMs)
        if ($arcDrained) {
            $arcChildDiagnostic.drainComplete=$true
            $arcChildDiagnostic.stdoutCharacters=[int]$arcOut.Result.Length; $arcChildDiagnostic.stderrCharacters=[int]$arcErr.Result.Length
        }
        if (-not $arcDrained -or $arcChild.ExitCode -ne 0 -or $arcOut.Result.Length -gt 65536 -or $arcErr.Result.Length -ne 0) { throw 'TERMINAL_CHILD_FAILED_STOP_RECONCILE' }
        $arcParsed=$arcOut.Result | ConvertFrom-Json -ErrorAction Stop
        $arcChildDiagnostic.jsonParseSucceeded=$true
        return $arcParsed
    } finally {
        try { if (-not $arcChild.HasExited) { $arcChild.Kill(); [void]$arcChild.WaitForExit(1000) } } catch { }
        $arcChild.Dispose()
    }
    } finally { $arcDiagnosticClock.Stop(); $arcChildDiagnostic.elapsedMs=$arcDiagnosticClock.ElapsedMilliseconds }
}
function Invoke-ArcFixedTerminalCommand([string]$Role,[string]$ContractPath,[string]$ContractSha256,[string]$LauncherPath,[string]$LauncherSha256,[string]$CommandPath) {
    $arcDiagnosticContext=New-ArcTerminalDiagnosticContext
    Assert-ArcAttendedConsole
    $arcInvokedAt=Get-ArcTerminalMs
    $arcInvocation=[Guid]::NewGuid().ToString('D')
    Assert-ArcTerminalReference ([pscustomobject]@{path=$ContractPath;sha256=$ContractSha256})
    Assert-ArcTerminalReference ([pscustomobject]@{path=$LauncherPath;sha256=$LauncherSha256})
    $arcContract=[IO.File]::ReadAllText($ContractPath) | ConvertFrom-Json
    $arcRoles=@($arcContract.roles | Where-Object { $_.role -ceq $Role })
    if ($arcRoles.Count -ne 1 -or $arcRoles[0].commandPath -cne $CommandPath -or $arcRoles[0].launcherPath -cne $LauncherPath -or $ContractPath -cne (Join-Path $PSScriptRoot 'launcher-contract.json')) { throw 'FIXED_RELEASED_TERMINAL_ROLE' }
    Assert-ArcTerminalReference $arcContract.terminalEntry
    $arcRole=$arcRoles[0]
    $arcTerminalDirectory=Join-Path $PSScriptRoot 'terminal'
    [void][IO.Directory]::CreateDirectory($arcTerminalDirectory)
    $arcShellAttempt=Join-Path $arcTerminalDirectory ($arcRole.scenarioId+'-'+$arcRole.mode+'-shell-attempt.json')
    $arcShellFailure=Join-Path $arcTerminalDirectory ($arcRole.scenarioId+'-'+$arcRole.mode+'-shell-failure.json')
    New-ArcTerminalExclusiveJson -Path $arcShellAttempt -Value ([ordered]@{schemaVersion='arc-guarded-terminal-shell-attempt-v1';role=$Role;invocationId=$arcInvocation;processId=$PID;invokedAt=$arcInvokedAt;command=[pscustomobject]@{path=$CommandPath;sha256=(Get-FileHash -LiteralPath $CommandPath -Algorithm SHA256).Hash.ToLowerInvariant()};contract=[pscustomobject]@{path=$ContractPath;sha256=$ContractSha256};entry=$arcContract.terminalEntry;noAutomaticRetry=$true})
    try {
    $arcDiagnosticContext.stage='inspect-child'
    $arcInspection=Invoke-ArcTerminalChild -Contract $arcContract -Values @('inspect',$Role) -DeadlineAt ($arcInvokedAt+30000) -MaximumWaitMs 30000 -DiagnosticContext $arcDiagnosticContext
    $arcInitial='none'
    if ($Role -ceq 'long:start') {
        $arcDiagnosticContext.stage='initial-enter'
        $arcFirstAck=Read-ArcLocalAcknowledgement -DeadlineAt ([Math]::Min($arcInspection.validUntil,(Get-ArcTerminalMs)+60000)) -Message '1. Press Enter once to confirm readiness. Then wait for prompt 2 after preparation. Do not press ahead or paste C yet.' -DiagnosticContext $arcDiagnosticContext
        $arcInitial=[string]$arcFirstAck.userReadyAt
    }
    $arcDiagnosticContext.stage='prepare-child'
    $arcPreparationDeadline=Get-ArcPreparationDeadline -PackageValidUntil $arcInspection.validUntil -InvokedAt $arcInvokedAt
    $arcPrepared=Invoke-ArcTerminalChild -Contract $arcContract -Values @('prepare',$Role,$arcInspection.template.sha256,$arcInvocation,[string]$PID,[string]$arcInvokedAt,$arcInitial) -DeadlineAt $arcPreparationDeadline -MaximumWaitMs 905000 -DiagnosticContext $arcDiagnosticContext
    $arcDiagnosticContext.stage='post-native-enter'
    $arcAck=Read-ArcLocalAcknowledgement -DeadlineAt $arcPrepared.acknowledgementDeadlineAt -Message '2. Native readiness passed. Press Enter once now to confirm readiness for the masked C prompt. Do not paste C until that prompt appears.' -DiagnosticContext $arcDiagnosticContext -ResetBufferedInput
    $arcDiagnosticContext.stage='acknowledge-child'
    $arcReady=Invoke-ArcTerminalChild -Contract $arcContract -Values @('acknowledge',$Role,$arcInspection.template.sha256,$arcInvocation,[string]$PID,[string]$arcAck.promptedAt,[string]$arcAck.userReadyAt) -DeadlineAt ($arcAck.userReadyAt+30000) -MaximumWaitMs 30000 -DiagnosticContext $arcDiagnosticContext
    $arcDiagnosticContext.stage='post-ack-validation'
    if ($arcReady.status -cne 'LOCAL_ACK_VALIDATED_PINNED_MASKED_WRAPPER_NEXT' -or (Get-ArcTerminalMs)+$arcContract.inputAllowanceMs.($arcRole.mode)+65000+70000 -ge $arcReady.deadlineAt) { throw 'TERMINAL_POST_ACK_RESERVES' }
    Assert-ArcTerminalReference ([pscustomobject]@{path=$ContractPath;sha256=$ContractSha256})
    Assert-ArcTerminalReference ([pscustomobject]@{path=$LauncherPath;sha256=$LauncherSha256})
    $arcPowerShell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arcArguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$LauncherPath,'-Mode',$arcRole.mode,'-Scenario',$arcRole.scenarioId,'-Inventory',$arcContract.inventory.path,'-ArtifactReport',$arcContract.artifactReport.path,'-ReportName',$arcRole.reportName)
    if ($arcRole.mode -ceq 'replay') { $arcArguments+=@('-Approval',$arcContract.approvalPath) }
    $arcArguments+='-UseSystemProxy'
    $arcDiagnosticContext.stage='masked-child'; $arcDiagnosticContext.child=$null
    & $arcPowerShell @arcArguments | Out-Host
    $arcExit=$LASTEXITCODE
    if ($arcExit -ne 0) { throw 'MASKED_CHILD_FAILED_STOP_RECONCILE' }
    Write-Host 'STOP. No retry. Preserve the original invocation, native, attempt and exit records.'
    if ($Role -ceq 'long:start') { Write-Host 'LONG quiet is 1170000 ms from confirmed child exit/latest contact. Root will validate the actual exit.' }
    if ($null -ne $arcDiagnosticContext) { $arcDiagnosticContext.stage='complete' }
    return $arcExit
    } catch {
        $arcFailureException=$_.Exception
        $arcFailureDiagnostic=[ordered]@{schemaVersion='arc-terminal-diagnostics-v1';stage='unavailable';code='OTHER_LOCAL_EXCEPTION'}
        try { $arcFailureDiagnostic=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $arcDiagnosticContext -Exception $arcFailureException } catch { }
        $arcFailureMessage='UNKNOWN_STOP_RECONCILE_NO_RETRY stage='+$arcFailureDiagnostic.stage+' code='+$arcFailureDiagnostic.code
        try {
            if (-not (Test-Path -LiteralPath $arcShellFailure)) {
                New-ArcTerminalExclusiveJson -Path $arcShellFailure -Value ([ordered]@{schemaVersion='arc-guarded-terminal-shell-failure-v1';role=$Role;invocationId=$arcInvocation;processId=$PID;observedAt=(Get-ArcTerminalMs);shellAttempt=[pscustomobject]@{path=$arcShellAttempt;sha256=(Get-FileHash -LiteralPath $arcShellAttempt -Algorithm SHA256).Hash.ToLowerInvariant()};disposition='UNKNOWN_STOP_RECONCILE_NO_RETRY';boundedCloudChildMayStillBeRunning=$true;rawDiagnosticPersisted=$false;noAutomaticRetry=$true;diagnostics=$arcFailureDiagnostic})
            }
        } catch { }
        try { [Console]::Error.WriteLine($arcFailureMessage+'. A bounded cloud child may still be running; preserve evidence and do not repeat.') } catch { }
        throw $arcFailureMessage
    }
}
