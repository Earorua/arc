// Read-only reconstruction of one exact consumed local command. Never imports r7 context.
import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {FIXED,G,assert,same,hash,integer,utc} from './guards.mjs';
const original=resolve(dirname(fileURLToPath(import.meta.url)),'../scenario-ops-r7');
const effects=Object.freeze({cloudReads:0,cloudMutations:0,controlCalls:0,providerCalls:0,credentialPrompts:0});
const keys=(value,names,code)=>assert(value&&same(Object.keys(value).sort(),names.split(',').sort()),code);
export function assertOriginalR7Inventory(inv){
 assert(inv.schemaVersion==='arc-historical-original-byte-inventory-v1'&&inv.sourceDirectory===original&&inv.files?.length===81,'EXACT_R7_COMPLETE_INVENTORY');
 const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(resolve(d,e.name)):[resolve(d,e.name)]).sort();
 assert(same(walk(original),inv.files.map(f=>f.originalPath).sort()),'R7_INVENTORY_COMPLETE_FILE_SET');
 for(const f of inv.files){const b=readFileSync(f.originalPath);assert(hash(b)===f.originalSha256&&b.length===f.bytes,'R7_ORIGINAL_BYTES_UNCHANGED');}
}
function absentPaths(){
 const paths=['controls','clocks','observations','handoffs','receipts','closed-baseline-acceptance.json','activate-root-policy-decision-r7.json','roster-preparation.json','replay-approval.json','replay-native-evidence.json','wrangler.site-roster.json',...['activate','admission-close','maintenance-close','site-roster'].flatMap(k=>[k+'-deploy-attempt.json',k+'-deploy-result.json'])].map(n=>resolve(original,n));
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay']){
  const stem=id+'-'+mode;
  paths.push(...['invocation','prepared','acknowledgement'].map(k=>resolve(original,'terminal',stem+'-'+k+'.json')),resolve(original,'handoffs',stem+'-readiness.json'),resolve(original,'handoffs',stem+'.json'),resolve(original,'controls',stem+'-attempt.json'),resolve(original,'controls',stem+'-exit.json'),resolve(original,'terminal',stem+'-failure.json'),resolve(G,'..',`cloud-guarded-${stem}-20261016-r7`));
 }
 return paths;
}
export function loadInitialAckTimeout(read,verify){
 const p=FIXED.initialAckTimeout;for(const pin of Object.values(p))verify(pin);
 const r=read(p.reconciliation),a=read(p.attempt),f=read(p.failure),t=read(p.template),inv=read(p.inventory);
 assertOriginalR7Inventory(inv);
 keys(r,'schemaVersion,rootReviewed,observedAt,sequence,disposition,attempt,failure,template,materials,rootAcceptance,inventory,terminalEntry,terminalPrepare,terminalContract,invokedAt,failedAt,inspectElapsedMs,afterInspectionMs,initialAcknowledgementReceived,inspectChildExitedAndDrained,downstreamAbsentPaths,scope,recordedCommandEffects,originalR7Complete,permanentIncomplete,oldCommandMustNotRun,task15Complete,futureNativeReadbackRequired,userClarification','EXACT_ROOT_TIMEOUT_FIELDS');
 keys(t,'schemaVersion,rootReviewed,authorityMode,sequence,epoch,identity,currentClosedAcceptance,pins,materials,preparation,dryRuns,spec,reviewedAt,validUntil,localValidationReserveMs,measuredValidationMs,noAutomaticRetry,providerCallsAllowed','EXACT_ORIGINAL_R7_PACKAGE_FIELDS');
 assert(r.schemaVersion==='arc-local-initial-ack-timeout-reconciliation-v1'&&r.rootReviewed===true&&r.sequence==='20261016-r7'&&r.disposition==='R7_RECORDED_COMMAND_STOPPED_AT_INITIAL_ACK_BEFORE_CLOUD_PREPARATION','DISTINCT_ROOT_LOCAL_TIMEOUT_RECONCILIATION');
 for(const key of ['attempt','failure','template','materials','rootAcceptance','inventory','terminalEntry','terminalPrepare','terminalContract'])assert(same(r[key],p[key]),'EXACT_R7_TIMEOUT_PROOF_BINDINGS');
 assert(r.initialAcknowledgementReceived===false&&r.inspectChildExitedAndDrained===true&&same(r.recordedCommandEffects,effects)&&r.originalR7Complete===false&&r.permanentIncomplete===true&&r.oldCommandMustNotRun===true&&r.task15Complete===false&&r.futureNativeReadbackRequired===true&&r.operationalReadiness===undefined,'LOCAL_TIMEOUT_NEVER_READINESS_OR_EFFECT_AUTHORITY');
 assert(r.scope==='Exact recorded r7 command and its fixed artifact paths; no claim of global Cloudflare invocation absence','EXACT_COMMAND_SCOPE_ONLY');
 keys(a,'schemaVersion,role,invocationId,processId,invokedAt,command,contract,entry,noAutomaticRetry','EXACT_SHELL_ATTEMPT_FIELDS');
 assert(a.schemaVersion==='arc-guarded-terminal-shell-attempt-v1'&&a.role==='long:start'&&a.invocationId==='05c24315-4804-41a2-b25c-714fef9f37dc'&&a.processId===20536&&a.invokedAt===1792144840274&&a.noAutomaticRetry===true,'EXACT_R7_SHELL_INVOCATION');
 assert(same(a.command,t.pins['long-start-command-r1.ps1'])&&same(a.contract,t.pins['launcher-contract.json'])&&same(a.entry,p.terminalEntry),'EXACT_R7_COMMAND_AND_CONTRACT');
 for(const pin of [a.command,a.contract,a.entry,...Object.values(t.pins)])verify(pin);
 keys(f,'schemaVersion,role,invocationId,processId,observedAt,shellAttempt,disposition,boundedCloudChildMayStillBeRunning,rawDiagnosticPersisted,noAutomaticRetry,diagnostics','EXACT_SHELL_FAILURE_FIELDS');
 assert(f.schemaVersion==='arc-guarded-terminal-shell-failure-v1'&&f.role===a.role&&f.invocationId===a.invocationId&&f.processId===a.processId&&same(f.shellAttempt,p.attempt)&&f.disposition==='UNKNOWN_STOP_RECONCILE_NO_RETRY'&&f.noAutomaticRetry===true&&f.rawDiagnosticPersisted===false&&f.boundedCloudChildMayStillBeRunning===true,'EXACT_R7_SHELL_FAILURE');
 const d=f.diagnostics;keys(d,'schemaVersion,stage,code,child,acknowledgement','EXACT_TIMEOUT_DIAGNOSTIC_FIELDS');
 assert(d.schemaVersion==='arc-terminal-diagnostics-v1'&&d.stage==='initial-enter'&&d.code==='LOCAL_ACK_DEADLINE_EXPIRED','EXACT_INITIAL_ENTER_TIMEOUT_ONLY');
 keys(d.child,'stage,started,exitedObserved,drainComplete,jsonParseSucceeded,exitCode,stdoutCharacters,stderrCharacters,elapsedMs','EXACT_INSPECT_CHILD_FIELDS');
 const child=d.child;assert(child.stage==='inspect-child'&&child.started===true&&child.exitedObserved===true&&child.drainComplete===true&&child.jsonParseSucceeded===true&&child.exitCode===0&&child.stdoutCharacters===431&&child.stderrCharacters===0&&child.elapsedMs===26984&&child.elapsedMs<=30000,'SUCCESSFUL_BOUNDED_INSPECT_EXIT_DRAIN_JSON_REQUIRED');
 keys(d.acknowledgement,'stage,bufferedInputPresent,deadlineRemainingMs','EXACT_INITIAL_ACK_FIELDS');
 assert(d.acknowledgement.stage==='initial-enter'&&d.acknowledgement.bufferedInputPresent===false&&d.acknowledgement.deadlineRemainingMs===59998,'ORIGINAL_INITIAL_ACK_DEADLINE_AND_BUFFER');
 const initialWaitMs=f.observedAt-a.invokedAt-child.elapsedMs;
 assert(integer(f.observedAt)&&initialWaitMs===60114&&initialWaitMs>=d.acknowledgement.deadlineRemainingMs&&initialWaitMs<61000&&r.invokedAt===a.invokedAt&&r.failedAt===f.observedAt&&r.inspectElapsedMs===child.elapsedMs&&r.afterInspectionMs===initialWaitMs&&utc(r.observedAt)>=f.observedAt,'RECOMPUTED_EXACT_INITIAL_WAIT_TIMING');
 assert(t.schemaVersion==='arc-guarded-terminal-template-v1'&&t.rootReviewed===true&&t.sequence==='20261016-r7'&&t.epoch===FIXED.epoch&&t.authorityMode==='ROOT_PRE_REVIEWED_FIXED_POLICY_AUTOMATED_NATIVE_GATE'&&t.identity.role===a.role&&t.identity.first===true&&t.identity.templatePath===p.template.path&&t.identity.shellAttemptPath===p.attempt.path&&t.identity.shellFailurePath===p.failure.path&&same(t.materials,p.materials)&&same(t.currentClosedAcceptance,FIXED.currentClosedAcceptance)&&same(t.pins['terminal-prepare.mjs'],p.terminalPrepare)&&same(t.pins['terminal-contract.mjs'],p.terminalContract)&&same(t.pins['terminal-entry.ps1'],p.terminalEntry),'EXACT_REVIEWED_R7_PACKAGE_PINS');
 assert(t.userReadyAt===undefined&&t.initialAcknowledgedAt===undefined&&t.spec===null&&t.noAutomaticRetry===true&&t.providerCallsAllowed===false&&t.localValidationReserveMs===110000&&integer(t.measuredValidationMs)&&t.measuredValidationMs>0&&t.measuredValidationMs*3+5000<110000,'NO_FABRICATED_R7_PACKAGE_ATTENDANCE');
 const reviewedAt=utc(t.reviewedAt);assert(integer(t.validUntil)&&reviewedAt<a.invokedAt&&a.invokedAt<t.validUntil&&t.validUntil-reviewedAt<=86400000,'ORIGINAL_R7_PACKAGE_UNEXPIRED_AT_INVOCATION');
 const absent=absentPaths();assert(same(r.downstreamAbsentPaths,absent),'COMPLETE_NINE_ROLE_DOWNSTREAM_PATHS');for(const path of absent)assert(!existsSync(path),'R7_DOWNSTREAM_ARTIFACT_APPEARED');
 // Complete inventory also rejects extra role shell attempts/failures anywhere in r7.
 return Object.freeze({reference:structuredClone(p.reconciliation),sequence:'20261016-r7',invocationId:a.invocationId,processId:a.processId,inspectElapsedMs:child.elapsedMs,initialWaitMs,originalFilesVerified:81,downstreamAbsentPaths:absent,recordedCommandEffects:effects,originalR7Complete:false,permanentIncomplete:true,operationalReadiness:false,futureNativeReadbackRequired:true});
}
