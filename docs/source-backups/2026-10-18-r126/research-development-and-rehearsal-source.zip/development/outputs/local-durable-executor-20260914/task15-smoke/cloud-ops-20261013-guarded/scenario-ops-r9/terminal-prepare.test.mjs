import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';
import {here} from './guards.mjs';
import * as terminal from './terminal-prepare.mjs';
test('exclusive terminal use refuses any consumed attempt, handoff, report or invocation',()=>{
 assert.equal(typeof terminal.assertUnusedTerminalFacts,'function');
 terminal.assertUnusedTerminalFacts({invocation:false,prepared:false,acknowledgement:false,readiness:false,handoff:false,attempt:false,exit:false,report:false,failure:false});
 for(const key of ['invocation','prepared','acknowledgement','readiness','handoff','attempt','exit','report','failure'])assert.throws(()=>terminal.assertUnusedTerminalFacts({[key]:true}),/CONSUMED/);
});
test('fixed bounded pipeline stops once on failing native collection before activation',async()=>{
 assert.equal(typeof terminal.runFirstPreparation,'function');
 const calls=[];
 await assert.rejects(terminal.runFirstPreparation({}, {preparation:{},materials:{}}, {initialAcknowledgedAt:1}, {
  prepareObservation:()=>{calls.push('preactivation');return{}}, collect:async()=>{calls.push('read');return {allReadsSucceeded:false}},
  operate:async()=>{calls.push('MUST_NOT_DEPLOY')},now:()=>10,
 }),/ACTUAL_COMPLETE_TERMINAL_NATIVE/);
 assert.deepEqual(calls,['preactivation','read']);
});
function offlinePipeline(failedActivation=false){
 const calls=[],files=new Map();let clock=10000;
 const pin=path=>({path,sha256:'a'.repeat(64)}),save=(path,value)=>{files.set(path,value);return pin(path)},iso=()=>new Date(++clock).toISOString();
 const gate=reference=>({...files.get(reference.path).result,reference});
 return {calls,files,c:{},t:{preparation:pin('OFFLINE-preparation'),materials:pin('OFFLINE-materials'),reference:pin('OFFLINE-template'),validUntil:1000000,dryRuns:{activate:pin('OFFLINE-dry'), 'admission-close':pin('OFFLINE-adry'),'maintenance-close':pin('OFFLINE-mdry')}},io:{
  now:()=>++clock,ref:pin,write:save,prepareObservation:(_c,spec)=>{calls.push(spec.phase);return {spec}},collect:async(_c,q)=>({allReadsSucceeded:true,reference:q}),
  evaluateNative:(_c,q)=>({phase:q.spec.phase,request:{...q.spec,directory:'OFFLINE-'+q.spec.phase,deadlineAt:1000000},nativeReference:pin('OFFLINE-native-'+q.spec.phase),startedAt:iso(),endedAt:iso(),allChecksPassed:true,mapping:{versions:{site:'OFFLINE-site',executor:'OFFLINE-executor'},configs:{}}}),
  loadGate:(_c,r)=>gate(r),loadPreparation:()=>({configs:{activate:pin('OFFLINE-config')}}),loadClosedBaseline:()=>{calls.push('baseline')},
  operate:async()=>{calls.push('activate');return pin('OFFLINE-activation')},loadOperation:()=>({commandSucceeded:!failedActivation,childCloseConfirmed:true,commandStartedAt:iso(),endedAt:iso()}),
  createStageClock:()=>{calls.push('activation-clock');return pin('OFFLINE-clock')},
 }};
}
test('fixed pipeline uses actual completed order and exactly one activation',async()=>{
 const f=offlinePipeline();const result=await terminal.runFirstPreparation(f.c,f.t,{initialAcknowledgedAt:1000},f.io);
 assert.deepEqual(f.calls,['preactivation','baseline','activate','activation-clock','post-activate','prestart']);
 assert.equal(result.spec.scenarioId,'long');assert.equal(result.spec.mode,'start');assert.equal(result.spec.readiness,undefined);
});
test('unknown or failed activation stops before post-native preparation and never retries',async()=>{
 const f=offlinePipeline(true);await assert.rejects(terminal.runFirstPreparation(f.c,f.t,{initialAcknowledgedAt:1000},f.io),/ACTUAL_SINGLE_ACTIVATION/);
 assert.deepEqual(f.calls,['preactivation','baseline','activate']);
});
test('24h package does not extend actual activation decision beyond initial acknowledgement900s',async()=>{
 const f=offlinePipeline();f.t.validUntil=86401000;
 const result=await terminal.runFirstPreparation(f.c,f.t,{initialAcknowledgedAt:1000},f.io);
 assert.equal(f.files.get(result.events.decision.path).validUntil,901000);
 assert.equal(result.events.decision.path,resolve(here,'activate-root-policy-decision-r9.json'));
 assert.deepEqual(f.calls,['preactivation','baseline','activate','activation-clock','post-activate','prestart']);
});
test('PowerShell5 terminal AST and credential-free failed children preserve no-retry boundaries',()=>{
 const powershell=resolve(process.env.SystemRoot,'System32/WindowsPowerShell/v1.0/powershell.exe');
 const result=spawnSync(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(here,'terminal-entry.test.ps1')],{encoding:'utf8',timeout:30000,windowsHide:true,env:{...process.env,PSModulePath:resolve(process.env.SystemRoot,'System32/WindowsPowerShell/v1.0/Modules')}});
 assert.equal(result.status,0,result.stdout+'\n'+result.stderr);assert.match(result.stdout,/OFFLINE_R4_TERMINAL_PS_PASS/);assert.match(result.stdout,/powershellMajor":5/);
});
