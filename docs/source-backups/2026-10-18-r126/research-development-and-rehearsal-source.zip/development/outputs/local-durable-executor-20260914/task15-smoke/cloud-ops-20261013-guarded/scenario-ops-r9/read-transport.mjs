// Fixed native READS ONLY. No mutation command can pass this module's allowlist.
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdtempSync} from 'node:fs';
import {performance} from 'node:perf_hooks';

export const limits=Object.freeze({maxAttempts:3,backoffMs:1000,childMs:45000,closeGraceMs:1000,collectorMs:720000});
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
import {assertCommand,commandsFor} from './read-plans.mjs';
import {FIXED,integer,assert} from './guards.mjs';
const transportCode=/\b(?:UND_ERR_CONNECT_TIMEOUT|UND_ERR_HEADERS_TIMEOUT|UND_ERR_BODY_TIMEOUT|UND_ERR_SOCKET|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN)\b/u;
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);

// Exact installed CLI byte signature only. A diagnostic never changes failure or retry policy.
export function classifyAuthenticationFailure(a){
  if(a.exitCode!==1||a.signal!==null||a.timedOut!==false||a.outputOverflow!==false||a.childCloseConfirmed!==true||a.stdoutBytes!==1||a.stderrBytes!==495||a.stdoutSha256!=='01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b'||a.stderrSha256!=='fd07d7ddb817d51b8a85924ed798de7f642eb6704c214a9a4e2959291fbb0b53')return null;
  return {code:'INSTALLED_CLI_NONINTERACTIVE_AUTH_REQUIRED',stdoutSha256:a.stdoutSha256,stderrSha256:a.stderrSha256};
}

// Runtime injection exists only to test child lifecycle and deadline behavior offline.
// Production collector supplies no runtime override, limits override or arbitrary runner.
export function createReadTransport({request,cli,cwd,env,remainingMs,runtime={},beforeSpawn=()=>{},
 createExportDirectory=role=>mkdtempSync('C:/Users/XF/AppData/Local/Temp/arc15-guarded-scenario-'+role+'-')}) {
  assert(integer(remainingMs)&&remainingMs>0,'FINITE_REMAINING_STAGE');
  const budgetMs=Math.min(limits.collectorMs,remainingMs);
  const io={spawn,now:()=>performance.now(),wallNow:()=>new Date().toISOString(),setTimeout,clearTimeout,...runtime};
  const started=io.now();let halted=null;
  if(!Number.isFinite(started)||started>io.now())throw Error('Finite nonfuture collector clock required');
  const remaining=()=>budgetMs-(io.now()-started);
  const stopForBudget=()=>{halted='collector-budget';return halted;};
  function status(){if(remaining()<=0)stopForBudget();return {maxAttempts:limits.maxAttempts,backoffMs:limits.backoffMs,childTimeoutMs:limits.childMs,closeGraceMs:limits.closeGraceMs,collectorBudgetMs:budgetMs,absoluteMonotonicDeadline:started+budgetMs,elapsedMs:Math.max(0,io.now()-started),budgetExhausted:halted==='collector-budget',halted};}
  function allowed(args){assertCommand(request,args);return commandsFor(request).find(c=>same(c.args,args)&&c.kind==='export')?.role;}
  function childAttempt(args,folder,attemptNumber,isExport){
    return new Promise(resolveResult=>{
      const startedAt=io.wallNow(),startedMs=io.now(),available=remaining(),deadlineLimited=available-limits.closeGraceMs<=limits.childMs;
      const timeoutMs=Math.min(limits.childMs,available-limits.closeGraceMs),maxBytes=isExport?65536:131072;
      let child,finished=false,timer,closeTimer,reason=null,timedOut=false,outputOverflow=false,stdoutBytes=0,stderrBytes=0,keptBytes=0;
      const stdout=[],stderr=[],outHash=createHash('sha256'),errHash=createHash('sha256');
      const finish=(code,signal,closed)=>{
        if(finished)return;finished=true;io.clearTimeout(timer);io.clearTimeout(closeTimer);
        if(!closed){reason='shutdown-unconfirmed';if(halted!=='collector-budget')halted=reason;}
        if(remaining()<=0)stopForBudget();
        const out=Buffer.concat(stdout).toString('utf8'),err=Buffer.concat(stderr).toString('utf8');
        if(!reason&&code!==0)reason=transportCode.test(err)?'transport-error':'unknown';
        const metadata={attempt:attemptNumber,startedAt,endedAt:io.wallNow(),elapsedMs:Math.max(0,io.now()-startedMs),
          exitCode:Number.isInteger(code)?code:null,signal:typeof signal==='string'&&/^[A-Z0-9]{1,32}$/u.test(signal)?signal:null,
          timedOut,outputOverflow,childCloseConfirmed:closed,childTimeoutMs:timeoutMs,
          stdoutSha256:outHash.digest('hex'),stderrSha256:errHash.digest('hex'),stdoutBytes,stderrBytes,
          failureKind:reason,rawContentPersisted:false,...(isExport?{preservedExportDirectory:folder}:{})};
        const authenticationDiagnostic=classifyAuthenticationFailure(metadata);
        if(authenticationDiagnostic)metadata.authenticationDiagnostic=authenticationDiagnostic;
        resolveResult({metadata,stdout:out,stderr:err});
      };
      const terminate=kind=>{
        if(finished||closeTimer!==undefined)return;
        reason=kind;
        closeTimer=io.setTimeout(()=>finish(null,null,false),Math.max(0,Math.min(limits.closeGraceMs,remaining())));
        try{child.kill();}catch{/* Unconfirmed close remains terminal; never infer shutdown from kill(). */}
      };
      try{child=io.spawn(process.execPath,[cli,...args],{cwd:folder,env,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});}
      catch{reason='unknown';finish(null,null,false);return;}
      timer=io.setTimeout(()=>{
        timedOut=true;if(deadlineLimited)stopForBudget();terminate(deadlineLimited?'collector-budget':'transport-timeout');
      },timeoutMs);
      for(const [stream,list,digest,key] of [[child.stdout,stdout,outHash,'stdout'],[child.stderr,stderr,errHash,'stderr']]){
        stream.on('data',chunk=>{
          if(finished)return;const bytes=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk);
          digest.update(bytes);if(key==='stdout')stdoutBytes+=bytes.length;else stderrBytes+=bytes.length;
          if(keptBytes+bytes.length<=maxBytes){list.push(bytes);keptBytes+=bytes.length;}
          if(stdoutBytes+stderrBytes>maxBytes){outputOverflow=true;reason='output-overflow';terminate('output-overflow');}
        });
        stream.on('error',()=>terminate('unknown'));
      }
      child.on('error',()=>terminate('unknown'));
      // Node emits close only after the child and its inherited stdio have closed.
      child.on('close',(code,signal)=>finish(code,signal,true));
    });
  }
  async function read(inputArgs,project,{exportTypeGatePassed=false}={}){
    const args=[...inputArgs],exportRole=allowed(args),attempts=[],preservedExportDirectories=[];
    const failed=kind=>({ok:false,failureKind:kind,attempts,exitCode:attempts.at(-1)?.exitCode??null,
      timedOut:attempts.some(a=>a.timedOut),fetchFailed:attempts.some(a=>a.failureKind==='transport-error'),projectionRejected:kind==='projection',
      ...(exportRole?{preservedExportDirectories}:{})});
    if(exportRole&&exportTypeGatePassed!==true)return failed('type-gate');
    for(let number=1;number<=limits.maxAttempts;number++){
      if(remaining()<=limits.closeGraceMs)stopForBudget();
      if(halted)return failed(halted);
      let folder=cwd;
      if(exportRole){try{folder=createExportDirectory(exportRole);preservedExportDirectories.push(folder);}catch{return failed('export-directory');}}
      if(remaining()<=limits.closeGraceMs){stopForBudget();return failed(halted);}
      try{beforeSpawn(args);}catch{return failed('dispatch-pins');}
      if(remaining()<=limits.closeGraceMs){stopForBudget();return failed(halted);}
      const result=await childAttempt(args,folder,number,Boolean(exportRole)),a=result.metadata;attempts.push(a);
      if(halted)return failed(halted);
      if(a.failureKind===null){
        let projection;
        try{projection=await project(result.stdout,result.stderr,folder);}catch{a.failureKind='projection';return failed('projection');}
        if(remaining()<=0){stopForBudget();return failed(halted);}
        return {...projection,ok:true,attempts,...(exportRole?{preservedExportDirectory:folder,preservedExportDirectories}:{})};
      }
      if(!a.childCloseConfirmed||!['transport-timeout','transport-error'].includes(a.failureKind)||number===limits.maxAttempts)return failed(a.failureKind);
      if(remaining()<=limits.backoffMs+limits.closeGraceMs){stopForBudget();return failed(halted);}
      await new Promise(resolveDelay=>io.setTimeout(resolveDelay,limits.backoffMs));
    }
    throw Error('Unreachable read attempt bound');
  }
  return {read,status};
}
