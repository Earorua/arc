import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {FIXED,here,createValidationContext,assertSuccessorBindings,hash} from './guards.mjs';
import {deriveConfigs} from './prepare.mjs';
import {fixedRole} from './terminal-contract.mjs';
test('recursive context requires exact actual terminal login and preserved closed/schema anchors',()=>{
 const c=createValidationContext();
 assert.equal(c.preactivationAuthFailure.safePreactivationSuccessor,true);
 assert.equal(c.preactivationAuthFailure.login.sha256,'e94e16257a653350d2e32075151c916c803326267a2e5ab481292f7929388190');
 assert.equal(c.preactivationAuthFailure.additionalNetworkCheckPerformed,false);
 assert.equal(c.currentClosed.currentVersions.site,'c188e75d-9b44-460a-859d-00a89035f8ed');
 assert.equal(c.currentClosed.currentVersions.executor,'a452ddce-02aa-436f-93be-ee15a2d0b55d');
 for(const [kind,config] of Object.entries(deriveConfigs(c)))assert.deepEqual(config,JSON.parse(readFileSync(resolve(here,'../scenario-ops-r5',`wrangler.${kind}.json`))));
 const bindings={sequence:FIXED.sequence,currentClosedAcceptance:FIXED.currentClosedAcceptance,successorPlan:FIXED.successorPlan,predecessorHistory:FIXED.predecessorHistory,diagnostics:FIXED.diagnostics,closedReconstruction:FIXED.closedReconstruction,terminalDiagnostics:FIXED.terminalDiagnostics,inputReset:FIXED.inputReset,initialAckTimeout:FIXED.initialAckTimeout,preparationDirectoryFailure:FIXED.preparationDirectoryFailure,supersededReviewClarification:FIXED.supersededReviewClarification};
 assert.doesNotThrow(()=>assertSuccessorBindings(bindings));
 const altered=structuredClone(bindings);delete altered.predecessorHistory.preactivationAuthFailure;assert.throws(()=>assertSuccessorBindings(altered));
 assert.throws(()=>c.verify({...FIXED.schemaAcceptance,opaqueHistoricalJson:true}),/ONLY_FROZEN_PREDECESSOR_SNAPSHOT_OPAQUE/);
});
test('all 152 predecessor files remain exact and no extra historical files appeared',()=>{
 const old=resolve(here,'../scenario-ops-r4'),snapshot=JSON.parse(readFileSync(resolve(here,'../scenario-ops-r5/predecessor-snapshot-r4.json')));
 const walk=dir=>readdirSync(dir,{withFileTypes:true}).flatMap(x=>x.isDirectory()?walk(resolve(dir,x.name)):[resolve(dir,x.name)]);
 assert.equal(snapshot.files.length,152);assert.deepEqual(walk(old).sort(),snapshot.files.map(x=>x.path).sort());
 for(const pin of snapshot.files)assert.equal(hash(readFileSync(pin.path)),pin.sha256,pin.name);
});
test('all nine current role identities are r8 and preserve fixed job identities',()=>{
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay']){
  const r=fixedRole(id+':'+mode);assert.equal(r.reportName,`cloud-guarded-${id}-${mode}-20261016-r9`);
  assert.equal(existsSync(r.shellAttemptPath),false);assert.equal(existsSync(r.invocationPath),false);assert.equal(existsSync(r.reportPath),false);
 }
});
