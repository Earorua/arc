import test from 'node:test';
import assert from 'node:assert/strict';
import * as transport from './read-transport.mjs';
const matching={exitCode:1,signal:null,timedOut:false,outputOverflow:false,childCloseConfirmed:true,stdoutBytes:1,stderrBytes:495,stdoutSha256:'01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b',stderrSha256:'fd07d7ddb817d51b8a85924ed798de7f642eb6704c214a9a4e2959291fbb0b53'};
test('exact installed missing-auth signature emits only finite enum and hashes',()=>{
 assert.equal(typeof transport.classifyAuthenticationFailure,'function');
 assert.deepEqual(transport.classifyAuthenticationFailure(matching),{code:'INSTALLED_CLI_NONINTERACTIVE_AUTH_REQUIRED',stdoutSha256:matching.stdoutSha256,stderrSha256:matching.stderrSha256});
});
test('nonmatching or uncertain lifecycle never receives a missing-auth diagnosis',()=>{
 assert.equal(typeof transport.classifyAuthenticationFailure,'function');
 for(const [key,value] of Object.entries({exitCode:0,signal:'SIGTERM',timedOut:true,outputOverflow:true,childCloseConfirmed:false,stdoutBytes:2,stderrBytes:494,stdoutSha256:'0'.repeat(64),stderrSha256:'0'.repeat(64)}))assert.equal(transport.classifyAuthenticationFailure({...matching,[key]:value}),null,key);
});
