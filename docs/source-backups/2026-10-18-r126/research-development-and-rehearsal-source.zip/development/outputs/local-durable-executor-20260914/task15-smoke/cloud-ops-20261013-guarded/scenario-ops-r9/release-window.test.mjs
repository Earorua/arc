// Pure timing boundaries and read-only actual predecessor evidence. No released command runs.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import * as t from './terminal-contract.mjs';
import {FIXED,G,here,hash,createValidationContext,assertFresh} from './guards.mjs';
import {STAGES,LIMITS} from './budget.mjs';
import {assertDecision} from './operate.mjs';
const at=1_000_000;
test('first immutable package allows delivery after15min and before24h',()=>{
 assert.equal(t.FIRST_ENTRY_PACKAGE_MAX_MS,86400000);
 assert.equal(t.LATER_ROLE_TEMPLATE_MAX_MS,900000);
 assert.equal(typeof t.assertTemplateWindow,'function');
 assert.equal(t.assertTemplateWindow('long:start',at,at+86400000,at+900001),at+86400000);
 assert.equal(t.assertTemplateWindow('long:start',at,at+86400000,at+86400000-1),at+86400000);
});
test('exact expiry, excess duration, future issue and all later role excess reject',()=>{
 assert.equal(typeof t.assertTemplateWindow,'function');
 for(const args of [['long:start',at,at+86400000,at+86400000],['long:start',at,at+86400001,at],['long:start',at,at+86400000,at-1]])assert.throws(()=>t.assertTemplateWindow(...args),/FINITE_ROOT_TERMINAL_TEMPLATE/);
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay'])if(id+':'+mode!=='long:start'){
  assert.equal(t.assertTemplateWindow(id+':'+mode,at,at+900000,at+899999),at+900000);
  assert.throws(()=>t.assertTemplateWindow(id+':'+mode,at,at+900001,at),/FINITE_ROOT_TERMINAL_TEMPLATE/);
  assert.throws(()=>t.assertTemplateWindow(id+':'+mode,at,at+900000,at+900000),/FINITE_ROOT_TERMINAL_TEMPLATE/);
 }
});
test('preparation retains independent original invocation905s deadline',()=>{
 assert.equal(t.PREPARATION_ALLOWANCE_MS,905000);
 assert.equal(typeof t.preparationDeadline,'function');
 assert.equal(t.preparationDeadline(at+86400000,at),at+905000);
 assert.equal(t.preparationDeadline(at+1000,at),at+1000);
 assert.throws(()=>t.preparationDeadline(at,at),/ORIGINAL_PREPARATION_ALLOWANCE/);
});
test('native and actual operation freshness remain strict and stage clocks unchanged',()=>{
 const iso=x=>new Date(x).toISOString();
 assertFresh(iso(at),iso(at+1),at+899999);
 assert.throws(()=>assertFresh(iso(at),iso(at+1),at+900000),/FRESH_ACTUAL_NATIVE_START/);
 assert.equal(STAGES.find(x=>x.stage==='activation').durationMs,600000);assert.equal(LIMITS.totalMs,5581000);
 assert.throws(()=>t.acknowledgementDeadline({deadlineAt:at+235000,inputAllowanceMs:60000,childReserveMs:65000},at+86400000,at),/LOCAL_ACK/);
});
test('in-memory operation decision cannot use long package as its actual dispatch window',()=>{
 const pin={path:'OFFLINE-IN-MEMORY',sha256:'a'.repeat(64)},versions={site:'OFFLINE',executor:'OFFLINE'},iso=x=>new Date(x).toISOString();
 const gate={startedAt:iso(at),endedAt:iso(at+1),mapping:{versions},request:{deadlineAt:at+900000}};
 const decision={schemaVersion:'arc-guarded-scenario-operation-decision-v1',rootReviewed:true,disposition:'DEPLOY_EXACT_CONFIG_ONCE',kind:'admission-close',sequence:FIXED.sequence,config:pin,controlCallsAllowed:false,providerCallsAllowed:false,expectedVersions:versions,reviewedAt:iso(at+2),validUntil:at+5000};
 assertDecision(decision,{kind:'admission-close',config:pin,gate,now:at+1000});
 assert.throws(()=>assertDecision(decision,{kind:'admission-close',config:pin,gate,now:at+5000}),/FINITE_DECISION/);
 assert.throws(()=>assertDecision({...decision,validUntil:at+86400000},{kind:'admission-close',config:pin,gate,now:at+1000}),/FINITE_DECISION/);
});
test('r6 successor retains the anchor to actual expired r3 with unchanged consumed records',()=>{
 assert.equal(FIXED.sequence,'20261016-r9');
 assert.equal(FIXED.predecessorHistory.precloudExpiry?.sha256,'9c6181fd636329c0b283f43b09e1bbd02752a1049ea0d5081657452c28253060');
 const c=createValidationContext();
 assert.equal(c.precloudExpiry.reproducedCode,'FINITE_ROOT_TERMINAL_TEMPLATE');
 assert.equal(c.precloudExpiry.safePrecloudSuccessor,true);
 const diagnosis=JSON.parse(readFileSync(FIXED.predecessorHistory.precloudExpiry.path,'utf8'));
 for(const pin of [diagnosis.attempt,diagnosis.failure,diagnosis.template])assert.equal(hash(readFileSync(pin.path)),pin.sha256);
 assert.equal(existsSync(resolve(G,'scenario-ops-r3/terminal/long-start-shell-attempt.json')),true);
 for(const name of ['terminal','templates','activate-deploy-attempt.json'])assert.equal(existsSync(resolve(here,name)),false);
});
