// Actual historical records, mutated only in memory; no child or cloud dispatch.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync,readdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {here,root} from './guards.mjs';
import {KINDS as predecessorKinds} from '../scenario-ops-r4/operate.mjs';
const modulePath=resolve(here,'preactivation-auth-failure.mjs');
const implementation=existsSync(modulePath)?await import(pathToFileURL(modulePath)):null;
const old=resolve(here,'../scenario-ops-r4'),r14=resolve(root,'outputs/local-durable-executor-20261014');
const names={shell:'terminal/long-start-shell-attempt.json',shellFailure:'terminal/long-start-shell-failure.json',invocation:'terminal/long-start-invocation.json',failure:'terminal/long-start-failure.json',template:'templates/long-start.json',request:'observations/terminal-preactivation-20261014-r4/request.json',collection:'observations/terminal-preactivation-20261014-r4/collection-attempt.json',checkpoint:'observations/terminal-preactivation-20261014-r4/checkpoint-1.json',native:'observations/terminal-preactivation-20261014-r4/native-evidence.json'};
const diagnosis={reproduction:'r4-empty-auth-reproduction-r1.json',terminalLocation:'r4-auth-location-terminal-r1.json',codexLocation:'r4-auth-location-codex-r1.json',login:'r4-terminal-login-verification-r1.json'};
const values=()=>Object.fromEntries([...Object.entries(names).map(([key,name])=>[key,JSON.parse(readFileSync(resolve(old,name)))]),...Object.entries(diagnosis).map(([key,name])=>[key,JSON.parse(readFileSync(resolve(r14,name)))])]);
test('exact consumed r4 single read and independent successful user login qualify',()=>{
 assert.equal(typeof implementation?.assertPreactivationAuthFailureRecords,'function');
 assert.equal(implementation.assertPreactivationAuthFailureRecords(values()),true);
});
const mutations={
 'mismatched invocation':v=>v.invocation.invocationId='00000000-0000-4000-8000-000000000000',
 'unconfirmed child shutdown':v=>v.native.observations[0].attempts[0].childCloseConfirmed=false,
 'unknown stderr':v=>v.native.observations[0].attempts[0].stderrSha256='0'.repeat(64),
 'timeout':v=>v.native.observations[0].attempts[0].timedOut=true,
 'extra read':v=>v.native.observations.push(structuredClone(v.native.observations[0])),
 'extra attempt':v=>v.native.observations[0].attempts.push(structuredClone(v.native.observations[0].attempts[0])),
 'successful native':v=>v.native.allReadsSucceeded=true,
 'mutation':v=>v.native.cloudMutations=1,
 'control':v=>v.native.workerControlCalls=1,
 'provider':v=>v.native.providerCalls=1,
 'activation request':v=>v.request.phase='postactivate',
 'changed command':v=>v.native.observations[0].commandSha256='0'.repeat(64),
 'wrong Site version':v=>v.login.currentDeployment.versionId='00000000-0000-4000-8000-000000000000',
 'wrong deployment':v=>v.login.currentDeployment.deploymentId='00000000-0000-4000-8000-000000000000',
 'failed login':v=>v.login.exitCode=1,
 'unverified login':v=>v.login.status='UNKNOWN',
 'login still missing auth':v=>v.login.noninteractiveAuthenticationRequired=true,
 'login mutation':v=>v.login.cloudMutations=1,
 'login before failure':v=>v.login.startedAt=v.native.startedAt,
 'terminal location not established':v=>v.terminalLocation.selectedAuthFilePresent=true,
 'Codex location not established':v=>v.codexLocation.selectedAuthFilePresent=false,
 'reproduction mismatch':v=>v.reproduction.matchesOriginalStderr=false,
 'checkpoint mismatch':v=>v.checkpoint.observations[0].exitCode=0,
};
for(const [name,change] of Object.entries(mutations))test('rejects '+name,()=>{
 assert.equal(typeof implementation?.assertPreactivationAuthFailureRecords,'function');
 const v=values();change(v);assert.throws(()=>implementation.assertPreactivationAuthFailureRecords(v));
});
test('actual frozen r4 scope has no activation, clock, control, roster or driver outputs',()=>{
 assert.equal(implementation.assertPreactivationAuthFailureScope(),true);
 for(const name of ['activate-root-policy-decision-r4.json','activate-deploy-attempt.json','activate-deploy-result.json','admission-close-deploy-attempt.json','maintenance-close-deploy-result.json','roster-preparation.json']){
  const forbidden=resolve(old,name);
  assert.throws(()=>implementation.assertPreactivationAuthFailureScope({exists:p=>p===forbidden||existsSync(p)}),name);
 }
 for(const name of ['clocks','controls','handoffs','receipts'])assert.throws(()=>implementation.assertPreactivationAuthFailureScope({list:p=>p===resolve(old,name)?['forbidden.json']:readdirSync(p)}),name);
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay']){
  const forbidden=resolve(old,'../..',`cloud-guarded-${id}-${mode}-20261014-r4`);
  assert.throws(()=>implementation.assertPreactivationAuthFailureScope({exists:p=>p===forbidden||existsSync(p)}));
 }
 assert.throws(()=>implementation.assertPreactivationAuthFailureScope({list:p=>p===resolve(old,'observations')?[...readdirSync(p),'extra-read']:readdirSync(p)}));
});
test('deployment refusal regression covers all four frozen predecessor operation kinds',()=>{
 assert.deepEqual(predecessorKinds,['activate','admission-close','maintenance-close','site-roster']);
});
for(const kind of predecessorKinds)for(const outcome of ['attempt','result'])test(`rejects predecessor ${kind} deploy ${outcome}`,()=>{
 const forbidden=resolve(old,`${kind}-deploy-${outcome}.json`);
 assert.throws(()=>implementation.assertPreactivationAuthFailureScope({exists:p=>p===forbidden||existsSync(p)}),/^Error: NO_R4_DEPLOYMENT$/);
});
