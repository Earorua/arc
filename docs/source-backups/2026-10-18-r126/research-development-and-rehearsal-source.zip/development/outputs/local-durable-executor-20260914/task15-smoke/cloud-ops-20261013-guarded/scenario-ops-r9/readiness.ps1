# Local guard functions only. Dot-sourcing performs no credential reads, child launches or writes.
function Get-ArcUtcNow { [DateTimeOffset]::UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'") }
function Get-ArcNowMs { [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
function Get-ArcHash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant() }
function Assert-ArcFileReference($Reference) {
    if ($null -eq $Reference -or $Reference.path -isnot [string] -or $Reference.sha256 -cnotmatch '\A[a-f0-9]{64}\z' -or
        (Get-ArcHash $Reference.path) -cne $Reference.sha256) { throw 'HASH_CHANGED' }
}
function New-ArcExclusiveJson([string]$Path, $Value) {
    $arcBytes = [Text.UTF8Encoding]::new($false).GetBytes(($Value | ConvertTo-Json -Depth 80 -Compress) + "`n")
    $arcStream = $null
    try {
        try { $arcStream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None) }
        catch { throw 'EXCLUSIVE_FILE_EXISTS_OR_UNAVAILABLE' }
        $arcStream.Write($arcBytes, 0, $arcBytes.Length); $arcStream.Flush($true)
    } finally { if ($null -ne $arcStream) { $arcStream.Dispose() } }
}
function Assert-ArcFixedInvocation($Contract, [string]$Mode, [string]$Scenario, [string]$Inventory, [string]$ArtifactReport,
    [string]$ReportName, [string]$Approval, [bool]$SystemProxy, [string]$LauncherPath, [string]$NodePath) {
    $arcRoles = @($Contract.roles | Where-Object { $_.scenarioId -ceq $Scenario -and $_.mode -ceq $Mode })
    if ($arcRoles.Count -ne 1) { throw 'FIXED_INVOCATION' }
    $arcRole = $arcRoles[0]
    if ($Contract.schemaVersion -cne 'arc-guarded-launcher-contract-v1' -or $Contract.here -cne $PSScriptRoot -or
        $Inventory -cne $Contract.inventory.path -or $ArtifactReport -cne $Contract.artifactReport.path -or
        $ReportName -cne $arcRole.reportName -or $LauncherPath -cne $arcRole.launcherPath -or
        $NodePath -cne $Contract.node.path -or -not $SystemProxy -or
        ($Mode -ceq 'replay' -and $Approval -cne $Contract.approvalPath) -or
        ($Mode -cne 'replay' -and -not [string]::IsNullOrEmpty($Approval))) { throw 'FIXED_INVOCATION' }
    return $arcRole
}
function Assert-ArcInputWindow($Ready, [long]$ElapsedMs, [long]$Now = (Get-ArcNowMs)) {
    if ($ElapsedMs -lt 0 -or $ElapsedMs -ge $Ready.Handoff.inputAllowanceMs -or
        $Ready.Handoff.childReserveMs -ne 65000 -or $Ready.Handoff.deadlineAt - $Now -lt 65000) { throw 'INPUT_WINDOW_EXPIRED' }
}
function Assert-ArcUnchangedReadiness($Before, $After) {
    foreach ($arcKey in @('HandoffSha256','MaterialsSha256','ReadinessSha256','LauncherSha256','ApprovalSha256')) {
        if ($Before.$arcKey -cne $After.$arcKey) { throw 'CHANGED_DURING_INPUT' }
    }
}
function Assert-ArcOwnedAttempt($Attempt, [string]$ExpectedPath, $Handoff = $null) {
    if ($null -eq $Attempt -or $Attempt.Path -cne $ExpectedPath -or $Attempt.ProcessId -ne $PID) { throw 'OWNED_ATTEMPT_REQUIRED' }
    Assert-ArcFileReference ([pscustomobject]@{path=$ExpectedPath;sha256=$Attempt.Sha256})
    $arcAttempt = [IO.File]::ReadAllText($ExpectedPath) | ConvertFrom-Json
    if ($arcAttempt.schemaVersion -cne 'arc-guarded-control-attempt-v1' -or $arcAttempt.invocationId -cne $Attempt.InvocationId -or
        $arcAttempt.processId -ne $PID -or $arcAttempt.noAutomaticRetry -ne $true -or
        ($null -ne $Handoff -and ($arcAttempt.handoff.path -cne $Handoff.path -or $arcAttempt.handoff.sha256 -cne $Handoff.sha256))) { throw 'OWNED_ATTEMPT_REQUIRED' }
}
function Invoke-ArcHandoffValidation($Contract, $Reference) {
    # This child only runs the frozen read-only local provenance validator. No input channel to C.
    $arcValidator = [Diagnostics.Process]::new()
    try {
        $arcValues = @($Contract.evaluator.path, 'validate-handoff', $Reference.path, $Reference.sha256)
        if ($arcValues | Where-Object { $_ -match '["\r\n]' }) { throw 'VALIDATOR_ARGUMENT' }
        $arcStart = [Diagnostics.ProcessStartInfo]::new()
        $arcStart.FileName=$Contract.node.path; $arcStart.WorkingDirectory=$Contract.root
        $arcStart.Arguments=(($arcValues | ForEach-Object { '"' + $_ + '"' }) -join ' ')
        $arcStart.UseShellExecute=$false; $arcStart.CreateNoWindow=$true
        $arcStart.RedirectStandardInput=$true; $arcStart.RedirectStandardOutput=$true; $arcStart.RedirectStandardError=$true
        $arcStart.EnvironmentVariables.Remove('NODE_OPTIONS'); $arcStart.EnvironmentVariables.Remove('NODE_PATH')
        $arcValidator.StartInfo=$arcStart
        [void]$arcValidator.Start(); $arcValidator.StandardInput.Close()
        $arcOut=$arcValidator.StandardOutput.ReadToEndAsync(); $arcErr=$arcValidator.StandardError.ReadToEndAsync()
        if (-not $arcValidator.WaitForExit(30000)) { throw 'LOCAL_VALIDATOR_TIMEOUT' }
        $arcDrain=[Threading.Tasks.Task]::WhenAll([Threading.Tasks.Task[]]@($arcOut,$arcErr))
        if (-not $arcDrain.Wait(5000) -or $arcValidator.ExitCode -ne 0 -or $arcOut.Result.Length -gt 1048576 -or $arcErr.Result.Length -ne 0) { throw 'LOCAL_PROVENANCE_REFUSED' }
        return ($arcOut.Result | ConvertFrom-Json -ErrorAction Stop)
    } finally {
        try { if (-not $arcValidator.HasExited) { $arcValidator.Kill(); [void]$arcValidator.WaitForExit(5000) } } catch { }
        $arcValidator.Dispose()
    }
}
function Assert-ArcScenarioReadiness([string]$ContractPath, [string]$ContractSha256, [string]$Mode, [string]$Scenario,
    [string]$Inventory, [string]$ArtifactReport, [string]$ReportName, [string]$Approval, [bool]$SystemProxy,
    [string]$LauncherPath, [string]$NodePath, $Previous = $null, $Attempt = $null) {
    if ($ContractPath -cne (Join-Path $PSScriptRoot 'launcher-contract.json')) { throw 'FIXED_CONTRACT_PATH' }
    Assert-ArcFileReference ([pscustomobject]@{path=$ContractPath;sha256=$ContractSha256})
    $arcContract = [IO.File]::ReadAllText($ContractPath) | ConvertFrom-Json
    $arcRole = Assert-ArcFixedInvocation -Contract $arcContract -Mode $Mode -Scenario $Scenario -Inventory $Inventory -ArtifactReport $ArtifactReport -ReportName $ReportName -Approval $Approval -SystemProxy $SystemProxy -LauncherPath $LauncherPath -NodePath $NodePath
    foreach ($arcRef in @($arcContract.source,$arcContract.driver,$arcContract.inventory,$arcContract.artifactReport,$arcContract.node)) { Assert-ArcFileReference $arcRef }
    foreach ($arcTool in $arcContract.task2Tools.PSObject.Properties) { Assert-ArcFileReference $arcTool.Value }
    if ((Test-Path -LiteralPath $arcRole.exitPath) -or (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($arcRole.reportPath)))) { throw 'CONSUMED_REPORT_OR_EXIT' }
    if (-not (Test-Path -LiteralPath $arcRole.handoffPath -PathType Leaf)) { throw 'ACTUAL_HANDOFF_REQUIRED' }
    $arcHandoffRef = [pscustomobject]@{path=$arcRole.handoffPath;sha256=(Get-ArcHash $arcRole.handoffPath)}
    if ($null -eq $Previous) {
        if ($null -ne $Attempt -or (Test-Path -LiteralPath $arcRole.attemptPath)) { throw 'ATTEMPT_ALREADY_CONSUMED' }
    } else {
        Assert-ArcOwnedAttempt -Attempt $Attempt -ExpectedPath $arcRole.attemptPath -Handoff $arcHandoffRef
    }
    # Each invocation creates a fresh Task2 WeakSet-backed context and recomputes all actual provenance.
    $arcHandoff = Invoke-ArcHandoffValidation -Contract $arcContract -Reference $arcHandoffRef
    if ($arcHandoff.schemaVersion -cne 'arc-guarded-signed-handoff-v1' -or $arcHandoff.scenarioId -cne $Scenario -or $arcHandoff.mode -cne $Mode -or
        $arcHandoff.jobId -cne $arcRole.jobId -or $arcHandoff.reportName -cne $ReportName -or
        $arcHandoff.materials.path -cne $arcContract.materialsPath -or $arcHandoff.spec.readiness.path -cne $arcRole.readinessPath -or
        $arcHandoff.childReserveMs -ne 65000 -or $arcHandoff.inputAllowanceMs -ne $arcContract.inputAllowanceMs.$Mode -or
        $arcHandoff.deadlineAt - (Get-ArcNowMs) -lt 65000) { throw 'FIXED_VALIDATED_HANDOFF' }
    Assert-ArcFileReference $arcHandoffRef
    Assert-ArcFileReference $arcHandoff.materials
    Assert-ArcFileReference $arcHandoff.spec.readiness
    $arcMaterials = [IO.File]::ReadAllText($arcContract.materialsPath) | ConvertFrom-Json
    $arcLaunchers = @($arcMaterials.launchers | Where-Object { $_.role -ceq ($Scenario + ':' + $Mode) })
    if ($arcLaunchers.Count -ne 1 -or $arcLaunchers[0].path -cne $LauncherPath) { throw 'REVIEWED_MASKED_LAUNCHER' }
    Assert-ArcFileReference $arcLaunchers[0]
    foreach ($arcName in @('prepare-launchers.mjs','readiness.ps1','launcher-contract.json','launcher-derivation.json','OPERATIONS.md')) {
        $arcFile = @($arcMaterials.task3Files | Where-Object { $_.path -ceq (Join-Path $PSScriptRoot $arcName) })
        if ($arcFile.Count -ne 1) { throw 'REVIEWED_TASK3_FILE_REQUIRED' }; Assert-ArcFileReference $arcFile[0]
    }
    $arcApprovalHash = $null
    if ($Mode -ceq 'replay') {
        if ($arcHandoff.approval.path -cne $Approval) { throw 'ACTUAL_HOST_APPROVAL' }
        Assert-ArcFileReference $arcHandoff.approval; $arcApprovalHash=$arcHandoff.approval.sha256
    } elseif ($null -ne $arcHandoff.approval) { throw 'UNEXPECTED_APPROVAL' }
    $arcReady = [pscustomobject]@{Contract=$arcContract;Role=$arcRole;Handoff=$arcHandoff;HandoffReference=$arcHandoffRef;
        HandoffSha256=$arcHandoffRef.sha256;MaterialsSha256=$arcHandoff.materials.sha256;ReadinessSha256=$arcHandoff.spec.readiness.sha256;
        Launcher=$arcLaunchers[0];LauncherSha256=$arcLaunchers[0].sha256;ApprovalSha256=$arcApprovalHash}
    if ($null -ne $Previous) { Assert-ArcUnchangedReadiness -Before $Previous -After $arcReady }
    if ($arcHandoff.deadlineAt - (Get-ArcNowMs) -lt 65000) { throw 'POST_CHECK_CHILD_RESERVE' }
    return $arcReady
}
function New-ArcLaunchAttempt($Ready) {
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Ready.Role.attemptPath))
    $arcId = [Guid]::NewGuid().ToString('D')
    $arcRecord = [ordered]@{schemaVersion='arc-guarded-control-attempt-v1';scenarioId=$Ready.Role.scenarioId;mode=$Ready.Role.mode;
        invocationId=$arcId;processId=$PID;at=(Get-ArcUtcNow);handoff=$Ready.HandoffReference;materials=$Ready.Handoff.materials;
        inventory=$Ready.Contract.inventory;driver=$Ready.Contract.driver;launcher=$Ready.Launcher;reportPath=$Ready.Role.reportPath;
        expectedVersions=$Ready.Handoff.expectedVersions;noAutomaticRetry=$true;controlCredentialMode='secure-masked-tty';providerCallsAllowed=$false}
    New-ArcExclusiveJson -Path $Ready.Role.attemptPath -Value $arcRecord
    return [pscustomobject]@{Path=$Ready.Role.attemptPath;Sha256=(Get-ArcHash $Ready.Role.attemptPath);InvocationId=$arcId;ProcessId=$PID}
}
function Get-ArcChildCloseFact($Child, $Clock, [int]$ReserveMs = 65000) {
    $arcClosed = $false; $arcAt = $null; $arcCode = $null
    if ($null -ne $Child -and $null -ne $Clock) {
        try {
            $arcRemaining = [Math]::Max(0, $ReserveMs - $Clock.ElapsedMilliseconds)
            $arcClosed = $Child.HasExited
            if (-not $arcClosed -and $arcRemaining -gt 0) { $arcClosed = $Child.WaitForExit([int]$arcRemaining) }
            if ($arcClosed -and $Child.HasExited) { $arcAt=Get-ArcUtcNow; $arcCode=$Child.ExitCode } else { $arcClosed=$false }
        } catch { $arcClosed=$false; $arcAt=$null; $arcCode=$null }
    }
    return [pscustomobject]@{childCloseConfirmed=$arcClosed;confirmedExitAt=$arcAt;exitCode=$arcCode}
}
function Write-ArcControlExit($Ready, $Attempt, [string]$StartedAt, $CloseFact, [int]$LauncherExitCode) {
    Assert-ArcOwnedAttempt -Attempt $Attempt -ExpectedPath $Ready.Role.attemptPath -Handoff $Ready.HandoffReference
    $arcConfirmed = $null -ne $CloseFact -and $CloseFact.childCloseConfirmed -eq $true -and -not [string]::IsNullOrEmpty($StartedAt)
    $arcReport = $null; $arcFailure = $null; $arcHost = $null
    # Missing report and partial replay remain missing/partial. Never synthesize driver evidence.
    foreach ($arcKind in @('report','failure','host')) {
        $arcName = if ($arcKind -ceq 'host') { 'host-helper.mjs' } else { $arcKind + '.json' }
        $arcPath = Join-Path ([IO.Path]::GetDirectoryName($Ready.Role.reportPath)) $arcName
        if (Test-Path -LiteralPath $arcPath -PathType Leaf) {
            $arcRef=[pscustomobject]@{path=$arcPath;sha256=(Get-ArcHash $arcPath)}
            if ($arcKind -ceq 'report') { $arcReport=$arcRef } elseif ($arcKind -ceq 'failure') { $arcFailure=$arcRef } else { $arcHost=$arcRef }
        }
    }
    $arcExitAt = if ($arcConfirmed) { $CloseFact.confirmedExitAt } else { $null }
    $arcRecord = [ordered]@{schemaVersion='arc-guarded-control-exit-v1';scenarioId=$Ready.Role.scenarioId;mode=$Ready.Role.mode;
        attempt=[pscustomobject]@{path=$Attempt.Path;sha256=$Attempt.Sha256};invocationId=$Attempt.InvocationId;
        childCloseConfirmed=[bool]$arcConfirmed;startedAt=$StartedAt;confirmedExitAt=$arcExitAt;endedAt=$arcExitAt;observedAt=(Get-ArcUtcNow);
        inventory=$Ready.Contract.inventory;driver=$Ready.Contract.driver;materials=$Ready.Handoff.materials;launcher=$Ready.Launcher;
        handoff=$Ready.HandoffReference;expectedVersions=$Ready.Handoff.expectedVersions;report=$arcReport;failure=$arcFailure;hostHelper=$arcHost;
        exitCode=$(if ($arcConfirmed) { $CloseFact.exitCode } else { $null });launcherExitCode=$LauncherExitCode;
        noAutomaticRetry=$true;disposition=$(if ($arcConfirmed -and $null -ne $arcReport -and $LauncherExitCode -eq 0) { 'CONFIRMED_CHILD_EXIT_REQUIRES_NATIVE_REVIEW' } else { 'STOP_RECONCILE_NO_RETRY' })}
    New-ArcExclusiveJson -Path $Ready.Role.exitPath -Value $arcRecord
}
