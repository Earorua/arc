// Exclusive fixed configuration operations. No operation runs on import; no write retries.
import {spawn} from 'node:child_process';
import {existsSync,mkdtempSync,writeFileSync,readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {FIXED,here,assert,same,hash,digest,integer,uuid,utc,ref,verify,jsonRef,write,createValidationContext,assertCurrentPins,assertMaterials,neutralRead,neutralDeploy,main} from './guards.mjs';
import {loadPreparation,assertReadBudget} from './prepare-observation.mjs';
import {assertRecoveryUse} from './recovery.mjs';
import {strictCommand} from './prepare.mjs';
import {assertTransition} from './contracts.mjs';
import {loadGate,loadOperation,loadClosedBaseline,assertActivationBaseline,assertDiagnosticRecord} from './evaluate.mjs';
import {createReadTransport} from './read-transport.mjs';
import {projectDeployment} from './project.mjs';
import {projectOperationOutput,assertOperationProjection} from '../no-start-ops-r2/rules.mjs';
import {buildRoster,rosterConfig,verifyRosterPreparation} from './roster.mjs';
import {projectDiagnostic} from '../../../../local-durable-executor-20261014/deployment-diagnostic-r1/project.mjs';
import {assertTerminalAuthority} from './terminal-contract.mjs';
export const KINDS=Object.freeze(['activate','admission-close','maintenance-close','site-roster']);
export function assertUnusedOperation({attemptExists,resultExists}){assert(!attemptExists&&!resultExists,'EXCLUSIVE_OPERATION_CONSUMED_RECONCILE_ONLY');}
export function assertDecision(d,{kind,config,gate,now,baseline=null}){
 assert(gate?.reconciliation?.outcome!=='predecessor-still-observed','UNRESOLVED_WRITE_CANNOT_AUTHORIZE_MUTATION');
 if(gate?.request?.incompleteClosure)assert(['admission-close','maintenance-close'].includes(kind)&&same(d.incompleteClosure,gate.request.incompleteClosure),'RECOVERY_CLOSURE_MUTATIONS_ONLY');else assert(!d?.incompleteClosure,'RECOVERY_DECISION_REQUIRES_RECOVERY_GATE');
 assert(KINDS.includes(kind)&&d?.schemaVersion==='arc-guarded-scenario-operation-decision-v1'&&d.rootReviewed===true&&d.disposition==='DEPLOY_EXACT_CONFIG_ONCE'&&d.kind===kind&&same(d.config,config)&&d.controlCallsAllowed===false&&d.providerCallsAllowed===false,'EXACT_ROOT_OPERATION_DECISION');
 assert(d.sequence===FIXED.sequence,'EXACT_DECISION_SUCCESSOR_SEQUENCE');if(kind==='activate')assertActivationBaseline(d,gate,baseline);
 assert(gate?.mapping&&same(d.expectedVersions,gate.mapping.versions)&&integer(d.validUntil)&&utc(d.reviewedAt)>=utc(gate.endedAt)&&utc(d.reviewedAt)<=now&&now<d.validUntil&&d.validUntil<=utc(gate.startedAt)+900000&&d.validUntil<=gate.request.deadlineAt,'FINITE_DECISION_FROM_ACTUAL_NATIVE_START');
 if(kind==='activate')assert(integer(d.userReadyAt)&&d.userReadyAt<=utc(d.reviewedAt)&&d.userReadyAt<=now&&now-d.userReadyAt<900000&&d.validUntil<=d.userReadyAt+900000,'CURRENT_ATTENDED_READINESS');
}
export function deploymentOptions(options,mode){assert(['deploy','dry-run'].includes(mode),'FIXED_DIAGNOSTIC_MODE');if(mode==='dry-run')return options;for(const r of Object.values(FIXED.diagnostics))verify(r);return {...options,env:{...options.env,NODE_OPTIONS:'--require '+JSON.stringify(FIXED.diagnostics.trace.path)}};}
export function projectMutationResponse(response){
 const metadata={childCloseConfirmed:response.childCloseConfirmed,childTimeoutMs:response.childTimeoutMs,exitCode:response.exitCode,commandFailureKind:response.failureKind,stdoutSha256:hash(response.stdout),stderrSha256:hash(response.stderr),diagnosticHelpers:FIXED.diagnostics,diagnosticProjection:projectDiagnostic({stdout:response.stdout,stderr:response.stderr})};
 assertDiagnosticRecord(metadata);return metadata;
}
// The inherited parser recognizes the proxy warning only when it is the entire
// stderr. Remove only complete projector-validated trace records for recognition;
// original streams remain the authority for hashes, diagnostics and byte limits.
export function projectTraceAwareOperationOutput(stdout,stderr,mode,config){
 assert(typeof stdout==='string'&&typeof stderr==='string','DIAGNOSTIC_OUTPUT_STRINGS');
 const retained=[];let records=0;
 for(const part of stderr.match(/[^\n]*\n|[^\n]+$/gu)??[]){
  if(!part.includes('ARC_NET_META')){retained.push(part);continue;}
  assert(part.startsWith('ARC_NET_META ')&&part.endsWith('\n'),'COMPLETE_DIAGNOSTIC_RECORD_REQUIRED');
  const diagnostic=projectDiagnostic({stdout:'',stderr:part});
  assert(diagnostic.events.length===1&&!diagnostic.truncated&&part.replace(/\r?\n$/u,'')==='ARC_NET_META '+JSON.stringify(diagnostic.events[0]),'EXACT_FINITE_DIAGNOSTIC_RECORD_REQUIRED');records++;
 }
 const diagnostic=projectDiagnostic({stdout:'',stderr});
 assert(!records||!diagnostic.truncated&&diagnostic.events.length===records,'BOUNDED_COMPLETE_DIAGNOSTIC_RECORDS_REQUIRED');
 const p=projectOperationOutput(stdout,retained.join(''),mode,config);
 p.stdoutBytes=Buffer.byteLength(stdout);p.stderrBytes=Buffer.byteLength(stderr);
 p.ready=p.ready&&p.stdoutBytes+p.stderrBytes<=524288;return p;
}
export function operationConfig(c,p,kind,rosterRef){assert(KINDS.includes(kind),'FIXED_OPERATION_KIND');return kind==='site-roster'?verifyRosterPreparation(c,rosterRef).config:p.configs[kind];}
export function boundedMutation({args,options,timeoutMs,runtime={}}){assert(integer(timeoutMs)&&timeoutMs>0&&timeoutMs<=90000,'BOUNDED_MUTATION_TIMEOUT');const io={spawn,setTimeout,clearTimeout,...runtime};return new Promise(resolveResult=>{let child,timer,closeTimer,closed=false,done=false,stopping=false,reason=null,bytes=0;const out=[],err=[];
 const finish=(code,confirmed)=>{if(done)return;done=true;io.clearTimeout(timer);io.clearTimeout(closeTimer);if(!confirmed)reason='shutdown-unconfirmed';if(!reason&&code!==0)reason='command-exit';resolveResult({stdout:Buffer.concat(out).toString('utf8'),stderr:Buffer.concat(err).toString('utf8'),exitCode:Number.isInteger(code)?code:null,childCloseConfirmed:confirmed,failureKind:reason,childTimeoutMs:timeoutMs});};
 const stop=kind=>{if(stopping||done)return;stopping=true;reason=kind;closeTimer=io.setTimeout(()=>finish(null,false),1000);try{child.kill();}catch{}};
 try{child=io.spawn(process.execPath,[FIXED.wrapper.path,...args],{cwd:options.cwd,env:options.env,windowsHide:true,shell:false,stdio:['ignore','pipe','pipe']});}catch{finish(null,false);return;}
 timer=io.setTimeout(()=>stop('command-timeout'),timeoutMs);for(const [stream,chunks] of [[child.stdout,out],[child.stderr,err]]){stream.on('data',chunk=>{if(done||stopping)return;bytes+=chunk.length;if(bytes>524288){stop('output-limit');return;}chunks.push(Buffer.from(chunk));});stream.on('error',()=>stop('command-error'));}child.on('error',()=>stop('command-error'));child.on('close',code=>finish(code,true));
 });}
export async function operate(c,{kind,mode,preparation,decision=null,rosterPreparation=null}){
 assert(KINDS.includes(kind)&&['dry-run','deploy'].includes(mode),'FIXED_OPERATION');const p=loadPreparation(c,preparation),configRef=operationConfig(c,p,kind,rosterPreparation),config=c.read(configRef),role=kind==='site-roster'?'site':'executor';
 const attemptPath=resolve(here,`${kind}-${mode}-attempt.json`),resultPath=resolve(here,`${kind}-${mode}-result.json`);assertUnusedOperation({attemptExists:existsSync(attemptPath),resultExists:existsSync(resultPath)});
 let d=null,gate=null,dryRun=null,baseline=null;
 const check=()=>{if(mode==='dry-run')return;d=jsonRef(decision);gate=loadGate(c,d.gate,{fresh:true});assertMaterials(d.materials,c);assertRecoveryUse(c,gate.request.incompleteClosure,Date.now());assertReadBudget(gate.request,gate.request.clock,Date.now());if(kind==='activate')baseline=loadClosedBaseline(c,d.baseline,{gateReference:d.gate,dispatch:true});assertDecision(d,{kind,config:configRef,gate,now:Date.now(),baseline});assert(gate.phase===(kind==='activate'?'preactivation':'pre-'+kind),'EXACT_PRE_OPERATION_GATE');
  const before=c.read(gate.mapping.configs[role]);assertTransition({kind,beforeConfig:before,afterConfig:config,now:Date.now(),nativeSettledProof:kind==='maintenance-close'?{nativeEvidenceSha256:gate.nativeReference.sha256,nativeStartedAt:utc(gate.startedAt),nativeEndedAt:utc(gate.endedAt),scope:gate.scope.scope}:undefined});
  dryRun=loadOperation(c,d.dryRun);assert(dryRun.kind===kind&&dryRun.mode==='dry-run'&&same(dryRun.config,configRef),'ACTUAL_SAME_CONFIG_DRY_RUN');
  if(kind==='activate'){assertTerminalAuthority(c,d,gate,Date.now());for(const k of ['admission-close','maintenance-close']){const r=loadOperation(c,d.closureDryRuns[k]);assert(r.kind===k&&r.mode==='dry-run'&&same(r.config,p.configs[k]),'BOTH_CLOSURE_DRY_RUNS_REQUIRED');}}
 };
 check();const short=mkdtempSync('C:/Users/XF/AppData/Local/Temp/arc15-guarded-scenario-op-'),shortConfig=resolve(short,'wrangler.json');writeFileSync(shortConfig,verify(configRef),{flag:'wx'});const command=strictCommand(shortConfig,mode),options=deploymentOptions(neutralDeploy(),mode);
 const attempt=write(attemptPath,{schemaVersion:'arc-guarded-scenario-operation-attempt-v1',sequence:FIXED.sequence,baseline:d?.baseline??null,diagnosticHelpers:FIXED.diagnostics,kind,mode,at:new Date().toISOString(),preparation,decision,rosterPreparation,config:configRef,artifact:c.artifacts[role],helper:ref(resolve(here,'operate.mjs')),command,commandSha256:hash(JSON.stringify(command)),shortConfig:{path:shortConfig,sha256:configRef.sha256},expectedVersions:gate?.mapping.versions??null,predecessorGate:d?.gate??null,dryRun:d?.dryRun??null,noAutomaticRetry:true,mutationIntended:mode==='deploy'});
 const r={schemaVersion:'arc-guarded-scenario-operation-result-v1',sequence:FIXED.sequence,baseline:d?.baseline??null,kind,mode,attempt,config:configRef,artifact:c.artifacts[role],decision,predecessorGate:d?.gate??null,startedAt:new Date().toISOString(),predecessors:[],commandSucceeded:false,mutationAttempted:false,versionId:null,controlCalls:0,providerCalls:0,...(gate?.request.incompleteClosure?{incompleteClosure:gate.request.incompleteClosure,permanentIncomplete:true}:{})};
 try{
  if(mode==='deploy'){const ro=neutralRead(),transport=createReadTransport({request:gate.request,cli:FIXED.wrapper.path,cwd:ro.cwd,env:ro.env,remainingMs:d.validUntil-Date.now(),beforeSpawn:()=>{assertCurrentPins(c,[d.gate,...Object.values(gate.request.readonlyConfigs),...Object.values(gate.request.configs),...Object.values(p.tools)]);assert(Date.now()<d.validUntil,'CURRENT_OPERATION_READ_WINDOW');}});for(const readRole of ['site','executor']){const args=['deployments','list','--config',resolve(gate.request.directory,`wrangler.${readRole}.readonly.json`),'--json'],o={role:readRole,startedAt:new Date().toISOString(),commandSha256:hash(JSON.stringify(args))};Object.assign(o,await transport.read(args,s=>projectDeployment(s,readRole,gate.mapping.versions[readRole])));o.endedAt=new Date().toISOString();r.predecessors.push(o);assert(o.ok,'IMMEDIATE_PREDECESSOR_FAILED');}check();assert(r.predecessors.every(o=>Date.now()-utc(o.startedAt)<120000),'IMMEDIATE_PAIR_FRESHNESS');}
  assertCurrentPins(c,[configRef,c.artifacts[role],preparation,...Object.values(p.tools),...(decision?[decision]:[])]);assert(hash(readFileSync(shortConfig))===configRef.sha256,'SHORT_CONFIG_CHANGED');if(mode==='deploy'){assertRecoveryUse(c,gate.request.incompleteClosure,Date.now());assertReadBudget(gate.request,gate.request.clock,Date.now());if(kind==='activate')baseline=loadClosedBaseline(c,d.baseline,{gateReference:d.gate,dispatch:true});assertDecision(d,{kind,config:configRef,gate,now:Date.now(),baseline});assert(r.predecessors.every(o=>Date.now()-utc(o.startedAt)<120000),'POST_PIN_CURRENT_PAIR_FRESHNESS');}
  const remaining=mode==='deploy'?d.validUntil-Date.now():91000;assert(remaining>1000,'MUTATION_STAGE_DEADLINE');r.commandStartedAt=new Date().toISOString();r.mutationAttempted=mode==='deploy';const response=await boundedMutation({args:command,options,timeoutMs:Math.min(90000,remaining-1000)});r.commandEndedAt=new Date().toISOString();r.childCloseConfirmed=response.childCloseConfirmed;r.childTimeoutMs=response.childTimeoutMs;r.exitCode=response.exitCode;r.stdoutSha256=hash(response.stdout);r.stderrSha256=hash(response.stderr);Object.assign(r,projectMutationResponse(response));assert(response.failureKind===null&&response.childCloseConfirmed&&response.exitCode===0,'BOUNDED_EXCLUSIVE_COMMAND');r.outputProjection=projectTraceAwareOperationOutput(response.stdout,response.stderr,mode,config);assertOperationProjection(r.outputProjection,mode,config);
  if(mode==='deploy'){const matches=[...response.stdout.matchAll(/Current Version ID:\s*([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})\b/gu)];assert(matches.length===1&&uuid(matches[0][1])&&matches[0][1]!==gate.mapping.versions[role],'UNIQUE_ACTUAL_NEW_VERSION');r.versionId=matches[0][1];}r.commandSucceeded=true;
 }catch{r.failureKind='STOP_RECONCILE_NO_RETRY';}
 r.endedAt=new Date().toISOString();r.disposition=r.commandSucceeded?(mode==='deploy'?'ACTUAL_NATIVE_READBACK_REQUIRED':'LOCAL_DRY_RUN_ONLY'):'STOP_RECONCILE_NO_RETRY';if(r.permanentIncomplete)r.disposition='INCOMPLETE_'+r.disposition;return write(resultPath,r);
}
export function parseOperationArgs(args){const [kind,mode,preparationSha,...rest]=args;assert(KINDS.includes(kind)&&['dry-run','deploy'].includes(mode)&&digest(preparationSha),'EXACT_OPERATION_ARGUMENTS');const deploy=mode==='deploy',roster=kind==='site-roster';assert(rest.length===(deploy?2:0)+(roster?2:0),'EXACT_OPERATION_ARGUMENTS');const reference=(path,sha256)=>{assert(typeof path==='string'&&digest(sha256),'PINNED_OPERATION_ARGUMENT');return {path:resolve(path),sha256};};return {kind,mode,preparation:{path:resolve(here,'preparation.json'),sha256:preparationSha},decision:deploy?reference(rest[0],rest[1]):null,rosterPreparation:roster?reference(rest[deploy?2:0],rest[deploy?3:1]):null};}
await main(import.meta.url,async()=>{const args=parseOperationArgs(process.argv.slice(2));console.log(JSON.stringify({result:await operate(createValidationContext(),args)}));});
