import {readFileSync,readdirSync} from 'node:fs';
import {resolve,relative,sep} from 'node:path';
import {FIXED,assert,same,integer,digest,uuid,hash} from './guards.mjs';
import {SCENARIOS} from './read-plans.mjs';
import {projectWorkflowDefinition,projectVersionBindings,currentDeployment} from '../no-start-ops-r2/rules.mjs';
import {parseBridgeReceiptMetadata,canonicalJson} from '../../cloud-ops-20261005-replay/long-followup-preparation-r1/r2-preparation/production-codec.mjs';
export {projectWorkflowDefinition};
const clean=s=>s.replace(/\u001b\[[0-9;]*m/gu,'');
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
export function safeMetadata(raw,scenarioId){
 assert(typeof raw==='string'&&Buffer.byteLength(raw)<=4096,'BOUNDED_CANONICAL_METADATA');const parsed=JSON.parse(raw),metadata=parseBridgeReceiptMetadata(parsed);
 assert(canonicalJson(parsed)===canonicalJson(metadata)&&metadata.grant.jobId===SCENARIOS[scenarioId].jobId&&metadata.outcome.kind==='response'&&metadata.outcome.actualModel==='moonshotai/kimi-k3','ACTUAL_FIXED_METADATA');
 assert(same(metadata.outcome.usage,{promptTokens:10,completionTokens:20,totalTokens:30,costMicros:1,webSearchRequests:2}),'EXACT_MOCK_USAGE');
 return {metadata,metadataSha256:hash(canonicalJson(metadata))};
}
function cell(value,type,query){
 if(value===null)return null;
 if(Array.isArray(type)){assert(type.includes(value),'SAFE_CELL_ENUM');return value;}
 if(type==='integer'){assert(integer(value),'SAFE_INTEGER');return value;}
 if(type==='boolean-integer'){assert(value===0||value===1,'BOOLEAN_INTEGER');return value;}
 if(type==='hash'){assert(digest(value),'SAFE_HASH');return value;}
 if(type==='fingerprint'){assert(typeof value==='string'&&/^p2-[0-9a-f]{32}$/u.test(value),'PRODUCTION_FINGERPRINT');return value;}
 if(type==='job'){assert(value===SCENARIOS[query.scenarioId].jobId,'FIXED_JOB');return value;}
 if(type==='job-any'){assert(Object.values(SCENARIOS).some(s=>s.jobId===value),'FIXED_JOB_ROSTER');return value;}
 if(type==='cron-id'){assert(typeof value==='string'&&/^cron-[0-9]{1,16}$/u.test(value),'CRON_ID');return value;}
 if(type==='error-code-presence'){assert(typeof value==='string'&&value.length>0&&value.length<=64,'BOUNDED_ERROR_CODE');return 'present-redacted';}
 if(type==='identity-hash'){assert(typeof value==='string'&&uuid(value),'ACTUAL_UUID_IDENTITY');return hash(value);}
 if(type==='budget-identity-hash'){assert(typeof value==='string'&&value.length>=1&&value.length<=160&&value.trim()===value,'ACTUAL_BUDGET_IDENTITY');return hash(value);}
 if(type==='metadata')return safeMetadata(value,query.scenarioId);
 throw Error('UNREVIEWED_CELL_TYPE');
}
export function assertCursorRows(id,rows){
 const executor=id==='executor-maintenance-cursors';assert(executor||id==='site-maintenance-cursors','FIXED_CURSOR_QUERY');const key=executor?'category':'name',time=executor?'after_accepted_at':'after_created_at',identities=executor?['bootstrap','results','site']:['maintenance','outbox'],columns=[key,time,'after_job_id','version',...(executor?['pickup_turn']:[])].sort();
 assert(Array.isArray(rows)&&same(rows.map(r=>r[key]).sort(),identities),'EXACT_UNIQUE_CURSOR_IDENTITIES');for(const r of rows){assert(same(Object.keys(r).sort(),columns)&&integer(r.version)&&(!executor||r.pickup_turn===0||r.pickup_turn===1),'COMPLETE_CURSOR_FIELDS');assert(r[time]===null?r.after_job_id===null:integer(r[time])&&Object.values(SCENARIOS).some(s=>s.jobId===r.after_job_id),'PAIRED_CURSOR_POSITION');}return rows;
}
export function projectD1(stdout,query){
 const body=JSON.parse(stdout);assert(Array.isArray(body)&&body.length===1&&body[0].success===true&&body[0].meta?.rows_written===0&&body[0].meta?.changed_db===false&&Array.isArray(body[0].results)&&body[0].results.length<=query.maxRows,'COMPLETE_READ_ONLY_BODY');
 const rows=body[0].results.map(row=>{assert(plain(row)&&same(Object.keys(row).sort(),Object.keys(query.columns).sort()),'EXACT_SAFE_COLUMNS');const result={};for(const [key,type] of Object.entries(query.columns)){const value=cell(row[key],type,query);if(type==='metadata'){assert(value!==null,'METADATA_REQUIRED');result.metadata=value.metadata;result.metadata_sha256=value.metadataSha256;}else result[key==='run_id'?'run_hash':key==='package_id'?'package_hash':key]=value;}return result;});
 if(['executor-maintenance-cursors','site-maintenance-cursors'].includes(query.id))assertCursorRows(query.id,rows);
 return {rows,rowsWritten:0,changedDb:false,rowsRead:integer(body[0].meta.rows_read)?body[0].meta.rows_read:null};
}
export function projectDeployment(stdout,role,version){const all=JSON.parse(stdout);assert(Array.isArray(all)&&all.length>0&&all.length<=10,'COMPLETE_DEPLOYMENT_LIST');const d=currentDeployment(all,version);assert(d.versions.length===1&&d.versions[0].percentage===100&&d.versions[0].version_id===version,'ACTUAL_CURRENT_REVISION');return {worker:FIXED.workers[role],versionId:version,deploymentId:d.id,createdOn:d.created_on};}
export function projectVersion(stdout,role,version,expected){
 const v=JSON.parse(stdout);assert(v.id===version&&Array.isArray(v.resources?.bindings)&&v.resources.bindings.length<=64,'ACTUAL_VERSION');const b=v.resources.bindings,bindings=projectVersionBindings(b,expected),secrets=expected.secrets.required;
 const allowed=new Set(Object.keys(expected.vars));const safe=b.every(x=>!(/SECRET|TOKEN|PASSWORD|API_KEY/u.test(x.name))||x.type==='secret_text')&&secrets.every(n=>b.some(x=>x.name===n&&x.type==='secret_text'))&&b.filter(x=>x.type==='plain_text').every(x=>allowed.has(x.name));
 const salt=b.find(x=>x.name==='ARC_AI_IP_HASH_SALT');assert(safe&&(role==='site'?salt?.type==='plain_text'&&salt.text==='synthetic-test-salt-value':salt===undefined),'PRE_EXPORT_TYPE_GATE');
 return {worker:FIXED.workers[role],versionId:v.id,bindings,exportTypeGatePassed:true,sensitiveTypesPass:true,syntheticSaltMatchesFixture:true};
}
export function projectExport(folder,role,expected){
 const dir=resolve(folder,FIXED.workers[role]),bytes=readFileSync(resolve(dir,'wrangler.jsonc')),c=JSON.parse(bytes);
 assert(c.name===expected.name&&!c.unsafe&&same(c.vars,expected.vars),'EXACT_EXPORT_PLAIN_VALUES');const files=[];
 function walk(p){for(const item of readdirSync(p,{withFileTypes:true})){const path=resolve(p,item.name);assert(path.startsWith(dir+sep)&&!item.isSymbolicLink(),'EXPORT_CONTAINMENT');if(item.isDirectory())walk(path);else if(item.isFile()){const b=readFileSync(path);files.push({path:relative(dir,path).replaceAll('\\','/'),bytes:b.length,sha256:hash(b)});}}}walk(resolve(dir,'src'));
 const entry=files.find(f=>resolve(dir,f.path)===resolve(dir,c.main));assert(files.length===1&&entry?.sha256===FIXED.artifacts[role],'EXACT_UNCHANGED_BUNDLE');
 return {configSha256:hash(bytes),moduleFiles:files,entrySha256:entry.sha256,actualSchedulesRead:true,projection:{name:c.name,workers_dev:c.workers_dev??null,preview_urls:c.preview_urls??null,routes:c.routes??[],triggers:{crons:c.triggers?.crons??[]},vars:Object.fromEntries(Object.entries(c.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT')),d1_databases:c.d1_databases??[],r2_buckets:c.r2_buckets??[],services:c.services??[],workflows:c.workflows??[],compatibility_date:c.compatibility_date??null,compatibility_flags:c.compatibility_flags??[],limits:c.limits??null,observability:c.observability??null}};
}
export function projectRoster(stdout,name){
 const text=clean(stdout),lines=text.split(/\r?\n/u),table=lines.filter(l=>l.includes('│')).map(l=>l.split('│').slice(1,-1).map(v=>v.trim()));
 const rows=table.filter(r=>r[0]!=='Instance ID');assert(Buffer.byteLength(text)<=131072&&rows.length<100&&rows.every(r=>r.length===5)&&((rows.length===0&&/There are no instances in workflow/u.test(text))||table.some(r=>r[0]==='Instance ID')),'COMPLETE_INSTANCE_LIST');
 const projected=rows.map(r=>{assert(uuid(r[0])&&uuid(r[1])&&r[2].length<=80&&r[3].length<=80&&/^[0-9/,:.\-\s年月日上下午APMapm]+$/u.test(r[2]+r[3]),'SAFE_INSTANCE_ID_TIMES');const status=r[4].replace(/^[^A-Za-z]+/u,'').toLowerCase();assert(['complete','completed','errored','paused','queued','running','terminated','waiting','waiting for pause'].includes(status),'INSTANCE_STATUS');return {instanceId:r[0],version:r[1],created:r[2],modified:r[3],status};});
 assert(new Set(projected.map(x=>x.instanceId)).size===projected.length,'UNIQUE_INSTANCE_LIST');return {name,rows:projected,availableListComplete:true};
}
export function projectScheduled(v){assert(v?.scriptName===FIXED.workers.executor&&integer(v.event?.scheduledTime),'FIXED_SCHEDULED_EVENT');const version=v.scriptVersion?.id??v.scriptVersion;assert(uuid(version)&&['ok','exception','canceled','exceededCpu','exceededMemory','unknown'].includes(v.outcome),'SAFE_SCHEDULED_METADATA');return {scriptName:FIXED.workers.executor,scriptVersionId:version,scheduledTime:v.event.scheduledTime,eventTimestamp:integer(v.eventTimestamp)?v.eventTimestamp:null,cron:v.event.cron==='* * * * *'?v.event.cron:null,outcome:v.outcome};}

// Corrected P parser: Completed/research-once-1/one attempt; epoch/job are fixed arguments.
const fail=code=>{throw Error(code);}, uuidTest=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u;
function safeDisplayTime(v) {
  if (typeof v !== 'string' || v.length > 80 || !/^[0-9/,:.\-\s年月日上下午APMapm]+$/u.test(v)) fail('workflow-time');
  return v;
}
function duration(v) { if (!/^\d+(?:\.\d+)? (?:seconds?|minutes?|hours?|days?|months?|years?)$/u.test(v)) fail('workflow-duration'); return v; }
function enumSuffix(v, values) {
  const found = values.find(x => v === x || v.endsWith(' ' + x));
  if (!found) fail('workflow-enum');
  return found.toLowerCase().replaceAll(' ', '-');
}
function metadataWorkflow(stdout, scenarioId) {
  const FIXED={workflowName:'arc-v8-smoke-workflow-20261013-guarded',jobId:SCENARIOS[scenarioId].jobId};
  const text = clean(stdout), lines = text.split(/\r?\n/u);
  if (Buffer.byteLength(text) > 65536 || lines.length > 512 || lines.some(l => /^\s*Output\s*:/u.test(l))) fail('workflow-output-forbidden');
  const instance = {}, steps = []; let inSteps = false, step = null, tableHeaders = null;
  const set = (obj, key, value) => { if (Object.hasOwn(obj, key)) fail('workflow-duplicate'); obj[key] = value; };
  for (const line of lines) {
    if (line.trim() === 'Steps:') { if (inSteps) fail('workflow-duplicate'); inSteps = true; continue; }
    if (line.includes('│')) {
      if (!step) fail('workflow-table');
      const cells = line.split('│').slice(1, -1).map(v => v.trim());
      if (cells[0] === 'Start') {
        if (tableHeaders || !same(cells.slice(0, 4), ['Start', 'End', 'Duration', 'State'])
          || (cells.length !== 4 && !(cells.length === 5 && cells[4] === 'Error'))) fail('workflow-table-header');
        tableHeaders = cells; continue;
      }
      if (!tableHeaders || cells.length !== tableHeaders.length || step.attempts.length >= 16) fail('workflow-table');
      step.attempts.push({ start: safeDisplayTime(cells[0]), end: cells[1] ? safeDisplayTime(cells[1]) : null,
        duration: duration(cells[2]), state: enumSuffix(cells[3], ['Working', 'Success', 'Error']),
        errorPresent: cells.length === 5 && cells[4] !== '' });
      continue;
    }
    const match = line.match(/^\s*([A-Za-z ]+):\s*(.*?)\s*$/u);
    if (!match) continue;
    const [, key, value] = match;
    if (!inSteps) {
      if (key === 'Workflow Name') { if (value !== FIXED.workflowName) fail('workflow-identity'); set(instance, 'workflowName', value); }
      else if (key === 'Instance Id') { if (value !== FIXED.jobId) fail('workflow-identity'); set(instance, 'instanceId', value); }
      else if (key === 'Version Id') { if (!uuidTest.test(value)) fail('workflow-version'); set(instance, 'versionId', value); }
      else if (key === 'Status') set(instance, 'status', enumSuffix(value, ['Completed', 'Errored', 'Paused', 'Queued', 'Running', 'Terminated', 'Waiting', 'Waiting for Pause', 'Unknown']).replace(/^completed$/u, 'complete'));
      else if (key === 'Trigger') set(instance, 'trigger', enumSuffix(value, ['API', 'Binding', 'Cron', 'Event', 'Unknown']));
      else if (['Queued', 'Start', 'End'].includes(key)) set(instance, key.toLowerCase(), safeDisplayTime(value));
      else if (key === 'Duration') set(instance, 'duration', duration(value));
      else if (key === 'Success') set(instance, 'success', enumSuffix(value, ['Yes', 'No']));
      else if (key === 'Last Successful Step') { if (value !== 'research-once-1') fail('workflow-step'); set(instance, 'lastSuccessfulStep', 'research-once'); set(instance, 'nativeLastSuccessfulStep', value); }
      else if (key === 'Error') set(instance, 'errorPresent', true);
    } else {
      if (key === 'Name') {
        if (value !== 'research-once-1' || steps.length >= 1) fail('workflow-step');
        step = { name: 'research-once', nativeName: value, attempts: [] }; steps.push(step); tableHeaders = null;
      } else if (step) {
        if (key === 'Type') set(step, 'type', enumSuffix(value, ['Step']));
        else if (key === 'Start' || key === 'End') set(step, key.toLowerCase(), safeDisplayTime(value));
        else if (key === 'Duration') set(step, 'duration', duration(value));
        else if (key === 'Success') set(step, 'success', enumSuffix(value, ['Yes', 'No', 'Running']));
        else if (key === 'Retries At') fail('workflow-unexpected-retry');
        else if (key === 'Error') set(step, 'errorPresent', true);
      }
    }
  }
  if (instance.workflowName !== FIXED.workflowName || instance.instanceId !== FIXED.jobId || !instance.status || !inSteps
    || steps.some(s => s.type !== 'step')) fail('workflow-required-metadata');
  if (steps.length !== 1 || steps[0].attempts.length !== 1) fail('workflow-step-cardinality');
  return { instance, steps, stepOutputRequested: false, rawOutputRetained: false, workflowOutputReferenceProved: false,
    timeFormat: 'Wrangler locale display; observation UTC timestamps are recorded separately' };
}

export function projectWorkflow(stdout,scenarioId){
 assert(Object.hasOwn(SCENARIOS,scenarioId),'FIXED_SCENARIO');const lines=clean(stdout).split(/\r?\n/u),outputs=lines.filter(l=>/^\s*Output\s*:/u.test(l));
 assert(outputs.length<2&&(scenarioId!=='long'||outputs.length===0),'ONE_SAFE_REFERENCE');let reference=null;
 if(outputs.length){const value=outputs[0].replace(/^\s*Output\s*:\s*/u,'');assert(Buffer.byteLength(value)<=4096,'REFERENCE_BOUND');const v=JSON.parse(value);assert(same(Object.keys(v).sort(),['jobId','receiptHash','state'])&&v.jobId===SCENARIOS[scenarioId].jobId&&['recorded','already-claimed','closed','unavailable'].includes(v.state)&&(v.receiptHash===null||digest(v.receiptHash))&&(v.state==='recorded'||v.receiptHash===null),'SAFE_WORKFLOW_REFERENCE');reference=v;}
 const metadata=metadataWorkflow(lines.filter(l=>!/^\s*Output\s*:/u.test(l)).join('\n'),scenarioId);
 assert(scenarioId==='long'||metadata.instance.status!=='complete'||reference!==null,'COMPLETED_FAULT_REFERENCE_REQUIRED');
 return {...metadata,reference,stepOutputRequested:scenarioId!=='long',workflowOutputReferenceProved:reference!==null};
}
