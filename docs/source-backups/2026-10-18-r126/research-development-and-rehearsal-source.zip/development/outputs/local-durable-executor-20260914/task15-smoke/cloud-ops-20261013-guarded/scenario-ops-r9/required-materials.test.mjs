// Read-only static completeness checks against actual readiness/tool/terminal requirements.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {here,hash,toolRefs} from './guards.mjs';
import {terminalPins} from './terminal-contract.mjs';
const material=()=>JSON.parse(readFileSync(resolve(here,'material-manifest-r9.json'),'utf8'));
function requiredPin(files,pin){const matches=files.filter(x=>x.path===pin.path);assert.equal(matches.length,1,'Exactly one reviewed static file: '+pin.path);assert.equal(matches[0].sha256,pin.sha256,'Current static bytes: '+pin.path);}
test('material inventory covers every exact file required by actual masked readiness source',()=>{
 const readiness=readFileSync(resolve(here,'readiness.ps1'),'utf8');
 const blocks=[...readiness.matchAll(/foreach \(\$arcName in @\(([^)]*)\)\) \{[\s\S]*?REVIEWED_TASK3_FILE_REQUIRED[\s\S]*?\n    \}/g)];
 assert.equal(blocks.length,1,'One actual readiness required-file gate');
 const literalList=blocks[0][1],names=[...literalList.matchAll(/'([^']+)'/g)].map(x=>x[1]);
 assert.equal(literalList.replace(/'[^']*'|[,\s]/g,''),'','Only fixed literal names in actual gate');
 assert.ok(names.length>0);const m=material();
 for(const name of names){const path=resolve(here,name);for(const files of [m.files,m.rootAcceptanceIngredients.task3Files]){
  const matches=files.filter(x=>x.path===path);assert.equal(matches.length,1,'Readiness-required material: '+name);
  assert.equal(matches[0].sha256,hash(readFileSync(path)),'Readiness-required bytes: '+name);
 }}
});
test('material inventory covers current tools and all nine exact terminal pin sets',()=>{
 const m=material(),tools=toolRefs();assert.deepEqual(m.rootAcceptanceIngredients.tools,tools);
 const pins=[...Object.values(tools)];
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay'])pins.push(...Object.values(terminalPins(id+':'+mode)));
 for(const pin of pins)for(const files of [m.files,m.rootAcceptanceIngredients.task3Files])requiredPin(files,pin);
});
