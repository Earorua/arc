$ErrorActionPreference = 'Stop'
try {
if ($args.Count -ne 0) { throw 'Fixed no-argument attended command only' }
$arcEntry = 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261013-guarded\scenario-ops-r9\terminal-entry.ps1'
if ((Get-FileHash -LiteralPath $arcEntry -Algorithm SHA256).Hash.ToLowerInvariant() -cne '750dec4f0749ca86c07ab478739ae9b896d3b9960c1e81764c6e0cc301583d09') { throw 'Reviewed terminal entry changed' }
. $arcEntry
    $arcExit = Invoke-ArcFixedTerminalCommand -Role 'long:status' -ContractPath 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261013-guarded\scenario-ops-r9\launcher-contract.json' -ContractSha256 'f9c4499228b5fdfc54a644c3ff612eff41e769f61997e36bda0f55c330da40f7' -LauncherPath 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20260914\task15-smoke\cloud-ops-20261013-guarded\scenario-ops-r9\run-long-status-masked-once-r1.ps1' -LauncherSha256 '6f2cb9f092248c93ecdbbae7f657b779e2d68518843f6526d60fff1d29a984fb' -CommandPath $PSCommandPath
    Write-Host ('ExitCode: ' + $arcExit)
    exit $arcExit
} catch {
    [Console]::Error.WriteLine('TERMINAL_PREPARATION_REFUSED_STOP_RECONCILE_NO_RETRY')
    Write-Host 'ExitCode: 1'
    exit 1
}
