$ErrorActionPreference = 'Stop'
# OFFLINE ONLY. Synthetic values remain in memory or the dedicated temporary test directory.
. (Join-Path $PSScriptRoot 'readiness.ps1')
$testContract = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'launcher-contract.json') -Raw | ConvertFrom-Json
$testCount = 0
function Check([bool]$Value, [string]$Message) { if (-not $Value) { throw $Message }; $script:testCount++ }
function Refuses([scriptblock]$Action, [string]$Code) {
    $caught = $false
    try { & $Action | Out-Null } catch { if ($_.Exception.Message -notlike "*$Code*") { throw }; $caught = $true }
    Check $caught ('Expected refusal: ' + $Code)
}
$testDirectory = Join-Path 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20261016\r7-integration-r1' ('r7-l-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
[void][IO.Directory]::CreateDirectory($testDirectory)
foreach ($testRole in $testContract.roles) {
    foreach ($testPath in @($testRole.launcherPath, $testRole.commandPath)) {
        $testTokens = $null; $testErrors = $null
        $testAst = [Management.Automation.Language.Parser]::ParseFile($testPath, [ref]$testTokens, [ref]$testErrors)
        Check ($testErrors.Count -eq 0) ('AST: ' + $testPath)
    }
    $testText = [IO.File]::ReadAllText($testRole.launcherPath)
    $testBlock = [regex]::Match($testText, '(?s)    \$smokeArgumentValues = @\(\).*?    \$smokeArguments = [^\r\n]*').Value
    Check (-not [string]::IsNullOrEmpty($testBlock)) 'Exact frozen argument block'
    $smokeDriver = $testContract.driver.path; $Mode = $testRole.mode; $Scenario = $testRole.scenarioId
    $smokeInventory = $testContract.inventory.path; $smokeArtifactReport = $testContract.artifactReport.path
    $ReportName = $testRole.reportName; $UseSystemProxy = $true; $smokeApproval = $testContract.approvalPath
    . ([scriptblock]::Create($testBlock))
    $testExpected = @('--use-env-proxy', $smokeDriver, $Mode, '--inventory', $smokeInventory, '--artifact-report', $smokeArtifactReport, '--scenario', $Scenario, '--report-name', $ReportName)
    if ($Mode -ceq 'replay') { $testExpected += @('--approval', $smokeApproval) }
    Check (($smokeArgumentValues | ConvertTo-Json -Compress) -ceq ($testExpected | ConvertTo-Json -Compress)) 'Exact child arguments'
    Check ($testText.Contains('Read-Host ''Paste 64-hex cloud smoke control secret (masked)'' -AsSecureString')) 'Masked prompt retained'
    Check ($testText.Contains('$smokeChild.StandardInput.WriteLine($smokePlain)')) 'Stdin-only original credential input'
    Check ($testText.Contains('$smokeStart.CreateNoWindow = $true')) 'Hidden child retained'
    Check ($testText.Contains('ZeroFreeBSTR($smokeBstr)')) 'Original zeroing retained'
    $testDrainBudget = [regex]::Match($testText, '(?m)^    \$smokeRemainingDrainMs = [^\r\n]*').Value
    Check (-not [string]::IsNullOrEmpty($testDrainBudget)) 'Absolute drain budget insertion'
    foreach ($testTiming in @(@(1000,5000),@(61000,4000),@(65000,0),@(66000,0))) {
        $smokeChildClock=[pscustomobject]@{ElapsedMilliseconds=$testTiming[0]}
        . ([scriptblock]::Create($testDrainBudget))
        Check ($smokeRemainingDrainMs -eq $testTiming[1]) 'Normal five seconds and strict remaining reserve'
    }
    $testPendingDrain=[Threading.Tasks.TaskCompletionSource[bool]]::new()
    $smokeDrainTask=$testPendingDrain.Task
    $testDrainCheck = [regex]::Match($testText, '(?m)^    if \(-not \$smokeDrainTask.Wait\(\$smokeRemainingDrainMs\)\) [^\r\n]*').Value
    Refuses { . ([scriptblock]::Create($testDrainCheck)) } 'Driver output deadline exceeded'
    $testPendingDrain.SetResult($true)
    . ([scriptblock]::Create($testDrainCheck))
}
foreach ($testPath in @((Join-Path $PSScriptRoot 'readiness.ps1'), $PSCommandPath)) {
    $testTokens = $null; $testErrors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($testPath, [ref]$testTokens, [ref]$testErrors)
    Check ($testErrors.Count -eq 0) ('AST: ' + $testPath)
}
$testHashPath = Join-Path $testDirectory 'hash.txt'
[IO.File]::WriteAllText($testHashPath, 'offline synthetic bytes')
Refuses { Assert-ArcFileReference ([pscustomobject]@{path=$testHashPath;sha256=('0' * 64)}) } 'HASH_CHANGED'
$testFirst = $testContract.roles[0]
$testFixed = @{Contract=$testContract;Mode=$testFirst.mode;Scenario=$testFirst.scenarioId;Inventory=$testContract.inventory.path;ArtifactReport=$testContract.artifactReport.path;ReportName=$testFirst.reportName;Approval=$null;SystemProxy=$true;LauncherPath=$testFirst.launcherPath;NodePath=$testContract.node.path}
$testWrong = $testFixed.Clone(); $testWrong.Inventory=$testHashPath
Refuses { Assert-ArcFixedInvocation @testWrong } 'FIXED_INVOCATION'
$testWrong = $testFixed.Clone(); $testWrong.Mode='status'
Refuses { Assert-ArcFixedInvocation @testWrong } 'FIXED_INVOCATION'
$testWrong = $testFixed.Clone(); $testWrong.LauncherPath=$testHashPath
Refuses { Assert-ArcFixedInvocation @testWrong } 'FIXED_INVOCATION'
$testWrong = $testFixed.Clone(); $testWrong.SystemProxy=$false
Refuses { Assert-ArcFixedInvocation @testWrong } 'FIXED_INVOCATION'
$testWrong = $testFixed.Clone(); $testWrong.Approval=$testHashPath
Refuses { Assert-ArcFixedInvocation @testWrong } 'FIXED_INVOCATION'
Check ($null -ne (Assert-ArcFixedInvocation @testFixed)) 'Fixed invocation accepts exact role'
$testNow = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$testReady = [pscustomobject]@{Handoff=[pscustomobject]@{inputAllowanceMs=60000;deadlineAt=($testNow+90000);childReserveMs=65000}}
Assert-ArcInputWindow -Ready $testReady -ElapsedMs 100 -Now $testNow
Refuses { Assert-ArcInputWindow -Ready $testReady -ElapsedMs 60000 -Now $testNow } 'INPUT_WINDOW'
Refuses { Assert-ArcInputWindow -Ready $testReady -ElapsedMs 100 -Now ($testNow+26000) } 'INPUT_WINDOW'
$testReady.Handoff.inputAllowanceMs=45000
Refuses { Assert-ArcInputWindow -Ready $testReady -ElapsedMs 45000 -Now $testNow } 'INPUT_WINDOW'
$testSnapshot = [pscustomobject]@{HandoffSha256=('a'*64);MaterialsSha256=('b'*64);ReadinessSha256=('c'*64);LauncherSha256=('d'*64);ApprovalSha256=$null}
Assert-ArcUnchangedReadiness -Before $testSnapshot -After $testSnapshot
$testChanged = $testSnapshot.PSObject.Copy(); $testChanged.ReadinessSha256=('e'*64)
Refuses { Assert-ArcUnchangedReadiness -Before $testSnapshot -After $testChanged } 'CHANGED_DURING_INPUT'
$testExclusive = Join-Path $testDirectory 'exclusive.json'
New-ArcExclusiveJson -Path $testExclusive -Value ([ordered]@{offline=$true;id='original'})
Refuses { New-ArcExclusiveJson -Path $testExclusive -Value ([ordered]@{offline=$true;id='replacement'}) } 'EXCLUSIVE_FILE_EXISTS'
Check ((Get-Content -LiteralPath $testExclusive -Raw | ConvertFrom-Json).id -ceq 'original') 'Exclusive write preserves first attempt'
$testAttempt=[pscustomobject]@{Path=$testExclusive;Sha256=(Get-FileHash $testExclusive -Algorithm SHA256).Hash.ToLowerInvariant();InvocationId='original';ProcessId=$PID}
Refuses { Assert-ArcOwnedAttempt -Attempt $testAttempt -ExpectedPath $testExclusive } 'OWNED_ATTEMPT'
# Real local processes contain no input, key, transport, control request, or evidence fixture.
$testProcess = [Diagnostics.Process]::new()
$testProcess.StartInfo.FileName=$testContract.node.path
$testProcess.StartInfo.Arguments='-e "setTimeout(()=>{},10000)"'
$testProcess.StartInfo.UseShellExecute=$false; $testProcess.StartInfo.CreateNoWindow=$true
$testProcess.StartInfo.EnvironmentVariables.Remove('NODE_OPTIONS')
$testClock=[Diagnostics.Stopwatch]::StartNew()
$testStartedAt=Get-ArcUtcNow
[void]$testProcess.Start()
$testUnconfirmed = Get-ArcChildCloseFact -Child $testProcess -Clock $testClock -ReserveMs 1
Check ($testUnconfirmed.childCloseConfirmed -eq $false) 'Live process is never confirmed from elapsed deadline'
$testProcess.Kill()
$testConfirmed = Get-ArcChildCloseFact -Child $testProcess -Clock $testClock -ReserveMs 65000
Check ($testConfirmed.childCloseConfirmed -eq $true) 'Actual post-kill WaitForExit confirms exit'
Check ($testConfirmed.confirmedExitAt -match '^\d{4}-\d{2}-\d{2}T.*\.\d{3}Z$') 'Exact exit UTC timestamp'
$testProcess.Dispose()
Check ($null -eq (Get-ArcChildCloseFact -Child $null -Clock $testClock).confirmedExitAt) 'Missing child cannot confirm exit'
$testHandoffRef=[pscustomobject]@{path=$testHashPath;sha256=(Get-ArcHash $testHashPath)}
$testOwnedReady=[pscustomobject]@{Contract=$testContract;Role=[pscustomobject]@{scenarioId='long';mode='start';attemptPath=(Join-Path $testDirectory 'attempt.json');exitPath=(Join-Path $testDirectory 'exit.json');reportPath=(Join-Path $testDirectory 'missing-report/report.json')};HandoffReference=$testHandoffRef;
    Handoff=[pscustomobject]@{materials=$testHandoffRef;expectedVersions=[pscustomobject]@{site='synthetic-only';executor='synthetic-only'}};
    Launcher=[pscustomobject]@{path=$testFirst.launcherPath;sha256=(Get-ArcHash $testFirst.launcherPath)}}
$testOwned=New-ArcLaunchAttempt -Ready $testOwnedReady
Assert-ArcOwnedAttempt -Attempt $testOwned -ExpectedPath $testOwnedReady.Role.attemptPath -Handoff $testHandoffRef
Refuses { New-ArcLaunchAttempt -Ready $testOwnedReady } 'EXCLUSIVE_FILE_EXISTS'
$testOtherOwner=$testOwned.PSObject.Copy();$testOtherOwner.InvocationId='another-invocation'
Refuses { Assert-ArcOwnedAttempt -Attempt $testOtherOwner -ExpectedPath $testOwnedReady.Role.attemptPath -Handoff $testHandoffRef } 'OWNED_ATTEMPT'
$testOtherHandoff=$testHandoffRef.PSObject.Copy();$testOtherHandoff.sha256=('b'*64)
Refuses { Assert-ArcOwnedAttempt -Attempt $testOwned -ExpectedPath $testOwnedReady.Role.attemptPath -Handoff $testOtherHandoff } 'OWNED_ATTEMPT'
Write-ArcControlExit -Ready $testOwnedReady -Attempt $testOwned -StartedAt $testStartedAt -CloseFact $testConfirmed -LauncherExitCode 1
$testExit=Get-Content -LiteralPath $testOwnedReady.Role.exitPath -Raw | ConvertFrom-Json
Check ($testExit.childCloseConfirmed -eq $true -and $testExit.endedAt -ceq $testConfirmed.confirmedExitAt) 'Exit uses actual local process close fact'
Check ($null -eq $testExit.report -and $null -eq $testExit.hostHelper -and $testExit.disposition -ceq 'STOP_RECONCILE_NO_RETRY') 'Missing report cannot become successful evidence'
Refuses { Write-ArcControlExit -Ready $testOwnedReady -Attempt $testOwned -StartedAt $testStartedAt -CloseFact $testConfirmed -LauncherExitCode 1 } 'EXCLUSIVE_FILE_EXISTS'
$testOwnedReady.Role.attemptPath=Join-Path $testDirectory 'unconfirmed-attempt.json';$testOwnedReady.Role.exitPath=Join-Path $testDirectory 'unconfirmed-exit.json'
$testUnconfirmedOwned=New-ArcLaunchAttempt -Ready $testOwnedReady
Write-ArcControlExit -Ready $testOwnedReady -Attempt $testUnconfirmedOwned -StartedAt $testStartedAt -CloseFact $testUnconfirmed -LauncherExitCode 1
$testUnconfirmedExit=Get-Content -LiteralPath $testOwnedReady.Role.exitPath -Raw | ConvertFrom-Json
Check ($testUnconfirmedExit.childCloseConfirmed -eq $false -and $null -eq $testUnconfirmedExit.confirmedExitAt -and $null -eq $testUnconfirmedExit.endedAt) 'Unconfirmed child cannot manufacture an exit time'
# A malformed temp reference reaches the actual frozen validator and is refused locally.
Refuses { Invoke-ArcHandoffValidation -Contract $testContract -Reference $testHandoffRef } 'LOCAL_PROVENANCE_REFUSED'
$testReadinessBefore = @($testContract.roles | Where-Object { Test-Path -LiteralPath $_.readinessPath }).Count
Check ($testReadinessBefore -eq 0) 'No operational readiness fixtures created'
@{status='OFFLINE_TASK3_PS_PASS';checks=$testCount;powershellMajor=$PSVersionTable.PSVersion.Major;syntheticDirectory=$testDirectory;controlCalls=0;credentialReads=0} | ConvertTo-Json -Compress
