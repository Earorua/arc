param([string]$EntryPath=(Join-Path $PSScriptRoot 'terminal-entry.ps1'),[string]$EvidenceName='green')
$ErrorActionPreference='Stop'
. $EntryPath
$testResults=[Collections.Generic.List[object]]::new()
function Check([bool]$Value,[string]$Name) { $testResults.Add([pscustomobject]@{name=$Name;passed=$Value}) }
function Failure([scriptblock]$Action) {
    $captured=[Collections.Generic.List[object]]::new(); $failure=$null
    try { & $Action | ForEach-Object { $captured.Add($_) } } catch { $failure=$_.Exception }
    return [pscustomobject]@{exception=$failure;output=@($captured.ToArray())}
}
$testDirectory=Join-Path 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20261016\r7-integration-r1' ('r7-d-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
[void][IO.Directory]::CreateDirectory($testDirectory)
$testCanary='PRIVATE_UNKNOWN_CANARY_8f1376'
$streamCanary='PRIVATE_STREAM_CANARY_273adc'
$testNode='C:\Program Files\nodejs\node.exe'
$testBackend=Join-Path $testDirectory 'fake-child.cjs'
$testCounter=Join-Path $testDirectory 'attempts.txt'
$testCounterLiteral=ConvertTo-Json $testCounter -Compress
[IO.File]::WriteAllText($testBackend,('const fs=require("fs"); const counter='+$testCounterLiteral+'; fs.appendFileSync(counter, "attempt\n"); fs.writeFileSync(counter+".pid",String(process.pid));'+@'
switch(process.argv[2]) {
case 'clean': process.stdout.write('{"ok":true}'); break;
case 'stderr': process.stdout.write('{"ok":true}'); process.stderr.write('PRIVATE_STREAM_CANARY_273adc'); break;
case 'nonzero': process.stdout.write('PRIVATE_STREAM_CANARY_273adc'); process.exitCode=7; break;
case 'invalid': process.stdout.write('PRIVATE_STREAM_CANARY_273adc'); break;
case 'timeout': setTimeout(()=>{},5000); break;
case 'oversize': process.stdout.write('x'.repeat(65537)); break;
case 'inspect': process.stdout.write(JSON.stringify({validUntil:Date.now()+10000,template:{sha256:'0'.repeat(64)}})); break;
case 'prepare': process.stdout.write(JSON.stringify({acknowledgementDeadlineAt:Date.now()+5000})); break;
default: process.exitCode=9;
}
'@))
$testContract=[pscustomobject]@{root=$testDirectory;node=[pscustomobject]@{path=$testNode;sha256=(Get-FileHash -LiteralPath $testNode -Algorithm SHA256).Hash.ToLowerInvariant()};terminalBackend=[pscustomobject]@{path=$testBackend;sha256=(Get-FileHash -LiteralPath $testBackend -Algorithm SHA256).Hash.ToLowerInvariant()}}
$testContext=@{stage='prepare-child';child=$null;acknowledgement=$null}
$clean=@(Invoke-ArcTerminalChild -Contract $testContract -Values @('clean') -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs 5000 -DiagnosticContext $testContext)
Check ($clean.Count -eq 1 -and $clean[0].ok -eq $true) 'clean JSON remains the only success-stream value'
Check ($null -ne $testContext.child -and $testContext.child.stage -ceq 'prepare-child' -and $testContext.child.started -eq $true -and $testContext.child.exitedObserved -eq $true -and $testContext.child.exitCode -eq 0 -and $testContext.child.drainComplete -eq $true -and $testContext.child.stdoutCharacters -eq 11 -and $testContext.child.stderrCharacters -eq 0 -and $testContext.child.jsonParseSucceeded -eq $true -and $testContext.child.elapsedMs -ge 0) 'clean child records stage, exit, drain, counts, parse and elapsed metadata'
$testContext.stage='acknowledge-child'
$stderr=Failure { Invoke-ArcTerminalChild -Contract $testContract -Values @('stderr') -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs 5000 -DiagnosticContext $testContext }
Check ($stderr.exception.Message -ceq 'TERMINAL_CHILD_FAILED_STOP_RECONCILE' -and $stderr.output.Count -eq 0) 'exit zero with stderr still refuses without success-stream content'
Check ($null -ne $testContext.child -and $testContext.child.stage -ceq 'acknowledge-child' -and $testContext.child.exitCode -eq 0 -and $testContext.child.drainComplete -eq $true -and $testContext.child.stderrCharacters -eq $streamCanary.Length -and $testContext.child.jsonParseSucceeded -eq $false) 'stderr failure is distinguishable from clean exit zero and context resets'
$hasProjection=$null -ne (Get-Command Get-ArcTerminalFailureDiagnostic -ErrorAction SilentlyContinue)
Check $hasProjection 'failure projection provides fixed stage and code'
if ($hasProjection) {
    $stderrProjection=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $stderr.exception
    Check ($stderrProjection.stage -ceq 'acknowledge-child' -and $stderrProjection.code -ceq 'TERMINAL_CHILD_FAILED_STOP_RECONCILE') 'failure projection includes actual stage and exact known code'
    Check (($stderrProjection | ConvertTo-Json -Depth 10 -Compress) -cnotmatch $streamCanary) 'stderr canary never enters projected diagnostics'
}
foreach($case in @(@{mode='nonzero';code='TERMINAL_CHILD_FAILED_STOP_RECONCILE';exit=7;drained=$true},@{mode='invalid';code='OTHER_LOCAL_EXCEPTION';exit=0;drained=$true},@{mode='timeout';code='TERMINAL_CHILD_TIMEOUT_STOP_RECONCILE';exit=$null;drained=$false},@{mode='oversize';code='TERMINAL_CHILD_FAILED_STOP_RECONCILE';exit=0;drained=$true})) {
    $before=([IO.File]::ReadAllLines($testCounter)).Count
    $testContext.stage='prepare-child'
    $wait=5000; if($case.mode -eq 'timeout'){$wait=200}
    $failed=Failure { Invoke-ArcTerminalChild -Contract $testContract -Values @($case.mode) -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs $wait -DiagnosticContext $testContext }
    Check ($null -ne $failed.exception -and $failed.output.Count -eq 0) ($case.mode+' refuses without success output')
    Check (([IO.File]::ReadAllLines($testCounter)).Count -eq ($before+1)) ($case.mode+' launches once without retry')
    Check ($null -ne $testContext.child -and $testContext.child.started -eq $true -and $testContext.child.jsonParseSucceeded -eq $false -and $testContext.child.drainComplete -eq $case.drained) ($case.mode+' records current child lifecycle')
    if($case.mode -eq 'timeout') {
        Check ($null -ne $testContext.child -and $testContext.child.exitedObserved -eq $false -and -not $testContext.child.Contains('exitCode') -and -not $testContext.child.Contains('stdoutCharacters') -and -not $testContext.child.Contains('stderrCharacters')) 'timeout does not invent exit or drained counts'
        $stillRunning=$false
        try { $timeoutProcess=[Diagnostics.Process]::GetProcessById([int]([IO.File]::ReadAllText($testCounter+'.pid'))); $stillRunning=-not $timeoutProcess.HasExited; $timeoutProcess.Dispose() } catch [ArgumentException] { }
        Check (-not $stillRunning) 'timed out local child is killed by original cleanup'
    } else {
        Check ($null -ne $testContext.child -and $testContext.child.exitedObserved -eq $true -and $testContext.child.exitCode -eq $case.exit) ($case.mode+' records observed numeric exit')
    }
    if($hasProjection) {
        $projection=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $failed.exception
        Check ($projection.code -ceq $case.code) ($case.mode+' projects finite code')
        Check (($projection | ConvertTo-Json -Depth 10 -Compress) -cnotmatch $streamCanary) ($case.mode+' stream canary excluded')
    }
}
$before=([IO.File]::ReadAllLines($testCounter)).Count
$testContext.stage='inspect-child'
$expired=Failure { Invoke-ArcTerminalChild -Contract $testContract -Values @('clean') -DeadlineAt (Get-ArcTerminalMs) -MaximumWaitMs 5000 -DiagnosticContext $testContext }
Check ($expired.exception.Message -ceq 'BOUNDED_TERMINAL_CHILD_DEADLINE') 'expired deadline still refuses'
Check ($null -ne $testContext.child -and $testContext.child.started -eq $false -and $testContext.child.exitedObserved -eq $false -and $testContext.child.stage -ceq 'inspect-child' -and -not $testContext.child.Contains('exitCode')) 'expired call clears preceding child metadata'
$testContract.terminalBackend.sha256='0'*64
$changed=Failure { Invoke-ArcTerminalChild -Contract $testContract -Values @('clean') -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs 5000 -DiagnosticContext $testContext }
Check ($changed.exception.Message -ceq 'TERMINAL_PIN_CHANGED') 'changed pin still refuses'
Check (([IO.File]::ReadAllLines($testCounter)).Count -eq $before) 'expired deadline and changed pin launch no child'
Check ($null -ne $testContext.child -and $testContext.child.started -eq $false -and $testContext.child.drainComplete -eq $false -and -not $testContext.child.Contains('stderrCharacters')) 'changed pin has fresh unstarted child metadata'
$testContext.stage='post-native-enter'
$ack=Failure { Read-ArcLocalAcknowledgement -DeadlineAt ((Get-ArcTerminalMs)-1) -Message 'OFFLINE MUST NOT PROMPT' -DiagnosticContext $testContext }
Check ($ack.exception.Message -ceq 'ACTUAL_ATTENDED_CONSOLE_REQUIRED' -and $ack.output.Count -eq 0) 'redirected acknowledgement refuses unchanged'
Check ($null -ne $testContext.acknowledgement -and $testContext.acknowledgement.stage -ceq 'post-native-enter' -and $testContext.acknowledgement.deadlineRemainingMs -le 0) 'acknowledgement entry records stage and remaining deadline even on console refusal'
if($hasProjection) {
    $ackProjection=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $ack.exception
    Check ($ackProjection.stage -ceq 'post-native-enter' -and $ackProjection.code -ceq 'ACTUAL_ATTENDED_CONSOLE_REQUIRED' -and $ackProjection.child.stage -ceq 'inspect-child') 'acknowledgement refusal and previous child retain distinct originating stages'
    $unknown=[Exception]::new($testCanary)
    $testContext.extra=$testCanary
    $testContext.child=@{stage='prepare-child';started=$true;exitedObserved=$true;exitCode=$testCanary;stdoutCharacters=$testCanary;stderrCharacters=0;drainComplete=$true;jsonParseSucceeded=$false;elapsedMs=1;raw=$streamCanary}
    $testContext.acknowledgement=@{stage='post-native-enter';bufferedInputPresent=$true;deadlineRemainingMs=22;pressed=$testCanary}
    $unknownProjection=@(Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $unknown)
    $projectionText=$unknownProjection[0] | ConvertTo-Json -Depth 10 -Compress
    Check ($unknownProjection.Count -eq 1 -and $unknownProjection[0].code -ceq 'OTHER_LOCAL_EXCEPTION') 'unknown exception produces one finite projection'
    Check ($projectionText -cnotmatch $testCanary -and $projectionText -cnotmatch $streamCanary -and $projectionText -notmatch 'exitCode|stdoutCharacters|pressed|raw|extra') 'whitelist excludes raw fields and nonnumeric metadata'
    Check ($unknownProjection[0].acknowledgement.bufferedInputPresent -eq $true -and $unknownProjection[0].acknowledgement.deadlineRemainingMs -eq 22) 'acknowledgement projection retains only safe observation'
    $testContext.child=@{stage='prepare-child';started=$true;exitedObserved=$true;exitCode=0;drainComplete=$false;stdoutCharacters=12;stderrCharacters=34;jsonParseSucceeded=$false;elapsedMs=1}
    $incompleteProjection=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $unknown
    Check ($incompleteProjection.child.exitCode -eq 0 -and $incompleteProjection.child.drainComplete -eq $false -and -not $incompleteProjection.child.Contains('stdoutCharacters') -and -not $incompleteProjection.child.Contains('stderrCharacters')) 'projection distinguishes observed exit from incomplete drain and omits unconfirmed counts'
    $testContext.child.exitedObserved='true'; $testContext.child.drainComplete='true'
    $untypedProjection=Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception $unknown
    Check (-not $untypedProjection.child.Contains('exitCode') -and -not $untypedProjection.child.Contains('stdoutCharacters') -and -not $untypedProjection.child.Contains('stderrCharacters')) 'projection requires actual boolean observations before publishing numeric exit or counts'
    foreach($code in @('ORIGINAL_PREPARATION_ALLOWANCE','ACTUAL_ATTENDED_CONSOLE_REQUIRED','TERMINAL_PIN_CHANGED','LOCAL_ACK_EXPIRED_OR_PREBUFFERED_INPUT','ONLY_ENTER_ACKNOWLEDGEMENT_ALLOWED','LOCAL_ACK_DEADLINE_EXPIRED','BOUNDED_TERMINAL_CHILD_DEADLINE','FIXED_TERMINAL_CHILD_ARGUMENT','TERMINAL_CHILD_TIMEOUT_STOP_RECONCILE','TERMINAL_CHILD_FAILED_STOP_RECONCILE','FIXED_RELEASED_TERMINAL_ROLE','TERMINAL_POST_ACK_RESERVES','MASKED_CHILD_FAILED_STOP_RECONCILE')) {
        Check ((Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception ([Exception]::new($code))).code -ceq $code) ('exact classifier '+$code)
        Check ((Get-ArcTerminalFailureDiagnostic -DiagnosticContext $testContext -Exception ([Exception]::new($code+' '+$testCanary))).code -ceq 'OTHER_LOCAL_EXCEPTION') ('classifier rejects decorated '+$code)
    }
    # Extract only the real terminal catch body. No operational entry or contract runs.
    $tokens=$null; $errors=$null; $ast=[Management.Automation.Language.Parser]::ParseFile($EntryPath,[ref]$tokens,[ref]$errors)
    $entryFunction=$ast.Find({param($a) $a -is [Management.Automation.Language.FunctionDefinitionAst] -and $a.Name -ceq 'Invoke-ArcFixedTerminalCommand'},$true)
    $entryTry=@($entryFunction.Body.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.TryStatementAst]})[-1]
    $catchBlock=[scriptblock]::Create('try { throw $testBoundaryException } catch '+$entryTry.CatchClauses[0].Body.Extent.Text)
    $arcDiagnosticContext=$testContext; $Role='offline:catch-only'; $arcInvocation='offline-fixture'; $arcShellAttempt=Join-Path $testDirectory 'attempt.json'
    [IO.File]::WriteAllText($arcShellAttempt,'{"offline":true}')
    $arcShellFailure=Join-Path $testDirectory 'failure.json'; $testBoundaryException=$unknown
    $boundary=Failure { & $catchBlock }
    $savedText=[IO.File]::ReadAllText($arcShellFailure); $saved=$savedText | ConvertFrom-Json
    Check ($saved.diagnostics.stage -ceq 'post-native-enter' -and $saved.diagnostics.code -ceq 'OTHER_LOCAL_EXCEPTION' -and $saved.noAutomaticRetry -eq $true -and $saved.rawDiagnosticPersisted -eq $false) 'actual catch persists safe diagnostic projection in original failure envelope'
    Check ($boundary.output.Count -eq 0 -and $boundary.exception.Message -ceq 'UNKNOWN_STOP_RECONCILE_NO_RETRY stage=post-native-enter code=OTHER_LOCAL_EXCEPTION') 'actual catch remains failure and emits no success-stream content'
    Check ($savedText -cnotmatch $testCanary -and $savedText -cnotmatch $streamCanary -and $boundary.exception.Message -cnotmatch $testCanary) 'saved catch and public exception exclude unknown and stream canaries'
    $arcShellFailure=Join-Path $testDirectory 'missing-parent/failure.json'
    $persistenceFailure=Failure { & $catchBlock }
    Check ($persistenceFailure.exception.Message -ceq $boundary.exception.Message -and $persistenceFailure.output.Count -eq 0) 'failure to persist diagnostics cannot change sanitized failure or success stream'
    # Execute the actual guarded try block with only the pinned offline child.
    # The real redirected-console refusal stops before acknowledgement/masked dispatch.
    $testContract.terminalBackend.sha256=(Get-FileHash -LiteralPath $testBackend -Algorithm SHA256).Hash.ToLowerInvariant()
    $arcContract=$testContract; $arcInvokedAt=Get-ArcTerminalMs; $Role='offline:try-block-only'
    $arcDiagnosticContext=New-ArcTerminalDiagnosticContext
    $arcShellFailure=Join-Path $testDirectory 'flow.json'
    $beforeFlow=([IO.File]::ReadAllLines($testCounter)).Count
    $entryFlow=Failure { & ([scriptblock]::Create($entryTry.Extent.Text)) }
    $flowSaved=[IO.File]::ReadAllText($arcShellFailure) | ConvertFrom-Json
    Check ($entryFlow.exception.Message -ceq 'UNKNOWN_STOP_RECONCILE_NO_RETRY stage=post-native-enter code=ACTUAL_ATTENDED_CONSOLE_REQUIRED' -and $entryFlow.output.Count -eq 0) 'actual entry try block identifies post-native acknowledgement refusal'
    Check ($flowSaved.diagnostics.child.stage -ceq 'prepare-child' -and $flowSaved.diagnostics.child.jsonParseSucceeded -eq $true -and $flowSaved.diagnostics.acknowledgement.stage -ceq 'post-native-enter') 'actual entry flow retains completed prepare metadata without assigning it to failed acknowledgement'
    Check (([IO.File]::ReadAllLines($testCounter)).Count -eq ($beforeFlow+2)) 'actual entry flow launches inspect and prepare once each and stops before later children'
    $fresh=@(New-ArcTerminalDiagnosticContext)
    Check ($fresh.Count -eq 1 -and $fresh[0].stage -ceq 'inspect-child' -and $null -eq $fresh[0].child -and $null -eq $fresh[0].acknowledgement) 'new invocation context contains no stale metadata'
}
Check ($PSVersionTable.PSVersion.Major -eq 5) 'tests execute in real Windows PowerShell 5'
$failedTests=@($testResults | Where-Object {-not $_.passed})
$evidence=[ordered]@{schemaVersion='arc-terminal-diagnostics-test-v1';phase=$EvidenceName;entryPath=$EntryPath;entrySha256=(Get-FileHash -LiteralPath $EntryPath -Algorithm SHA256).Hash.ToLowerInvariant();powershellVersion=$PSVersionTable.PSVersion.ToString();checks=$testResults.Count;failed=$failedTests.Count;cloudCalls=0;credentialReads=0;fixtures=$testDirectory;results=@($testResults.ToArray())}
$evidence | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20261016\r7-integration-r1' ($EvidenceName+'-evidence.json')) -Encoding UTF8
Write-Output ($evidence | ConvertTo-Json -Depth 10 -Compress)
if($failedTests.Count -gt 0){exit 1}
