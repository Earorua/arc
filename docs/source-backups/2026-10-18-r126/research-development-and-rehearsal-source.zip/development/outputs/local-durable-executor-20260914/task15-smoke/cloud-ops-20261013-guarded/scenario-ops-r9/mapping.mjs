import {resolve} from 'node:path';
import {FIXED,assert,same,hash,utc,integer,digest,uuid,assertFresh} from './guards.mjs';
import {commandsFor,fullMapping,workflowNames,SCENARIOS} from './read-plans.mjs';
import {assertRead,readConfig} from '../no-start-ops-r2/mapping.mjs';
import {assertWorkflowDefinitionProjection} from '../no-start-ops-r2/rules.mjs';
export {readConfig,assertRead};
const canonical=v=>Array.isArray(v)?v.map(canonical).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,canonical(x)])):v;
const equivalent=(a,b)=>same(canonical(a),canonical(b));
export function assertCollection(n,q,now,{fresh=true}={}){
 const commands=commandsFor(q),start=utc(n.startedAt),end=utc(n.endedAt);assert(n.schemaVersion==='arc-guarded-scenario-native-v1'&&n.phase===q.phase&&n.scenarioId===q.scenarioId&&n.allReadsSucceeded===true&&n.cloudMutations===0&&n.workerControlCalls===0&&n.providerCalls===0,'WHOLE_NATIVE_COLLECTION_REQUIRED');
 assert(start<=end&&end<=now&&end<=q.deadlineAt&&end-start<=720000,'ACTUAL_COLLECTION_DEADLINE');if(fresh)assertFresh(n.startedAt,n.endedAt,now);
 assert(Array.isArray(n.observations)&&same(n.observations.map(o=>o.id),commands.map(c=>c.id)),'COMPLETE_ORDERED_COLLECTION_NO_STITCHING');
 let previous=start;for(const [index,o] of n.observations.entries()){const command=commands[index];assertRead(o,start,end,command.args);assert(utc(o.startedAt)>=previous,'SEQUENTIAL_COMPLETE_COLLECTION');previous=utc(o.endedAt);if(command.kind==='d1')assert(o.databaseId===FIXED.databases[command.query.role]&&o.sqlSha256===command.query.sqlSha256&&o.rowsWritten===0&&o.changedDb===false,'ACTUAL_FIXED_READ_ONLY_STORE');}
 assert(n.transport?.halted===null&&n.transport.maxAttempts===3&&n.transport.backoffMs===1000&&n.transport.childTimeoutMs===45000&&n.transport.closeGraceMs===1000&&n.transport.collectorBudgetMs>0&&n.transport.collectorBudgetMs<=720000&&n.transport.elapsedMs<=n.transport.collectorBudgetMs,'BOUNDED_TRANSPORT');return n;
}
export function evaluateMapping(n,q,{configs,baseline,previousLatestVersions=null,allowNewLatestVersions=false},now){
 assertCollection(n,q,now);const get=id=>{const o=n.observations.find(o=>o.id===id);assert(o?.ok,'MAPPING_READ_MISSING');return o;};
 const latestVersions={},rosters={},workflows={};
 for(const role of ['site','executor']){
  const d=get(role+'-current-deployment'),f=get(role+'-final-deployment');assert(d.worker===FIXED.workers[role]&&d.versionId===q.expectedVersions[role]&&f.worker===d.worker&&f.versionId===d.versionId&&f.deploymentId===d.deploymentId,'EXACT_STABLE_CURRENT_PAIR');
  if(!fullMapping(q))continue;
  const v=get(role+'-current-version'),e=get(role+'-export'),c=configs[role],p=e.projection;
  const bindings=[...Object.entries(c.vars).map(([name,value])=>({name,type:'plain_text',...(name==='ARC_AI_IP_HASH_SALT'?{}:{value})})),...c.secrets.required.map(name=>({name,type:'secret_text'})),...c.d1_databases.map(b=>({name:b.binding,type:'d1',id:b.database_id})),...(c.r2_buckets??[]).map(b=>({name:b.binding,type:'r2_bucket',bucketName:b.bucket_name})),...c.services.map(b=>({name:b.binding,type:'service',service:b.service,environment:b.environment??'production'})),...(c.workflows??[]).map(b=>({name:b.binding,type:'workflow',workflowName:b.name,className:b.class_name,scriptName:b.script_name??null}))];
  assert(v.versionId===d.versionId&&v.exportTypeGatePassed===true&&v.sensitiveTypesPass===true&&v.syntheticSaltMatchesFixture===true&&equivalent(v.bindings,bindings),'EXACT_NATIVE_BINDING_TYPES_VALUES');
  assert(utc(v.startedAt)>=utc(d.endedAt)&&utc(e.startedAt)>=utc(v.endedAt)&&utc(f.startedAt)>=utc(e.endedAt)&&e.precedingVersionId===v.versionId,'TYPE_GATE_BEFORE_EXPORT');
  assert(e.entrySha256===FIXED.artifacts[role]&&e.moduleFiles.length===1&&e.moduleFiles[0].sha256===FIXED.artifacts[role]&&digest(e.configSha256),'UNCHANGED_NATIVE_ARTIFACT');
  assert(p.name===c.name&&p.workers_dev===c.workers_dev&&p.preview_urls===false&&same(p.routes,c.routes??[])&&e.actualSchedulesRead===true&&same(p.triggers.crons,c.triggers?.crons??[]),'NATIVE_PRIVACY_SCHEDULES');
  assert(same(p.vars,Object.fromEntries(Object.entries(c.vars).filter(([k])=>k!=='ARC_AI_IP_HASH_SALT')))&&equivalent(p.d1_databases.map(b=>({binding:b.binding,id:b.database_id})),c.d1_databases.map(b=>({binding:b.binding,id:b.database_id})))&&equivalent(p.r2_buckets,c.r2_buckets??[])&&equivalent(p.services.map(b=>({...b,environment:b.environment??'production'})),c.services.map(b=>({...b,environment:b.environment??'production'})))&&equivalent(p.workflows,c.workflows??[]),'EXACT_CONFIG_MAPPING');
  assert(p.compatibility_date===c.compatibility_date&&equivalent(p.compatibility_flags,c.compatibility_flags??[])&&same({limits:p.limits,observability:p.observability},baseline.nativeSettings[role]),'NATIVE_SETTINGS_STABLE');
 }
 for(const name of workflowNames){const d=get(name+'-definition'),r=get(name+'-instances');assertWorkflowDefinitionProjection(d,name);const values=Object.fromEntries(d.fields.map(f=>[f.field,f.value]));assert(values.Id===baseline.workflows[name].id&&values.Id!==q.expectedVersions.executor&&d.latestVersion.id!==q.expectedVersions.executor,'DISTINCT_EXACT_WORKFLOW_IDENTITIES');
  latestVersions[name]=d.latestVersion;workflows[name]={id:values.Id,worker:values['Script Name'],className:values['Class Name']};
  if(previousLatestVersions&&!allowNewLatestVersions)assert(same(d.latestVersion,previousLatestVersions[name]),'WITHIN_PHASE_LATEST_VERSION_CHANGED');
  assert(r.availableListComplete===true&&new Set(r.rows.map(x=>x.instanceId)).size===r.rows.length,'COMPLETE_WORKFLOW_ROSTER');
  if(name===FIXED.workflowName)assert(r.rows.length<=3&&r.rows.every(row=>Object.values(SCENARIOS).some(s=>s.jobId===row.instanceId)),'NO_EXTRA_PRIMARY_INSTANCES');else assert(same(r.rows,baseline.rosters[name].rows),'RETAINED_LEGACY_ROSTER_UNCHANGED');rosters[name]=r.rows;
 }
 if(fullMapping(q))assert(get('r2-dev-url').bucket===FIXED.bucket&&get('r2-dev-url').devUrlEnabled===false&&get('r2-custom-domains').bucket===FIXED.bucket&&get('r2-custom-domains').customDomainCount===0,'PRIVATE_R2');
 return {versions:q.expectedVersions,workflowLatestVersions:latestVersions,workflows,rosters,configs:q.configs,allChecksPassed:true};
}
