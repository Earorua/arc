// Closed, reviewable SELECT/command list. Runtime inputs never supply SQL or target names.
import {resolve} from 'node:path';
import {FIXED,G,assert,same,hash,jsonRef} from './guards.mjs';
import {workflowNames} from '../no-start-ops-r2/rules.mjs';
export {workflowNames};
export const SCENARIOS=Object.freeze(Object.fromEntries(['long','after-r2','after-d1'].map((id,i)=>[id,Object.freeze({id,jobId:'00000000-0000-4000-8000-000000000'+(151+i),ownerId:'owner-task15-'+id,mutationId:'mutation-task15-'+id,requestId:'request-task15-'+id})])));
export const PHASES=Object.freeze(['preactivation','post-activate','pre-admission-close','post-admission-close','pre-maintenance-close','post-maintenance-close','pre-site-roster','post-site-roster','reconcile-activate','reconcile-admission-close','reconcile-maintenance-close','reconcile-site-roster','prestart','acceptance','long-proof','fault-gap','fault-settlement','fault-followup','replay-before','replay-after','drain-first','drain-second','scheduled']);
export const SOURCES=Object.freeze({
 long:{path:resolve(G,'../cloud-ops-20261012-ack/native-scenario-preparation-r1/read-only-verification-plan.json'),sha256:'6ce49bbe359b5108c5947b6a4de062dbcf169afbccbba66f3ae0db959e34ece6'},
 fault:{path:resolve(G,'../cloud-ops-20261012-ack/native-scenario-preparation-r1/fault-native-read-plan.json'),sha256:'a9877ef48f26a229def0c97b50b75f17c23c95f3ba07995b1b12c2486a0fb144'},
 lifecycle:{path:resolve(G,'../cloud-ops-20261012-ack/activation-preparation-r1/native-read-plan.json'),sha256:'a9124046454f2aae9a379b80bc47047a5b12b87e2c674cdc83085be8b6de6a02'},
});
const query=(id,role,sql,columns,maxRows=1,scenarioId=null)=>({id,role,sql,columns,maxRows,scenarioId,sqlSha256:hash(sql)});
const integers=names=>Object.fromEntries(names.split(' ').map(k=>[k,'integer']));
export function lifecycleQueries(){
 const types={
 'executor-global-lifecycle':integers('jobs unclaimed_jobs jobs_without_result results_unacknowledged receipt_bodies_not_marked_removed delivery_incomplete acceptance_unacknowledged'),
 'site-global-lifecycle':integers('executions active_runs runs_with_active_marker imports_incomplete recoveries_unsettled budget_unsettled budget_reserved_micros pending_admissions'),
 'executor-maintenance-lease':integers('singleton next_category generation lease_until observed_database_time_ms lease_current'),
 'executor-maintenance-cursors':{category:['bootstrap','results','site'],...integers('after_accepted_at version pickup_turn'),after_job_id:'job-any'},
 'cron-capacity-and-unmatched':integers('total_rows start_rows end_rows remaining_rows first_at last_at unmatched_start_rows'),
 'cron-recent-events':{event_id:'cron-id',phase:['start','end'],at:'integer',outcome:['ok','error']},
 'site-maintenance-cursors':{name:['maintenance','outbox'],...integers('after_created_at version'),after_job_id:'job-any'},
 'executor-job-roster':{job_id:'job-any',dispatch_state:['unclaimed','claimed','closed'],accepted_at:'integer',workflow_accepted_at:'integer'},
 };
 return [...jsonRef(SOURCES.lifecycle).queries.map(q=>({...q,columns:types[q.id],scenarioId:null})),query('executor-accepted-deadlines','executor',"SELECT job_id,json_extract(grant_json,'$.beganAt') AS began_at,json_extract(grant_json,'$.executionExpiresAt') AS execution_expires_at FROM research_executor_jobs ORDER BY job_id LIMIT 4",{job_id:'job-any',began_at:'integer',execution_expires_at:'integer'},3)];
}
// Adapted from production replay-admission currentProofSql. Raw identity and complete
// metadata exist only inside the projector, which emits their production canonical hashes.
function replayQuery(s){const {id,jobId,ownerId,mutationId,requestId}=s;
 const sql=`SELECT e.job_id,e.request_hash,r.id AS run_id,p.id AS package_id,p.expires_at AS package_expires_at,i.receipt_hash,i.receipt_metadata_json AS metadata_json,a.workflow_accepted_at AS accepted_at,e.began_at,e.execution_expires_at,e.queue_expires_at,r.created_at AS run_created_at,CAST(strftime('%s','now') AS INTEGER)*1000 AS database_time,
 (SELECT count(*) FROM smoke_scenarios WHERE scenario_id='${id}' OR job_id='${jobId}' OR owner_id='${ownerId}' OR mutation_id='${mutationId}' OR request_id='${requestId}') AS scenarios,
 (SELECT count(*) FROM research_runs WHERE id=r.id OR (user_id='${ownerId}' AND (mutation_id='${mutationId}' OR request_id='${requestId}'))) AS runs,
 (SELECT count(*) FROM research_site_executions WHERE job_id='${jobId}' OR run_id=r.id OR (user_id='${ownerId}' AND request_id='${requestId}')) AS executions,
 (SELECT count(*) FROM research_site_imports WHERE job_id='${jobId}' OR run_id=r.id OR (user_id='${ownerId}' AND request_id='${requestId}')) AS imports,
 (SELECT count(*) FROM research_packages WHERE id=p.id OR (normalized_role_key=r.normalized_role_key AND locale=r.locale AND config_fingerprint=r.config_fingerprint)) AS packages,
 (SELECT count(*) FROM research_site_acceptances WHERE job_id='${jobId}') AS acceptances,
 (SELECT count(*) FROM quota_ledger WHERE reservation_id=e.quota_reservation_id OR (user_id='${ownerId}' AND idempotency_key=e.quota_key)) AS quota_rows,
 (SELECT count(*) FROM quota_ledger WHERE reservation_id=e.quota_reservation_id AND user_id='${ownerId}' AND idempotency_key=e.quota_key AND purpose='role-research' AND entry_kind='reserved' AND units=1) AS quota_reserved,
 (SELECT count(*) FROM quota_ledger WHERE reservation_id=e.quota_reservation_id AND user_id='${ownerId}' AND idempotency_key=e.quota_key AND purpose='role-research' AND entry_kind='accepted' AND units=1) AS quota_accepted,
 (SELECT count(*) FROM ai_budget_reservations WHERE run_id=r.id OR request_id='${requestId}' OR id=e.budget_reservation_id) AS budgets,
 (SELECT count(*) FROM ai_runs WHERE user_id='${ownerId}' AND request_id=json_extract(i.audit_json,'$.requestId')) AS audits,b.settled_micros
 FROM smoke_scenarios s JOIN research_site_executions e ON e.job_id=s.job_id AND e.user_id=s.owner_id AND e.request_id=s.request_id
 JOIN research_runs r ON r.id=e.run_id AND r.user_id=e.user_id AND r.request_id=e.request_id AND r.mutation_id=s.mutation_id
 JOIN research_site_imports i ON i.job_id=e.job_id AND i.run_id=r.id AND i.user_id=r.user_id AND i.request_id=e.request_id AND i.request_hash=e.request_hash AND i.config_fingerprint=r.config_fingerprint
 JOIN research_packages p ON p.id=r.package_id AND p.normalized_role_key=r.normalized_role_key AND p.locale=r.locale AND p.config_fingerprint=r.config_fingerprint
 JOIN research_site_acceptances a ON a.job_id=e.job_id AND a.request_hash=e.request_hash AND a.workflow_id=e.job_id
 JOIN ai_budget_reservations b ON b.id=e.budget_reservation_id AND b.run_id=r.id AND b.request_id=e.request_id
 JOIN ai_runs audit ON audit.user_id=r.user_id AND audit.request_id=json_extract(i.audit_json,'$.requestId') AND audit.purpose='role-research' AND audit.status='accepted'
 WHERE s.scenario_id='${id}' AND s.job_id='${jobId}' AND s.owner_id='${ownerId}' AND s.mutation_id='${mutationId}' AND s.request_id='${requestId}'
 AND r.execution_mode='cloudflare-workflow-v1' AND r.remote_quota_key=e.quota_key AND r.retry_of_run_id IS NULL AND r.state='ready' AND r.active_slot IS NULL AND r.active_expires_at IS NULL
 AND e.admission_state='admitted' AND e.closed_at IS NULL AND e.close_reason IS NULL AND i.phase=5 AND json_extract(i.resolution_json,'$.state')='ready'
 AND json_extract(i.resolution_json,'$.packageId')=p.id AND json_extract(i.resolution_json,'$.runVersion')=r.state_version AND json_extract(i.resolution_json,'$.quotaStatus')='accepted' AND b.status='settled' AND b.settled_micros=1 LIMIT 2`.replace(/\s+/gu,' ');
 return query('site-replay-proof','site',sql,{job_id:'job',request_hash:'hash',run_id:'identity-hash',package_id:'identity-hash',receipt_hash:'hash',metadata_json:'metadata',...integers('package_expires_at accepted_at began_at execution_expires_at queue_expires_at run_created_at database_time scenarios runs executions imports packages acceptances quota_rows quota_reserved quota_accepted budgets audits settled_micros')},1,id);
}
// Include every reservation before validating the fixed observed scope: inner joins
// or a fixed-scenario WHERE would hide extra or incorrectly bound budget rows.
function budgetQuery(s){
 const fixed=Object.values(SCENARIOS).map(x=>`SELECT '${x.id}' AS scenario_id,'${x.jobId}' AS job_id,'${x.ownerId}' AS owner_id,'${x.mutationId}' AS mutation_id,'${x.requestId}' AS request_id`).join(' UNION ALL ');
 const sql=`SELECT f.scenario_id,e.job_id,e.request_hash,b.run_id,b.id AS reservation_hash,b.created_at,b.status,b.settled_micros,
 b.day_bucket_id AS day_bucket_hash,d.scope AS day_scope,d.period_kind AS day_kind,d.period_start AS day_period_start,d.reserved_micros AS day_reserved,d.settled_micros AS day_settled,
 b.month_bucket_id AS month_bucket_hash,m.scope AS month_scope,m.period_kind AS month_kind,m.period_start AS month_period_start,m.reserved_micros AS month_reserved,m.settled_micros AS month_settled,
 CASE WHEN f.scenario_id IS NOT NULL AND s.scenario_id=f.scenario_id AND s.owner_id=f.owner_id AND s.mutation_id=f.mutation_id AND s.request_id=f.request_id
 AND e.user_id=f.owner_id AND e.request_id=f.request_id AND e.run_id=b.run_id AND b.request_id=f.request_id
 AND r.user_id=f.owner_id AND r.request_id=f.request_id AND r.mutation_id=f.mutation_id AND r.execution_mode='cloudflare-workflow-v1' AND r.remote_quota_key=e.quota_key AND r.retry_of_run_id IS NULL
 AND e.admission_state='admitted' AND e.closed_at IS NULL AND e.close_reason IS NULL AND b.created_at>=r.created_at AND b.created_at<=e.admitted_at
 AND a.request_hash=e.request_hash AND a.workflow_id=e.job_id THEN 1 ELSE 0 END AS binding_matches,
 (SELECT count(*) FROM ai_budget_reservations) AS global_reservations,
 (SELECT coalesce(sum(reserved_micros),0) FROM ai_budget_buckets) AS global_reserved,
 (SELECT coalesce(sum(settled_micros),0) FROM ai_budget_buckets) AS global_settled
 FROM ai_budget_reservations b LEFT JOIN research_site_executions e ON e.budget_reservation_id=b.id
 LEFT JOIN research_runs r ON r.id=b.run_id LEFT JOIN (${fixed}) f ON f.job_id=e.job_id LEFT JOIN smoke_scenarios s ON s.job_id=e.job_id
 LEFT JOIN research_site_acceptances a ON a.job_id=e.job_id LEFT JOIN ai_budget_buckets d ON d.id=b.day_bucket_id LEFT JOIN ai_budget_buckets m ON m.id=b.month_bucket_id
 ORDER BY CASE WHEN e.job_id='${s.jobId}' THEN 0 ELSE 1 END,b.id LIMIT 4`.replace(/\s+/gu,' ');
 return query('site-budget-buckets','site',sql,{scenario_id:Object.keys(SCENARIOS),job_id:'job-any',request_hash:'hash',run_id:'identity-hash',reservation_hash:'budget-identity-hash',day_bucket_hash:'budget-identity-hash',month_bucket_hash:'budget-identity-hash',status:['reserved','settled','conservative-hold','released'],day_scope:['site'],month_scope:['site'],day_kind:['day'],month_kind:['month'],binding_matches:'boolean-integer',...integers('created_at settled_micros day_period_start day_reserved day_settled month_period_start month_reserved month_settled global_reservations global_reserved global_settled')},3,s.id);
}
export function scenarioQueries(id){assert(Object.hasOwn(SCENARIOS,id),'FIXED_SCENARIO');
 const s=SCENARIOS[id],source=id==='long'?jsonRef(SOURCES.long).queries:jsonRef(SOURCES.fault).scenarios.find(x=>x.id===id).queries;
 const baseIds=jsonRef(SOURCES.long).queries.map(q=>q.id);
 const queries=source.filter(q=>baseIds.includes(q.id)).map(q=>{if(q.id==='site-budget-buckets')return budgetQuery(s);let sql=q.sql;if(q.id==='site-audit')sql=sql.replaceAll("'$.costMicros'","'$.usage.costMicros'").replaceAll("'$.totalTokens'","'$.usage.totalTokens'").replaceAll("'$.webSearchRequests'","'$.usage.webSearchRequests'");return {...q,sql,sqlSha256:hash(sql),scenarioId:id};});
 assert(queries.length===15,'EXACT_FIFTEEN_SCENARIO_READS');
 return [...queries,replayQuery(s),query('executor-replay-metadata','executor',`SELECT job_id,receipt_hash,metadata_json,cleanup_requested_at,body_removed_at FROM research_executor_results WHERE job_id='${s.jobId}' LIMIT 2`,{job_id:'job',receipt_hash:'hash',metadata_json:'metadata',cleanup_requested_at:'integer',body_removed_at:'integer'},1,id)];
}
export function queriesFor(q){assert(PHASES.includes(q.phase),'FIXED_PHASE');
 if(q.phase==='fault-gap'){assert(q.scenarioId==='after-r2'||q.scenarioId==='after-d1','FAULT_SCENARIO');const source=jsonRef(SOURCES.fault).scenarios.find(x=>x.id===q.scenarioId);return ['executor-gap','site-run-execution','site-import'].map(id=>({...source.queries.find(x=>x.id===id),scenarioId:q.scenarioId}));}
 if(q.phase==='acceptance')return scenarioQueries(q.scenarioId).filter(x=>['executor-job','site-acceptance'].includes(x.id));
 if(['long-proof','fault-settlement','fault-followup'].includes(q.phase))return [...scenarioQueries(q.scenarioId),...lifecycleQueries()];
 if(['replay-before','replay-after'].includes(q.phase))return [...Object.keys(SCENARIOS).flatMap(id=>scenarioQueries(id).filter(x=>['site-replay-proof','executor-replay-metadata','executor-scenario','site-accounting'].includes(x.id)).map(x=>({...x,id:id+':'+x.id}))),...lifecycleQueries()];
 if(q.phase==='scheduled')return [];return lifecycleQueries();
}
export const fullMapping=q=>!['fault-gap','acceptance','long-proof','fault-settlement','fault-followup','replay-before','replay-after','scheduled'].includes(q.phase);
export function commandsFor(q){assert(PHASES.includes(q.phase),'FIXED_PHASE');const cfg=role=>['--config',resolve(q.directory,`wrangler.${role}.readonly.json`)];
 const queries=queriesFor(q).map(query=>({id:query.id,kind:'d1',query,args:['d1','execute',query.role==='site'?'SMOKE_SITE_DB':'EXECUTOR_DB','--remote',...cfg(query.role),'--json','--command',query.sql]}));
 const workflow=()=>({id:'workflow',kind:'instance',scenarioId:q.scenarioId,args:['workflows','instances','describe',FIXED.workflowName,SCENARIOS[q.scenarioId].jobId,...(q.scenarioId==='long'?['--no-step-output']:['--step-output','--truncate-output-limit','4096']),...cfg('executor')]});
 if(q.phase==='fault-gap')return [...queries,workflow()];
 if(q.phase==='acceptance')return [workflow(),...queries];
 if(q.phase==='scheduled')return [{id:'scheduled',kind:'scheduled',args:['tail',FIXED.workers.executor,...cfg('executor'),'--format','json']}];
 const commands=['site','executor'].flatMap(role=>[{id:role+'-current-deployment',kind:'deployment',role,args:['deployments','list',...cfg(role),'--json']},...(fullMapping(q)?[{id:role+'-current-version',kind:'version',role,args:['versions','view',q.expectedVersions[role],...cfg(role),'--json']},{id:role+'-export',kind:'export',role,args:['init','--from-dash',FIXED.workers[role],'--no-delegate-c3']}]:[])]);
 for(const name of workflowNames)commands.push({id:name+'-definition',kind:'definition',name,args:['workflows','describe',name,...cfg('executor')]},{id:name+'-instances',kind:'roster',name,args:['workflows','instances','list',name,'--page','1','--per-page','100',...cfg('executor')]});
 if(['long-proof','fault-settlement','fault-followup'].includes(q.phase))commands.push(workflow());commands.push(...queries);
 if(fullMapping(q))commands.push({id:'r2-dev-url',kind:'privacy-dev',args:['r2','bucket','dev-url','get',FIXED.bucket,...cfg('executor')]},{id:'r2-custom-domains',kind:'privacy-domains',args:['r2','bucket','domain','list',FIXED.bucket,...cfg('executor')]});
 commands.push(...['site','executor'].map(role=>({id:role+'-final-deployment',kind:'deployment',role,args:['deployments','list',...cfg(role),'--json']})));return commands;
}
export function assertCommand(q,args){assert(Array.isArray(args)&&commandsFor(q).some(c=>same(c.args,args)),'EXACT_REVIEWED_READ_COMMAND');}
