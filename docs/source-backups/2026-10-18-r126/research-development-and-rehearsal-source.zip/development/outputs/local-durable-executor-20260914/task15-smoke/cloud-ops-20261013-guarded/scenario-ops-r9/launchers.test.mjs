// OFFLINE ONLY: no ready/native/activation/control fixtures in operational locations.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
import {FIXED,root,here,hash,toolRefs} from './guards.mjs';
const generator=resolve(here,'prepare-launchers.mjs');
const impl=existsSync(generator)?await import(pathToFileURL(generator).href):null;
const source=readFileSync(resolve(root,'scripts/run-research-cloud-smoke.ps1'),'utf8');
const powershell=resolve(process.env.SystemRoot,'System32/WindowsPowerShell/v1.0/powershell.exe');
const json=p=>JSON.parse(readFileSync(p,'utf8'));
test('Task3 provides the reviewed static derivation implementation',()=>assert.ok(impl?.deriveLauncher&&impl?.verifyDerivation&&impl?.buildStaticArtifacts));
test('nine roles have unique epoch reports, wrappers and short commands',{skip:!impl},()=>{
 const bundle=impl.buildStaticArtifacts();
 assert.equal(bundle.launchers.length,9);assert.equal(new Set(bundle.launchers.map(x=>x.role)).size,9);
 assert.equal(new Set(bundle.launchers.map(x=>x.reportName)).size,9);
 assert.equal(new Set(bundle.launchers.flatMap(x=>[x.launcher.path,x.command.path])).size,18);
 assert.deepEqual(bundle.contract.task2Tools,toolRefs());
 assert.deepEqual(bundle.contract.inventory,FIXED.inventory);assert.deepEqual(bundle.contract.artifactReport,FIXED.report);
 for(const role of bundle.launchers){
  assert.equal(role.reportName,`cloud-guarded-${role.scenarioId}-${role.mode}-20261016-r9`);
  assert.equal(impl.verifyDerivation(source,role.text,role.edits),true);
  const before=role.text.indexOf('$smokeReadyBeforeInput = Assert-ArcScenarioReadiness');
  const input=role.text.indexOf('$smokeSecret = Read-Host');
  const after=role.text.indexOf('$smokeReadyAfterInput = Assert-ArcScenarioReadiness');
  const child=role.text.indexOf('$smokeChild = [Diagnostics.Process]::new()');
  assert.ok(before<input&&input<after&&after<child);
  assert.match(role.text,/New-ArcLaunchAttempt/);assert.match(role.text,/Get-ArcChildCloseFact/);
  assert.match(role.text,/Write-ArcControlExit/);assert.match(role.command.text,/Invoke-ArcFixedTerminalCommand/);
  assert.ok(role.command.text.includes(`-Role '${role.role}'`));
 }
});
test('derivation refuses changed sources and changed generated security text',{skip:!impl},()=>{
 const bundle=impl.buildStaticArtifacts(),role=bundle.launchers[0];
 assert.throws(()=>impl.deriveLauncher(source.replace('60000','60001'),role.settings),/SOURCE/);
 assert.throws(()=>impl.verifyDerivation(source,role.text.replace('ZeroFreeBSTR','FreeBSTR'),role.edits),/INVERSE/);
 assert.equal(hash(Buffer.from(source)),bundle.contract.source.sha256);
 assert.equal(hash(readFileSync(FIXED.driver.path)),FIXED.driver.sha256);
});
test('drain and kill confirmation share 65-second reserve; unconfirmed exit returns failure',{skip:!impl},()=>{
 for(const role of impl.buildStaticArtifacts().launchers){
  assert.match(role.text,/65000 - \$smokeChildClock\.ElapsedMilliseconds/);
  assert.ok(role.text.indexOf('$smokeDrainTask.Wait($smokeRemainingDrainMs)')<role.text.indexOf('$smokeDrainTask.Wait(5000)'));
  assert.match(role.text,/if \(\$null -eq \$smokeCloseFact -or -not \$smokeCloseFact\.childCloseConfirmed\) \{ \$smokeExitCode = 1 \}/);
 }
});
test('generated files equal deterministic derivation; manifests pin all 18 outputs',{skip:!impl},()=>{
 const bundle=impl.buildStaticArtifacts(),manifest=json(resolve(here,'launcher-derivation.json'));
 assert.equal(manifest.launchers.length,9);assert.equal(manifest.inverseByteChecks,9);
 for(const role of bundle.launchers){
  assert.equal(readFileSync(role.launcher.path,'utf8'),role.text);
  assert.equal(readFileSync(role.command.path,'utf8'),role.command.text);
  const recorded=manifest.launchers.find(x=>x.role===role.role);
  for(const kind of ['launcher','command'])assert.equal(recorded[kind].sha256,hash(readFileSync(role[kind].path)));
 }
 assert.equal(manifest.source.sha256,'7017350c6103cbb8903afe1327959e62cb6ea98f38361de4b6c7effb29cd0957');
 assert.equal(manifest.driver.sha256,'472e0cecc6ee0f070b71d46174b7151a562689e4fef4dfaffd4e38ae06158099');
});
test('Windows PowerShell 5.1 parses wrappers and validates exact child arguments offline',{skip:!impl},()=>{
 const result=spawnSync(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(here,'launchers.test.ps1')],{encoding:'utf8',timeout:30000,windowsHide:true,
  env:{...process.env,PSModulePath:resolve(process.env.SystemRoot,'System32/WindowsPowerShell/v1.0/Modules')}});
 assert.equal(result.status,0,result.stdout+'\n'+result.stderr);
 assert.match(result.stdout,/OFFLINE_TASK3_PS_PASS/);
 assert.match(result.stdout,/powershellMajor":5/);
});
