import {isDeepStrictEqual} from 'node:util';

export const NATIVE_FRESHNESS_MS = 900_000;

export const SCENARIO_IDS = Object.freeze(['long', 'after-r2', 'after-d1']);
export const OUTSTANDING_KEYS = Object.freeze([
  'unclaimed_jobs', 'jobs_without_result', 'results_unacknowledged', 'receipt_bodies_not_marked_removed',
  'delivery_incomplete', 'acceptance_unacknowledged', 'active_runs', 'runs_with_active_marker',
  'imports_incomplete', 'recoveries_unsettled', 'budget_unsettled', 'budget_reserved_micros', 'pending_admissions',
]);
const WORKFLOWS = Object.freeze([
  ['RESEARCH_WORKFLOW', 'arc-v8-smoke-workflow-20261013-guarded'],
  ['RESEARCH_WORKFLOW_LEGACY_20261012_ACK', 'arc-v8-smoke-workflow-20261012-ack'],
  ['RESEARCH_WORKFLOW_LEGACY_20260921', 'arc-v8-smoke-workflow-20260921'],
  ['RESEARCH_WORKFLOW_LEGACY_20261005_REPLAY', 'arc-v8-smoke-workflow-20261005-replay'],
].map(Object.freeze));
const admission = 'ARC_RESEARCH_EXECUTOR_ACCEPT_NEW';
const maintenance = 'ARC_RESEARCH_EXECUTOR_MAINTENANCE_ENABLED';
const roster = 'SMOKE_REPLAY_APPROVAL_JSON';
const inventoryHash = 'SMOKE_REPLAY_INVENTORY_SHA256';
const sha256 = /^[a-f0-9]{64}$/u;

function requireRule(condition, message) {
  if (!condition) throw new TypeError(message);
}
function record(value, name) {
  requireRule(value !== null && typeof value === 'object' && !Array.isArray(value), `${name}: record required`);
}
function integer(value, name) {
  requireRule(Number.isSafeInteger(value) && value >= 0, `${name}: nonnegative safe integer required`);
}
function scenarioSet(value, name) {
  requireRule(Array.isArray(value) && value.every(id => SCENARIO_IDS.includes(id))
    && new Set(value).size === value.length, `${name}: unique fixed scenario IDs required`);
  return new Set(value);
}

export function assertCompletionScope({expectedScenarioIds, observedScenarioIds, outstanding, terminal}) {
  const expected = scenarioSet(expectedScenarioIds, 'expectedScenarioIds');
  requireRule(expected.size === SCENARIO_IDS.length, 'expectedScenarioIds cannot narrow the full rehearsal');
  const observed = scenarioSet(observedScenarioIds, 'observedScenarioIds');
  const ended = scenarioSet(terminal, 'terminal');
  requireRule([...ended].every(id => observed.has(id)), 'terminal scenarios must be observed');
  record(outstanding, 'outstanding');
  requireRule(isDeepStrictEqual(Object.keys(outstanding).sort(), [...OUTSTANDING_KEYS].sort()), 'exact outstanding counters required');
  for (const key of OUTSTANDING_KEYS) integer(outstanding[key], `outstanding.${key}`);
  const safeToClose = [...observed].every(id => ended.has(id)) && OUTSTANDING_KEYS.every(key => outstanding[key] === 0);
  const missingScenarioIds = Object.freeze(SCENARIO_IDS.filter(id => !observed.has(id)));
  const fullScenarioCompletion = safeToClose && missingScenarioIds.length === 0;
  return Object.freeze({safeToClose, fullScenarioCompletion, missingScenarioIds,
    disposition: fullScenarioCompletion ? 'full-scope-settled' : safeToClose ? 'settled-incomplete' : 'unsettled-incomplete',
    evidenceProvenanceVerified: false});
}

function executorShape(config) {
  requireRule(config.name === 'arc-v8-smoke-executor-20260921', 'executor config target');
  requireRule(config.workers_dev === false && config.preview_urls === false
    && isDeepStrictEqual(config.routes, []) && config.observability?.enabled === false, 'executor privacy config');
  requireRule(Array.isArray(config.workflows) && config.workflows.length === 4, 'four Workflow declarations required');
  for (const [binding, name] of WORKFLOWS) {
    const matches = config.workflows.filter(value => value?.binding === binding);
    requireRule(matches.length === 1 && matches[0].name === name && matches[0].class_name === 'ResearchWorkflow'
      && (matches[0].script_name === undefined || matches[0].script_name === config.name), 'exact Workflow declaration required');
  }
}

function settledShape(nativeSettledProof, now) {
  record(nativeSettledProof, 'native settled proof'); integer(now, 'now');
  const {nativeEvidenceSha256, nativeStartedAt, nativeEndedAt, scope} = nativeSettledProof;
  requireRule(typeof nativeEvidenceSha256 === 'string' && sha256.test(nativeEvidenceSha256), 'native proof hash required');
  integer(nativeStartedAt, 'nativeStartedAt'); integer(nativeEndedAt, 'nativeEndedAt');
  requireRule(nativeStartedAt <= nativeEndedAt && nativeEndedAt <= now, 'native proof clock order');
  requireRule(now - nativeStartedAt < NATIVE_FRESHNESS_MS, 'fresh native settled proof required');
  requireRule(assertCompletionScope(scope).safeToClose, 'native proof scope must be settled');
}

// This asserts allowed deltas and proof shape, never native authenticity or dispatch authority.
export function assertTransition({kind, beforeConfig, afterConfig, nativeSettledProof, now}) {
  record(beforeConfig, 'beforeConfig'); record(afterConfig, 'afterConfig');
  record(beforeConfig.vars, 'beforeConfig.vars'); record(afterConfig.vars, 'afterConfig.vars');
  const expected = structuredClone(beforeConfig);
  if (kind === 'site-roster') {
    requireRule(beforeConfig.name === 'arc-v8-smoke-site-20260921', 'Site config target');
    requireRule(!Object.hasOwn(beforeConfig.vars, roster) && !Object.hasOwn(beforeConfig.vars, inventoryHash), 'roster transition only adds absent variables');
    requireRule(typeof afterConfig.vars[roster] === 'string' && afterConfig.vars[roster].length > 0
      && new TextEncoder().encode(afterConfig.vars[roster]).byteLength <= 4096, 'bounded roster JSON required');
    requireRule(typeof afterConfig.vars[inventoryHash] === 'string' && sha256.test(afterConfig.vars[inventoryHash]), 'inventory SHA256 required');
    expected.vars[roster] = afterConfig.vars[roster];
    expected.vars[inventoryHash] = afterConfig.vars[inventoryHash];
  } else {
    executorShape(beforeConfig); executorShape(afterConfig);
    const activeCron = ['* * * * *'];
    if (kind === 'activate') {
      requireRule(beforeConfig.vars[admission] === 'false' && beforeConfig.vars[maintenance] === 'false'
        && isDeepStrictEqual(beforeConfig.triggers?.crons, []), 'invalid activation transition predecessor');
      expected.vars[admission] = 'true'; expected.vars[maintenance] = 'true'; expected.triggers.crons = activeCron;
    } else if (kind === 'admission-close') {
      requireRule(beforeConfig.vars[admission] === 'true' && beforeConfig.vars[maintenance] === 'true'
        && isDeepStrictEqual(beforeConfig.triggers?.crons, activeCron), 'invalid admission-close transition predecessor');
      expected.vars[admission] = 'false';
    } else if (kind === 'maintenance-close') {
      requireRule(beforeConfig.vars[admission] === 'false' && beforeConfig.vars[maintenance] === 'true'
        && isDeepStrictEqual(beforeConfig.triggers?.crons, activeCron), 'invalid maintenance-close transition predecessor');
      settledShape(nativeSettledProof, now);
      expected.vars[maintenance] = 'false'; expected.triggers.crons = [];
    } else throw new TypeError('unknown transition kind');
  }
  requireRule(isDeepStrictEqual(expected, afterConfig), 'unapproved config delta');
  return Object.freeze({valid: true, kind, evidenceProvenanceVerified: false});
}
