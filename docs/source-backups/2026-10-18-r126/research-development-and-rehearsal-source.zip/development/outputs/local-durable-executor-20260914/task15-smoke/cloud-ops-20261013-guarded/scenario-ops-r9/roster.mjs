import {writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {here,FIXED,assert,same,hash,ref,write,jsonRef,verify,createValidationContext,assertContext,main} from './guards.mjs';
import {SCENARIO_IDS,assertTransition} from './contracts.mjs';
import {checkReplayTimes} from './budget.mjs';
import {loadGate,loadControl,completedProofs} from './evaluate.mjs';
import {verifyReceipt} from './receipt.mjs';
import {canonicalJson} from '../../cloud-ops-20261005-replay/long-followup-preparation-r1/r2-preparation/production-codec.mjs';
const keys=['scenarioId','jobId','requestHash','receiptHash','receiptMetadataSha256','runHash','packageHash','acceptedAt','beganAt','executionExpiresAt'];
export function buildRoster(c,{proofs,now,remainingReplayMs}){
 assertContext(c);assert(Array.isArray(proofs)&&proofs.length===3,'THREE_ACTUAL_NATIVE_R2_STATUS_PROOFS');completedProofs(c,proofs,SCENARIO_IDS,{now});const scenarios=[],pins=[];
 for(const id of SCENARIO_IDS){const source=proofs.find(p=>p.scenarioId===id);assert(source,'EXACT_THREE_SCENARIOS');const gate=loadGate(c,source.nativeGate,{fresh:false}),p=gate.scenarioProof;assert(p?.scenarioId===id,'ACTUAL_SCENARIO_PROOF');const r2=verifyReceipt(c,source.receipt,source.nativeGate,p),status=loadControl(c,source.status,'status',id);
  assert(Date.parse(status.startedAt)>=Date.parse(r2.endedAt)&&status.report.view?.state==='ready'&&status.report.view.backgroundAccepted===true,'ORIGINAL_STATUS_AFTER_NATIVE_R2');const times={acceptedAt:p.acceptedAt,beganAt:p.beganAt,executionExpiresAt:p.executionExpiresAt};assert(checkReplayTimes({now,original:times,bound:times,earliestPackageExpiresAt:p.packageExpiresAt,remainingReplayMs}).canAdvance,'ACTUAL_PACKAGE_EXPIRY');scenarios.push(Object.fromEntries(keys.map(k=>[k,p[k]])));pins.push(source);
 }
 const nativeEvidence={schemaVersion:'arc-guarded-replay-native-evidence-v1',inventory:FIXED.inventory,proofs:pins},nativeEvidenceSha256=hash(JSON.stringify(nativeEvidence,null,2)+'\n'),roster={schemaVersion:'arc-smoke-replay-approval-v1',inventorySha256:FIXED.inventory.sha256,nativeEvidenceSha256,scenarios},json=canonicalJson(roster);assert(Buffer.byteLength(json)<=4096,'ROSTER_4096_BYTE_LIMIT');return {roster,json,nativeEvidence,earliestPackageExpiresAt:Math.min(...proofs.map(p=>loadGate(c,p.nativeGate,{fresh:false}).scenarioProof.packageExpiresAt))};
}
export function rosterConfig(before,rosterJson){const after=structuredClone(before);after.vars.SMOKE_REPLAY_APPROVAL_JSON=rosterJson;after.vars.SMOKE_REPLAY_INVENTORY_SHA256=FIXED.inventory.sha256;assertTransition({kind:'site-roster',beforeConfig:before,afterConfig:after});return after;}
function writeApproval(json){const path=resolve(here,'replay-approval.json');assert(Buffer.byteLength(json)<=4096,'HOST_APPROVAL_4096_BYTES');writeFileSync(path,json,{flag:'wx'});return ref(path);}
export function assertRosterBinding(record,built,evidence,approval){assert(same(evidence,built.nativeEvidence)&&same(approval,built.roster)&&record.evidence.sha256===hash(JSON.stringify(evidence,null,2)+'\n')&&record.evidence.sha256===approval.nativeEvidenceSha256&&record.nativeEvidenceSha256===approval.nativeEvidenceSha256,'ACTUAL_ROSTER_AGGREGATE_BYTES');}
export function verifyRosterPreparation(c,reference,{now=Date.now(),remainingReplayMs=360000}={}){
 const r=c.read(reference);assert(reference.path===resolve(here,'roster-preparation.json')&&r.schemaVersion==='arc-guarded-roster-preparation-v1'&&same(r.inventory,FIXED.inventory),'ACTUAL_ROSTER_PREPARATION');
 for(const [key,name] of [['approval','replay-approval.json'],['evidence','replay-native-evidence.json'],['config','wrangler.site-roster.json']])assert(r[key].path===resolve(here,name),'EXACT_ROSTER_ARTIFACT_PATH');
 const built=buildRoster(c,{proofs:r.proofs,now,remainingReplayMs});assertRosterBinding(r,built,c.read(r.evidence),c.read(r.approval));assert(verify(r.approval).toString('utf8')===built.json&&Buffer.byteLength(built.json)<=4096&&same(c.read(r.config),rosterConfig(c.configs.site,built.json)),'EXACT_HOST_AND_SITE_ROSTER_BYTES');return r;
}
export function prepareRoster(c,input){const built=buildRoster(c,input);const evidence=write(resolve(here,'replay-native-evidence.json'),built.nativeEvidence),approval=writeApproval(built.json),config=write(resolve(here,'wrangler.site-roster.json'),rosterConfig(c.configs.site,built.json));return write(resolve(here,'roster-preparation.json'),{schemaVersion:'arc-guarded-roster-preparation-v1',inventory:FIXED.inventory,evidence,approval,config,nativeEvidenceSha256:built.roster.nativeEvidenceSha256,earliestPackageExpiresAt:built.earliestPackageExpiresAt,proofs:input.proofs,cloudCalls:0});}
await main(import.meta.url,()=>{assert(process.argv.length===4,'EXACT_ROSTER_SPEC_PATH_SHA');const spec=jsonRef({path:resolve(process.argv[2]),sha256:process.argv[3]});console.log(JSON.stringify({rosterPreparation:prepareRoster(createValidationContext(),{...spec,now:Date.now()})}));});
