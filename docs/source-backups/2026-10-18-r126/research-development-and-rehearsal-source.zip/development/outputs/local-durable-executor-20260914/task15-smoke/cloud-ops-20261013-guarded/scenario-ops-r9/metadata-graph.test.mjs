// Read-only real provenance graph checks. No acceptance, template, or operation is created.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {isAbsolute,resolve} from 'node:path';
import {createValidationContext,assertCurrentPins,here,hash} from './guards.mjs';
const materialPath=resolve(here,'material-manifest-r9.json');
const materialRef=()=>({path:materialPath,sha256:hash(readFileSync(materialPath))});
test('current material manifest recursively validates actual pinned graph',()=>{
 const c=createValidationContext(),m=c.read(materialRef());
 assert.equal(m.status,'SOURCE_STATIC_ONLY_REQUIRES_INDEPENDENT_ROOT_ACCEPTANCE');
 assertCurrentPins(c,[materialRef()]);
 assert.ok(c.currentReferences().length>0);
});
test('final root acceptance ingredients independently traverse actual pinned graph',()=>{
 const c=createValidationContext(),m=JSON.parse(readFileSync(materialPath,'utf8'));
 let count=0;
 function walk(v){
  if(!v||typeof v!=='object')return;
  if(typeof v.path==='string'&&/^[a-f0-9]{64}$/.test(v.sha256)&&(isAbsolute(v.path)||/^(?:outputs|scripts|app|worker|tests|node_modules)[\\/]/.test(v.path))){c.verify(v);count++;}
  for(const [key,value] of Object.entries(v))if(key!=='path'&&key!=='sha256')walk(value);
 }
 walk(m.rootAcceptanceIngredients);
 assertCurrentPins(c,[]);
 assert.ok(count>=70);
});
