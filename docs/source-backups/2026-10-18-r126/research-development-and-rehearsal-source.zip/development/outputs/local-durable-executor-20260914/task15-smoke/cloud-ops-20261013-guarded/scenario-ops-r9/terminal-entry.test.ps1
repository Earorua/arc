$ErrorActionPreference='Stop'
# Credential-free fake children in a dedicated OFFLINE fixture directory only.
. (Join-Path $PSScriptRoot 'terminal-entry.ps1')
$testCount=0
function Check([bool]$Value,[string]$Message) { if (-not $Value) { throw $Message }; $script:testCount++ }
function Refuses([scriptblock]$Action,[string]$Code) { $caught=$false; try { & $Action | Out-Null } catch { if ($_.Exception.Message -notlike "*$Code*") { throw }; $caught=$true }; Check $caught $Code }
foreach($testPath in @((Join-Path $PSScriptRoot 'terminal-entry.ps1'),$PSCommandPath)) {
    $testTokens=$null; $testErrors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($testPath,[ref]$testTokens,[ref]$testErrors)
    Check ($testErrors.Count -eq 0) ('PS5 AST '+$testPath)
}
Refuses { Assert-ArcAttendedConsole } 'ACTUAL_ATTENDED_CONSOLE_REQUIRED'
Refuses { Read-ArcLocalAcknowledgement -DeadlineAt ((Get-ArcTerminalMs)+1000) -Message 'OFFLINE MUST NOT PROMPT' } 'ACTUAL_ATTENDED_CONSOLE_REQUIRED'
Check ($null -ne (Get-Command Get-ArcPreparationDeadline -ErrorAction SilentlyContinue)) 'Independent preparation deadline helper exists'
Check ((Get-ArcPreparationDeadline -PackageValidUntil 87400000 -InvokedAt 1000000) -eq 1905000) '24h package cannot extend original preparation allowance'
Check ((Get-ArcPreparationDeadline -PackageValidUntil 1001000 -InvokedAt 1000000) -eq 1001000) 'Earlier package expiry bounds preparation child'
Refuses { Get-ArcPreparationDeadline -PackageValidUntil 1000000 -InvokedAt 1000000 } 'ORIGINAL_PREPARATION_ALLOWANCE'
$testSource=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'terminal-entry.ps1'))
Check ($testSource.Contains('Get-ArcPreparationDeadline -PackageValidUntil $arcInspection.validUntil -InvokedAt $arcInvokedAt')) 'Preparation remains tied to original shell invocation'
Check ($testSource.Contains('-DeadlineAt $arcPreparationDeadline -MaximumWaitMs 905000')) 'Actual prepare child uses both finite deadline and905s cap'
$testDirectory=Join-Path 'C:\Users\XF\Documents\Codex\2026-07-26\sites-plugin-sites-openai-bundled-2\.worktrees\v8-openrouter-research-beta\outputs\local-durable-executor-20261016\r7-integration-r1' ('r7-t-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
[void][IO.Directory]::CreateDirectory($testDirectory)
try {
    $testNode='C:\Program Files\nodejs\node.exe'
    $testBackend=Join-Path $testDirectory 'fake-child.cjs'
    $testCounter=Join-Path $testDirectory 'attempts.txt'
    $testCounterLiteral=ConvertTo-Json $testCounter -Compress
    [IO.File]::WriteAllText($testBackend,('require("fs").appendFileSync('+ $testCounterLiteral +', "attempt\n"); process.exit(1);'))
    $testContract=[pscustomobject]@{root=$testDirectory;node=[pscustomobject]@{path=$testNode;sha256=(Get-FileHash $testNode -Algorithm SHA256).Hash.ToLowerInvariant()};terminalBackend=[pscustomobject]@{path=$testBackend;sha256=(Get-FileHash $testBackend -Algorithm SHA256).Hash.ToLowerInvariant()}}
    Refuses { Invoke-ArcTerminalChild -Contract $testContract -Values @('OFFLINE') -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs 5000 } 'TERMINAL_CHILD_FAILED_STOP_RECONCILE'
    Check (([IO.File]::ReadAllLines($testCounter)).Count -eq 1) 'One failed child, no automatic retry'
    Refuses { Invoke-ArcTerminalChild -Contract $testContract -Values @('OFFLINE') -DeadlineAt (Get-ArcTerminalMs) -MaximumWaitMs 5000 } 'BOUNDED_TERMINAL_CHILD_DEADLINE'
    Check (([IO.File]::ReadAllLines($testCounter)).Count -eq 1) 'Expired child never launches'
    $testContract.terminalBackend.sha256='0'*64
    Refuses { Invoke-ArcTerminalChild -Contract $testContract -Values @('OFFLINE') -DeadlineAt ((Get-ArcTerminalMs)+5000) -MaximumWaitMs 5000 } 'TERMINAL_PIN_CHANGED'
    Check (([IO.File]::ReadAllLines($testCounter)).Count -eq 1) 'Changed pin never launches'

    # Execute only the production masked-child dispatch block with an offline fake
    # PowerShell child. Never invoke a released command, readiness, or credentials.
    $testEntrySource=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'terminal-entry.ps1'))
    $testDispatchMatch=[regex]::Match($testEntrySource,'(?ms)^    & \$arcPowerShell @arcArguments[^\r\n]*\r?\n.*?^    return \$arcExit\r?$')
    Check $testDispatchMatch.Success 'Exact production masked-child dispatch block exists'
    $testDispatch=[scriptblock]::Create($testDispatchMatch.Value)
    $arcPowerShell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $testMaskedChild=Join-Path $testDirectory 'fake-masked-child.ps1'
    $testMaskedCounter=Join-Path $testDirectory 'masked-attempts.txt'
    [IO.File]::WriteAllText($testMaskedChild,@'
param([string]$Counter,[int]$Code)
[IO.File]::AppendAllText($Counter,"attempt`n")
Write-Output 'OFFLINE child status line'
[Console]::WriteLine('OFFLINE child second line')
exit $Code
'@)
    $Role='offline:dispatch-only'
    $arcArguments=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$testMaskedChild,'-Counter',$testMaskedCounter,'-Code','0')
    $testDispatchExit=& $testDispatch
    Check ($testDispatchExit -is [int] -and $testDispatchExit -eq 0) 'Noisy successful child returns scalar numeric zero only'
    Check (('ExitCode: '+$testDispatchExit) -ceq 'ExitCode: 0') 'Outer command prints numeric success without child body'
    Check (([IO.File]::ReadAllLines($testMaskedCounter)).Count -eq 1) 'Noisy success launches exactly once'
    $arcArguments[-1]='7'
    $testFailureOutput=@()
    $testMaskedFailure=$null
    try { & $testDispatch | ForEach-Object { $testFailureOutput += $_ } } catch { $testMaskedFailure=$_.Exception.Message }
    Check ($testMaskedFailure -ceq 'MASKED_CHILD_FAILED_STOP_RECONCILE') 'Noisy nonzero child preserves STOP_RECONCILE failure'
    Check ($testFailureOutput.Count -eq 0) 'Noisy failed child emits no function success-stream body'
    Check (([IO.File]::ReadAllLines($testMaskedCounter)).Count -eq 2) 'Nonzero child launches exactly once without retry'
} finally {
    # Preserve owned offline fixtures for review; no cleanup or operational outputs.
}
Write-Output ('OFFLINE_R4_TERMINAL_PS_PASS '+(@{checks=$testCount;powershellMajor=$PSVersionTable.PSVersion.Major;cloudCalls=0;credentialReads=0}|ConvertTo-Json -Compress))
