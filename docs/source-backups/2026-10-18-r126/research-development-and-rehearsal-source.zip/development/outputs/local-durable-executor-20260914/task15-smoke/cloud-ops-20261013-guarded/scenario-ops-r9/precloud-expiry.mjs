// Read-only reconstruction of the exact consumed r3 package expiry. No operation is dispatched.
import {existsSync,readdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {FIXED,G,assert,same,integer,uuid,utc} from './guards.mjs';
import {createValidationContext as predecessorContext,toolRefs as predecessorTools,ref as predecessorRef,FIXED as HISTORICAL} from '../scenario-ops-r3/guards.mjs';
import {fixedRole as predecessorRole,loadTerminalTemplate} from '../scenario-ops-r3/terminal-contract.mjs';
export function assertPrecloudExpiryRecords({diagnosis:d,attempt:a,failure:f,template:t}){
 const r=predecessorRole('long:start');
 assert(d.schemaVersion==='arc-terminal-expiry-local-diagnosis-v1'&&d.disposition==='R3_REFUSED_BEFORE_INITIAL_ACK_OR_CLOUD_PREPARATION'&&d.reproducedCode==='FINITE_ROOT_TERMINAL_TEMPLATE'&&d.oldAttemptMustNotBeRepeated===true&&d.attempt.path===r.shellAttemptPath&&d.failure.path===r.shellFailurePath&&d.template.path===r.templatePath,'EXACT_PREDECESSOR_EXPIRY_DIAGNOSIS');
 assert(a.schemaVersion==='arc-guarded-terminal-shell-attempt-v1'&&a.role==='long:start'&&uuid(a.invocationId)&&integer(a.processId)&&a.processId>0&&integer(a.invokedAt)&&a.noAutomaticRetry===true&&same(a.command,predecessorRef(r.commandPath))&&same(a.contract,predecessorRef(resolve(G,'scenario-ops-r3/launcher-contract.json')))&&same(a.entry,predecessorRef(resolve(G,'scenario-ops-r3/terminal-entry.ps1'))),'EXACT_CONSUMED_PREDECESSOR_SHELL');
 assert(f.schemaVersion==='arc-guarded-terminal-shell-failure-v1'&&f.role===a.role&&f.invocationId===a.invocationId&&f.processId===a.processId&&same(f.shellAttempt,d.attempt)&&integer(f.observedAt)&&f.observedAt>=a.invokedAt&&f.disposition==='UNKNOWN_STOP_RECONCILE_NO_RETRY'&&f.noAutomaticRetry===true&&f.rawDiagnosticPersisted===false,'EXACT_PREDECESSOR_SHELL_FAILURE');
 assert(t.sequence==='20261014-r3'&&t.identity.role==='long:start'&&same(t.currentClosedAcceptance,HISTORICAL.currentClosedAcceptance)&&a.invokedAt>=t.validUntil&&utc(d.invokedAt)===a.invokedAt&&utc(d.templateExpiredAt)===t.validUntil&&d.lateByMs===a.invokedAt-t.validUntil&&utc(d.observedAt)>=f.observedAt,'ACTUAL_PREDECESSOR_TEMPLATE_EXPIRY');
 assert(same(Object.keys(d.downstream).sort(),['invocationPath','preparedPath','acknowledgementPath','readinessPath','handoffPath','attemptPath','exitPath','reportPath'].sort())&&Object.values(d.downstream).every(x=>x===false)&&same(d.operational,{controls:0,clocks:0,observations:0,handoffs:0})&&d.activationExists===false&&[d.cloudReads,d.cloudMutations,d.providerCalls,d.credentialReads].every(x=>x===0),'SPECIFIC_PRE_CLOUD_DIAGNOSIS_ONLY');
 return true;
}
export function loadPrecloudExpiry(read,verify){
 const d=read(FIXED.predecessorHistory.precloudExpiry),a=read(d.attempt),f=read(d.failure),t=read(d.template);
 assertPrecloudExpiryRecords({diagnosis:d,attempt:a,failure:f,template:t});
 for(const pin of Object.values(predecessorTools()))verify(pin);
 const c=predecessorContext();
 loadTerminalTemplate(c,d.template,'long:start',{now:utc(t.reviewedAt)});
 let code=null;try{loadTerminalTemplate(c,d.template,'long:start',{now:a.invokedAt});}catch(error){code=error.message;}
 assert(code==='FINITE_ROOT_TERMINAL_TEMPLATE','RECOMPUTED_PREDECESSOR_EXPIRY_BEFORE_INSPECT_RETURN');
 const dir=resolve(G,'scenario-ops-r3');
 assert(same(readdirSync(resolve(dir,'terminal')).sort(),['long-start-shell-attempt.json','long-start-shell-failure.json']),'ONLY_ORIGINAL_EXPIRED_SHELL_RECORDS');
 assert(same(readdirSync(resolve(dir,'templates')).sort(),['long-start.json']),'ONLY_ORIGINAL_EXPIRED_TEMPLATE');
 for(const name of ['controls','clocks','observations','handoffs','receipts'])assert(!existsSync(resolve(dir,name))||readdirSync(resolve(dir,name)).length===0,'NO_PREDECESSOR_DOWNSTREAM_PREPARATION');
 for(const name of ['activate-deploy-attempt.json','activate-deploy-result.json','closed-baseline-acceptance.json','activate-root-policy-decision-r3.json','roster-preparation.json','replay-approval.json','replay-native-evidence.json','wrangler.site-roster.json'])assert(!existsSync(resolve(dir,name)),'NO_PREDECESSOR_ACTIVATION_OR_ROSTER');
 for(const id of ['long','after-r2','after-d1'])for(const mode of ['start','status','replay']){
  const r=predecessorRole(id+':'+mode);
  for(const key of ['invocationPath','preparedPath','acknowledgementPath','readinessPath','handoffPath','attemptPath','exitPath','failurePath'])assert(!existsSync(r[key]),'NO_PREDECESSOR_ROLE_PREPARATION');
  assert(!existsSync(dirname(r.reportPath)),'NO_PREDECESSOR_DRIVER_REPORT');
 }
 return Object.freeze({reference:FIXED.predecessorHistory.precloudExpiry,attempt:d.attempt,failure:d.failure,template:d.template,reproducedCode:code,safePrecloudSuccessor:true,oldAttemptMustNotBeRepeated:true});
}
