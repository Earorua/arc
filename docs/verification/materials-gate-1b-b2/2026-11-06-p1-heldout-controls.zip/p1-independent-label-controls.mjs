// Run from this checkout: node --import tsx work/release-equiv/p1-independent-label-controls.mjs
// Stdout is the JSON report. Use --write to replace only its ignored sibling JSON.
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { readSourceSpanExtraction } from "../../worker/document-executor/source-span-extraction.ts";
import { serializeDocumentExtraction, validateStoredDocumentExtraction } from "../../app/server/documents/extraction-validator.ts";
import { mapMaterialItems, MATERIAL_MAPPING_VERSION } from "../../app/lib/materials/skill-mapper.ts";
import { flagshipBlueprint } from "../../app/data/flagship-blueprint.ts";
import { flagshipUnitRegistry } from "../../app/data/flagship-unit-registry.ts";

const station = [
  "在虚构的车站 kiosk audit 中，我用 WAI-ARIA 标记了三种闸门提示。",
  "Lab access is limited，带 WAI-ARIA 的练习牌只在周三午间开放。",
];
const gaugeDuty = "This role must calibrate the MicaLatch gauge 才能读取磨砂标牌。";
const catalogNote = "Catalog note：本岗位使用的培训目录明确不含 MicaLatch 校准课程。";
const catalogName = "Accessible Design Systems";
const item = (line, kind, skillLabels, selfLevelHint = null) => ({ line, kind, skillLabels, selfLevelHint });
const duty = item(1, "requirement", ["MicaLatch"]);
const constraint = item(2, "constraint", ["WAI-ARIA"]);

function observe(id, lines, name, submittedItems, coverageLine = null) {
  const text = lines.join("\n");
  const sources = { text, segments: [{ id: "body", start: 0, end: text.length }] };
  const source = line => ({ segmentId: "body", quote: lines[line - 1] });
  const items = submittedItems.map(({ line, kind, skillLabels, selfLevelHint }) => ({
    source: source(line), kind, skillLabels, selfLevelHint, requirementLevel: kind === "requirement" ? "must" : null,
  }));
  const reviewPoints = coverageLine === null ? [] : [{ code: "uncovered-skill", source: source(coverageLine) }];
  const content = JSON.stringify({ format: "source-spans-v1", items, reviewPoints });
  const read = readSourceSpanExtraction({ choices: [{ finish_reason: "stop", message: { role: "assistant", content } }] }, sources);
  const observation = { name, submittedItems, submittedCoverageClaimLine: coverageLine, extractionRead: read.extractionRead };
  if (!read.candidate) return { ...observation, product: null };

  const ownerId = "local-synthetic-owner";
  const context = { ownerId, documentId: id, documentVersionId: "synthetic-v1", textVersionId: "source-v1", lifecycle: "active", ...sources };
  const draft = validateStoredDocumentExtraction(serializeDocumentExtraction(read.candidate), ownerId, context);
  // Model what would be mapped if a user kept all projected items and labels.
  const mappings = mapMaterialItems(draft.items, flagshipBlueprint, flagshipUnitRegistry);
  function lineOf(ref) {
    const at = lines.indexOf(text.slice(ref.start, ref.end));
    if (at < 0) throw new Error("Projected source did not resolve to a control line");
    return at + 1;
  }
  const projected = draft.items.map(fact => ({
    line: lineOf(fact.sourceRef), kind: fact.kind, retainedLabels: fact.skillLabels ?? null,
    hintCount: draft.selfAssessmentHints.filter(hint => hint.candidateId === fact.id).length,
    mappings: mappings.filter(m => m.itemId === fact.id).map(({ status, skillIds, labels }) => ({ status, skillIds, labels })),
  }));
  const reviews = draft.reviewPoints.map(point => ({ code: point.code, resolution: point.resolution, line: lineOf(point.sourceRef) }));
  return { ...observation, product: { projected, reviews } };
}

function example(id, lines, variants) {
  return { id, sourceLines: lines, observations: variants.map(args => observe(id, lines, ...args)) };
}

const cases = [
  example("harbor-kiosk", station, [
    ["literal and catalog name", [item(1, "experience", ["WAI-ARIA", catalogName]), constraint]],
    ["only catalog name", [item(1, "experience", [catalogName]), constraint]],
    ["constraint with fabricated self-level", [item(2, "constraint", ["WAI-ARIA"], "guided")]],
  ]),
  example("frosted-tag-duty", [gaugeDuty], [
    ["uncovered tool only", [duty]],
    ["unsupported coverage assertion supplied manually", [duty], 1],
  ]),
  example("frosted-tag-catalog", [gaugeDuty, catalogNote], [
    ["explicit passage without submitted review", [duty]],
    ["explicit passage with source-bound review", [duty], 2],
  ]),
];
const sourceHashes = {};
for (const file of ["worker/document-executor/source-span-extraction.ts", "app/server/documents/extraction-validator.ts",
  "app/server/documents/review-points.ts", "app/lib/materials/skill-labels.ts", "app/lib/materials/skill-mapper.ts",
  "app/data/flagship-blueprint.ts", "app/data/flagship-role.ts", "app/data/flagship-unit-registry.ts"]) {
  sourceHashes[file] = createHash("sha256").update(readFileSync(new URL("../../" + file, import.meta.url))).digest("hex");
}
const report = {
  purpose: "Handwritten bilingual observations for a future comparison. No corpus, scorer, model or provider invoked.",
  scope: "In-memory compact decoding and stored-candidate review projection, followed by flagship mapping assuming every retained word is kept. No database confirmation or plan generation.",
  catalog: { role: flagshipBlueprint.id, version: flagshipBlueprint.version, mappingVersion: MATERIAL_MAPPING_VERSION },
  cases, sourceSha256: sourceHashes,
  limits: "Source-bound review acceptance does not validate entailment. Catalog lookup supplies only this published role's mapping. These are observations, not new quality thresholds.",
};
const json = JSON.stringify(report, null, 2) + "\n";
if (process.argv.includes("--write")) writeFileSync(new URL("./p1-independent-label-controls.json", import.meta.url), json);
else process.stdout.write(json);
