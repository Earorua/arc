import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { readFileSync, readdirSync, existsSync, writeFileSync } from "node:fs";
import { dirname, extname, join, relative, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { Miniflare, Log, LogLevel } from "miniflare";
import { serializeSignedCookie } from "better-call";
import { execFileSync } from "node:child_process";
const program=fileURLToPath(import.meta.url), root=resolve(dirname(program),"../.."), area=process.env.ARC_ROLLBACK_RUN;
assert(area&&resolve(area).startsWith(resolve(root,"work/release-rollback/run-")));
const sha=x=>createHash("sha256").update(x).digest("hex"), read=(path)=>readFileSync(path,"utf8");
const args=process.argv.slice(2);
assert(args.length===0||(args.length===2&&args[0]==="--package"),"use --package <closed package root>");
const packageRoot=args.length?resolve(args[1]):null;
const source=JSON.parse(read(join(root,"work/browser-validation/checked-source.json"))).project;
const compiled=packageRoot?join(packageRoot,"site/server"):join(source,"dist/server"), configPath=join(compiled,"wrangler.json"),config=JSON.parse(read(configPath));
assert.equal(config.main.replace(/^\.\//,""),"index.js");
for(const key of ["ARC_DOCUMENTS_ENABLED","ARC_DOCUMENT_ANALYSIS_ENABLED","ARC_DOCUMENT_PLANNING_ENABLED"])assert.equal(config.vars[key],"false","real closed package binding "+key);
for(const [key,value] of Object.entries(config.vars))assert(!/(?:API_KEY|SECRET|PASSWORD|AUTHORIZATION)$/i.test(key)||value==="","unexpected private or authorized binding in closed package");
if(packageRoot){assert.equal(config.vars.ARC_DOCUMENT_PRODUCTION_ENABLED,"false");assert.equal(config.vars.ARC_DOCUMENT_PRODUCTION_AUTHORIZATION,"");}
assert.deepEqual(config.d1_databases.map(x=>x.binding),["DB"]);assert.deepEqual(config.r2_buckets.map(x=>x.binding).sort(),["DOCUMENT_ASSETS","PROOF_ASSETS"]);
assert.equal(config.assets.binding,"ASSETS");assert(config.services.some(x=>x.binding==="DOCUMENT_EXECUTOR"));
const treeFiles=readdirSync(compiled,{withFileTypes:true,recursive:true}).filter(x=>x.isFile()).map(x=>join(x.parentPath,x.name)).sort();
const scripts=[join(compiled,"index.js"),...treeFiles.filter(p=>extname(p)===".js"&&p!==join(compiled,"index.js"))];
const portable=p=>relative(compiled,p).replaceAll("\\","/");
const modules=scripts.map(path=>({type:"ESModule",path,contents:readFileSync(path)}));
const sourceCommit=execFileSync("git",["rev-parse","--verify","28069c4^{commit}"],{cwd:root,encoding:"utf8"}).trim();
const git=(...args)=>execFileSync("git",args,{cwd:root,encoding:"utf8",maxBuffer:64*1024*1024});
const report={schemaVersion:1,sourceCommit,startedAt:new Date().toISOString(),worker:"Miniflare/workerd with native D1 and R2; reviewed compiled site JS bytes",
  entrySha256:sha(modules[0].contents),moduleCount:modules.length,moduleSetSha256:sha(JSON.stringify(modules.map(m=>[portable(m.path),sha(m.contents)]))),
  programSha256:sha(readFileSync(program)),launcherSha256:sha(readFileSync(join(dirname(program),"launch.mjs"))),checkedSourceMetadataSha256:sha(readFileSync(join(root,"work/browser-validation/checked-source.json"))),
  network:{workerOutbound:0,executorCalls:0,researchExecutorCalls:0,assetCalls:0},routes:[],assertions:[]};
report.deployment={mode:packageRoot?"final-closed-package":"reviewed-dist",configSha256:sha(readFileSync(configPath)),
  closedBindings:Object.fromEntries(["ARC_ENVIRONMENT","ARC_DOCUMENT_ACCEPTANCE_MODE","ARC_DOCUMENT_PRODUCTION_ENABLED","ARC_DOCUMENTS_ENABLED","ARC_DOCUMENT_ANALYSIS_ENABLED","ARC_DOCUMENT_PLANNING_ENABLED","ARC_AI_ENABLED","ARC_AI_RESEARCH_ENABLED"].map(k=>[k,config.vars[k]??null])),
  compatibilityDate:config.compatibility_date,compatibilityFlags:config.compatibility_flags,
  serviceBindings:config.services.map(s=>s.binding).sort(),closedMaterialFlagOverrides:[],authorizationEmpty:!String(config.vars.ARC_DOCUMENT_PRODUCTION_AUTHORIZATION??""),
  testOverrides:["local Better Auth origin/session secret and fake OAuth provider","local native D1/R2 with named service bindings mapped to sinks",
    "ARC_AI_ENABLED and ARC_AI_RESEARCH_ENABLED forced false locally; unrelated Research executor URL replaced by an isolated .test name; no provider credentials"]};
if(packageRoot){
  const index=JSON.parse(read(join(packageRoot,"artifact-index.json"))),proof=JSON.parse(read(join(packageRoot,"verification.json")));
  const target="c238fc056659517d5b13113e3d349a08fee46daef0688a6b8b8e83a4ee8dcb3e";
  assert.equal(proof.mode,"closed");assert.equal(proof.candidate,sourceCommit);assert.equal(proof.artifactTreeSha256,target);
  assert.equal(index.treeSha256,target);assert.equal(sha(JSON.stringify(index.artifacts)),target);assert.equal(index.artifacts.length,390);
  const present=readdirSync(packageRoot,{recursive:true,withFileTypes:true}).filter(x=>x.isFile()).map(x=>relative(packageRoot,join(x.parentPath,x.name)).replaceAll("\\","/"))
    .filter(p=>!["artifact-index.json","verification.json"].includes(p)).sort();
  assert.deepEqual(present,index.artifacts.map(x=>x.path).sort());
  for(const row of index.artifacts)assert.equal(sha(readFileSync(join(packageRoot,row.path))),row.sha256,"package bytes mismatch "+row.path);
  report.deployment.artifactTreeSha256=target;report.deployment.filesVerified=390;report.deployment.indexSha256=sha(readFileSync(join(packageRoot,"artifact-index.json")));
  report.deployment.artifactVerificationSha256=sha(readFileSync(join(packageRoot,"verification.json")));
}
const origin="https://rollback.arc.test",secret=randomBytes(40).toString("hex"),cookies={};
const statuses={};
const worker=(open)=>new Miniflare({cf:false,log:new Log(LogLevel.ERROR),host:"127.0.0.1",unsafeTriggerHandlers:true,d1Persist:join(area,"d1"),r2Persist:join(area,"r2"),
  workers:[{name:"rollback-site",modules,modulesRoot:compiled,compatibilityDate:config.compatibility_date,compatibilityFlags:config.compatibility_flags,
  d1Databases:{DB:"rollback-site-database"},r2Buckets:{DOCUMENT_ASSETS:"rollback-document-assets",PROOF_ASSETS:"rollback-proof-assets"},
  bindings:{...config.vars,...(open?{ARC_DOCUMENTS_ENABLED:"true",ARC_DOCUMENT_PLANNING_ENABLED:"true"}:{}),
    ARC_AI_ENABLED:"false",ARC_AI_RESEARCH_ENABLED:"false",...(config.vars.ARC_AI_RESEARCH_EXECUTOR_URL?{ARC_AI_RESEARCH_EXECUTOR_URL:"https://research-sink.rollback.test"}:{}),
    BETTER_AUTH_URL:origin,BETTER_AUTH_SECRET:secret,GITHUB_CLIENT_ID:"fake-rollback-github-id",GITHUB_CLIENT_SECRET:"fake-rollback-github-value"},
  serviceBindings:{ASSETS:async()=>{report.network.assetCalls++;return new Response(null,{status:404});},
    ...(config.services.some(x=>x.binding==="ARC_RESEARCH_EXECUTOR")?{ARC_RESEARCH_EXECUTOR:async()=>{report.network.researchExecutorCalls++;return new Response(null,{status:503});}}:{}),
    DOCUMENT_EXECUTOR:async()=>{report.network.executorCalls++;return new Response(null,{status:503});}},
  outboundService:async()=>{report.network.workerOutbound++;return new Response(null,{status:503});}}]});
const contracts=(await import(pathToFileURL(join(source,"app/contracts/documents-api.ts")).href)).documentEndpointContracts;
const planningFixture=(await import(pathToFileURL(join(source,"tests/helpers/material-planning.ts")).href)).materialContextRequest;
let mf,db,phase="enabled";
async function call(label,actor,method,path,data,expectStatus=200){
  const headers={...actor?{cookie:cookies[actor]}:{},...(method!=="GET"?{origin,"content-type":"application/json"}:{})};
  const response=await mf.dispatchFetch(new URL(path,origin).href,{method,headers,...(data?{body:JSON.stringify(data)}:{})});
  const body=await response.json().catch(()=>({error:{code:"non-json"}}));
  report.routes.push({phase,actor:actor??"anonymous",operation:label,method,status:response.status,errorCode:body.error?.code??null});
  if(response.status!==expectStatus)throw new Error(label+" HTTP "+response.status+" expected "+expectStatus+" code="+(body.error?.code??"-"));
  return body;
}
async function endpoint(actor,name,input,expected){
  const c=contracts[name],data={...input};
  const url=new URL(c.path.replace(/\[([^\]]+)\]/g,(_,key)=>{const value=data[key];delete data[key];return encodeURIComponent(value);}),origin);
  if(c.method==="GET"){for(const [k,v] of Object.entries(data))if(v!==undefined)url.searchParams.set(k,String(v));}
  return call(name,actor,c.method,url.pathname+url.search,c.method==="GET"?undefined:data,expected??(["createDocument","createDocumentVersion"].includes(name)?201:200));
}
async function boot(enabled){phase=enabled?"enabled":"closed";mf=worker(enabled);await mf.ready;db=await mf.getD1Database("DB","rollback-site");}
async function migrate(){
  const directory=packageRoot?join(compiled,config.d1_databases[0].migrations_dir):join(source,"drizzle");
  const files=readdirSync(directory).filter(n=>/^\d{4}_.*\.sql$/.test(n)).sort();
  assert.deepEqual(files,readdirSync(join(source,"drizzle")).filter(n=>/^\d{4}_.*\.sql$/.test(n)).sort());
  for(const n of files){const sql=read(join(directory,n));assert.equal(sha(sql),sha(read(join(source,"drizzle",n))),"packaged SQL "+n);
    const stmts=sql.split("--> statement-breakpoint").map(s=>s.trim()).filter(Boolean);
    for(const s of stmts){try{await db.prepare(s).run()}catch(e){throw new Error("migration "+n+" "+String(e.message).slice(0,180));}}}
  report.migrationCount=files.length;
}
async function seed(actor){const token=randomBytes(32).toString("hex"),now=Date.now();
  await db.batch([db.prepare("INSERT INTO users(id,name,email,email_verified) VALUES (?,?,?,1)").bind(actor,actor,actor+"@example.invalid"),
    db.prepare("INSERT INTO sessions(id,user_id,token,expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?)").bind("session-"+actor,actor,token,now+7_200_000,now,now),
    db.prepare("INSERT INTO career_goals(id,user_id,role_id,level,weekly_minutes,target_weeks,status,active_slot,created_at,updated_at) VALUES (?,?,'ai-native-full-stack-engineer','beginner',420,52,'active',1,?,?)").bind("goal-"+actor,actor,now,now)]);
  cookies[actor]=(await serializeSignedCookie("__Secure-arc.session_token",token,secret,{path:"/",httpOnly:true,secure:true})).split(";",1)[0];
}
function verifyTree(){
  const recorded=JSON.parse(read(join(root,"work/browser-validation/checked-source.json"))).entries,checked=[];
  for(const row of git("ls-tree","-r","-z",sourceCommit).split("\0").filter(Boolean)){
    const tab=row.indexOf("\t"),name=row.slice(tab+1),[mode,type,id]=row.slice(0,tab).split(" ");
    if(name.startsWith("docs/"))continue;
    assert(type==="blob"&&["100644","100755"].includes(mode),"non-regular source file");
    const data=readFileSync(join(source,name));assert.equal(sha(data),recorded[name],"reviewed SHA "+name);
    assert.equal(createHash("sha1").update("blob "+data.length+"\0").update(data).digest("hex"),id,"Git source "+name);
    checked.push([name,sha(data)]);
  }
  report.sourceFilesVerified=checked.length;report.sourceFileSetSha256=sha(JSON.stringify(checked));
  report.workerModuleManifest=modules.map(m=>({path:portable(m.path),sha256:sha(m.contents)}));
  report.hostBlockerSha256=sha(readFileSync(join(root,"work/materials-browser-handoff/block-outbound.cjs")));
  report.toolVersions={node:process.version,miniflare:JSON.parse(read(join(root,"node_modules/miniflare/package.json"))).version,
    workerd:JSON.parse(read(join(root,"node_modules/workerd/package.json"))).version};
}
async function confirmed(actor,kind,slug,skill){
  const doc=await endpoint(actor,"createDocument",{kind,displayName:"Synthetic "+slug,text:"Synthetic source "+slug,mutationId:"create-"+slug});
  const item={id:slug,text:skill,kind:kind==="jd"?"requirement":"experience",requirementLevel:kind==="jd"?"must":null,sourceRef:null,origin:"user"};
  const {draft}=await endpoint(actor,"saveDocumentReviewDraft",{documentId:doc.documentId,textVersionId:doc.textVersionId,extractionId:null,items:[item],selfAssessmentHints:[],expectedRevision:0,mutationId:"draft-"+slug});
  const receipt=await endpoint(actor,"createDocumentConfirmation",{documentId:doc.documentId,documentVersionId:doc.documentVersionId,textVersionId:doc.textVersionId,
    items:draft.items,expectedRevision:doc.revision,reviewRevision:draft.revision,mutationId:"confirm-"+slug});
  return {...doc,...receipt,slot:kind};
}
const entry=({documentId,documentVersionId,slot,confirmationId})=>({documentId,documentVersionId,slot,confirmationId});
const refs=x=>x.map(e=>e.confirmationId).sort();
async function adopted(actor,ws){return (await endpoint(actor,"readAdoptedMaterials",{goalId:ws.goalId,workspaceId:ws.id,baseVersionId:ws.activePlanVersionId})).entries;}
const history=async(actor,goalId)=>(await endpoint(actor,"readMaterialHistory",{goalId,includeProposalState:"current"})).plans;
const completion=ws=>ws.events.filter(e=>e.kind==="completed");
const identity=ws=>({activePlanVersionId:ws.activePlanVersionId,pendingPlanVersionId:ws.pendingPlanVersionId,revision:ws.revision,lastSequence:ws.lastSequence});
async function setupJourney(actor){
  const cap=await endpoint(actor,"readDocumentCapabilities",{});assert(cap.documentsEnabled&&cap.planningEnabled&&!cap.analysisEnabled);
  const a=await confirmed(actor,"jd","company-a","TypeScript"),resume=await confirmed(actor,"resume","resume","TypeScript"),
    supplement=await confirmed(actor,"supplement","notes","TypeScript"),b=await confirmed(actor,"jd","company-b","proof-of-work");
  const {selectionRef:unusedRef,scope:unusedScope,mutationId:unusedMutation,...input}=planningFixture();
  input.audit={...input.audit,id:"audit-"+actor,createdBy:actor};input.availability={...input.availability,id:"availability-"+actor};input.target={...input.target,id:"target-"+actor};
  const scope={kind:"draft",draftId:"draft-"+actor,previousGoalId:null};
  const sel=await endpoint(actor,"createMaterialSelection",{scope,entries:[a,resume,supplement].map(entry),mutationId:"select-a"});
  const ctx=await endpoint(actor,"createMaterialContext",{...input,scope,selectionRef:sel,mutationId:"preview-a"});
  const generated=await endpoint(actor,"generatePlanning",{...input,materials:{selectionRef:sel,contextVersionId:ctx.contextVersionId,previewToken:ctx.previewToken},mutationId:"generate-a"});
  const start=generated.result.workspace,unitId=start.dailyUnits[0].id;
  const complete=await call("complete-task",actor,"POST","/api/planning/events",{mutationId:"complete-one",baseVersionId:start.activePlanVersionId,
    event:{kind:"completed",unitId,actualMinutes:60,planningDate:input.planningDate}});
  const ws=complete.result.workspace;assert.equal(completion(ws).length,1);assert.equal(completion(ws)[0].unitId,unitId);
  const goalScope={kind:"goal",goalId:ws.goalId,workspaceId:ws.id,baseVersionId:ws.activePlanVersionId,revision:ws.revision};
  const selB=await endpoint(actor,"createMaterialSelection",{scope:goalScope,entries:[b,resume,supplement].map(entry),mutationId:"select-b"});
  const ctxB=await endpoint(actor,"createMaterialContext",{...input,scope:goalScope,selectionRef:selB,mutationId:"preview-b"});
  const proposalRequest={scope:goalScope,selectionRef:selB,contextVersionId:ctxB.contextVersionId,previewToken:ctxB.previewToken,mutationId:"offer-b"};
  const proposed=await endpoint(actor,"materialReplan",proposalRequest);assert.equal(proposed.outcome,"proposed");
  const pending=proposed.planning.result.workspace;assert(pending.pendingPlanVersionId);assert.deepEqual(completion(pending),completion(ws));
  const decision={baseVersionId:pending.activePlanVersionId,candidatePlanVersionId:pending.pendingPlanVersionId,mutationId:"accept-b"};
  let final=pending;
  if(actor==="accepted"){final=(await call("accept-before-close",actor,"POST","/api/planning/replans/accept",decision)).result.workspace;
    assert.equal(final.activePlanVersionId,decision.candidatePlanVersionId);assert.equal(final.pendingPlanVersionId,null);}
  const expected=[actor==="accepted"?b:a,resume,supplement];
  assert.deepEqual(refs(await adopted(actor,final)),refs(expected));
  const h=await history(actor,ws.goalId),row=h.find(r=>r.contextVersionId===ctxB.contextVersionId);
  assert.equal(row.kind,actor==="accepted"?"accepted":"proposal");if(actor==="pending")assert.equal(row.proposalState,"pending");
  assert.equal(h.filter(r=>r.contextVersionId===ctxB.contextVersionId).length,1);
  // An existing synthetically seeded consent lets the closed job ingress be tested with real valid owner/document/version refs.
  // It is a local fixture only; analysis stays disabled even in setup.
  const consentId="analysis-consent-"+actor;
  await db.prepare(`INSERT INTO document_processing_consents(owner_id,id,text_version_id,document_id,document_version_id,purpose,policy_version,provider_policy_id,generation,granted_at)
    SELECT ?,?,?,?,?, 'analysis','2026.11.1','synthetic-policy',generation,? FROM documents WHERE owner_id=? AND id=?`)
    .bind(actor,consentId,b.textVersionId,b.documentId,b.documentVersionId,Date.now(),actor,b.documentId).run();
  const r2Keys={};const bucket=await mf.getR2Bucket("DOCUMENT_ASSETS","rollback-site");
  for(const [name,doc] of Object.entries({a,b,resume,supplement})){
    const key=await db.prepare("SELECT object_key FROM document_storage_operations WHERE owner_id=? AND document_id=? AND state='active'").bind(actor,doc.documentId).first("object_key");
    assert.equal(typeof key,"string");assert(await bucket.head(key));r2Keys[name]=key;
  }
  return {ws:final,pending,decision,proposalRequest,goalScope,input,selB,consentId,a,b,resume,supplement,expected,unitId,done:completion(ws)[0],h,r2Keys};
}
const counts=async()=>Object.fromEntries(await Promise.all(["document_jobs","document_budget_reservations","planning_events","document_usage_links","material_plan_proposals"].map(async table=>
  [table,(await db.prepare("SELECT COUNT(*) AS n FROM "+table).first()).n])));
async function proveClosed(actor,s){
  const cap=await endpoint(actor,"readDocumentCapabilities",{});assert(!cap.documentsEnabled&&!cap.planningEnabled&&!cap.analysisEnabled&&cap.hasDocuments);
  const fetched=await call("read-workspace-after-close",actor,"GET","/api/planning/workspace");
  assert.deepEqual(identity(fetched.workspace),identity(s.ws));assert.deepEqual(completion(fetched.workspace),[s.done]);
  assert(!JSON.stringify(fetched.workspace.events).includes("materialContextFingerprint"));
  assert.deepEqual(refs(await adopted(actor,s.ws)),refs(s.expected));
  assert.deepEqual(await history(actor,s.ws.goalId),s.h);
  const before=await counts();
  await endpoint(actor,"createDocument",{kind:"jd",displayName:"Closed",text:"Synthetic closed input",mutationId:"new-after-close"},503);
  await endpoint(actor,"createMaterialContext",{...s.input,scope:s.goalScope,selectionRef:s.selB,mutationId:"new-preview-after-close"},503);
  await endpoint(actor,"materialReplan",{...s.proposalRequest,mutationId:"new-offer-after-close"},503);
  await endpoint(actor,"createDocumentJob",{textVersionId:s.b.textVersionId,consentId:s.consentId,mutationId:"do-not-send"},503);
  let final=s.ws;
  if(actor==="pending"){
    await call("fresh-pending-accept-refused",actor,"POST","/api/planning/replans/accept",s.decision,503);
  }else{
    const recovered=await call("accepted-identical-receipt-replay",actor,"POST","/api/planning/replans/accept",s.decision);
    assert.deepEqual(identity(recovered.result.workspace),identity(s.ws));
  }
  assert.deepEqual(await counts(),before);
  assert.deepEqual(identity((await call("workspace-after-closed-admission",actor,"GET","/api/planning/workspace")).workspace),identity(s.ws));
  if(actor==="pending"){
    const discarded=await call("discard-existing-pending",actor,"POST","/api/planning/replans/discard",{...s.decision,mutationId:"discard-in-closed"});
    final=discarded.result.workspace;assert.equal(final.pendingPlanVersionId,null);assert.equal(final.activePlanVersionId,s.pending.activePlanVersionId);
    assert.deepEqual(refs(await adopted(actor,final)),refs(s.expected));
    assert.equal((await history(actor,final.goalId)).find(row=>row.contextVersionId===s.proposalRequest.contextVersionId)?.proposalState,"discarded");
  }
  const deletion=await endpoint(actor,"deleteDocument",{documentId:s.b.documentId,expectedRevision:s.b.revision,mutationId:"cleanup-b"});
  const deletionStatus=await endpoint(actor,"readDocumentDeletion",{deletionJobId:deletion.deletionJobId});
  const deletedRow=(await history(actor,final.goalId)).find(row=>row.contextVersionId===s.proposalRequest.contextVersionId);
  assert.equal(deletedRow.sourceAvailability,"unavailable");assert.equal(deletedRow.explanations.length,1);
  assert.equal(deletedRow.explanations[0].ruleId,"source-unavailable-v1");assert.deepEqual(deletedRow.explanations[0].reasonItemIds,[]);
  assert.deepEqual(deletedRow.explanations[0].unitIds,[]);assert.equal(deletedRow.explanations[0].skillId,null);
  const closed=(await call("workspace-after-source-revocation",actor,"GET","/api/planning/workspace")).workspace;
  assert.deepEqual(identity(closed),identity(final));assert.deepEqual(completion(closed),[s.done]);
  report[actor]={priorWorkspaceRevision:s.ws.revision,closedReadRevision:fetched.workspace.revision,pendingBeforeClose:!!s.ws.pendingPlanVersionId,
    historicalPlans:s.h.length,matchingAdoptedRefs:s.expected.length,completedEventsPreserved:1,closedAdmissionChangedRows:false,
    deletionInitialState:deletionStatus.state,finalHistoryKind:deletedRow.kind,finalProposalState:deletedRow.proposalState??null,explanationsAfterRevocation:"source-unavailable-v1"};
  report[actor].finalWorkspaceIdentitySha256=sha(JSON.stringify(identity(final)));
  return deletion.deletionJobId;
}
try{
  verifyTree();
  await boot(true);await migrate();await seed("pending");await seed("accepted");
  await call("anonymous-workspace",null,"GET","/api/planning/workspace",undefined,401);
  for(const actor of ["pending","accepted"]){const session=await call("signed-session",actor,"GET","/api/auth/get-session");assert.equal(session?.user?.id,actor);}
  report.assertions.push("production Better Auth signed cookies resolve only seeded local users");
  const pending=await setupJourney("pending"),accepted=await setupJourney("accepted");
  report.beforeRestart=await counts();
  await mf.dispose();mf=null;await boot(false);
  assert.deepEqual(await counts(),report.beforeRestart);
  const jobs=[await proveClosed("pending",pending),await proveClosed("accepted",accepted)];
  const trigger=await mf.dispatchFetch(origin+"/cdn-cgi/handler/scheduled?cron="+encodeURIComponent("*/5 * * * *"));
  assert.equal(trigger.status,200,"native scheduled handler");await trigger.arrayBuffer();
  for(const [index,actor] of ["pending","accepted"].entries()){
    const status=await endpoint(actor,"readDocumentDeletion",{deletionJobId:jobs[index]});
    report[actor].cleanupAfterScheduled=status.state;
    assert.equal(status.state,"completed");
    const bucket=await mf.getR2Bucket("DOCUMENT_ASSETS","rollback-site"),s=actor==="pending"?pending:accepted;
    assert.equal(await bucket.head(s.r2Keys.b),null);
    for(const name of ["a","resume","supplement"])assert(await bucket.head(s.r2Keys[name]));
    report[actor].physicalR2Readback={deletedTargetAbsent:true,unrelatedObjectsStillPresent:3};
  }
  // The history detail route deliberately excludes an active goal. Set only the interview fixture's archive eligibility after all live-workspace checks.
  for(const [actor,s] of [["pending",pending],["accepted",accepted]]){
    await db.prepare("UPDATE career_goals SET status='archived',active_slot=NULL WHERE user_id=? AND id=?").bind(actor,s.ws.goalId).run();
    const list=await call("archived-goal-list",actor,"GET","/api/planning/history");
    assert(list.goals.some(g=>g.id===s.ws.goalId&&g.hasWorkspace));
    const saved=await call("archived-plan-after-close",actor,"GET","/api/planning/history?goal="+s.ws.goalId);
    assert.equal(sha(JSON.stringify(identity(saved.workspace))),report[actor].finalWorkspaceIdentitySha256);
    assert.deepEqual(completion(saved.workspace),[s.done]);report[actor].archivedWorkspaceRead=true;
    const redacted=(await history(actor,s.ws.goalId)).find(row=>row.contextVersionId===s.proposalRequest.contextVersionId);
    assert.equal(redacted.sourceAvailability,"unavailable");assert.equal(redacted.explanations[0].ruleId,"source-unavailable-v1");
  }
  await call("wrong-owner-saved-plan","accepted","GET","/api/planning/history?goal="+pending.ws.goalId,undefined,404);
  const finalCounts=await counts();assert.equal(finalCounts.document_jobs,0);assert.equal(finalCounts.document_budget_reservations,0);
  assert.equal(report.network.workerOutbound,0);assert.equal(report.network.executorCalls,0);assert.equal(report.network.researchExecutorCalls,0);assert.equal(read(process.env.ARC_LOCAL_BUILD_DENIAL_LOG),"");
  report.afterCleanup=finalCounts;
  report.assertions.push("both authentic sessions survive an actual same-code disabled restart with durable D1/R2",
    "pending proposal stays pending on refused fresh accept; explicit discard is allowed",
    "already accepted plan and its exact receipt replay remain readable without a new write",
    "manual document, material preview/replan and analysis job ingress all refuse new work after closure",
    "completed task and equivalent history/adopted links are preserved; source deletion redacts only affected evidence",
    "native scheduled cleanup completes both deletions; wrong-owner archival read refused; zero inference jobs, reservations or outbound requests");
  report.status="PASS";
}catch(e){report.status="FAIL";report.failure=String(e.message).slice(0,350);process.exitCode=1;console.error(report.failure);}
finally{if(mf)await mf.dispose();report.completedAt=new Date().toISOString();report.network.hostDenials=read(process.env.ARC_LOCAL_BUILD_DENIAL_LOG).trim().split("\n").filter(Boolean).length;
  writeFileSync(join(area,"result.json"),JSON.stringify(report,null,2)+"\n");console.log(JSON.stringify({status:report.status,assertions:report.assertions,routes:report.routes.length,network:report.network}));}
