import { spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
const location=dirname(fileURLToPath(import.meta.url)), repo=resolve(location,"../.."), run=mkdtempSync(join(location,"run-"));
const temp=join(run,"tmp"), home=join(run,"profile");mkdirSync(temp);mkdirSync(home);
const denial=join(run,"host-network-denials.log");writeFileSync(denial,"");
const env={SystemRoot:process.env.SystemRoot,windir:process.env.windir,PATH:process.env.PATH,ComSpec:process.env.ComSpec,
  TEMP:temp,TMP:temp,TMPDIR:temp,HOME:home,USERPROFILE:home,APPDATA:home,LOCALAPPDATA:home,
  ARC_ROLLBACK_RUN:run,ARC_LOCAL_BUILD_DENIAL_LOG:denial,WRANGLER_SEND_METRICS:"false",CI:"1"};
const result=spawnSync(process.execPath,["--require",join(repo,"work/materials-browser-handoff/block-outbound.cjs"),"--import","tsx",
  join(location,"prove.mjs"),...process.argv.slice(2)],{cwd:repo,env,stdio:"inherit",windowsHide:true});
console.log("run directory",run);process.exitCode=result.status??2;
