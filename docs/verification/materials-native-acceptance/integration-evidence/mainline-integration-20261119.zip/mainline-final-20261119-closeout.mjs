import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { stripVTControlCharacters } from 'node:util';
const work='work/grounded-verification/', evidence='docs/verification/materials-native-acceptance/';
const json=file=>JSON.parse(readFileSync(file,'utf8'));
const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const source=json(work+'mainline-final-20261119-reconciled.json');
for(const [file,digest] of Object.entries(source.source.files)) assert.equal(hash(file),digest,file);
const course=json(evidence+'course-binding.json');
for(const [name,digest] of Object.entries(course.frozenAssetHashes)) assert.equal(hash(course.frozenAssetDirectory+'/'+name),digest,name);
for(const file of course.frozenInputs) assert.equal(hash(file.path),file.sha256,file.path);
const integrated=json(evidence+'course-binding.integrated.json');
assert.equal(hash(evidence+'course-binding.integrated.json'),'0abfafdde4125cabf7a2b56aea7497b2e1dbd75b9c8406896fa42566af858d6a');
assert.equal(hash(integrated.currentCapture.path),integrated.currentCapture.sha256);
const current=json(integrated.currentCapture.path);
for(const file of current.dependencies) assert.equal(hash(file.path),file.sha256,file.path);
const native=json(evidence+'native-evidence/manifest.json');
const expectedChanges={
  'app/data/flagship-role.ts':'7070068cd2edb6bb176b61f01e9e2e2f1800b24179c908e3619e11be5560572e',
  'app/lib/materials/course-task-evidence.ts':'9918053c28c8577cfee0f4d416290908c189cd4202964d91a35508924d39b49e',
  'app/lib/materials/explanations.ts':'4890a600779022b9a956682076d3a3cfddc5759a154e314fed41a6c18fb5d0b8',
};
const deltas=native.sourceClosure.filter(file=>hash(file.path)!==file.sha256);
assert.deepEqual(deltas.map(file=>file.path).sort(),Object.keys(expectedChanges).sort());
for(const [file,digest] of Object.entries(expectedChanges)) assert.equal(hash(file),digest,file);
const runs=['types-01','lint-02','build-01','rendered-01','node-01'].map(suffix=>{
  const name='mainline-final-20261119-'+suffix,receipt=json(work+name+'.json');
  assert.equal(receipt.exit,0,name); assert.equal(receipt.nonLoopbackDenials,0,name);
  assert.equal(hash(work+name+'.log'),receipt.logSha256,name);
  return {...receipt,commandName:suffix};
});
const counts=suffix=>{
  const plain=stripVTControlCharacters(readFileSync(work+'mainline-final-20261119-'+suffix+'.log','utf8'));
  const result={}; for(const key of ['tests','pass','fail','cancelled','skipped','todo']) {
    const match=plain.match(new RegExp('^[ℹ#] '+key+' (\\d+)','m'));
    assert.ok(match,'Missing Node count '+key); result[key]=Number(match[1]);
  }
  assert.equal(result.tests,result.pass); for(const key of ['fail','cancelled','skipped','todo']) assert.equal(result[key],0);
  return result;
};
const rendered=counts('rendered-01'),node=counts('node-01'); assert.equal(rendered.tests,5);
const reviews=['mainline-integration-spec-review.md','mainline-integration-quality-review.md','mainline-final-repair-spec-review.md','mainline-final-repair-quality-review.md','planning-integration-reuse-review.md'];
for(const file of reviews) assert.ok(readFileSync(evidence+file,'utf8').length>100);
const result={schemaVersion:'materials-mainline-offline-acceptance-v1',status:'OFFLINE_ACCEPTED',
  sourceDigest:source.source.digest,sourceFiles:source.source.count,sourceHead:source.source.head,mergedMainline:source.source.mergeHead,
  vitest:{files:source.finalCoverage.files,tests:source.finalCoverage.tests,failed:0,basis:source.basis},node,rendered,
  types:'PASS',lint:{errors:0,warnings:4,scope:'All repository source except ignored local work scratch; no tracked files under work.'},build:'PASS',runs,
  reviews:Object.fromEntries(reviews.map(file=>[file,hash(evidence+file)])),
  integrity:{frozenAssets:Object.keys(course.frozenAssetHashes).length,frozenInputs:course.frozenInputs.length,courseDependencies:current.dependencies.length,
    nativeClosure:native.sourceClosure.length,nativeUnchanged:native.sourceClosure.length-deltas.length,reviewedNativeDisplayDeltas:expectedChanges},
  exclusions:{nativeRerun:false,newModelRequests:0,newModelCostUsd:0,remoteMigration:false,deployed:false,gate1BAccepted:false,productionReleased:false},
  retainedFailures:['Full Vitest run: 5 failed files / 9 failed tests; diagnosed and five suites repaired only.',
    'First lint command included ignored historical work scratch; all 139 errors were confined there. Scope corrected without changing rules or source.',
    'Author ID probe initial strict-input mismatch retained; corrected diagnostic proved both fixed IDs.']};
writeFileSync(work+'mainline-final-20261119-acceptance.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,vitest:result.vitest,node,rendered,sourceDigest:result.sourceDigest,integrity:result.integrity}));
