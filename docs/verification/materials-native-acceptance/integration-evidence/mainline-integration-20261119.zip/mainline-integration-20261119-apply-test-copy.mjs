import fs from "node:fs";
import ts from "typescript";
const prefix = "work/grounded-verification/mainline-integration-20261119-";
const inventory = JSON.parse(fs.readFileSync(prefix + "test-copy-inventory.json", "utf8"));
const values = [...new Set(inventory.map(row => row.value))];
const translations = JSON.parse(fs.readFileSync(prefix + "test-copy-translations.json", "utf8"));
const mapping = new Map(Object.entries(translations).map(([index, value]) => [values[index], value]));
const paths = [...new Set(inventory.map(row => row.path))];
function relevant(node) {
  for (let parent = node.parent; parent; parent = parent.parent) if (ts.isCallExpression(parent)) {
    const name = ts.isPropertyAccessExpression(parent.expression) ? parent.expression.name.text : "";
    if (/^(get|find|query)(All)?By/.test(name) || ["toHaveTextContent", "toHaveAccessibleName"].includes(name)) return true;
  }
  return false;
}
const template = value => value.replaceAll("\\", "\\\\").replaceAll("`", "\\`").replaceAll("${", "\\${");
for (const path of paths) {
  const source = fs.readFileSync(path, "utf8"), edits = [];
  const ast = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  function visit(node) {
    const value = mapping.get(node.text);
    if (value !== undefined && relevant(node) && (ts.isStringLiteral(node) || ts.isRegularExpressionLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)
      || node.kind === ts.SyntaxKind.TemplateHead || node.kind === ts.SyntaxKind.TemplateMiddle || node.kind === ts.SyntaxKind.TemplateTail)) {
      const replacement = ts.isStringLiteral(node) ? JSON.stringify(value) : ts.isRegularExpressionLiteral(node) ? value
        : ts.isNoSubstitutionTemplateLiteral(node) ? "`" + template(value) + "`"
        : node.kind === ts.SyntaxKind.TemplateHead ? "`" + template(value) + "${"
        : node.kind === ts.SyntaxKind.TemplateMiddle ? "}" + template(value) + "${" : "}" + template(value) + "`";
      edits.push({ start: node.getStart(ast), end: node.end, replacement });
    }
    ts.forEachChild(node, visit);
  }
  visit(ast);
  if (!edits.length) continue;
  let changed = source;
  for (const edit of edits.sort((a, b) => b.start - a.start)) changed = changed.slice(0, edit.start) + edit.replacement + changed.slice(edit.end);
  if (ts.createSourceFile(path, changed, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX).parseDiagnostics.length) throw Error(`Invalid translated test: ${path}`);
  fs.writeFileSync(path, changed);
  console.log(JSON.stringify({ path, updatedSelectors: edits.length }));
}
