import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { stripVTControlCharacters } from 'node:util';
const dir = 'work/grounded-verification/';
const read = file => JSON.parse(readFileSync(dir + file, 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const prior = read('mainline-final-20261119-source.json');
const repair = read('mainline-final-20261119-repair/handoff.json');
const allowed = new Map(repair.changedFiles.map(file => [file.path, file]));
const paths = [...new Set(execFileSync('git', ['-c','core.longpaths=true','ls-files','--cached','--others','--exclude-standard','-z'], { encoding:'utf8', maxBuffer:32*1024*1024 }).split('\0').filter(Boolean))]
  .filter(file => !file.startsWith('docs/') && !file.endsWith('.md')).sort();
assert.deepEqual(paths, Object.keys(prior.files));
const files = Object.fromEntries(paths.map(file => [file, hash(readFileSync(file))]));
const changed = paths.filter(file => files[file] !== prior.files[file]);
assert.deepEqual(changed, [...allowed.keys()].sort());
for (const file of changed) {
  assert.equal(prior.files[file], allowed.get(file).sha256);
  assert.equal(files[file], allowed.get(file).afterSha256);
  assert.equal(hash(readFileSync(allowed.get(file).archive)), prior.files[file]);
}
function results(name) {
  const receipt = read(name + '.json');
  const bytes = readFileSync(dir + name + '.log');
  assert.equal(hash(bytes), receipt.logSha256);
  assert.equal(receipt.nonLoopbackDenials, 0);
  const plain = stripVTControlCharacters(bytes.toString());
  const rows = [...plain.matchAll(/^\s*([✓✔❯])\s+(tests\/\S+\.test\.(?:ts|tsx))\s+\((\d+) tests?(?:\s*\|\s*(\d+) failed)?\)/gm)]
    .map(([,symbol,file,count,failed]) => ({file,count:Number(count),failed:Number(failed??0),passed:symbol!=='❯'}));
  return { receipt, rows };
}
const first=results('mainline-final-20261119-vitest-01'), targeted=results('mainline-final-20261119-repair-targeted-01');
assert.equal(first.receipt.exit,1); assert.equal(targeted.receipt.exit,0);
assert.deepEqual(first.rows.map(r=>r.file).sort(),prior.vitestFiles);
assert.deepEqual(first.rows.filter(r=>r.failed).map(r=>r.file).sort(),changed);
assert.deepEqual(targeted.rows.map(r=>r.file).sort(),changed);
assert.ok(targeted.rows.every(r=>r.passed && r.failed===0));
const final = first.rows.filter(row=>!allowed.has(row.file)).map(row=>({...row,evidence:'full-run'}))
  .concat(targeted.rows.map(row=>({...row,evidence:'targeted-repair'}))).sort((a,b)=>a.file.localeCompare(b.file));
assert.equal(new Set(final.map(r=>r.file)).size,386);
assert.ok(final.every(row=>row.passed && row.failed===0));
const result = {schemaVersion:'materials-mainline-final-reconciled-v1', source:{...prior,files,digest:hash(JSON.stringify(files))},
  priorSourceDigest:prior.digest, testOnlyChanges:changed,
  fullRun:{files:386,passedFiles:381,failedFiles:5,tests:10030,passed:10021,failed:9,receipt:first.receipt},
  targeted:{files:targeted.rows.length,tests:targeted.rows.reduce((n,r)=>n+r.count,0),receipt:targeted.receipt},
  finalCoverage:{files:final.length,tests:final.reduce((n,r)=>n+r.count,0),failed:0,rows:final},
  basis:'All product/runtime/config bytes stayed frozen; only the five failed test files changed. Reuse 381 untouched passing files and replace the five failed-suite outcomes with their one targeted run. Not a new all-pass full run.'};
writeFileSync(dir+'mainline-final-20261119-reconciled.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({sourceDigest:result.source.digest,changedTests:changed.length,files:result.finalCoverage.files,tests:result.finalCoverage.tests,failed:0}));
