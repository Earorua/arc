import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
const output = "work/grounded-verification/mainline-final-20261119-source.json";
const hash = value => createHash("sha256").update(value).digest("hex");
const git = (...args) => execFileSync("git", ["-c", "core.longpaths=true", ...args], { encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
assert.equal(git("ls-files", "-u"), "", "Unresolved merge entries remain");
const paths = [...new Set(git("ls-files", "--cached", "--others", "--exclude-standard", "-z").split("\0").filter(Boolean))]
  .filter(file => !file.startsWith("docs/") && !file.endsWith(".md")).sort();
const files = Object.fromEntries(paths.map(file => [file, hash(readFileSync(file))]));
if (process.argv[2] === "--verify") {
  const original = JSON.parse(readFileSync(output, "utf8"));
  assert.deepEqual(files, original.files, "Runtime/test/config source changed during final acceptance");
  console.log(JSON.stringify({ verified: true, count: paths.length, digest: original.digest }));
} else {
  assert.ok(!existsSync(output), "Never overwrite a source freeze");
  const result = { schemaVersion: "materials-mainline-final-source-v1", head: git("rev-parse", "HEAD").trim(),
    mergeHead: git("rev-parse", "MERGE_HEAD").trim(), branch: git("branch", "--show-current").trim(),
    scope: "Tracked/unignored runtime, tests, assets and configuration; Markdown and docs evidence are separately pinned and may receive reports.",
    count: paths.length, digest: hash(JSON.stringify(files)), files,
    vitestFiles: paths.filter(file => /^tests\/.+\.test\.(?:ts|tsx)$/u.test(file)),
    nodeFiles: paths.filter(file => /^tests\/.+\.test\.mjs$/u.test(file)) };
  writeFileSync(output, `${JSON.stringify(result, null, 2)}\n`, { flag: "wx" });
  console.log(JSON.stringify({ count: result.count, digest: result.digest, vitestFiles: result.vitestFiles.length, nodeFiles: result.nodeFiles.length }));
}
