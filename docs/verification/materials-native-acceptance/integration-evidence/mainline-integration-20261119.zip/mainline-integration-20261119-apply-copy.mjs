import fs from "node:fs";
import ts from "typescript";
const prefix = "work/grounded-verification/mainline-integration-20261119-";
const inventory = JSON.parse(fs.readFileSync(prefix + "copy-inventory.json", "utf8"));
const translations = JSON.parse(fs.readFileSync(prefix + "copy-translations.json", "utf8"));
const paths = process.argv.length > 2 ? process.argv.slice(2) : [...new Set(inventory.map(row => row.path))];
const template = value => value.replaceAll("\\", "\\\\").replaceAll("`", "\\`").replaceAll("${", "\\${");
for (const path of paths) {
  let index = inventory.findIndex(row => row.path === path);
  if (index < 0) throw Error(`Uninventoried path: ${path}`);
  const expectedEnd = index + inventory.filter(row => row.path === path).length;
  const source = fs.readFileSync(path, "utf8"), edits = [];
  const ast = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  function visit(node) {
    if ((ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node) || ts.isJsxText(node)
      || node.kind === ts.SyntaxKind.TemplateHead || node.kind === ts.SyntaxKind.TemplateMiddle || node.kind === ts.SyntaxKind.TemplateTail)
      && /\p{Script=Han}/u.test(node.getText(ast))) {
      const prior = inventory[index], value = translations[index++];
      if (!prior || prior.path !== path || prior.value !== node.text || typeof value !== "string") throw Error(`Inventory mismatch: ${path}:${index}`);
      let replacement;
      if (ts.isJsxText(node)) replacement = value;
      else if (ts.isStringLiteral(node)) replacement = ts.isJsxAttribute(node.parent)
        ? '"' + value.replaceAll("&", "&amp;").replaceAll('"', "&quot;") + '"' : JSON.stringify(value);
      else if (ts.isNoSubstitutionTemplateLiteral(node)) replacement = "`" + template(value) + "`";
      else if (node.kind === ts.SyntaxKind.TemplateHead) replacement = "`" + template(value) + "${";
      else if (node.kind === ts.SyntaxKind.TemplateMiddle) replacement = "}" + template(value) + "${";
      else replacement = "}" + template(value) + "`";
      edits.push({ start: ts.isJsxText(node) ? node.pos : node.getStart(ast), end: node.end, replacement });
    }
    ts.forEachChild(node, visit);
  }
  visit(ast);
  if (index !== expectedEnd) throw Error(`Incomplete translation inventory: ${path}`);
  let changed = source;
  for (const edit of edits.sort((a, b) => b.start - a.start)) changed = changed.slice(0, edit.start) + edit.replacement + changed.slice(edit.end);
  const parsed = ts.createSourceFile(path, changed, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  if (parsed.parseDiagnostics.length) throw Error(`Invalid translated syntax: ${path}`);
  fs.writeFileSync(path, changed);
  console.log(JSON.stringify({ path, translatedNodes: edits.length }));
}
