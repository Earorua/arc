import { build } from "esbuild";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { isDeepStrictEqual } from "node:util";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const out = "work/grounded-verification/mainline-final-20261119-repair/id-diagnosis.json";
const bundled = await build({ stdin: { contents: `
  export { agentFixture } from "./tests/helpers/agent-fixture.ts";
  export { buildLearningPaths } from "./app/lib/planning/path-builder.ts";
  export { buildPlanVersion } from "./app/lib/planning/scheduler.ts";
  export { applyPlanningEvent, replayPlanningEvents } from "./app/lib/planning/event-reducer.ts";
  export { planningWorkspaceSchema, planningEventSchema } from "./app/contracts/planning.ts";
  export { fingerprint } from "./app/lib/planning/fingerprint.ts";
`, resolveDir: process.cwd(), loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false });
const bundlePath = "work/grounded-verification/mainline-final-20261119-repair/id-probe.bundle.mjs";
writeFileSync(bundlePath, bundled.outputFiles[0].text, { flag: "wx" });
const api = await import(pathToFileURL(resolve(bundlePath)).href);
const current = api.agentFixture();
const historicalBlueprint = { ...current.sourceContext.blueprint, name: "AI 原生全栈工程师" };
const historicalPath = api.buildLearningPaths({ ...current.request, blueprint: historicalBlueprint, registry: current.sourceContext.registry }).fullScope;
const historicalBuilt = api.buildPlanVersion({ path: historicalPath, registry: current.sourceContext.registry, availability: current.request.availability,
  planningDate: current.request.planningDate, generation: "initial", baseVersionId: null, replanReason: null, completedUnitIds: new Set() });
const historical = { ...current, path: historicalPath, sourceContext: { ...current.sourceContext, blueprint: historicalBlueprint },
  workspace: api.planningWorkspaceSchema.parse({ ...current.workspace, pathVersions: [historicalPath], planVersions: [historicalBuilt.plan], dailyUnits: historicalBuilt.dailyUnits,
    activePathVersionId: historicalPath.id, activePlanVersionId: historicalBuilt.plan.id }) };
function run(f) {
  const event = api.planningEventSchema.parse({ kind: "agent_replanned", baseRevision: 0, unitOrder: f.path.units.map(unit => unit.id),
    planningDate: "2026-10-14", eventId: "agent-event", mutationId: "agent-mutation", sequence: 1,
    targetPlanVersionId: f.workspace.activePlanVersionId, occurredAt: "2026-10-14T01:00:00.000Z" });
  const { blueprint, registry } = f.sourceContext;
  const next = api.applyPlanningEvent({ workspace: f.workspace, event, blueprint, registry });
  const plan = next.workspace.planVersions.find(plan => plan.id === next.workspace.pendingPlanVersionId);
  const path = next.workspace.pathVersions.find(path => path.id === plan.pathVersionId);
  return { sourceName: f.sourceContext.blueprint.name, blueprintFingerprint: api.fingerprint(f.sourceContext.blueprint),
    sourcePathFingerprint: f.path.inputFingerprint, sourcePathId: f.path.id, activePlanId: f.workspace.activePlanVersionId,
    proposedPathFingerprint: path.inputFingerprint, proposedPathId: path.id, proposedPlanFingerprint: plan.inputFingerprint,
    proposedPlanId: plan.id, days: plan.days, units: path.units,
    replayEqual: isDeepStrictEqual(api.replayPlanningEvents({ initial: f.workspace, events: [event], blueprint, registry }), next.workspace) };
}
const currentResult = run(current), historicalResult = run(historical);
const paths = ["app/lib/planning/path-builder.ts", "app/lib/planning/scheduler.ts", "app/lib/planning/event-reducer.ts", "tests/helpers/agent-fixture.ts"];
const unchangedSince = "ef1b26bf886860298b7d292b788f2d221440edc9";
const gitArgs = ["-c", "core.longpaths=true"];
const hashes = paths.map(path => { const prior = execFileSync("git", [...gitArgs, "show", `${unchangedSince}:${path}`]); const now = readFileSync(path);
  return { path, unchanged: prior.equals(now), sha256: createHash("sha256").update(now).digest("hex") }; });
const result = { unchangedSince, hashes, changedInput: "Only blueprint.name; all remaining inputs and production algorithm identical",
  historical: historicalResult, current: currentResult, unitsEqual: isDeepStrictEqual(currentResult.units, historicalResult.units),
  daysEqual: isDeepStrictEqual(currentResult.days, historicalResult.days),
  oldIdReproduced: historicalResult.proposedPlanId === "plan-version-99727a989539f78219f6adb4a83e4fce",
  currentIdReproduced: currentResult.proposedPlanId === "plan-version-354a875eebd378e0774cd87aa9c7533c" };
writeFileSync(out, JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ out, ...result, current: { ...currentResult, units: undefined, days: undefined }, historical: { ...historicalResult, units: undefined, days: undefined } }, null, 2));
process.exitCode = result.oldIdReproduced && result.currentIdReproduced && hashes.every(row => row.unchanged) && result.unitsEqual && result.daysEqual && currentResult.replayEqual && historicalResult.replayEqual ? 0 : 1;
