$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
$workspace = (Get-Location).Path
$work = Join-Path $workspace 'work/grounded-verification'
$out = Join-Path $workspace 'docs/verification/materials-native-acceptance/integration-evidence'
$zipPath = Join-Path $out 'mainline-integration-20261119.zip'
if (Test-Path -LiteralPath $zipPath) { throw 'Never overwrite an archive' }
$files = @((Get-ChildItem -LiteralPath $work -File | Where-Object { $_.Name -like 'mainline-*20261119*' }) + (Get-ChildItem -LiteralPath (Join-Path $work 'mainline-final-20261119-repair') -Recurse -File)) | Sort-Object FullName
[IO.Directory]::CreateDirectory($out) | Out-Null
$stream = [IO.File]::Open($zipPath,[IO.FileMode]::CreateNew)
$zip = [IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
$records = @()
try {
  foreach ($file in $files) {
    $relative = [IO.Path]::GetRelativePath($work,$file.FullName).Replace('\','/')
    if ($relative.StartsWith('../')) { throw 'Archive entry outside intended directory' }
    $entry = $zip.CreateEntry($relative,[IO.Compression.CompressionLevel]::Optimal)
    $entryStream = $entry.Open()
    $bytes = [IO.File]::ReadAllBytes($file.FullName)
    try { $entryStream.Write($bytes,0,$bytes.Length) } finally { $entryStream.Dispose() }
    $records += [ordered]@{ entry=$relative; bytes=$bytes.Length; sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant(); original=[IO.Path]::GetRelativePath($workspace,$file.FullName).Replace('\','/') }
  }
} finally { $zip.Dispose(); $stream.Dispose() }
$readStream = [IO.File]::OpenRead($zipPath)
$readZip = [IO.Compression.ZipArchive]::new($readStream,[IO.Compression.ZipArchiveMode]::Read)
try {
  if ($readZip.Entries.Count -ne $records.Count) { throw 'Entry count mismatch' }
  foreach ($record in $records) {
    $entry = $readZip.GetEntry($record.entry)
    $entryStream = $entry.Open()
    try { $digest=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($entryStream)).ToLowerInvariant() } finally { $entryStream.Dispose() }
    if ($entry.Length -ne $record.bytes -or $digest -ne $record.sha256) { throw 'Archived bytes differ' }
  }
} finally { $readZip.Dispose(); $readStream.Dispose() }
$manifest = [ordered]@{ schemaVersion='materials-integration-lossless-archive-v1'; scope='Original implementation, diagnosis, full-run failures, scoped repairs, final source/coverage and standard-check evidence; no credential or model output.'; archive='mainline-integration-20261119.zip'; sha256=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant(); bytes=(Get-Item -LiteralPath $zipPath).Length; entryCount=$records.Count; entries=$records; verifiedEveryEntry=$true }
[IO.File]::WriteAllText((Join-Path $out 'archive-manifest.json'),($manifest | ConvertTo-Json -Depth 8)+"`n",[Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath (Join-Path $work 'mainline-final-20261119-acceptance.json') -Destination (Join-Path $out 'acceptance.json')
Copy-Item -LiteralPath (Join-Path $work 'mainline-final-20261119-reconciled.json') -Destination (Join-Path $out 'source-and-coverage.json')
[ordered]@{ archive=$manifest.archive; entries=$records.Count; bytes=$manifest.bytes; sha256=$manifest.sha256; verifiedEveryEntry=$true } | ConvertTo-Json
